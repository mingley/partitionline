#!/usr/bin/env python3
"""Verify v16 pins, v2 dry-run and the source-derived model; do not build."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
EXPECTED = {
    'src/producer.rs': '38add9415de68efd3ede5a27ce3c182adea92cbd94cd8c77e07b74774d30f6d1',
    'src/producer/split.rs': '03e893bc8b41182cae2d35f8702cb7821a41fafab6306205d017df4bd5593ad0',
    'src/producer/prepare_tests.rs': 'c6696efaa6edbee311d508a391603d5332d52ed58c7ac6a82d0385add1f35712',
    'src/producer/completion.rs': 'b90efa97f5176f5dcc44fe4ffa86b5a88e03a645c74ad32191047e2eaded779f',
    'src/config.rs': '926852e4680408b314d34ff206593ebfd8858881a93841f274a46c0d1ea27c19',
    'Cargo.lock': 'bdc37c48feb0d7a17a1b08e70c5301ec30b9a90e64c93adaf28aef6b6f9f46bc',
}
CATALOG = '15da704200222b0b3b8de7d74274b9cf1fb3933a9339112c09b3467aa07868ea'
PATCH = 'd539ab29021a6307b8a4070b982920191c7641b2f9f0ee3cfea01098b12e7c99'
MODEL = 'a8314bea43adc9d7d3caa94b7e34a436829ee33448c55d9f8680386eae1c96fb'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def need(condition, message):
    if not condition:
        raise RuntimeError(message)

if len(sys.argv) != 8:
    raise SystemExit('usage: verify.py <producer.rs> <split.rs> <prepare_tests.rs> <completion.rs> <config.rs> <Cargo.lock> <v16-fixed-inputs.json>')
paths = list(map(Path, sys.argv[1:7]))
catalog = Path(sys.argv[7])
need(sha(catalog) == CATALOG, 'v16 catalog mismatch')
need(sha(HERE / 'prototype-v2.patch') == PATCH, 'v2 patch mismatch')
need(sha(HERE / 'retry_group_model.py') == MODEL, 'model mismatch')
entries = json.loads(catalog.read_text())
for (name, digest), path in zip(EXPECTED.items(), paths):
    need(entries.get(name) == digest and sha(path) == digest, f'v16 source mismatch: {name}')
with tempfile.TemporaryDirectory(prefix='deque-v16-dryrun-') as directory:
    work = Path(directory)
    for name, path in zip(EXPECTED, paths):
        target = work / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    subprocess.run(['git', 'apply', '--check', str(HERE / 'prototype-v2.patch')], cwd=work, check=True)
    for (name, digest) in EXPECTED.items():
        need(sha(work / name) == digest, f'dry-run changed source: {name}')
model = json.loads(subprocess.check_output([sys.executable, str(HERE / 'retry_group_model.py')]))
need(model.get('model_only') is True, 'model result not identified')
print('PASS: six v16 source pins, untouched v2 patch dry-run and source-derived counterexample')
print('No Rust source patch was applied; no Cargo, Rust test or benchmark was run.')
