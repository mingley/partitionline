#!/usr/bin/env python3
"""Small source-derived model; it does not execute or validate Rust code."""
from dataclasses import dataclass
import json

U32_MAX = 2**32 - 1

@dataclass(frozen=True)
class Record:
    name: str
    topic: str
    retry: int
    expired: bool = False
    skip_meta_refresh: bool = False

def retire_batch(records):
    """Mirror retry_topic_groups/index_firsts/retry_one for one batch.

    Delays use base=1 and cap=1000 arbitrary units; retry_after uses one
    common abstract timestamp and the source's min(shift,16) cap.
    """
    maxima = {}
    firsts = {}
    for index, record in enumerate(records):
        incremented = min(record.retry + 1, U32_MAX)
        maxima[record.topic] = max(maxima.get(record.topic, 0), incremented)
        firsts.setdefault(record.topic, index)
    result = []
    for index, record in enumerate(records):
        incremented = min(record.retry + 1, U32_MAX)
        if record.expired:
            result.append({'name': record.name, 'terminal': 'Timeout', 'retry': incremented})
            continue
        maximum = maxima[record.topic]
        delay = min(1 << min(max(maximum - 1, 0), 16), 1000)
        result.append({
            'name': record.name,
            'retry': incremented,
            'topic_max': maximum,
            'skip_meta_refresh': record.skip_meta_refresh or index != firsts[record.topic],
            'retry_delay_units': delay,
        })
    return result

def segmented(parts):
    return [item for part in parts for item in retire_batch(part)]

parts = [
    [Record('pending', 't', 0)],
    [Record('scratch', 't', 4)],
    [Record('channel', 't', 2)],
]
combined = retire_batch([record for part in parts for record in part])
separate = segmented(parts)
assert [r['retry'] for r in combined] == [1, 5, 3]
assert [r['topic_max'] for r in combined] == [5, 5, 5]
assert [r['skip_meta_refresh'] for r in combined] == [False, True, True]
assert [r['retry_delay_units'] for r in combined] == [16, 16, 16]
assert [r['topic_max'] for r in separate] == [1, 5, 3]
assert [r['skip_meta_refresh'] for r in separate] == [False, False, False]
assert [r['retry_delay_units'] for r in separate] == [1, 16, 4]

# First-index selection includes expired records. A segmented fallback must
# reproduce this behavior; it cannot infer first-refresh from live records only.
expired_first = retire_batch([Record('expired', 't', 4, True), Record('later', 't', 0)])
assert expired_first[0]['terminal'] == 'Timeout'
assert expired_first[1]['topic_max'] == 5
assert expired_first[1]['skip_meta_refresh'] is True

# Close admission first; a successful receive of C records can coexist with a
# channel refilled to C before admission closes. With zero deque spare space,
# moving scratch and channel into it requires storage for 2*C more elements.
capacity = 4096
scratch_received = capacity
channel_after_refill = capacity
deque_spare = 0
assert scratch_received + channel_after_refill - deque_spare == 2 * capacity
print(json.dumps({
    'model_only': True,
    'combined': combined,
    'separate_batches': separate,
    'expired_first_case': expired_first,
    'capacity_example': {'channel_bound': capacity, 'scratch': scratch_received, 'closed_channel': channel_after_refill, 'deque_spare': deque_spare, 'additional_slots': 2 * capacity},
    'limitations': 'No Tokio scheduling, allocations, physical sockets, callbacks or Rust code were executed.',
}, indent=2))
