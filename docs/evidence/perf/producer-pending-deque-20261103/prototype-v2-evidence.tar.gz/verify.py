#!/usr/bin/env python3
"""Verify v14 preimages, test preservation and patch round-trip without building."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
BASE = {
    'src/producer.rs': 'ecf14e7e89fff1d1c29faa6778061d58545f9df565eb7858561d4de58920b279',
    'src/producer/split.rs': '03e893bc8b41182cae2d35f8702cb7821a41fafab6306205d017df4bd5593ad0',
    'src/producer/prepare_tests.rs': 'c6696efaa6edbee311d508a391603d5332d52ed58c7ac6a82d0385add1f35712',
}
OUTPUT = {
    'src/producer.rs': '1a1a28e7bbf745ac290b79d191919d2051465aadf635130111fae225093a8d6f',
    'src/producer/split.rs': '4e9e251ebe907e6b0ee95886303fead7e777b4941e4e0c8adc817707ce9cd629',
    'src/producer/prepare_tests.rs': 'ffbb20758ed15c2389d9143923eb5968f07d6fcd8eee2ae25747fb3fd56aefca',
    'src/producer/pending_deque_tests.rs': '430df8e804c05e88b0e10eefc9033c6da4df5c98d054a8d664f6bb080c1dc285',
}
CATALOG = '96741778c14d8ea03358b8ece94850cbf7f89f156c4b50bacf818fe4a2530e9a'
PATCH = 'd539ab29021a6307b8a4070b982920191c7641b2f9f0ee3cfea01098b12e7c99'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def need(condition, message):
    if not condition:
        raise RuntimeError(message)

if len(sys.argv) != 3:
    raise SystemExit('usage: verify.py <v14-fixed-source-directory> <v14-fixed-inputs.json>')
base, catalog = map(Path, sys.argv[1:])
patch = HERE / 'prototype.patch'
need(sha(patch) == PATCH, 'prototype patch hash mismatch')
need(sha(catalog) == CATALOG, 'v14 catalog hash mismatch')
inputs = json.loads(catalog.read_text())
for path, digest in BASE.items():
    need(inputs.get(path) == digest and sha(base / path) == digest, f'v14 preimage mismatch: {path}')
need(not (base / 'src/producer/pending_deque_tests.rs').exists(), 'new test file already exists')
with tempfile.TemporaryDirectory(prefix='pending-deque-verify-') as tmp:
    work = Path(tmp)
    for path in BASE:
        out = work / path
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(base / path, out)
    subprocess.run(['git', 'apply', '--check', str(patch)], cwd=work, check=True)
    subprocess.run(['git', 'apply', str(patch)], cwd=work, check=True)
    for path, digest in OUTPUT.items():
        need(sha(work / path) == digest, f'output mismatch: {path}')
    marker = '#[cfg(test)]\nmod tests {'
    old = (base / 'src/producer.rs').read_text()
    new = (work / 'src/producer.rs').read_text()
    old_tail = old[old.index(marker):]
    new_tail = new[new.index(marker):]
    new_tail = new_tail.replace('            pending: VecDeque::new(),\n            receiving: Vec::new(),', '            pending: Vec::new(),')
    new_tail = new_tail.replace('            pending: std::collections::VecDeque::new(),\n            receiving: Vec::new(),', '            pending: Vec::new(),')
    need(old_tail == new_tail, 'old test tail changed beyond documented Worker initializers')
    prep = (work / 'src/producer/prepare_tests.rs').read_text()
    prep = prep.replace('        pending: VecDeque::new(),\n        receiving: Vec::new(),', '        pending: Vec::new(),')
    prep = prep.replace('fixture.worker.pending.front_mut()', 'fixture.worker.pending.first_mut()')
    prep = prep.replace('fixture.worker.pending.back_mut()', 'fixture.worker.pending.last_mut()')
    prep = prep.replace('fixture.worker.pending.front()', 'fixture.worker.pending.first()')
    prep = prep.replace('fixture.worker.pending.push_back(older)', 'fixture.worker.pending.push(older)')
    prep = prep.replace('    let in_flight_phase = fixture\n        .worker\n        .pending\n        .remove(0)\n        .expect("pending first record");', '    let in_flight_phase = fixture.worker.pending.remove(0);')
    prep = prep.replace('let mut pending = VecDeque::with_capacity(31);', 'let mut pending = Vec::with_capacity(31);')
    prep = prep.replace('pending.push_back(record);', 'pending.push(record);')
    prep = prep.replace('pending.as_slices().0.as_ptr()', 'pending.as_ptr()')
    need(prep == (base / 'src/producer/prepare_tests.rs').read_text(), 'prepare tests changed beyond deque syntax')
    subprocess.run(['git', 'apply', '--reverse', '--check', str(patch)], cwd=work, check=True)
    subprocess.run(['git', 'apply', '--reverse', str(patch)], cwd=work, check=True)
    for path, digest in BASE.items():
        need(sha(work / path) == digest, f'reverse mismatch: {path}')
    need(not (work / 'src/producer/pending_deque_tests.rs').exists(), 'new file survived reverse')
print('PASS: exact v14 preimages, output hashes, old test tail normalization and patch round-trip')
print('No Rust compile, tests, benchmark or production qualification performed.')
