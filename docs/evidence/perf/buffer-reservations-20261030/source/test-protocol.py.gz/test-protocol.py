import gzip
import hashlib
import json
from pathlib import Path
import re
import run

events = []
for line in (run.OUT/'protocol-build-retry.log').read_text().splitlines():
    try:
        event = json.loads(line)
    except ValueError:
        continue
    if event.get('reason') == 'compiler-artifact' and event.get('executable') and event.get('profile',{}).get('test'):
        events.append(event)
artifacts = {}
for event in events:
    name = event['target']['name']
    if name not in ('partitionline','codec_malformed_java','codec_matrix','codec_sparse'):
        continue
    if event['fresh']:
        prior = []
        for line in (run.OUT/'protocol-build.log').read_text().splitlines():
            try:
                previous = json.loads(line)
            except ValueError:
                continue
            if previous.get('reason') == 'compiler-artifact' and previous.get('executable') == event['executable']:
                prior.append(previous)
        assert any(not a['fresh'] for a in prior), name
        assert (run.OUT/'protocol-build-inputs-after.json').read_bytes() == (run.OUT/'protocol-build-retry-inputs-before.json').read_bytes()
    binary = Path(event['executable'])
    artifacts[name] = dict(path=str(binary), sha256=run.sha(binary), bytes=binary.stat().st_size,
        cargo_fresh=event['fresh'], fresh_build='protocol-build' if event['fresh'] else 'protocol-build-retry')
assert len(artifacts)==4
(run.OUT/'protocol-artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
for name, artifact in artifacts.items():
    binary = artifact['path']
    filters = ['protocol::'] if name == 'partitionline' else []
    assert run.sha(binary)==artifact['sha256']
    result = run.run(name+'-list', [binary,*filters,'--list'])
    assert result==0
    names = [s.removesuffix(': test') for s in (run.OUT/(name+'-list.log')).read_text().splitlines() if s.endswith(': test')]
    assert names and (name != 'partitionline' or len(names)>100)
    (run.OUT/(name+'-test-names.json')).write_text(json.dumps(names,indent=2)+'\n')
    result = run.run(name+'-tests', [binary,*filters,'--test-threads=1'])
    text = (run.OUT/(name+'-tests.log')).read_text()
    matches = re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)
    assert len(matches)==1 and sum(map(int,matches[0]))==len(names),(name,matches,len(names))
    assert run.sha(binary)==artifact['sha256']
    packed = run.OUT/(name+'-protocol.elf.gz')
    with open(binary,'rb') as source, packed.open('xb') as output:
        with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0) as dest:
            while chunk := source.read(1024*1024):
                dest.write(chunk)
    with gzip.open(packed,'rb') as restored:
        assert hashlib.file_digest(restored,'sha256').hexdigest()==artifact['sha256']
    artifact.update(retained_gzip=packed.name,gzip_sha256=run.sha(packed))
    (run.OUT/'protocol-artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
    print(name, matches, flush=True)
    if result:
        raise SystemExit(result)
