import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path('/workspace/partitionline')
OUT = Path(__file__).resolve().parent
FLOOR = int(os.environ.get('RESERVE_STUDY_DISK_FLOOR_BYTES', str(2 * 1024**3 + 8 * 1024**2)))
ENV = dict(os.environ)
ENV.update(RUSTUP_HOME='/workspace/work/rustup', CARGO_HOME='/workspace/work/cargo',
    PATH='/workspace/work/cargo/bin:' + ENV.get('PATH', ''),
    CARGO_TARGET_DIR='/workspace/work/qualification-20261027/broker-check-target',
    CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
for key in ('RUST_TEST_THREADS', 'RUST_MIN_STACK', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS',
            'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'):
    ENV.pop(key, None)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def inputs():
    paths = set()
    for name in ('src', 'tests', 'examples', '.cargo', 'benchmarks/codec', 'scripts'):
        paths.update(p for p in (ROOT/name).rglob('*') if p.is_file()
                     and 'target' not in p.parts and '__pycache__' not in p.parts
                     and p.suffix != '.pyc')
    for name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'clippy.toml', 'build.rs'):
        if (ROOT/name).is_file():
            paths.add(ROOT/name)
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted(paths)}

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def run(name, argv, timeout=900):
    log = OUT/(name+'.log')
    assert not log.exists(), log
    before = inputs()
    (OUT/(name+'-inputs-before.json')).write_text(json.dumps(before, indent=2)+'\n')
    (OUT/(name+'-source.patch')).write_text(git('diff', 'HEAD', '--binary')+'\n')
    row = dict(name=name, argv=argv, source_base=git('rev-parse','HEAD'),
        git_status_before=git('status','--porcelain=v1','--untracked-files=all'),
        input_scope='src, tests, examples, .cargo, benchmarks/codec, scripts, root Cargo/lock/toolchain/clippy/build files; external dependencies are not exhaustively pinned',
        started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        disk_stop_bytes=FLOOR,
        memory_events_before=Path('/sys/fs/cgroup/memory.events').read_text())
    minimum = shutil.disk_usage(ROOT).free
    if minimum <= FLOOR:
        raise RuntimeError('disk reserve unavailable')
    started = time.monotonic()
    with log.open('xb') as stream:
        proc = subprocess.Popen(argv, cwd=ROOT, env=ENV, stdout=stream,
                                stderr=subprocess.STDOUT, start_new_session=True)
        reason = None
        while proc.poll() is None:
            free = shutil.disk_usage(ROOT).free
            minimum = min(minimum, free)
            if free <= FLOOR or time.monotonic()-started >= timeout:
                reason = 'disk_floor' if free <= FLOOR else 'timeout'
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
                break
            time.sleep(.25)
        result = proc.wait()
    after = inputs()
    (OUT/(name+'-inputs-after.json')).write_text(json.dumps(after, indent=2)+'\n')
    changes = [p for p in sorted(before.keys()|after.keys()) if before.get(p)!=after.get(p)]
    row.update(exit=result, stop_reason=reason, elapsed_seconds=time.monotonic()-started,
        minimum_disk_free_bytes=minimum, log_sha256=sha(log), input_changes=changes,
        inputs_stable=not changes, git_status_after=git('status','--porcelain=v1','--untracked-files=all'),
        ending_head=git('rev-parse','HEAD'),
        memory_events_after=Path('/sys/fs/cgroup/memory.events').read_text())
    (OUT/(name+'.json')).write_text(json.dumps(row, indent=2)+'\n')
    print(json.dumps(row), flush=True)
    return result if not reason and not changes else 125

if __name__ == '__main__':
    sys.exit(run(sys.argv[1], sys.argv[2:]))
