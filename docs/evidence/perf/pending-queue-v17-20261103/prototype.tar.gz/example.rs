//! Private runner for the isolated pending queue microbenchmark.
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = std::env::args().collect();
    if args.len() != 5 {
        return Err("usage: pending_queue_bench SHAPE COUNT CHUNK PROBES".into());
    }
    let count = args[2].parse::<usize>()?;
    let chunk = args[3].parse::<usize>()?;
    let probes = args[4].parse::<usize>()?;
    let runtime = tokio::runtime::Builder::new_current_thread().enable_all().build()?;
    let result = runtime.block_on(partitionline::producer::pending_queue_bench::sample(
        &args[1], count, chunk, probes,
    ))?;
    println!("{result}");
    Ok(())
}
