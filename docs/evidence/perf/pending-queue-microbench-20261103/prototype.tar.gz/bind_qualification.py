#!/usr/bin/env python3
"""Record same-job workflow context and hashes after v14 qualification succeeds.

This is an ordering witness from the illustrative workflow, not a signed
attestation that independently proves the origin of an arbitrary file.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

SPEC_SHA='d51f80f274fe28802c7f9c44bf11008605cea6a297bde209e9a47e24ad21ba3a'

def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def same_job_context(env,qualification,checkout):
    run=env.get('GITHUB_RUN_ID','');attempt=env.get('GITHUB_RUN_ATTEMPT','');sha=env.get('GITHUB_SHA','')
    if env.get('GITHUB_ACTIONS')!='true' or env.get('GITHUB_WORKFLOW')!='candidate qualification' or env.get('GITHUB_JOB')!='qualify':
        raise RuntimeError('requires the candidate qualification workflow job')
    if not re.fullmatch('[1-9][0-9]*',run) or not re.fullmatch('[1-9][0-9]*',attempt) or not re.fullmatch('[0-9a-f]{40}',sha):
        raise RuntimeError('invalid GitHub run, attempt or checkout SHA')
    temp=env.get('RUNNER_TEMP');workspace=env.get('GITHUB_WORKSPACE')
    if not temp or not workspace:raise RuntimeError('missing GitHub workspace or runner temp')
    temp=Path(temp).resolve();workspace=Path(workspace).resolve()
    qual=Path(qualification).resolve();checkout=Path(checkout).resolve()
    if qual!=temp/'candidate-qualification' or checkout!=workspace:
        raise RuntimeError('requires the fixed same-job qualification and workspace paths')
    return {'github_run_id':run,'github_run_attempt':attempt,'github_sha':sha,
            'github_workflow':env['GITHUB_WORKFLOW'],'github_job':env['GITHUB_JOB'],
            'qualification_path':str(qual),'checkout_path':str(checkout),'runner_temp':str(temp)}

def expected_witness(context,contract_sha,summary_sha,driver_sha,binder_sha):
    return {'schema':1,'scope':'same-job workflow ordering witness; not an independent signature',**context,
            'spec_sha256':SPEC_SHA,'contract_sha256':contract_sha,'summary_sha256':summary_sha,
            'driver_sha256':driver_sha,'binder_sha256':binder_sha}

def validate_witness(actual,expected):
    return isinstance(actual,dict) and actual==expected

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--qualification',type=Path,required=True)
    parser.add_argument('--checkout',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();context=same_job_context(os.environ,args.qualification,args.checkout)
    qual=Path(context['qualification_path']);checkout=Path(context['checkout_path']);output=args.output.resolve()
    if output!=Path(context['runner_temp'])/'pending-queue-qualification.json':
        raise RuntimeError('witness must use the fixed same-job path')
    actual=subprocess.run(['git','rev-parse','HEAD'],cwd=checkout,check=True,capture_output=True,text=True,timeout=60).stdout.strip()
    if actual!=context['github_sha']:raise RuntimeError('checkout does not match GitHub SHA')
    spec=checkout/'docs/evidence/client/candidate-20261030/v14/spec.json'
    if digest(spec)!=SPEC_SHA:raise RuntimeError('unexpected v14 specification')
    contract_path=qual/'contract.json';summary_path=qual/'summary.json'
    contract=json.loads(contract_path.read_text());summary=json.loads(summary_path.read_text())
    driver=checkout/'scripts/ci-qualify-client-candidate.py'
    if contract.get('checkout_commit')!=actual or contract.get('spec_sha256')!=SPEC_SHA or contract.get('driver_sha256')!=digest(driver):
        raise RuntimeError('qualification contract does not match checkout and driver')
    if summary.get('passed') is not True or summary.get('baseline_expectations_matched') is not True or \
       summary.get('required_library_controls')!=166 or summary.get('required_integration_controls')!=17 or \
       not summary.get('gates') or not all(g.get('passed') is True for g in summary['gates']):
        raise RuntimeError('the complete v14 qualification has not passed')
    witness=expected_witness(context,digest(contract_path),digest(summary_path),digest(driver),digest(Path(__file__)))
    with output.open('x') as stream:json.dump(witness,stream,indent=2);stream.write('\n')
    return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as error:print(str(error),file=sys.stderr);raise SystemExit(1)
