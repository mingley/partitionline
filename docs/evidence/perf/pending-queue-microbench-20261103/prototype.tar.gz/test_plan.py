#!/usr/bin/env python3
"""Static and source-roundtrip controls; never invokes Cargo or a Rust compiler."""
import gzip
import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('bench_runner',HERE/'run.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)

class PlanTests(unittest.TestCase):
    def test_bounded_and_balanced_pairs(self):
        cases=runner.case_plan()
        self.assertEqual(len(cases),19)
        self.assertEqual(len({tuple(sorted(case.items())) for case in cases}),19)
        for case in cases:
            self.assertGreater(case['count'],0);self.assertLessEqual(case['count'],8192)
            self.assertGreater(case['chunk'],0);self.assertLessEqual(case['chunk'],case['count'])
            self.assertGreater(case['probes'],0);self.assertLessEqual(case['probes'],256)
        orders=runner.pair_orders()
        self.assertEqual(orders,runner.pair_orders())
        self.assertEqual(orders.count(('v10-queue','v14')),5)
        self.assertEqual(orders.count(('v14','v10-queue')),5)
        fixed=json.loads((HERE/'v14-fixed-inputs.json').read_text())
        control=json.loads((HERE/'v10-queue-inputs.json').read_text())
        self.assertEqual(len(fixed),1754);self.assertEqual(len(control),1754)
        self.assertEqual({k for k in fixed if fixed[k]!=control.get(k)},{'src/producer.rs','src/producer/prepare_tests.rs'})
        self.assertEqual(fixed['src/producer.rs'],runner.V14_PRODUCER);self.assertEqual(control['src/producer.rs'],runner.V10_PRODUCER)

    def test_sample_validation_rejects_lost_or_ambiguous_identities(self):
        case=runner.case_plan()[0]
        zero=('missing','duplicate','invalid','out_of_order','ack_wrong','ack_error','ack_closed','ack_pending','remaining','buffer_bytes')
        details=('missing_ids','duplicate_ids','invalid_positions','out_of_order_ids','ack_wrong_ids','ack_error_ids','ack_closed_ids','ack_pending_ids')
        row={**case,'valid':True,'accepted':case['count'],'returned':case['count'],'ack_ok':case['count'],'elapsed_ns':17}
        row.update({name:0 for name in zero});row.update({name:[] for name in details})
        self.assertTrue(runner.validate_sample(row,case))
        for name in zero:
            broken={**row,name:1};self.assertFalse(runner.validate_sample(broken,case),name)
        for name in details:
            broken={**row,name:[0]};self.assertFalse(runner.validate_sample(broken,case),name)
        for broken in ({**row,'elapsed_ns':0},{**row,'valid':False},{**row,'ack_ok':case['count']-1},None,{}):
            self.assertFalse(runner.validate_sample(broken,case))

    def test_same_job_witness_rejects_stale_run_and_attempt(self):
        with tempfile.TemporaryDirectory(prefix='pending-witness-static-',dir=HERE) as temp:
            root=Path(temp);workspace=root/'workspace';workspace.mkdir()
            qualification=root/'candidate-qualification';qualification.mkdir()
            env={'GITHUB_ACTIONS':'true','GITHUB_WORKFLOW':'candidate qualification','GITHUB_JOB':'qualify',
                 'GITHUB_RUN_ID':'1245','GITHUB_RUN_ATTEMPT':'2','GITHUB_SHA':'a'*40,
                 'RUNNER_TEMP':str(root),'GITHUB_WORKSPACE':str(workspace)}
            context=runner.binding.same_job_context(env,qualification,workspace)
            witness=runner.binding.expected_witness(context,'b'*64,'c'*64,'d'*64,'e'*64)
            self.assertTrue(runner.binding.validate_witness(witness,witness.copy()))
            for field,value in [('github_run_id','1244'),('github_run_attempt','1'),('github_job','other'),
                                ('github_sha','f'*40),('contract_sha256','f'*64),('summary_sha256','f'*64),
                                ('binder_sha256','f'*64),('qualification_path','/other')]:
                self.assertFalse(runner.binding.validate_witness({**witness,field:value},witness),field)
            for field,value in [('GITHUB_RUN_ID','0'),('GITHUB_RUN_ATTEMPT','0'),('GITHUB_JOB','other'),
                                ('GITHUB_ACTIONS','false'),('GITHUB_SHA','bad')]:
                with self.assertRaises(RuntimeError,msg=field):
                    runner.binding.same_job_context({**env,field:value},qualification,workspace)
            with self.assertRaises(RuntimeError):
                runner.binding.same_job_context(env,root/'other',workspace)

    def test_exact_patch_roundtrip_and_hook_parity(self):
        names=('PL_BENCH_PRODUCER_PATH','PL_BENCH_PREPARE_TESTS_PATH','PL_BENCH_CARGO_PATH','PL_BENCH_IMPORT_PATH')
        if not all(os.environ.get(name) for name in names):
            self.skipTest('set all four PL_BENCH_* source paths for the source-roundtrip control')
        source,tests,cargo,fix=(Path(os.environ[name]) for name in names)
        self.assertEqual(runner.digest(source),runner.V14_PRODUCER)
        self.assertEqual(runner.digest(tests),runner.V14_TESTS)
        self.assertEqual(runner.digest(fix),runner.IMPORT_SHA)
        self.assertEqual(runner.digest(HERE/'queue-v2.patch.gz'),runner.QUEUE_GZ_SHA)
        with tempfile.TemporaryDirectory(prefix='pending-bench-static-',dir=HERE) as temp:
            root=Path(temp);control=root/'control';candidate=root/'candidate'
            for arm in (control,candidate):
                (arm/'src/producer').mkdir(parents=True);(arm/'examples').mkdir()
                shutil.copy2(source,arm/'src/producer.rs');shutil.copy2(tests,arm/'src/producer/prepare_tests.rs');shutil.copy2(cargo,arm/'Cargo.toml')
            patch=root/'queue.patch';patch.write_bytes(gzip.decompress((HERE/'queue-v2.patch.gz').read_bytes()))
            runner.checked_patch(control,fix,True);runner.checked_patch(control,patch,True)
            self.assertEqual(runner.digest(control/'src/producer.rs'),runner.V10_PRODUCER)
            self.assertEqual(runner.digest(control/'src/producer/prepare_tests.rs'),runner.V10_TESTS)
            runner.checked_patch(control,patch,False);runner.checked_patch(control,fix,False)
            self.assertEqual(runner.digest(control/'src/producer.rs'),runner.V14_PRODUCER)
            self.assertEqual(runner.digest(control/'src/producer/prepare_tests.rs'),runner.V14_TESTS)
            runner.checked_patch(control,fix,True);runner.checked_patch(control,patch,True)
            a=runner.inject(control);b=runner.inject(candidate)
            self.assertEqual(a['modified_cargo_sha256'],b['modified_cargo_sha256'])
            extra=('        pending_deadlines_ordered: true,\n'
                   '        pending_stats_valid: true,\n'
                   '        #[cfg(test)]\n'
                   '        pending_work: Arc::new(PendingWork::default()),\n')
            self.assertEqual(b['constructor'].replace(extra,'',1),a['constructor'])
            for adapter in (a,b):
                self.assertIn('WorkerLease::register(&shared)',adapter['constructor'])
                self.assertNotIn('WorkerLease::register(shared)',adapter['constructor'])
            common=(HERE/'pending_queue_bench.rs.in').read_text()
            for name,arm,adapter in (('v10-queue',control,a),('v14',candidate,b)):
                frozen=json.loads((HERE/(name+'-hook-inputs.json')).read_text())
                self.assertEqual(len(frozen),1756)
                for path in ('src/producer.rs','src/producer/prepare_tests.rs','Cargo.toml','src/producer/pending_queue_bench.rs','examples/pending_queue_bench.rs'):
                    self.assertEqual(frozen[path],runner.digest(arm/path),path)
                self.assertEqual((HERE/(name+'-worker-initializer.rs.txt')).read_text(),adapter['constructor'])
                generated=(arm/'src/producer/pending_queue_bench.rs').read_text()
                self.assertEqual(generated.replace(adapter['constructor'],'__WORKER_INITIALIZER__',1),common)
                self.assertIn('#[cfg(any(test, feature = "pending-queue-bench"))]\nfn test_shared(', (arm/'src/producer.rs').read_text())
            self.assertEqual((control/'examples/pending_queue_bench.rs').read_bytes(),(candidate/'examples/pending_queue_bench.rs').read_bytes())

if __name__=='__main__':unittest.main()
