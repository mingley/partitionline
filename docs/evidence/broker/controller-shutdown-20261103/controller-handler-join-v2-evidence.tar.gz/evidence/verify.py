#!/usr/bin/env python3
"""Source-only join-candidate verification; no Cargo or native execution."""
from pathlib import Path
import hashlib
import subprocess

root = Path('/workspace/work/controller-handler-join-v2-20261103')
repo = Path('/workspace/partitionline')
tokio = Path('/workspace/work/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tokio-1.53.3/src/runtime/task')
checks = {
    root/'base/partitionline-broker/src/raft/protocol.rs': '47ae96c84080813e4b81cfbfcdbe8bd45e48389c13c8562c0963dfc743137127',
    root/'candidate/partitionline-broker/src/raft/protocol.rs': '86c8971a500208bb93ff015d9d3dd056efd8a34d7204b7de1f0d27c59a4499c3',
    root/'baseline-test/partitionline-broker/src/raft/protocol.rs': 'd8930b26edd533ac4534570eeb41a7cc9a3b129435c3d7b2502b69d50853a8b0',
    root/'evidence/controller-join.patch': '879595b42050f6ba7a5995d341263e6a163e64ca2e35420fd10cf0eb910beaef',
    root/'evidence/baseline-controls.patch': '4865489843dae983459bfd182a286fe935d6f76212277589fafb080154d62a81',
    repo/'partitionline-broker/Cargo.toml': '88c9f2efaec47615dba40c4d1feb5e481b38bd51796e76ca6fc87cf064495bf5',
    repo/'partitionline-broker/Cargo.lock': '42eaddf993ab4dfbe99e5af9d7c1a7cd858776a214eedbd6112de6a146933a2c',
    repo/'partitionline-broker/tests/raft_protocol.rs': '2212994acdd0cb6b9115e0f6a6c4f5426b2978bbb988a5d827a4b263476ab515',
    tokio/'core.rs': '7c896dec6ef10054ed2b8049a2b35667eae348615c162a46d1ceb9181fc71b5c',
    tokio/'harness.rs': '008c697f432197c6537472e2cea55fa973aec45df946b85abfbea966f2db8d51',
    tokio/'join.rs': 'e1c5c5730743d901ce375f0c46eb3050a9d69b5c28ebe275fb2a585a3e22debb',
    tokio/'error.rs': '0c84e9189f351c6e1eb0c5865b9df84a928ed4602b06fd5c2e71fb7c43eb1e27',
}
for file, digest in checks.items():
    assert hashlib.sha256(file.read_bytes()).hexdigest() == digest, file
for target, patch, reverse in [
    ('base', 'controller-join.patch', False),
    ('candidate', 'controller-join.patch', True),
    ('base', 'baseline-controls.patch', False),
    ('baseline-test', 'baseline-controls.patch', True),
]:
    command = ['git', '-C', str(root/target), 'apply']
    if reverse:
        command += ['--reverse']
    command += ['--check', str(root/'evidence'/patch)]
    subprocess.run(command, check=True)
base = (root/'base/partitionline-broker/src/raft/protocol.rs').read_text()
fixed = (root/'candidate/partitionline-broker/src/raft/protocol.rs').read_text()
baseline = (root/'baseline-test/partitionline-broker/src/raft/protocol.rs').read_text()
assert baseline.startswith(base)
marker = '\n#[cfg(test)]\nmod controller_join_tests {\n'
assert fixed.count(marker) == baseline.count(marker) == 1
fmod = fixed.split(marker, 1)[1]
bmod = baseline.split(marker, 1)[1]
for a, b in [
    ('use super::{Command, Config, ControllerHandler, ControllerJoin, Error};',
     'use super::{Command, Config, ControllerHandler, Error};'),
    ('join: Mutex::new(ControllerJoin::Running(join)),', 'join: Mutex::new(Some(join)),'),
    ('matches!(&*join, ControllerJoin::Running(task) if !task.is_finished())',
     'matches!(&*join, Some(task) if !task.is_finished())'),
]:
    assert fmod.count(a) == 1
    fmod = fmod.replace(a, b)
assert fmod == bmod
for name in (
    'panicking_payload_drops_outside_join_lock_after_failure_is_recorded',
    'panicked_actor_is_reported_by_every_later_shutdown',
    'concurrent_shutdowns_share_the_actor_failure',
    'cancelled_shutdown_retains_a_successful_actor_until_join',
    'cancelled_shutdown_retains_a_failing_actor_until_join',
):
    assert fmod.count('async fn ' + name + '(') == 1
rustfmt = '/workspace/work/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt'
for target in ('candidate', 'baseline-test'):
    subprocess.run([rustfmt, '--edition', '2021', '--check',
                    str(root/target/'partitionline-broker/src/raft/protocol.rs')], check=True)
print('Pinned sources, patches, adapted baseline controls and source formatting verified.')
print('No compilation, Rust tests, controller/WAL execution, network or benchmark.')
