//! Owned autonomous replication over explicitly configured trusted numeric peers.
//!
//! Private framing does not authenticate a network, discover directories, or
//! advertise native Kafka KRaft APIs. The durable Node keeps its known-leader
//! configuration gate. Configured accounting covers admitted envelopes;
//! caller-owned unpolled or admission-waiting futures and their inputs, OS
//! socket buffers, allocator overhead and total process RSS are outside it.

use super::{
    election::{LogPosition, Role, Timeouts},
    membership::{Bootstrap, FeatureRequest, Key, Voter, MAX_CONFIGURATION_BYTES},
    peer_codec::{self, Frame, Group, Hello, Message},
    protocol,
    replication::{self, ChangeReceipt, DynamicSnapshotRequest, Node, Record, State},
    snapshot,
};
use bytes::BufMut;
#[cfg(test)]
use std::path::Path;
use std::{
    fmt,
    io::{self, IoSlice},
    net::{IpAddr, SocketAddr},
    path::PathBuf,
    sync::{
        atomic::{AtomicBool, AtomicUsize, Ordering},
        Arc,
    },
    time::Duration,
};
use tokio::{
    io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt},
    net::{TcpListener, TcpStream},
    sync::{mpsc, oneshot, watch, Notify, OwnedSemaphorePermit, Semaphore},
    task::{JoinHandle, JoinSet},
    time::{Instant, MissedTickBehavior},
};

const MANAGED_CEILING: usize = 512 * 1024 * 1024;

#[cfg(not(test))]
type AdmissionPermit = OwnedSemaphorePermit;
#[cfg(test)]
type AdmissionPermit = TestPermit;

#[cfg(test)]
#[derive(Default)]
struct TestGauge {
    current: AtomicUsize,
    peak: AtomicUsize,
}
#[cfg(test)]
#[derive(Default)]
struct TestMetrics {
    // Constructed RAII owners: client, charged bytes, network task, socket,
    // pending/executing command envelope. This is not allocator or RSS usage.
    gauges: [TestGauge; 5],
    workers_spawned: AtomicUsize,
    workers_joined: AtomicUsize,
    clock: std::sync::OnceLock<std::time::Instant>,
}
#[cfg(test)]
impl TestMetrics {
    fn json(&self) -> Result<String> {
        use std::fmt::Write;
        let mut out = String::new();
        out.try_reserve_exact(1024).map_err(|_| Error::Allocation)?;
        out.push_str("{\"names\":[\"client_admission_owners\",\"charged_transport_owner_bytes\",\"network_task_owners\",\"socket_owners\",\"command_envelope_owners\"],\"gauges\":[");
        for (index, g) in self.gauges.iter().enumerate() {
            if index > 0 {
                out.push(',');
            }
            // A constructor may be preempted between its current increment
            // and peak publication. This observed current value is itself a
            // genuine high-water observation; publish it before emitting both.
            let current = g.current.load(Ordering::Acquire);
            let peak = g.peak.fetch_max(current, Ordering::AcqRel).max(current);
            write!(out, "{{\"current\":{},\"peak\":{}}}", current, peak)
                .map_err(|_| Error::Peer)?;
        }
        out.push_str("]}");
        Ok(out)
    }
}
#[cfg(test)]
struct TestCounter {
    metrics: Arc<TestMetrics>,
    gauge: usize,
    amount: usize,
}
#[cfg(test)]
impl TestCounter {
    fn new(metrics: Arc<TestMetrics>, gauge: usize, amount: usize) -> Self {
        let value = metrics.gauges[gauge]
            .current
            .fetch_add(amount, Ordering::AcqRel)
            + amount;
        metrics.gauges[gauge]
            .peak
            .fetch_max(value, Ordering::AcqRel);
        Self {
            metrics,
            gauge,
            amount,
        }
    }
}
#[cfg(test)]
impl Drop for TestCounter {
    fn drop(&mut self) {
        self.metrics.gauges[self.gauge]
            .current
            .fetch_sub(self.amount, Ordering::AcqRel);
    }
}
#[cfg(test)]
struct TestPermit {
    // Rust drops fields in declaration order. Publish the logical decrement
    // before returning semaphore capacity to the next constructed owner.
    _counter: TestCounter,
    _permit: OwnedSemaphorePermit,
}
#[cfg(test)]
impl TestPermit {
    fn new(
        permit: OwnedSemaphorePermit,
        metrics: Arc<TestMetrics>,
        gauge: usize,
        amount: usize,
    ) -> Self {
        Self {
            _counter: TestCounter::new(metrics, gauge, amount),
            _permit: permit,
        }
    }
}
type Result<T> = std::result::Result<T, Error>;

fn command_payload_limit(
    controller: &protocol::Config,
    storage: StorageLimits,
    limits: Limits,
) -> usize {
    limits
        .frame_bytes
        .max(storage.fetch_bytes)
        .max(controller.protocol_limits.max_request_bytes())
}

fn bounded_proposal(
    bytes: Vec<u8>,
    record_limit: usize,
    allocation_limit: usize,
) -> Result<Vec<u8>> {
    if bytes.is_empty() || bytes.len() > record_limit || bytes.capacity() > allocation_limit {
        return Err(Error::InvalidConfig);
    }
    Ok(bytes)
}

/// Explicit bounded runtime failure; a timeout after admission can be ambiguous.
#[derive(Debug)]
pub enum Error {
    /// Configuration or a checked resource envelope is invalid.
    InvalidConfig,
    /// Runtime admissions have stopped.
    Closed,
    /// An absolute deadline expired; already started storage can still finish.
    Deadline,
    /// Recovery failed; shutdown retains the owner for joined cleanup.
    Startup,
    /// Private bytes or identities do not match their configured session.
    Peer,
    /// The requested position is currently absent or has another term.
    PositionMismatch,
    /// A bounded allocation failed.
    Allocation,
    /// Socket or local filesystem failure.
    Io(io::Error),
    /// Durable Node rejection or ambiguous storage failure.
    Node(replication::Error),
    /// An owned task panicked or was otherwise interrupted.
    Join(tokio::task::JoinError),
}
impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "private peer runtime: {self:?}")
    }
}
impl std::error::Error for Error {}
impl From<io::Error> for Error {
    fn from(e: io::Error) -> Self {
        Self::Io(e)
    }
}
impl From<replication::Error> for Error {
    fn from(e: replication::Error) -> Self {
        Self::Node(e)
    }
}
impl From<peer_codec::Error> for Error {
    fn from(_: peer_codec::Error) -> Self {
        Self::Peer
    }
}

/// One immutable numeric route and the exact expected replica descriptor.
#[derive(Debug, Clone)]
pub struct Peer {
    voter: Voter,
    address: SocketAddr,
}
impl Peer {
    /// Configure a full directory-qualified peer; port zero cannot be dialed.
    pub fn new(voter: Voter, address: SocketAddr) -> Result<Self> {
        if address.port() == 0 || address.ip().is_unspecified() {
            return Err(Error::InvalidConfig);
        }
        Ok(Self { voter, address })
    }
    /// Exact configured peer identity.
    pub fn key(&self) -> Key {
        self.voter.key()
    }
    /// Configured numeric endpoint; no DNS worker is created.
    pub fn address(&self) -> SocketAddr {
        self.address
    }
}
/// Trusted bounded storage paths, never derived from wire fields.
#[derive(Debug, Clone)]
pub struct Paths {
    wal: PathBuf,
    election: PathBuf,
    images: PathBuf,
}
impl Paths {
    /// Configure distinct paths, each at most4096 encoded bytes.
    pub fn new(wal: PathBuf, election: PathBuf, images: PathBuf) -> Result<Self> {
        if [&wal, &election, &images]
            .iter()
            .any(|p| p.as_os_str().is_empty() || p.as_os_str().as_encoded_bytes().len() > 4096)
            || wal == election
            || wal == images
            || election == images
        {
            return Err(Error::InvalidConfig);
        }
        Ok(Self {
            wal,
            election,
            images,
        })
    }
}
/// Exact storage numbers used for both Node construction and runtime accounting.
#[derive(Debug, Clone, Copy)]
pub struct StorageLimits {
    /// Maximum payload of one opaque or Voters record.
    pub record_bytes: usize,
    /// Bounded Node append/WAL chunk.
    pub chunk_bytes: usize,
    /// Maximum retained live positions.
    pub live_entries: usize,
    /// Maximum retained opaque payload bytes.
    pub live_bytes: usize,
    /// Maximum durable operations.
    pub operations: usize,
    /// Maximum content WAL bytes.
    pub wal_bytes: u64,
    /// Maximum committed fetch output.
    pub fetch_bytes: usize,
    /// Existing bounded image decode/disk/generation/chunk limits.
    pub images: snapshot::Limits,
}
impl StorageLimits {
    /// Recommended finite runtime profile. Image chunks are2MiB so their
    /// private envelope fits Limits::default(); the image/live byte ceilings
    /// retain the existing core defaults. Constructor errors propagate.
    pub fn standard() -> Result<Self> {
        Ok(Self {
            record_bytes: 1024 * 1024,
            chunk_bytes: 2 * 1024 * 1024,
            live_entries: 4096,
            live_bytes: 64 * 1024 * 1024,
            operations: 65536,
            wal_bytes: 256 * 1024 * 1024,
            fetch_bytes: 2 * 1024 * 1024,
            images: snapshot::Limits::new(
                65 * 1024 * 1024,
                4096,
                64 * 1024 * 1024,
                1024 * 1024,
                2 * 1024 * 1024,
                8,
                32,
            )
            .map_err(|_| Error::InvalidConfig)?,
        })
    }
    fn node(self) -> Result<replication::Limits> {
        Ok(replication::Limits::new(
            self.record_bytes,
            self.chunk_bytes,
            self.live_entries,
            self.live_bytes,
            self.operations,
            self.wal_bytes,
            self.fetch_bytes,
        )?)
    }
}
/// Finite tasks, messages, command admissions and exact monotonic timer settings.
#[derive(Debug, Clone, Copy)]
pub struct Limits {
    /// Active incoming sessions, including incomplete Hello admissions; zero derives max(peers,1).
    pub incoming: usize,
    /// Public queued/in-flight/completed-unconsumed command slots.
    pub client_slots: usize,
    /// Maximum private payload, excluding TCP length prefix.
    pub frame_bytes: usize,
    /// Election minimum milliseconds, assigned directly to the durable owner.
    pub election_min_ms: u64,
    /// Election maximum milliseconds, assigned directly to the durable owner.
    pub election_max_ms: u64,
    /// Current-term quorum interval and Node transfer lifetime.
    pub quorum_ms: u64,
    /// Coalesced autonomous timer interval.
    pub tick_ms: u64,
    /// Per-peer heartbeat/retry interval.
    pub heartbeat_ms: u64,
    /// Absolute TCP connect budget, bounded by an RPC deadline.
    pub connect_ms: u64,
    /// Whole private RPC/Hello read/write budget.
    pub rpc_ms: u64,
    /// Whole image stream budget; progress never renews it.
    pub transfer_ms: u64,
    /// Public admission and response deadline.
    pub command_ms: u64,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            incoming: 0,
            client_slots: 8,
            frame_bytes: 2 * 1024 * 1024 + 4096,
            election_min_ms: 1000,
            election_max_ms: 2000,
            quorum_ms: 3000,
            tick_ms: 20,
            heartbeat_ms: 100,
            connect_ms: 500,
            rpc_ms: 1000,
            transfer_ms: 2000,
            command_ms: 5000,
        }
    }
}
/// Immutable fixed routes combined with existing durable dynamic-directory semantics.
#[derive(Debug, Clone)]
pub struct Config {
    controller: protocol::Config,
    bootstrap: Bootstrap,
    peers: Vec<Peer>,
    storage: StorageLimits,
    limits: Limits,
    group: Group,
    charge: usize,
    pool: usize,
    managed: usize,
}
impl Config {
    /// Validate exact genesis/routes and all positive byte/task/deadline ceilings.
    pub fn new(
        mut controller: protocol::Config,
        bootstrap: Bootstrap,
        peers: Vec<Peer>,
        storage: StorageLimits,
        mut limits: Limits,
    ) -> Result<Self> {
        let p = peers.len();
        let local = bootstrap.local().key();
        if limits.incoming == 0 {
            limits.incoming = p.max(1);
        }
        if p > 64
            || controller.local_id != local.id
            || !(1..=65).contains(&limits.incoming)
            || !(1..=64).contains(&limits.client_slots)
            || !(1024..=4 * 1024 * 1024).contains(&limits.frame_bytes)
            || limits.incoming > p + 1
            || storage
                .chunk_bytes
                .checked_add(256)
                .is_none_or(|n| n > limits.frame_bytes)
            || storage.images.chunk_bytes() > limits.frame_bytes - 256
            || peers
                .iter()
                .enumerate()
                .any(|(i, v)| v.key() == local || peers[..i].iter().any(|a| a.key() == v.key()))
        {
            return Err(Error::InvalidConfig);
        }
        for v in bootstrap.genesis().voters() {
            if v.key() != local && !peers.iter().any(|p| &p.voter == v) {
                return Err(Error::InvalidConfig);
            }
        }
        let local_endpoint = bootstrap
            .local()
            .endpoint(bootstrap.listener())
            .ok_or(Error::InvalidConfig)?;
        let local_ip = local_endpoint
            .host()
            .parse::<IpAddr>()
            .map_err(|_| Error::InvalidConfig)?;
        if local_ip.is_unspecified() {
            return Err(Error::InvalidConfig);
        }
        for peer in &peers {
            let ep = peer
                .voter
                .endpoint(bootstrap.listener())
                .ok_or(Error::InvalidConfig)?;
            let ip = ep
                .host()
                .parse::<IpAddr>()
                .map_err(|_| Error::InvalidConfig)?;
            if SocketAddr::new(ip, ep.port()) != peer.address {
                return Err(Error::InvalidConfig);
            }
        }
        for n in [
            limits.quorum_ms,
            limits.tick_ms,
            limits.heartbeat_ms,
            limits.connect_ms,
            limits.rpc_ms,
            limits.transfer_ms,
            limits.command_ms,
        ] {
            if !(1..=600000).contains(&n) {
                return Err(Error::InvalidConfig);
            }
        }
        if limits.tick_ms > limits.heartbeat_ms
            || limits
                .heartbeat_ms
                .checked_mul(3)
                .ok_or(Error::InvalidConfig)?
                > limits.quorum_ms
            || limits.connect_ms > limits.rpc_ms
            || limits.rpc_ms > limits.quorum_ms
            || limits.transfer_ms > limits.quorum_ms
        {
            return Err(Error::InvalidConfig);
        }
        controller.election_timeouts =
            Timeouts::new(limits.election_min_ms, limits.election_max_ms)
                .map_err(|_| Error::InvalidConfig)?;
        controller.validate().map_err(|_| Error::InvalidConfig)?;
        storage.node()?;
        if storage.images.records() > storage.live_entries
            || storage.images.payload_bytes()
                > u64::try_from(storage.live_bytes).map_err(|_| Error::InvalidConfig)?
            || storage.images.record_bytes() > storage.record_bytes
        {
            return Err(Error::InvalidConfig);
        }
        let genesis = bootstrap
            .genesis()
            .encode()
            .map_err(|_| Error::InvalidConfig)?;
        if genesis
            .len()
            .checked_add(600)
            .is_none_or(|n| n > limits.frame_bytes)
        {
            return Err(Error::InvalidConfig);
        }
        let table = storage
            .live_entries
            .checked_mul(std::mem::size_of::<Record>())
            .ok_or(Error::InvalidConfig)?;
        let charge = checked_sum(&[
            product(limits.frame_bytes, 3)?,
            table,
            std::mem::size_of::<Message>(),
        ])?;
        let network_slots = checked_sum(&[p, limits.incoming])?;
        let pool = product(network_slots, charge)?;
        let command_envelope = checked_sum(&[
            command_payload_limit(&controller, storage, limits),
            table,
            std::mem::size_of::<Command>(),
            std::mem::size_of::<Reply>(),
        ])?;
        let command_slots = checked_sum(&[product(limits.client_slots, 2)?, 1])?;
        let owner_slots = checked_sum(&[p, limits.incoming, limits.client_slots, 1])?;
        let managed = checked_sum(&[
            product(checked_sum(&[storage.live_bytes, table])?, 2)?,
            usize::try_from(storage.images.decoded_bytes()).map_err(|_| Error::InvalidConfig)?,
            32 * 1024 * 1024,
            product(MAX_CONFIGURATION_BYTES, 16)?,
            pool,
            product(command_slots, command_envelope)?,
            product(owner_slots, 4096)?,
        ])?;
        if managed > MANAGED_CEILING || pool > u32::MAX as usize {
            return Err(Error::InvalidConfig);
        }
        let group = Group {
            cluster: controller.cluster_id.clone(),
            topic: controller.topic.clone(),
            partition: u32::try_from(controller.partition).map_err(|_| Error::InvalidConfig)?,
            genesis,
        };
        Ok(Self {
            controller,
            bootstrap,
            peers,
            storage,
            limits,
            group,
            charge,
            pool,
            managed,
        })
    }
    /// Configured estimate for Node state and admitted command/transport buffers.
    /// Caller-owned unpolled or admission-waiting futures and their inputs,
    /// allocator overhead, process RSS and OS buffers are outside this estimate.
    pub fn managed_bytes(&self) -> usize {
        self.managed
    }
    /// Maximum supervisor/storage/network tasks owned by this runtime.
    pub fn task_bound(&self) -> usize {
        2 + self.peers.len() + self.limits.incoming
    }
}
fn checked_sum(values: &[usize]) -> Result<usize> {
    values
        .iter()
        .try_fold(0usize, |a, v| a.checked_add(*v).ok_or(Error::InvalidConfig))
}
fn product(left: usize, right: usize) -> Result<usize> {
    left.checked_mul(right).ok_or(Error::InvalidConfig)
}

/// Current ownership diagnostics, not a read lease or durability certificate.
#[derive(Debug, Clone, Copy)]
pub struct Diagnostics {
    /// Active network workers/sessions.
    pub network_tasks: usize,
    /// Currently owned connected/dialing sockets; listener adds one while running.
    pub sockets: usize,
    /// Charged live transport bytes.
    pub transport_bytes: usize,
    /// Current public admission slots.
    pub client_slots: usize,
    /// True after stop was requested.
    pub stopping: bool,
}
struct Control {
    stopped: AtomicBool,
    notify: Notify,
    commands: mpsc::Sender<Envelope>,
    clients: Arc<Semaphore>,
    bytes: Arc<Semaphore>,
    startup: watch::Receiver<u8>,
    tasks: AtomicUsize,
    sockets: AtomicUsize,
    #[cfg(test)]
    metrics: Arc<TestMetrics>,
    #[cfg(test)]
    capture_root: Option<PathBuf>,
    config: Arc<Config>,
}
impl Control {
    fn stop(&self) {
        self.stopped.store(true, Ordering::Release);
        self.clients.close();
        self.notify.notify_waiters();
    }
    async fn stopping(&self) {
        loop {
            let notified = self.notify.notified();
            if self.stopped.load(Ordering::Acquire) {
                return;
            }
            notified.await;
        }
    }
    async fn call(
        &self,
        command: Command,
        permit: Option<AdmissionPermit>,
        transport: Option<Arc<AdmissionPermit>>,
        deadline: Instant,
    ) -> Result<Reply> {
        if Instant::now() >= deadline {
            return Err(Error::Deadline);
        }
        let (tx, rx) = oneshot::channel();
        let started = Arc::new(AtomicBool::new(false));
        let envelope = Envelope {
            command,
            reply: tx,
            permit,
            transport,
            started,
            deadline: Some(deadline),
            #[cfg(test)]
            delivery_gate: None,
            #[cfg(test)]
            _counter: Some(TestCounter::new(self.metrics.clone(), 4, 1)),
        };
        tokio::time::timeout_at(deadline, self.commands.send(envelope))
            .await
            .map_err(|_| Error::Deadline)?
            .map_err(|_| Error::Closed)?;
        let delivered = tokio::time::timeout_at(deadline, rx)
            .await
            .map_err(|_| Error::Deadline)?
            .map_err(|_| Error::Closed)?;
        if Instant::now() >= deadline {
            return Err(Error::Deadline);
        }
        delivered.result
    }
    async fn internal(&self, command: Command) -> Result<Reply> {
        // A network worker keeps at most one such call; the owner channel includes
        // one reserved position per worker and a separate timer/stop position.
        self.call(
            command,
            None,
            None,
            Instant::now() + Duration::from_millis(self.config.limits.command_ms),
        )
        .await
    }
    // Cleanup and Stop have bounded admission memory, but deliberately no
    // response timeout. The supervisor retains and awaits every such future;
    // a delayed blocking storage operation must finish before joined shutdown.
    // Failure is channel/owner loss, never silently skipped expired admission.
    async fn reliable(&self, command: Command) -> Result<Reply> {
        let (tx, rx) = oneshot::channel();
        let envelope = Envelope {
            command,
            reply: tx,
            permit: None,
            transport: None,
            started: Arc::new(AtomicBool::new(false)),
            deadline: None,
            #[cfg(test)]
            delivery_gate: None,
            #[cfg(test)]
            _counter: Some(TestCounter::new(self.metrics.clone(), 4, 1)),
        };
        self.commands
            .send(envelope)
            .await
            .map_err(|_| Error::Closed)?;
        rx.await.map_err(|_| Error::Closed)?.result
    }
    async fn cancel_job(&self, job: Job) -> Result<Reply> {
        self.reliable(job.cancellation()).await
    }
    async fn reserve_frame(&self, deadline: Instant) -> Result<Arc<AdmissionPermit>> {
        tokio::time::timeout_at(
            deadline,
            self.bytes
                .clone()
                .acquire_many_owned(self.config.charge as u32),
        )
        .await
        .map_err(|_| Error::Deadline)?
        .map_err(|_| Error::Closed)
        .map(|permit| {
            #[cfg(test)]
            let permit = TestPermit::new(permit, self.metrics.clone(), 1, self.config.charge);
            Arc::new(permit)
        })
    }
    #[cfg(test)]
    fn lifecycle(
        &self,
        stage: &str,
        spawned: usize,
        joined: usize,
        owner_joined: bool,
        supervisor_joined: bool,
        listener_closed: bool,
    ) -> Result<()> {
        use std::io::Write;
        let Some(root) = &self.capture_root else {
            return Ok(());
        };
        if !matches!(stage, "workers-owner-joined" | "supervisor-joined") {
            return Err(Error::InvalidConfig);
        }
        let now_ms = u64::try_from(
            self.metrics
                .clock
                .get()
                .ok_or(Error::InvalidConfig)?
                .elapsed()
                .as_millis(),
        )
        .map_err(|_| Error::InvalidConfig)?;
        let capacity = checked_sum(&[
            self.config.limits.client_slots,
            self.config.peers.len(),
            self.config.limits.incoming,
            1,
        ])?;
        let bounds = [
            self.config.limits.client_slots,
            self.config.pool,
            checked_sum(&[self.config.peers.len(), self.config.limits.incoming])?,
            checked_sum(&[self.config.peers.len(), self.config.limits.incoming])?,
            checked_sum(&[product(capacity, 2)?, 1])?,
        ];
        for (gauge, bound) in self.metrics.gauges.iter().zip(bounds) {
            if gauge.current.load(Ordering::Acquire) != 0
                || gauge.peak.load(Ordering::Acquire) > bound
            {
                return Err(Error::InvalidConfig);
            }
        }
        if spawned != joined {
            return Err(Error::InvalidConfig);
        }
        std::fs::create_dir_all(root)?;
        let mut file = std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(root.join(format!("lifecycle-{stage}.json")))?;
        let text = format!("{{\"schema_version\":1,\"capture_revision\":2,\"pid\":{},\"stage\":\"{stage}\",\"now_ms\":{now_ms},\"clock_basis\":\"same exclusive owner process-local monotonic epoch\",\"source_sha\":\"{}\",\"local_id\":{},\"directory\":\"{}\",\"network_workers_spawned\":{spawned},\"network_workers_joined\":{joined},\"owner_joined\":{owner_joined},\"supervisor_joined\":{supervisor_joined},\"listener_closed\":{listener_closed},\"resource_owners\":{},\"stopping\":{},\"available_client_permits\":{},\"available_transport_permits\":{}}}\n", std::process::id(), std::env::var("PL_PEER_RUNTIME_SOURCE_SHA").map_err(|_| Error::InvalidConfig)?, self.config.bootstrap.local().key().id, TestTrace::hex(&self.config.bootstrap.local().key().directory)?, self.metrics.json()?, self.stopped.load(Ordering::Acquire), self.clients.available_permits(), self.bytes.available_permits());
        if text.len() > 8192 {
            return Err(Error::InvalidConfig);
        }
        file.write_all(text.as_bytes())?;
        file.sync_all()?;
        std::fs::File::open(root)?.sync_all()?;
        Ok(())
    }
}
struct Envelope {
    command: Command,
    reply: oneshot::Sender<Delivered>,
    permit: Option<AdmissionPermit>,
    transport: Option<Arc<AdmissionPermit>>,
    started: Arc<AtomicBool>,
    deadline: Option<Instant>,
    #[cfg(test)]
    delivery_gate: Option<DeliveryGate>,
    #[cfg(test)]
    _counter: Option<TestCounter>,
}
#[cfg(test)]
struct DeliveryGate {
    ready: oneshot::Sender<(Vec<replication::DynamicVoteRequest>, State)>,
    release: std::sync::mpsc::Receiver<()>,
}
struct Delivered {
    result: Result<Reply>,
    _permit: Option<AdmissionPermit>,
    _transport: Option<Arc<AdmissionPermit>>,
}
enum Command {
    Tick,
    State,
    Voters,
    Propose(Vec<u8>),
    Position(LogPosition),
    Fetch(u64, usize, usize),
    Checkpoint([u8; 16]),
    Prepare(Key),
    Inbound(Key, Message),
    Acknowledge(Message),
    Timeout(Key, u64, bool),
    CancelVote(replication::DynamicVoteRequest),
    Chunk(DynamicSnapshotRequest),
    Add(Key),
    Addition(Key),
    Remove(Key),
    Change,
    Disconnected(Key),
    Stop,
}
enum Reply {
    Done,
    State(State),
    Voters(super::membership::Voters),
    Position(LogPosition),
    Visible(bool),
    Records(Vec<Record>),
    Descriptor(snapshot::Descriptor),
    Job(Option<Job>),
    Message(Message),
    Votes(Vec<Job>),
    Change(ChangeReceipt),
    Addition(Option<ChangeReceipt>),
}
#[derive(Debug)]
enum Job {
    Vote(replication::DynamicVoteRequest),
    Feature(FeatureRequest),
    Append(replication::DynamicRequest),
    Image(DynamicSnapshotRequest),
}
impl Job {
    fn peer(&self) -> Key {
        match self {
            Self::Vote(q) => q.context.peer,
            Self::Feature(q) => q.peer,
            Self::Append(q) => q.context.peer,
            Self::Image(q) => q.context.peer,
        }
    }
    fn sequence(&self) -> u64 {
        match self {
            Self::Vote(q) => q.sequence,
            Self::Feature(q) => q.sequence,
            Self::Append(q) => q.request.sequence,
            Self::Image(q) => q.request.sequence,
        }
    }
    fn cancellation(&self) -> Command {
        match self {
            Self::Vote(q) => Command::CancelVote(*q),
            _ => Command::Timeout(self.peer(), self.sequence(), matches!(self, Self::Image(_))),
        }
    }
}

/// Exclusive lifecycle owner; successful shutdown joins every subordinate task.
pub struct Runtime {
    control: Arc<Control>,
    supervisor: Option<JoinHandle<Result<State>>>,
    finished: Option<State>,
}
/// Cloneable bounded command handle; it cannot borrow storage or join handles.
#[derive(Clone)]
pub struct Handle {
    control: Arc<Control>,
}
impl Runtime {
    /// Start owned recovery/tasks using an already bound private listener.
    /// Cancellation of wait_ready does not detach the storage owner. A Tokio
    /// runtime must be present; startup itself performs no filesystem I/O.
    pub fn start(listener: TcpListener, config: Config, paths: Paths) -> Result<Self> {
        tokio::runtime::Handle::try_current().map_err(|_| Error::InvalidConfig)?;
        // The caller owns the listener, possibly behind an explicitly configured
        // fixed numeric forwarder. Advertised route != local bind is supported;
        // neither SocketAddr nor private Hello is represented as authentication.
        let bound = listener.local_addr()?;
        if bound.port() == 0 {
            return Err(Error::InvalidConfig);
        }
        let config = Arc::new(config);
        let capacity = checked_sum(&[
            config.limits.client_slots,
            config.peers.len(),
            config.limits.incoming,
            1,
        ])?;
        let (tx, rx) = mpsc::channel(capacity);
        let (ready_tx, ready_rx) = watch::channel(0);
        let control = Arc::new(Control {
            stopped: AtomicBool::new(false),
            notify: Notify::new(),
            commands: tx,
            clients: Arc::new(Semaphore::new(config.limits.client_slots)),
            bytes: Arc::new(Semaphore::new(config.pool)),
            startup: ready_rx,
            tasks: AtomicUsize::new(0),
            sockets: AtomicUsize::new(0),
            #[cfg(test)]
            metrics: Arc::new(TestMetrics::default()),
            #[cfg(test)]
            capture_root: TestTrace::capture_root(&paths, &config)?,
            config,
        });
        let owner_control = control.clone();
        let start = std::time::Instant::now();
        let owner = tokio::task::spawn_blocking(move || {
            run_owner(owner_control, paths, rx, ready_tx, start)
        });
        let supervisor = tokio::spawn(supervise(listener, control.clone(), owner));
        Ok(Self {
            control,
            supervisor: Some(supervisor),
            finished: None,
        })
    }
    /// Observe confirmed startup without taking ownership away from recovery.
    pub async fn wait_ready(&self) -> Result<()> {
        let deadline =
            Instant::now() + Duration::from_millis(self.control.config.limits.command_ms);
        let mut state = self.control.startup.clone();
        loop {
            if Instant::now() >= deadline {
                return Err(Error::Deadline);
            }
            let value = *state.borrow_and_update();
            match value {
                1 => return Ok(()),
                2 => return Err(Error::Startup),
                _ => {}
            }
            tokio::time::timeout_at(deadline, state.changed())
                .await
                .map_err(|_| Error::Deadline)?
                .map_err(|_| Error::Startup)?;
        }
    }
    /// Return a bounded admission handle.
    pub fn handle(&self) -> Handle {
        Handle {
            control: self.control.clone(),
        }
    }
    /// Stop admission and join listener/network/storage owners. Cancellation
    /// leaves the supervisor handle in place so this call can be retried.
    pub async fn shutdown(&mut self) -> Result<State> {
        self.control.stop();
        if let Some(state) = self.finished {
            return Ok(state);
        }
        let handle = self.supervisor.as_mut().ok_or(Error::Closed)?;
        let result = handle.await;
        self.supervisor.take();
        let result = result.map_err(Error::Join)?;
        let state = result?;
        #[cfg(test)]
        self.control.lifecycle(
            "supervisor-joined",
            self.control.metrics.workers_spawned.load(Ordering::Acquire),
            self.control.metrics.workers_joined.load(Ordering::Acquire),
            true,
            true,
            true,
        )?;
        self.finished = Some(state);
        Ok(state)
    }
}
impl Drop for Runtime {
    fn drop(&mut self) {
        self.control.stop();
    }
}
impl Handle {
    async fn call(&self, command: Command) -> Result<Reply> {
        self.call_until(
            command,
            Instant::now() + Duration::from_millis(self.control.config.limits.command_ms),
        )
        .await
    }
    async fn call_until(&self, command: Command, outer: Instant) -> Result<Reply> {
        if Instant::now() >= outer {
            return Err(Error::Deadline);
        }
        if self.control.stopped.load(Ordering::Acquire) {
            return Err(Error::Closed);
        }
        if *self.control.startup.borrow() != 1 {
            return Err(Error::Startup);
        }
        let deadline = outer
            .min(Instant::now() + Duration::from_millis(self.control.config.limits.command_ms));
        let permit =
            tokio::time::timeout_at(deadline, self.control.clients.clone().acquire_owned())
                .await
                .map_err(|_| Error::Deadline)?
                .map_err(|_| Error::Closed)?;
        #[cfg(test)]
        let permit = TestPermit::new(permit, self.control.metrics.clone(), 0, 1);
        self.control
            .call(command, Some(permit), None, deadline)
            .await
    }
    /// Copy the immutable configured metadata group/canonical genesis for an
    /// explicit application journal binding. Local voter ID is intentionally
    /// excluded; application state is verified against the committed source.
    pub fn metadata_binding(&self) -> Result<(String, String, u32, Vec<u8>)> {
        fn bounded_copy(value: &str) -> Result<String> {
            let mut output = String::new();
            output
                .try_reserve_exact(value.len())
                .map_err(|_| Error::Allocation)?;
            output.push_str(value);
            Ok(output)
        }
        let config = &self.control.config;
        Ok((
            bounded_copy(&config.controller.cluster_id)?,
            bounded_copy(&config.controller.topic)?,
            u32::try_from(config.controller.partition).map_err(|_| Error::InvalidConfig)?,
            config
                .bootstrap
                .genesis()
                .encode()
                .map_err(|_| Error::InvalidConfig)?,
        ))
    }
    /// Exact finite Node storage settings; no ownership or mutation is exposed.
    pub fn storage_limits(&self) -> StorageLimits {
        self.control.config.storage
    }

    /// Get current confirmed state; a leader role alone is not a read lease.
    pub async fn state(&self) -> Result<State> {
        match self.call(Command::State).await? {
            Reply::State(v) => Ok(v),
            _ => Err(Error::Peer),
        }
    }
    /// Get the actual current canonical voter configuration.
    pub async fn voters(&self) -> Result<super::membership::Voters> {
        match self.call(Command::Voters).await? {
            Reply::Voters(v) => Ok(v),
            _ => Err(Error::Peer),
        }
    }
    /// Synchronize opaque bytes locally; returned position is not a commit ACK.
    /// The input must be nonempty and its length must not exceed the record
    /// byte limit. Its allocation capacity must fit the configured command
    /// payload envelope (the largest of the frame, fetch and controller request
    /// byte limits). Invalid input is rejected before admission.
    pub async fn propose(&self, bytes: Vec<u8>) -> Result<LogPosition> {
        let config = &self.control.config;
        let bytes = bounded_proposal(
            bytes,
            config.storage.record_bytes,
            command_payload_limit(&config.controller, config.storage, config.limits),
        )?;
        match self.call(Command::Propose(bytes)).await? {
            Reply::Position(v) => Ok(v),
            _ => Err(Error::Peer),
        }
    }
    /// Wait for this exact term/index; an absent/replaced current position fails.
    pub async fn wait_committed(&self, position: LogPosition) -> Result<()> {
        let deadline =
            Instant::now() + Duration::from_millis(self.control.config.limits.command_ms);
        loop {
            match self
                .call_until(Command::Position(position), deadline)
                .await?
            {
                Reply::Visible(true) => return Ok(()),
                Reply::Visible(false) => {}
                _ => return Err(Error::Peer),
            }
            if Instant::now() >= deadline {
                return Err(Error::Deadline);
            }
            tokio::time::sleep_until(
                deadline.min(
                    Instant::now() + Duration::from_millis(self.control.config.limits.tick_ms),
                ),
            )
            .await;
        }
    }
    /// Fetch only synchronized committed records within configured output bounds.
    pub async fn fetch_committed(
        &self,
        from: u64,
        count: usize,
        bytes: usize,
    ) -> Result<Vec<Record>> {
        let l = self.control.config.storage;
        if count > l.live_entries || bytes > l.fetch_bytes {
            return Err(Error::InvalidConfig);
        }
        match self.call(Command::Fetch(from, count, bytes)).await? {
            Reply::Records(v) => Ok(v),
            _ => Err(Error::Peer),
        }
    }
    /// Select a full-prefix image through the existing authoritative Install WAL.
    pub async fn checkpoint(&self, generation: [u8; 16]) -> Result<snapshot::Descriptor> {
        match self.call(Command::Checkpoint(generation)).await? {
            Reply::Descriptor(v) => Ok(v),
            _ => Err(Error::Peer),
        }
    }
    /// Negotiate/catch up one configured observer and append its safe voter change.
    /// Completion returns ChangeReceipt; committed=false remains uncommitted.
    pub async fn add_voter(&self, key: Key) -> Result<ChangeReceipt> {
        let deadline = Instant::now() + Duration::from_millis(self.control.config.limits.quorum_ms);
        self.call_until(Command::Add(key), deadline).await?;
        loop {
            match self.call_until(Command::Addition(key), deadline).await? {
                Reply::Addition(Some(v)) => return Ok(v),
                Reply::Addition(None) => {}
                _ => return Err(Error::Peer),
            }
            if Instant::now() >= deadline {
                return Err(Error::Deadline);
            }
            tokio::time::sleep_until(
                deadline.min(
                    Instant::now() + Duration::from_millis(self.control.config.limits.tick_ms),
                ),
            )
            .await;
        }
    }
    /// Append one configured voter removal; new-set majority remains authoritative.
    pub async fn remove_voter(&self, key: Key) -> Result<ChangeReceipt> {
        match self.call(Command::Remove(key)).await? {
            Reply::Change(v) => Ok(v),
            _ => Err(Error::Peer),
        }
    }
    /// Confirm whether the latest active configuration position is committed.
    pub async fn change_status(&self) -> Result<ChangeReceipt> {
        match self.call(Command::Change).await? {
            Reply::Change(v) => Ok(v),
            _ => Err(Error::Peer),
        }
    }
    /// Current finite ownership counters, excluding the listening socket.
    pub fn diagnostics(&self) -> Diagnostics {
        let c = &self.control;
        Diagnostics {
            network_tasks: c.tasks.load(Ordering::Acquire),
            sockets: c.sockets.load(Ordering::Acquire),
            transport_bytes: c.config.pool - c.bytes.available_permits(),
            client_slots: c.config.limits.client_slots - c.clients.available_permits(),
            stopping: c.stopped.load(Ordering::Acquire),
        }
    }
}

struct Addition {
    key: Key,
    request: FeatureRequest,
    sent: bool,
    negotiated: bool,
    deadline: u64,
    receipt: Option<ChangeReceipt>,
    failed: bool,
}
struct Owner {
    node: Node,
    config: Arc<Config>,
    matches: Vec<(Key, u64, bool)>,
    addition: Option<Addition>,
    incoming: Option<(Key, DynamicSnapshotRequest)>,
    term: u64,
    #[cfg(test)]
    metrics: Arc<TestMetrics>,
    #[cfg(test)]
    cleanup: Option<String>,
}
impl Owner {
    fn execute(&mut self, command: Command, now: u64) -> Result<Reply> {
        #[cfg(test)]
        {
            self.cleanup = None;
        }
        match command {
            Command::Tick => {
                self.node.poll(now)?;
                let votes = self.node.campaign_dynamic(now)?;
                let s = self.node.state();
                if self.term != s.election.persistent.term || s.election.role != Role::Leader {
                    for v in &mut self.matches {
                        v.1 = 0;
                        v.2 = false;
                    }
                    self.term = s.election.persistent.term;
                }
                if s.election.role == Role::Leader && s.active_term.is_none() {
                    self.node.activate_leader(now)?;
                }
                if let Some(a) = &mut self.addition {
                    if a.receipt.is_none() && !a.failed {
                        if now >= a.deadline {
                            let _ = self.node.cancel_addition(a.key);
                            a.failed = true;
                        } else if a.negotiated {
                            match self.node.add_voter(a.key, now) {
                                Ok(r) => a.receipt = Some(r),
                                // An owned image reader is normal catch-up work,
                                // not terminal admission failure. Retry under the
                                // same absolute deadline; never renew it here.
                                Err(
                                    replication::Error::MembershipNotReady
                                    | replication::Error::Busy,
                                ) => {}
                                Err(_) => a.failed = true,
                            }
                        }
                    }
                }
                Ok(Reply::Votes(votes.into_iter().map(Job::Vote).collect()))
            }
            Command::State => Ok(Reply::State(self.node.state())),
            Command::Voters => Ok(Reply::Voters(self.node.voters()?.clone())),
            Command::Propose(bytes) => {
                let index = self.node.propose(&bytes, now)?;
                let term = self.node.term_at(index)?.ok_or(Error::Peer)?;
                Ok(Reply::Position(LogPosition { term, index }))
            }
            Command::Position(p) => {
                if self.node.term_at(p.index)? != Some(p.term) {
                    return Err(Error::PositionMismatch);
                }
                Ok(Reply::Visible(self.node.state().committed_end >= p.index))
            }
            Command::Fetch(from, count, bytes) => Ok(Reply::Records(
                self.node.fetch_committed(from, count, bytes)?,
            )),
            Command::Checkpoint(generation) => {
                Ok(Reply::Descriptor(self.node.checkpoint(generation, now)?))
            }
            Command::Prepare(key) => {
                if self.node.state().election.role != Role::Leader {
                    return Ok(Reply::Job(None));
                }
                if let Some(a) = &mut self.addition {
                    if a.key == key && !a.failed && a.receipt.is_none() && !a.negotiated {
                        if !a.sent {
                            a.sent = true;
                            return Ok(Reply::Job(Some(Job::Feature(a.request))));
                        }
                        return Ok(Reply::Job(None));
                    }
                }
                let active = self.node.voters()?.contains(key)
                    || self
                        .addition
                        .as_ref()
                        .is_some_and(|a| a.key == key && a.negotiated && !a.failed);
                if !active {
                    return Ok(Reply::Job(None));
                }
                let matched = self
                    .matches
                    .iter()
                    .find(|(k, _, _)| *k == key)
                    .map_or(0, |(_, n, _)| *n);
                if self
                    .node
                    .selected_snapshot()?
                    .is_some_and(|d| d.base.index > matched)
                    && !self.matches.iter().any(|(k, _, skip)| *k == key && *skip)
                {
                    match self.node.prepare_dynamic_snapshot(key, now) {
                        Ok(q) => return Ok(Reply::Job(Some(Job::Image(q)))),
                        Err(replication::Error::Busy) => return Ok(Reply::Job(None)),
                        Err(e) => return Err(e.into()),
                    }
                }
                match self.node.prepare_dynamic(key, now) {
                    Ok(q) => Ok(Reply::Job(Some(Job::Append(q)))),
                    Err(replication::Error::Busy) => Ok(Reply::Job(None)),
                    Err(e) => Err(e.into()),
                }
            }
            Command::Inbound(source, message) => {
                let context = message.context().ok_or(Error::Peer)?;
                if context.leader != source || context.peer != self.config.bootstrap.local().key() {
                    return Err(Error::Peer);
                }
                let reply = match message {
                    Message::Vote(q) => Message::VoteReply(self.node.receive_dynamic_vote(q, now)?),
                    Message::Feature(q) => {
                        Message::FeatureReply(self.node.receive_feature_probe(q, now)?)
                    }
                    Message::Append(q) => Message::AppendReply(self.node.receive_dynamic(&q, now)?),
                    Message::Begin(q) => {
                        self.node.begin_dynamic_snapshot(q, now)?;
                        self.incoming = Some((source, q));
                        Message::Begun(q)
                    }
                    Message::Chunk {
                        offer,
                        offset,
                        bytes,
                    } => {
                        if self.incoming != Some((source, offer)) {
                            return Err(Error::Peer);
                        }
                        self.node
                            .receive_dynamic_snapshot_chunk(offer, offset, &bytes, now)?;
                        Message::Chunked {
                            offer,
                            offset,
                            length: bytes.len() as u32,
                        }
                    }
                    Message::Finish(q) => {
                        if self.incoming != Some((source, q)) {
                            return Err(Error::Peer);
                        }
                        let r = self.node.finish_dynamic_snapshot(q, now)?;
                        self.incoming = None;
                        Message::Finished(r)
                    }
                    _ => return Err(Error::Peer),
                };
                Ok(Reply::Message(reply))
            }
            Command::Acknowledge(message) => {
                match message {
                    Message::VoteReply(r) => {
                        self.node.acknowledge_dynamic_vote(r, now)?;
                    }
                    Message::FeatureReply(r) => {
                        let expected = self
                            .config
                            .peers
                            .iter()
                            .find(|p| p.key() == r.request.peer)
                            .ok_or(Error::Peer)?;
                        if r.voter != expected.voter {
                            return Err(Error::Peer);
                        }
                        self.node.acknowledge_feature_probe(r.clone(), now)?;
                        let a = self
                            .addition
                            .as_mut()
                            .filter(|a| a.request == r.request)
                            .ok_or(Error::Peer)?;
                        a.negotiated = true;
                    }
                    Message::AppendReply(r) => {
                        self.node.acknowledge_dynamic(r, now)?;
                        if r.response.success {
                            self.matched(r.context.peer, r.response.matched.index);
                        }
                    }
                    Message::Finished(r) => {
                        self.node.acknowledge_dynamic_snapshot(r, now)?;
                        self.matched(r.context.peer, r.response.response.matched.index);
                    }
                    _ => return Err(Error::Peer),
                }
                Ok(Reply::Done)
            }
            Command::Timeout(key, sequence, image) => {
                let released = self.node.timeout_dynamic(key, sequence).is_ok();
                if image && released {
                    if let Some(v) = self.matches.iter_mut().find(|(k, _, _)| *k == key) {
                        v.2 = true;
                    }
                }
                #[cfg(test)]
                let mut feature_released = "null";
                if let Some(a) = &mut self.addition {
                    if a.key == key && a.request.sequence == sequence && !a.negotiated {
                        let result = self.node.timeout_feature_probe(a.request);
                        #[cfg(test)]
                        {
                            feature_released = if result.is_ok() { "true" } else { "false" };
                        }
                        drop(result);
                        a.failed = true;
                    }
                }
                #[cfg(test)]
                {
                    self.cleanup = Some(format!("{{\"append_or_image_released\":{released},\"feature_released\":{feature_released},\"image_fallback_set\":{}}}", image && released));
                }
                Ok(Reply::Done)
            }
            Command::CancelVote(request) => {
                self.node.timeout_dynamic_vote(request)?;
                Ok(Reply::Done)
            }
            Command::Chunk(q) => {
                let c = self.node.dynamic_snapshot_chunk(q, now)?;
                Ok(Reply::Message(Message::Chunk {
                    offer: q,
                    offset: c.offset,
                    bytes: c.bytes,
                }))
            }
            Command::Add(key) => {
                if self
                    .addition
                    .as_ref()
                    .is_some_and(|a| a.receipt.is_none() && !a.failed)
                {
                    return Err(replication::Error::Busy.into());
                }
                let voter = self
                    .config
                    .peers
                    .iter()
                    .find(|p| p.key() == key)
                    .ok_or(Error::Peer)?
                    .voter
                    .clone();
                let request = self.node.probe_addition(voter, now)?;
                self.addition = Some(Addition {
                    key,
                    request,
                    sent: false,
                    negotiated: false,
                    deadline: now
                        .checked_add(self.config.limits.quorum_ms)
                        .ok_or(Error::InvalidConfig)?,
                    receipt: None,
                    failed: false,
                });
                Ok(Reply::Done)
            }
            Command::Addition(key) => {
                let a = self
                    .addition
                    .as_ref()
                    .filter(|a| a.key == key)
                    .ok_or(Error::Peer)?;
                if a.failed {
                    return Err(Error::Deadline);
                }
                Ok(Reply::Addition(a.receipt))
            }
            Command::Remove(key) => Ok(Reply::Change(self.node.remove_voter(key, now)?)),
            Command::Change => Ok(Reply::Change(self.node.change_status()?)),
            Command::Disconnected(source) => {
                if let Some((_, _offer)) = self.incoming.filter(|(key, _)| *key == source) {
                    #[cfg(test)]
                    {
                        self.cleanup = Some(format!(
                            "{{\"aborted_dispatch_offer\":{{\"kind\":30,\"body_hex\":\"{}\"}}}}",
                            TestTrace::body(
                                &Message::Begin(_offer),
                                self.config.limits.frame_bytes
                            )?
                        ));
                    }
                    self.node.abort_snapshot()?;
                    self.incoming = None;
                }
                Ok(Reply::Done)
            }
            Command::Stop => {
                self.node.abort_snapshot()?;
                Ok(Reply::Done)
            }
        }
    }
    fn matched(&mut self, key: Key, index: u64) {
        if let Some(v) = self.matches.iter_mut().find(|(k, _, _)| *k == key) {
            v.1 = v.1.max(index);
            v.2 = false;
        }
    }
}
fn run_owner(
    control: Arc<Control>,
    paths: Paths,
    mut receiver: mpsc::Receiver<Envelope>,
    startup: watch::Sender<u8>,
    start: std::time::Instant,
) -> Result<State> {
    let c = &control.config;
    #[cfg(test)]
    if control.metrics.clock.set(start).is_err() {
        return Err(Error::InvalidConfig);
    }
    let mut config = replication::Config::new(c.controller.clone());
    config.limits = c.storage.node()?;
    config.max_queued_requests = c.limits.client_slots;
    config.quorum_timeout_ms = c.limits.quorum_ms;
    let opened = (|| {
        let identity = snapshot::Identity::dynamic(
            c.group.cluster.clone(),
            c.group.topic.clone(),
            c.group.partition,
            c.bootstrap.genesis().clone(),
        )
        .map_err(replication::Error::from)?;
        let store = snapshot::Store::open(&paths.images, identity, c.storage.images)
            .map_err(replication::Error::from)?;
        Ok::<_, Error>(Node::open_dynamic(
            &paths.wal,
            &paths.election,
            config,
            c.bootstrap.clone(),
            Some(store),
            0,
        )?)
    })();
    let node = match opened {
        Ok(node) => node,
        Err(e) => {
            let _ = startup.send(2);
            control.stop();
            return Err(e);
        }
    };
    let mut matches = Vec::new();
    matches
        .try_reserve_exact(c.peers.len())
        .map_err(|_| Error::Allocation)?;
    matches.extend(c.peers.iter().map(|p| (p.key(), 0, false)));
    let mut owner = Owner {
        node,
        config: c.clone(),
        matches,
        addition: None,
        incoming: None,
        term: 0,
        #[cfg(test)]
        metrics: control.metrics.clone(),
        #[cfg(test)]
        cleanup: None,
    };
    #[cfg(test)]
    let mut trace = TestTrace::open(&paths, c, receiver.max_capacity())?;
    let _ = startup.send(1);
    while let Some(envelope) = receiver.blocking_recv() {
        let Envelope {
            command,
            reply,
            permit,
            transport,
            started,
            deadline,
            #[cfg(test)]
            delivery_gate,
            #[cfg(test)]
            _counter,
        } = envelope;
        let stop = matches!(command, Command::Stop);
        let internal = matches!(
            command,
            Command::Timeout(..)
                | Command::CancelVote(..)
                | Command::Disconnected(..)
                | Command::Stop
        );
        if !internal && reply.is_closed() {
            continue;
        }
        if !internal && deadline.is_some_and(|d| Instant::now() >= d) {
            let _ = reply.send(Delivered {
                result: Err(Error::Deadline),
                _permit: permit,
                _transport: transport,
            });
            continue;
        }
        if control.stopped.load(Ordering::Acquire) && !internal {
            let _ = reply.send(Delivered {
                result: Err(Error::Closed),
                _permit: permit,
                _transport: transport,
            });
            continue;
        }
        started.store(true, Ordering::Release);
        let now = u64::try_from(start.elapsed().as_millis()).map_err(|_| Error::InvalidConfig)?;
        #[cfg(test)]
        let captured = TestTrace::input(&command, c.limits.frame_bytes)?;
        let result = owner.execute(command, now);
        // Tests pause only after the actual Node operation has completed. This
        // cannot inject a grant, alter Node state, or expose production handles.
        #[cfg(test)]
        if let Some(gate) = delivery_gate {
            let requests = match &result {
                Ok(Reply::Votes(jobs)) => jobs
                    .iter()
                    .filter_map(|j| if let Job::Vote(q) = j { Some(*q) } else { None })
                    .collect(),
                _ => Vec::new(),
            };
            let _ = gate.ready.send((requests, owner.node.state()));
            gate.release.recv().map_err(|_| Error::Closed)?;
        }
        #[cfg(test)]
        if let Some(trace) = &mut trace {
            trace.record(&owner, captured, &result, now, &paths)?;
        }
        if let Err(delivery) = reply.send(Delivered {
            result,
            _permit: permit,
            _transport: transport,
        }) {
            match delivery.result {
                Ok(Reply::Job(Some(job))) => {
                    cancel_owner_job(
                        &mut owner,
                        job,
                        now,
                        #[cfg(test)]
                        &mut trace,
                        #[cfg(test)]
                        &paths,
                    )?;
                }
                Ok(Reply::Votes(jobs)) => {
                    for job in jobs {
                        cancel_owner_job(
                            &mut owner,
                            job,
                            now,
                            #[cfg(test)]
                            &mut trace,
                            #[cfg(test)]
                            &paths,
                        )?;
                    }
                }
                _ => {}
            }
        }
        if stop {
            break;
        }
    }
    owner.node.abort_snapshot()?;
    // Dropping the sole Node closes journals/readers after its last synchronous
    // operation. Store::drop removes any staged partial generation.
    Ok(owner.node.state())
}
fn cancel_owner_job(
    owner: &mut Owner,
    job: Job,
    now: u64,
    #[cfg(test)] trace: &mut Option<TestTrace>,
    #[cfg(test)] paths: &Paths,
) -> Result<()> {
    let command = job.cancellation();
    #[cfg(test)]
    let captured = TestTrace::input(&command, owner.config.limits.frame_bytes)?;
    let result = owner.execute(command, now);
    #[cfg(test)]
    if let Some(trace) = trace {
        trace.record(owner, captured, &result, now, paths)?;
    }
    // A previously acknowledged/stepped-down exact request is already absent;
    // rejecting its cancellation does not create a fabricated grant/contact.
    drop(result);
    Ok(())
}

async fn supervise(
    listener: TcpListener,
    control: Arc<Control>,
    owner: JoinHandle<Result<State>>,
) -> Result<State> {
    let mut startup = control.startup.clone();
    while *startup.borrow() != 1 {
        if *startup.borrow() == 2 || control.stopped.load(Ordering::Acquire) {
            break;
        }
        tokio::select! {r=startup.changed()=>{if r.is_err(){break;}},_ = control.stopping()=>break}
    }
    let mut workers = JoinSet::new();
    let mut routes = Vec::new();
    let mut failure = None;
    #[cfg(test)]
    let (mut spawned, mut joined) = (0usize, 0usize);
    let incoming = Arc::new(Semaphore::new(control.config.limits.incoming));
    let identities: Arc<Vec<AtomicBool>> = Arc::new(
        control
            .config
            .peers
            .iter()
            .map(|_| AtomicBool::new(false))
            .collect(),
    );
    if *startup.borrow() == 1 && !control.stopped.load(Ordering::Acquire) {
        if routes
            .try_reserve_exact(control.config.peers.len())
            .is_err()
        {
            control.stop();
            failure = Some(Error::Allocation);
        }
        for peer in control
            .config
            .peers
            .iter()
            .filter(|_| !control.stopped.load(Ordering::Acquire))
        {
            let (tx, rx) = mpsc::channel(1);
            routes.push((peer.key(), tx));
            let c = control.clone();
            let p = peer.clone();
            workers.spawn(async move {
                outbound(c, p, rx).await;
            });
            #[cfg(test)]
            {
                spawned += 1;
            }
        }
        let mut tick = tokio::time::interval(Duration::from_millis(control.config.limits.tick_ms));
        tick.set_missed_tick_behavior(MissedTickBehavior::Skip);
        while !control.stopped.load(Ordering::Acquire) {
            tokio::select! {
                _ = control.stopping()=>break,
                _ = tick.tick()=>{
                    match control.internal(Command::Tick).await {
                        Ok(Reply::Votes(jobs))=>dispatch_votes(&control,&routes,jobs).await,
                        Ok(_)=>{},Err(_)=>{control.stop();break;}
                    }
                }
                accepted=listener.accept()=>{
                    match accepted {
                        Ok((socket,_))=>{
                            if let Ok(permit)=incoming.clone().try_acquire_owned(){let c=control.clone();let keys=identities.clone();workers.spawn(async move{serve(c,socket,permit,keys).await;});
                                #[cfg(test)] { spawned += 1; }}
                            else{abandon_peer_socket(socket).await;}
                        }
                        Err(_)=>{control.stop();break;}
                    }
                }
                result=workers.join_next(),if !workers.is_empty()=>{
                    #[cfg(test)] if result.is_some() { joined += 1; }
                    if let Some(Err(e))=result{failure=Some(Error::Join(e));control.stop();break;}
                }
            }
        }
    }
    control.stop();
    drop(listener);
    drop(routes);
    while let Some(result) = workers.join_next().await {
        #[cfg(test)]
        {
            joined += 1;
        }
        if let Err(e) = result {
            if failure.is_none() {
                failure = Some(Error::Join(e));
            }
        }
    }
    let stopped = control.reliable(Command::Stop).await;
    let state = owner.await.map_err(Error::Join)??;
    stopped?;
    if let Some(error) = failure {
        return Err(error);
    }
    #[cfg(test)]
    {
        control
            .metrics
            .workers_spawned
            .store(spawned, Ordering::Release);
        control
            .metrics
            .workers_joined
            .store(joined, Ordering::Release);
        control.lifecycle("workers-owner-joined", spawned, joined, true, false, true)?;
    }
    Ok(state)
}
async fn dispatch_votes(control: &Control, routes: &[(Key, mpsc::Sender<Job>)], jobs: Vec<Job>) {
    for job in jobs {
        match routes.iter().find(|(k, _)| *k == job.peer()) {
            Some((_, tx)) => {
                if let Err(error) = tx.try_send(job) {
                    let _ = control.cancel_job(error.into_inner()).await;
                }
            }
            None => {
                let _ = control.cancel_job(job).await;
            }
        }
    }
}
struct Counter {
    control: Arc<Control>,
    socket: bool,
    #[cfg(test)]
    _counter: TestCounter,
}
impl Counter {
    fn task(c: &Arc<Control>) -> Self {
        c.tasks.fetch_add(1, Ordering::AcqRel);
        Self {
            control: c.clone(),
            socket: false,
            #[cfg(test)]
            _counter: TestCounter::new(c.metrics.clone(), 2, 1),
        }
    }
    fn socket(c: &Arc<Control>) -> Self {
        c.sockets.fetch_add(1, Ordering::AcqRel);
        Self {
            control: c.clone(),
            socket: true,
            #[cfg(test)]
            _counter: TestCounter::new(c.metrics.clone(), 3, 1),
        }
    }
}
impl Drop for Counter {
    fn drop(&mut self) {
        if self.socket {
            self.control.sockets.fetch_sub(1, Ordering::AcqRel);
        } else {
            self.control.tasks.fetch_sub(1, Ordering::AcqRel);
        }
    }
}
/// Fill `length` bytes into spare capacity. The body is not zeroed first.
async fn read_exact_spare<S: AsyncRead + Unpin>(
    socket: &mut S,
    payload: &mut Vec<u8>,
    length: usize,
) -> Result<()> {
    payload
        .try_reserve_exact(length)
        .map_err(|_| Error::Allocation)?;
    while payload.len() < length {
        // One ready read can fill every spare byte. Stop after one chunk so
        // the frame deadline runs before the rest of the body is copied.
        let step = length.saturating_sub(payload.len()).min(8 * 1024);
        let mut limited = (&mut *payload).limit(step);
        let n = socket.read_buf(&mut limited).await?;
        if n == 0 {
            return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "frame body closed").into());
        }
        // A ready body never returns from this read, so the frame deadline
        // cannot run until every byte is buffered.
        tokio::task::yield_now().await;
    }
    Ok(())
}

/// Read and write buffers kept for the life of one peer connection.
struct WireBuf {
    read: Vec<u8>,
    write: Vec<u8>,
    /// Bytes read while a command was running, ahead of the next frame.
    unread: Vec<u8>,
}
impl WireBuf {
    fn new() -> Self {
        Self {
            read: Vec::new(),
            write: Vec::new(),
            unread: Vec::new(),
        }
    }
}

fn take_unread(unread: &mut Vec<u8>, dest: &mut Vec<u8>, n: usize) {
    let have = unread.len().min(n);
    if have == 0 {
        return;
    }
    if let Some(chunk) = unread.get(..have) {
        dest.extend_from_slice(chunk);
    }
    let _taken = unread.drain(..have);
}

async fn read_frame<S: AsyncRead + Unpin>(
    socket: &mut S,
    limit: usize,
    max_records: usize,
    deadline: Instant,
    wire: &mut WireBuf,
) -> Result<Frame> {
    tokio::time::timeout_at(deadline, async {
        let mut prefix = Vec::with_capacity(4);
        take_unread(&mut wire.unread, &mut prefix, 4);
        if prefix.len() < 4 {
            let mut tail = Vec::new();
            read_exact_spare(&mut *socket, &mut tail, 4 - prefix.len()).await?;
            prefix.append(&mut tail);
        }
        let raw = prefix
            .get(..4)
            .ok_or(Error::Peer)?
            .try_into()
            .map_err(|_| Error::Peer)?;
        let length = u32::from_be_bytes(raw) as usize;
        if !(28..=limit).contains(&length) {
            return Err(Error::Peer);
        }
        wire.read.clear();
        take_unread(&mut wire.unread, &mut wire.read, length);
        let need = length.saturating_sub(wire.read.len());
        if need > 0 {
            let mut tail = Vec::new();
            read_exact_spare(&mut *socket, &mut tail, need).await?;
            wire.read.append(&mut tail);
        }
        Ok(peer_codec::decode(&wire.read, limit, max_records)?)
    })
    .await
    .map_err(|_| Error::Deadline)?
}
async fn write_frame<S: AsyncWrite + Unpin>(
    socket: &mut S,
    frame: &Frame,
    limit: usize,
    deadline: Instant,
    wire: &mut WireBuf,
) -> Result<()> {
    peer_codec::encode_into(frame, limit, &mut wire.write)?;
    let bytes = &wire.write;
    let len = u32::try_from(bytes.len())
        .map_err(|_| Error::Peer)?
        .to_be_bytes();
    // A length already read while the previous command ran is not a later
    // socket read. The peer is not accepting this frame, so the write must
    // not sit until its deadline. A long run of frames is walked in slices
    // so a command beside this write can run.
    let mut scanned = 0usize;
    loop {
        if scanned > wire.unread.len() {
            scanned = 0;
        }
        match scan_peer_frames(&wire.unread, scanned, limit, 64 * 1024) {
            PeerScan::Rejected => return Err(Error::Peer),
            PeerScan::Rest(_) => break,
            PeerScan::Partial(at) => {
                scanned = at;
                tokio::task::yield_now().await;
            }
        }
    }
    tokio::time::timeout_at(deadline, async {
        // The length stays in front of the body. A large body is sent in
        // chunks so a deadline can stop the copy.
        let mut slices = [IoSlice::new(&len), IoSlice::new(bytes)];
        let mut bufs: &mut [IoSlice<'_>] = &mut slices;
        while !bufs.is_empty() {
            // A ready socket can accept the whole frame. Offer one chunk so
            // the deadline runs before the rest is copied.
            let Some(first) = bufs.first() else {
                break;
            };
            let take = first.len().min(8 * 1024);
            if take == 0 {
                return Err(Error::Peer);
            }
            let head = [IoSlice::new(&first[..take])];
            let n = socket.write_vectored(&head).await?;
            if n == 0 {
                return Err(Error::Peer);
            }
            IoSlice::advance_slices(&mut bufs, n);
            // A ready socket can accept one byte at a time without ever
            // returning, so the frame deadline cannot run until the write
            // finishes.
            tokio::task::yield_now().await;
        }
        Ok::<_, Error>(())
    })
    .await
    .map_err(|_| Error::Deadline)?
}
async fn hello(
    socket: &mut TcpStream,
    control: &Control,
    peer: Key,
    deadline: Instant,
    wire: &mut WireBuf,
) -> Result<()> {
    let h = Hello {
        source: control.config.bootstrap.local().key(),
        target: peer,
        group: control.config.group.clone(),
    };
    write_frame(
        socket,
        &Frame {
            rpc: 0,
            message: Message::Hello(h.clone()),
        },
        control.config.limits.frame_bytes,
        deadline,
        wire,
    )
    .await?;
    let response = read_frame(
        socket,
        control.config.limits.frame_bytes,
        control.config.storage.live_entries,
        deadline,
        wire,
    )
    .await?;
    if response.rpc != 0 || response.message != Message::HelloAck(h) {
        return Err(Error::Peer);
    }
    Ok(())
}
async fn rpc(
    socket: &mut TcpStream,
    message: Message,
    id: &mut u64,
    control: &Control,
    deadline: Instant,
    wire: &mut WireBuf,
) -> Result<Message> {
    *id = id.checked_add(1).ok_or(Error::Peer)?;
    let frame = Frame { rpc: *id, message };
    write_frame(
        socket,
        &frame,
        control.config.limits.frame_bytes,
        deadline,
        wire,
    )
    .await?;
    let response = read_frame(
        socket,
        control.config.limits.frame_bytes,
        control.config.storage.live_entries,
        deadline,
        wire,
    )
    .await?;
    if response.rpc != frame.rpc || !frame.message.matches_reply(&response.message) {
        return Err(Error::Peer);
    }
    Ok(response.message)
}
enum PeerScan {
    Rejected,
    /// Walked through `at`. Anything after that is a short tail or empty.
    Rest(usize),
    /// Walked through `at` and more complete frames are still buffered.
    Partial(usize),
}

/// Walk complete frames from `start`, stopping after `budget` bytes.
///
/// A long run of minimum frames is still legal. Scanning all of it in one
/// turn keeps a command beside this peer from running until the walk finishes.
fn scan_peer_frames(unread: &[u8], start: usize, limit: usize, budget: usize) -> PeerScan {
    let mut offset = start.min(unread.len());
    let end = offset.saturating_add(budget.max(4));
    while unread.len().saturating_sub(offset) >= 4 {
        if offset >= end {
            return PeerScan::Partial(offset);
        }
        let Some(prefix) = unread.get(offset..offset.saturating_add(4)) else {
            return PeerScan::Rejected;
        };
        let Ok(raw) = <[u8; 4]>::try_from(prefix) else {
            return PeerScan::Rejected;
        };
        let length = u32::from_be_bytes(raw) as usize;
        if !(28..=limit).contains(&length) {
            return PeerScan::Rejected;
        }
        let Some(total) = 4usize.checked_add(length) else {
            return PeerScan::Rejected;
        };
        let Some(frame_end) = offset.checked_add(total) else {
            return PeerScan::Rejected;
        };
        // A short tail of the next frame is still arriving. Only a finished
        // frame can hide a later length this peer will not accept.
        if unread.len() < frame_end {
            return PeerScan::Rest(offset);
        }
        offset = frame_end;
    }
    PeerScan::Rest(offset)
}

async fn peer_socket_closed<S: AsyncRead + Unpin>(
    socket: &mut S,
    unread: &mut Vec<u8>,
    limit: usize,
) {
    let mut buf = [0u8; 1024];
    let mut scanned = 0usize;
    loop {
        // One next frame fits in the frame limit. More than that during a
        // command is not a single pipelined request, so the socket is closed.
        // A length this peer will not accept is not a frame either.
        if unread.len() > limit {
            return;
        }
        if scanned > unread.len() {
            scanned = 0;
        }
        match scan_peer_frames(unread, scanned, limit, 64 * 1024) {
            PeerScan::Rejected => return,
            PeerScan::Rest(at) => scanned = at,
            PeerScan::Partial(at) => {
                scanned = at;
                // More complete frames are buffered. Yield before walking
                // the rest so a command beside this peer can run.
                tokio::task::yield_now().await;
                continue;
            }
        }
        match socket.read(&mut buf).await {
            Ok(0) | Err(_) => return,
            Ok(n) => {
                if let Some(chunk) = buf.get(..n) {
                    unread.extend_from_slice(chunk);
                }
                // A ready flood never leaves this read, so a command or
                // heartbeat beside it cannot run until the cap is reached.
                tokio::task::yield_now().await;
            }
        }
    }
}

async fn abandon_peer_socket(mut socket: TcpStream) {
    // A rejected length leaves the rest of that write in the kernel buffer.
    // Shut the write side down before drop so the peer observes EOF. Yield so
    // that close is visible before the caller continues.
    let _ = socket.shutdown().await;
    drop(socket);
    for _ in 0..8 {
        tokio::task::yield_now().await;
    }
}

async fn abandon_open_peer(open: (TcpStream, Counter, u64)) {
    let (socket, _counter, _) = open;
    abandon_peer_socket(socket).await;
}

async fn outbound(control: Arc<Control>, peer: Peer, mut jobs: mpsc::Receiver<Job>) {
    let _task = Counter::task(&control);
    let mut wire = WireBuf::new();
    let mut socket: Option<(TcpStream, Counter, u64)> = None;
    let mut tick = tokio::time::interval(Duration::from_millis(control.config.limits.heartbeat_ms));
    tick.set_missed_tick_behavior(MissedTickBehavior::Skip);
    loop {
        let admission = Instant::now() + Duration::from_millis(control.config.limits.rpc_ms);
        // An open peer can leave while the next frame reservation waits.
        let reservation = tokio::select! {
            biased;
            _ = control.stopping()=>break,
            _ = async {
                if let Some((open, _, _)) = &mut socket {
                    peer_socket_closed(
                        open,
                        &mut wire.unread,
                        control.config.limits.frame_bytes,
                    )
                    .await;
                } else {
                    std::future::pending::<()>().await;
                }
            } => {
                wire.unread.clear();
                if let Some(open) = socket.take() {
                    abandon_open_peer(open).await;
                }
                continue;
            },
            r = control.reserve_frame(admission) => r,
        };
        let Ok(reservation) = reservation else {
            continue;
        };
        let mut peer_left = false;
        let job = tokio::select! {
            biased;
            _ = control.stopping()=>break,
            // A peer can leave between jobs. The next heartbeat must not be
            // what first notices that close.
            _ = async {
                if let Some((open, _, _)) = &mut socket {
                    peer_socket_closed(
                        open,
                        &mut wire.unread,
                        control.config.limits.frame_bytes,
                    )
                    .await;
                } else {
                    std::future::pending::<()>().await;
                }
            } => {
                peer_left = true;
                None
            },
            value=jobs.recv()=>match value{Some(j)=>Some(j),None=>break},
            _ = tick.tick() => {
                // Prepare waits on the owner. A peer that leaves during that
                // wait must not stay connected until the heartbeat deadline.
                let prepare = control.call(
                    Command::Prepare(peer.key()),
                    None,
                    Some(reservation.clone()),
                    admission,
                );
                tokio::pin!(prepare);
                let early = tokio::select! {
                    biased;
                    _ = async {
                        if let Some((open, _, _)) = &mut socket {
                            peer_socket_closed(
                                open,
                                &mut wire.unread,
                                control.config.limits.frame_bytes,
                            )
                            .await;
                        } else {
                            std::future::pending::<()>().await;
                        }
                    } => None,
                    result = &mut prepare => Some(result),
                };
                match early {
                    None => {
                        peer_left = true;
                        None
                    }
                    Some(Ok(Reply::Job(job))) => job,
                    Some(_) => None,
                }
            },
        };
        if peer_left {
            wire.unread.clear();
            if let Some(open) = socket.take() {
                abandon_open_peer(open).await;
            }
            continue;
        }
        let Some(job) = job else {
            continue;
        };
        let cancellation = job.cancellation();
        let deadline = Instant::now()
            + Duration::from_millis(if matches!(job, Job::Image(_)) {
                control.config.limits.transfer_ms
            } else {
                control.config.limits.rpc_ms
            });
        if socket.is_none() {
            let counter = Counter::socket(&control);
            let connect_deadline = deadline
                .min(Instant::now() + Duration::from_millis(control.config.limits.connect_ms));
            if let Ok(Ok(mut s)) =
                tokio::time::timeout_at(connect_deadline, TcpStream::connect(peer.address)).await
            {
                let stored = configure_peer_socket(&s).is_ok()
                    && hello(&mut s, &control, peer.key(), deadline, &mut wire)
                        .await
                        .is_ok();
                if stored {
                    socket = Some((s, counter, 0));
                } else {
                    abandon_peer_socket(s).await;
                }
            }
        }
        let result = if let Some((s, _, id)) = &mut socket {
            tokio::select! {
                _ = control.stopping()=>Err(Error::Closed),
                result=send_job(s,&control,job,id,deadline,&reservation,&mut wire)=>result,
            }
        } else {
            Err(Error::Peer)
        };
        match result {
            Ok(response) => {
                let ack = control.call(
                    Command::Acknowledge(response),
                    None,
                    Some(reservation.clone()),
                    deadline,
                );
                tokio::pin!(ack);
                // The owner can outlive the peer. A close during that wait must
                // drop this socket instead of holding it until the deadline.
                let early = tokio::select! {
                    biased;
                    _ = async {
                        if let Some((open, _, _)) = &mut socket {
                            peer_socket_closed(
                                open,
                                &mut wire.unread,
                                control.config.limits.frame_bytes,
                            )
                            .await;
                        } else {
                            std::future::pending::<()>().await;
                        }
                    } => None,
                    result = &mut ack => Some(result),
                };
                if early.is_none() {
                    // Bytes read from the closed socket are not the next peer's frame.
                    wire.unread.clear();
                    if let Some(open) = socket.take() {
                        abandon_open_peer(open).await;
                    }
                }
                let result = match early {
                    Some(result) => result,
                    None => ack.await,
                };
                if result.is_err() {
                    if let Some(open) = socket.take() {
                        abandon_open_peer(open).await;
                    }
                    let _ = control.reliable(cancellation).await;
                }
            }
            Err(_) => {
                if let Some(open) = socket.take() {
                    abandon_open_peer(open).await;
                }
                let _ = control.reliable(cancellation).await;
            }
        }
    }
    if let Some(open) = socket.take() {
        abandon_open_peer(open).await;
    }
    jobs.close();
    while let Some(job) = jobs.recv().await {
        let _ = control.cancel_job(job).await;
    }
}
async fn send_job(
    socket: &mut TcpStream,
    control: &Control,
    job: Job,
    id: &mut u64,
    deadline: Instant,
    reservation: &Arc<AdmissionPermit>,
    wire: &mut WireBuf,
) -> Result<Message> {
    match job {
        Job::Vote(q) => rpc(socket, Message::Vote(q), id, control, deadline, wire).await,
        Job::Feature(q) => rpc(socket, Message::Feature(q), id, control, deadline, wire).await,
        Job::Append(q) => rpc(socket, Message::Append(q), id, control, deadline, wire).await,
        Job::Image(offer) => {
            rpc(socket, Message::Begin(offer), id, control, deadline, wire).await?;
            let mut offset = 0;
            while offset < offer.request.descriptor.bytes {
                let call = control.call(
                    Command::Chunk(offer),
                    None,
                    Some(reservation.clone()),
                    deadline,
                );
                tokio::pin!(call);
                // The next image bytes come from the owner. A peer that leaves
                // during that read must not stay connected until the transfer deadline.
                let reply = tokio::select! {
                    biased;
                    _ = peer_socket_closed(
                        socket,
                        &mut wire.unread,
                        control.config.limits.frame_bytes,
                    ) => {
                        wire.unread.clear();
                        return Err(Error::Peer);
                    }
                    result = &mut call => result?,
                };
                let Reply::Message(Message::Chunk {
                    offer: q,
                    offset: o,
                    bytes,
                }) = reply
                else {
                    return Err(Error::Peer);
                };
                if q != offer || o != offset || bytes.is_empty() {
                    return Err(Error::Peer);
                }
                offset = offset.checked_add(bytes.len() as u64).ok_or(Error::Peer)?;
                if offset > offer.request.descriptor.bytes {
                    return Err(Error::Peer);
                }
                rpc(
                    socket,
                    Message::Chunk {
                        offer,
                        offset: o,
                        bytes,
                    },
                    id,
                    control,
                    deadline,
                    wire,
                )
                .await?;
            }
            rpc(socket, Message::Finish(offer), id, control, deadline, wire).await
        }
    }
}
struct IdentitySlot {
    slots: Arc<Vec<AtomicBool>>,
    index: usize,
}
fn configure_peer_socket(socket: &TcpStream) -> Result<()> {
    // A length prefix and a small election/heartbeat body must not wait for
    // the previous segment's delayed ACK before reaching the peer.
    socket.set_nodelay(true)?;
    Ok(())
}
impl Drop for IdentitySlot {
    fn drop(&mut self) {
        self.slots[self.index].store(false, Ordering::Release);
    }
}
async fn serve(
    control: Arc<Control>,
    mut socket: TcpStream,
    _permit: OwnedSemaphorePermit,
    slots: Arc<Vec<AtomicBool>>,
) {
    let _task = Counter::task(&control);
    let _socket_counter = Counter::socket(&control);
    // The socket stays in this function. The session only borrows it, so a
    // hello failure and a later request-loop exit share one close. The peer
    // is reported disconnected only after hello has succeeded.
    let mut claimed: Option<IdentitySlot> = None;
    let source = async {
        if configure_peer_socket(&socket).is_err() {
            return None;
        }
        let mut wire = WireBuf::new();
        let deadline = Instant::now() + Duration::from_millis(control.config.limits.rpc_ms);
        // Frame memory can be exhausted while the peer is already gone. Do not
        // hold this socket until that reservation times out.
        let reservation = tokio::select! {
            biased;
            _ = peer_socket_closed(&mut socket, &mut wire.unread, control.config.limits.frame_bytes) => return None,
            r = control.reserve_frame(deadline) => r,
        };
        let Ok(reservation) = reservation else {
            return None;
        };
        let first = tokio::select! {_ = control.stopping()=>return None,r=read_frame(&mut socket,control.config.limits.frame_bytes,control.config.storage.live_entries,deadline,&mut wire)=>r};
        let Ok(Frame {
            rpc: 0,
            message: Message::Hello(h),
        }) = first
        else {
            return None;
        };
        if h.group != control.config.group || h.target != control.config.bootstrap.local().key() {
            return None;
        }
        let index = control
            .config
            .peers
            .iter()
            .position(|p| p.key() == h.source)?;
        if slots[index]
            .compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire)
            .is_err()
        {
            return None;
        }
        claimed = Some(IdentitySlot { slots, index });
        let source = h.source;
        if write_frame(
            &mut socket,
            &Frame {
                rpc: 0,
                message: Message::HelloAck(h),
            },
            control.config.limits.frame_bytes,
            deadline,
            &mut wire,
        )
        .await
        .is_err()
        {
            return None;
        }
        drop(reservation);
        let mut last_rpc = 0;
        loop {
            let deadline = Instant::now() + Duration::from_millis(control.config.limits.rpc_ms);
            let reservation = tokio::select! {
                biased;
                _ = control.stopping()=>break,
                _ = peer_socket_closed(&mut socket, &mut wire.unread, control.config.limits.frame_bytes) => break,
                r = control.reserve_frame(deadline) => r,
            };
            let Ok(reservation) = reservation else {
                break;
            };
            let frame = tokio::select! {_ = control.stopping()=>break,r=read_frame(&mut socket,control.config.limits.frame_bytes,control.config.storage.live_entries,deadline,&mut wire)=>r};
            let Ok(frame) = frame else {
                break;
            };
            if frame.rpc <= last_rpc || !frame.message.request() {
                break;
            }
            last_rpc = frame.rpc;
            let kind = frame.message.kind();
            let call = control.call(
                Command::Inbound(source, frame.message),
                None,
                Some(reservation.clone()),
                deadline,
            );
            tokio::pin!(call);
            let response = tokio::select! {
                biased;
                // The command can outlive the peer. A close during that wait
                // must drop this socket instead of holding it until the deadline.
                _ = peer_socket_closed(
                    &mut socket,
                    &mut wire.unread,
                    control.config.limits.frame_bytes,
                ) => break,
                result = &mut call => match result {
                    Ok(Reply::Message(message)) => message,
                    _ => Message::Failure {
                        request_kind: kind,
                        code: 1,
                    },
                },
            };
            if control.stopped.load(Ordering::Acquire) || Instant::now() >= deadline {
                break;
            }
            if write_frame(
                &mut socket,
                &Frame {
                    rpc: last_rpc,
                    message: response,
                },
                control.config.limits.frame_bytes,
                deadline,
                &mut wire,
            )
            .await
            .is_err()
            {
                break;
            }
        }
        Some(source)
    }
    .await;
    // Hello never completed, so this connection does not own the peer slot.
    if source.is_none() {
        drop(claimed.take());
    }
    // Finish the write side and yield before drop so a peer blocked in read
    // observes EOF. A rejected length leaves the rest of a flood in the kernel
    // buffer; dropping that socket resets the connection instead.
    let _ = socket.shutdown().await;
    for _ in 0..8 {
        tokio::task::yield_now().await;
    }
    drop(socket);
    if let Some(source) = source {
        let _ = control.reliable(Command::Disconnected(source)).await;
    }
    drop(claimed);
    for _ in 0..8 {
        tokio::task::yield_now().await;
    }
}

// Owner-local test evidence; no production mutable-storage or fault API.
// Its additional bounded temporary encoding/hex envelope is separate from the
// production transport counter and must be recorded in test resource receipts.
#[cfg(test)]
struct TestTrace {
    root: PathBuf,
    file: std::fs::File,
    ordinal: u64,
    disk_bytes: u64,
    last: (usize, usize, bool),
}
#[cfg(test)]
impl TestTrace {
    fn capture_root(paths: &Paths, c: &Config) -> Result<Option<PathBuf>> {
        let Some(base) = std::env::var_os("PL_PEER_RUNTIME_CAPTURE_DIR") else {
            return Ok(None);
        };
        if base.as_encoded_bytes().len() > 4096 {
            return Err(Error::InvalidConfig);
        }
        let case = paths
            .wal
            .parent()
            .and_then(Path::file_name)
            .and_then(|n| n.to_str())
            .ok_or(Error::InvalidConfig)?;
        Ok(Some(PathBuf::from(base).join(format!(
            "{}-{case}-{}",
            std::process::id(),
            c.bootstrap.local().key().id
        ))))
    }
    fn key(key: Key) -> Result<String> {
        Ok(format!(
            "{{\"id\":{},\"directory\":\"{}\"}}",
            key.id,
            Self::hex(&key.directory)?
        ))
    }
    fn descriptor(d: snapshot::Descriptor) -> Result<String> {
        Ok(format!("{{\"generation\":\"{}\",\"base_term\":{},\"base_index\":{},\"records\":{},\"payload_bytes\":{},\"bytes\":{},\"checksum\":{}}}", Self::hex(&d.generation)?, d.base.term, d.base.index, d.records, d.payload_bytes, d.bytes, d.checksum))
    }
    fn open(paths: &Paths, c: &Config, command_queue_capacity: usize) -> Result<Option<Self>> {
        use std::io::Write;
        let Some(base) = std::env::var_os("PL_PEER_RUNTIME_CAPTURE_DIR") else {
            return Ok(None);
        };
        let extra = checked_sum(&[
            product(c.limits.frame_bytes, 6)?,
            product(MAX_CONFIGURATION_BYTES, 2)?,
        ])?;
        if checked_sum(&[c.managed, extra])? > MANAGED_CEILING {
            return Err(Error::InvalidConfig);
        }
        if base.as_encoded_bytes().len() > 4096 {
            return Err(Error::InvalidConfig);
        }
        let local = c.bootstrap.local().key();
        let root = Self::capture_root(paths, c)?.ok_or(Error::InvalidConfig)?;
        std::fs::create_dir_all(&root)?;
        let mut file = std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(root.join("owner.jsonl"))?;
        let source = std::env::var("PL_PEER_RUNTIME_SOURCE_SHA")
            .unwrap_or_else(|_| "unqualified-WORK-draft".into());
        if source.len() > 128
            || source
                .bytes()
                .any(|b| !b.is_ascii_alphanumeric() && b != b'-')
        {
            return Err(Error::InvalidConfig);
        }
        writeln!(file,concat!(
            "{{\"schema_version\":1,\"capture_revision\":2,\"source_sha\":\"{source}\",\"local_id\":{local_id},\"directory\":\"{directory}\",\"genesis_hex\":\"{genesis}\",",
            "\"clock_basis\":\"process-local monotonic Instant; restart begins a new clock epoch\",\"pid\":{pid},",
            "\"trace_layer\":\"exclusive Node owner; typed bodies are not TCP packet captures\",",
            "\"runtime_settings\":{{\"frame_bytes\":{frame_bytes},\"record_bytes\":{record_bytes},\"chunk_bytes\":{chunk_bytes},",
            "\"live_entries\":{live_entries},\"live_bytes\":{live_bytes},\"operations\":{operations},\"wal_bytes\":{wal_bytes},\"fetch_bytes\":{fetch_bytes},",
            "\"image_bytes\":{image_bytes},\"image_records\":{image_records},\"image_record_bytes\":{image_record_bytes},\"image_payload_bytes\":{image_payload_bytes},",
            "\"image_chunk_bytes\":{image_chunk_bytes},\"image_decoded_bytes\":{image_decoded_bytes},\"image_generations\":{image_generations},\"image_disk_bytes\":{image_disk_bytes},",
            "\"peer_count\":{peer_count},\"incoming_slots\":{incoming_slots},\"client_slots\":{client_slots},\"command_queue_capacity\":{command_queue_capacity},",
            "\"peer_mailbox_slots\":1,\"dns_admissions\":0,\"canonical_configuration_max_bytes\":{configuration_max},\"task_bound\":{task_bound},\"socket_bound_with_listener\":{socket_bound},",
            "\"quorum_ms\":{quorum_ms},\"quorum_timeout_ms\":{quorum_ms},\"election_min_ms\":{election_min_ms},\"election_max_ms\":{election_max_ms},",
            "\"tick_ms\":{tick_ms},\"heartbeat_ms\":{heartbeat_ms},\"connect_ms\":{connect_ms},\"rpc_ms\":{rpc_ms},\"transfer_ms\":{transfer_ms},\"command_ms\":{command_ms},",
            "\"transport_charge_bytes\":{charge},\"transport_pool_bytes\":{pool},\"managed_bytes\":{managed},\"managed_ceiling_bytes\":{ceiling},\"extra_test_encode_hex_bytes\":{extra},\"test_resource_observation\":\"constructed RAII ownership high-water counters; excludes acquired-but-unpublished permit window, allocator, RSS and OS buffers\",\"command_owner_bound\":{command_owner_bound},\"test_counter_fixed_bytes\":{test_counter_fixed_bytes}}}}}"
        ),source=source,local_id=local.id,directory=Self::hex(&local.directory)?,genesis=Self::hex(&c.group.genesis)?,pid=std::process::id(),
            frame_bytes=c.limits.frame_bytes,record_bytes=c.storage.record_bytes,chunk_bytes=c.storage.chunk_bytes,
            live_entries=c.storage.live_entries,live_bytes=c.storage.live_bytes,operations=c.storage.operations,wal_bytes=c.storage.wal_bytes,fetch_bytes=c.storage.fetch_bytes,
            image_bytes=c.storage.images.image_bytes(),image_records=c.storage.images.records(),image_record_bytes=c.storage.images.record_bytes(),image_payload_bytes=c.storage.images.payload_bytes(),
            image_chunk_bytes=c.storage.images.chunk_bytes(),image_decoded_bytes=c.storage.images.decoded_bytes(),image_generations=c.storage.images.generations(),image_disk_bytes=c.storage.images.disk_bytes(),
            peer_count=c.peers.len(),incoming_slots=c.limits.incoming,client_slots=c.limits.client_slots,command_queue_capacity=command_queue_capacity,
            configuration_max=MAX_CONFIGURATION_BYTES,task_bound=c.task_bound(),socket_bound=checked_sum(&[1,c.peers.len(),c.limits.incoming])?,
            quorum_ms=c.limits.quorum_ms,election_min_ms=c.limits.election_min_ms,election_max_ms=c.limits.election_max_ms,
            tick_ms=c.limits.tick_ms,heartbeat_ms=c.limits.heartbeat_ms,connect_ms=c.limits.connect_ms,rpc_ms=c.limits.rpc_ms,transfer_ms=c.limits.transfer_ms,command_ms=c.limits.command_ms,
            charge=c.charge,pool=c.pool,managed=c.managed,ceiling=MANAGED_CEILING,extra=extra,
            command_owner_bound=checked_sum(&[product(command_queue_capacity,2)?,1])?,test_counter_fixed_bytes=std::mem::size_of::<TestMetrics>())?;
        file.sync_all()?;
        let disk_bytes = file.metadata()?.len();
        Ok(Some(Self {
            root,
            file,
            ordinal: 0,
            disk_bytes,
            last: (0, 0, false),
        }))
    }
    fn hex(bytes: &[u8]) -> Result<String> {
        use std::fmt::Write;
        let mut out = String::new();
        out.try_reserve_exact(bytes.len().checked_mul(2).ok_or(Error::InvalidConfig)?)
            .map_err(|_| Error::Allocation)?;
        for b in bytes {
            write!(out, "{b:02x}").map_err(|_| Error::Peer)?;
        }
        Ok(out)
    }
    fn body(message: &Message, limit: usize) -> Result<String> {
        let bytes = peer_codec::encode(
            &Frame {
                rpc: 1,
                message: message.clone(),
            },
            limit,
        )?;
        Self::hex(&bytes[24..bytes.len() - 4])
    }
    #[expect(
        clippy::type_complexity,
        reason = "test receipt returns command, optional packet and optional barrier text"
    )]
    fn input(
        command: &Command,
        limit: usize,
    ) -> Result<(String, Option<(u8, String)>, Option<String>)> {
        let name = match command {
            Command::Tick => "tick",
            Command::State => "state",
            Command::Voters => "voters",
            Command::Propose(_) => "propose",
            Command::Position(_) => "position",
            Command::Fetch(..) => "fetch",
            Command::Checkpoint(_) => "checkpoint",
            Command::Prepare(_) => "prepare",
            Command::Inbound(..) => "receive",
            Command::Acknowledge(_) => "ack",
            Command::Timeout(..) => "timeout",
            Command::CancelVote(_) => "cancel-vote",
            Command::Chunk(_) => "image-read",
            Command::Add(_) => "add",
            Command::Addition(_) => "addition-status",
            Command::Remove(_) => "remove",
            Command::Change => "change-status",
            Command::Disconnected(_) => "disconnect",
            Command::Stop => "stop",
        }
        .to_owned();
        let typed = match command {
            Command::Inbound(_, m) | Command::Acknowledge(m) => {
                Some((m.kind(), Self::body(m, limit)?))
            }
            Command::CancelVote(q) => Some((10, Self::body(&Message::Vote(*q), limit)?)),
            _ => None,
        };
        let target = match command {
            Command::Timeout(peer, sequence, image) => Some(format!(
                "{{\"peer\":{},\"sequence\":{sequence},\"image\":{image}}}",
                Self::key(*peer)?
            )),
            Command::Disconnected(peer) => Some(format!("{{\"peer\":{}}}", Self::key(*peer)?)),
            Command::Prepare(peer) | Command::Add(peer) | Command::Remove(peer) => {
                Some(format!("{{\"peer\":{}}}", Self::key(*peer)?))
            }
            _ => None,
        };
        Ok((name, typed, target))
    }
    fn record(
        &mut self,
        owner: &Owner,
        input: (String, Option<(u8, String)>, Option<String>),
        result: &Result<Reply>,
        now: u64,
        paths: &Paths,
    ) -> Result<()> {
        use std::io::Write;
        let s = owner.node.state();
        let counts = (s.wal_durable_ops, s.election_durable_states, s.poisoned);
        let interesting = counts != self.last
            || matches!(
                input.0.as_str(),
                "prepare"
                    | "receive"
                    | "ack"
                    | "timeout"
                    | "cancel-vote"
                    | "disconnect"
                    | "image-read"
                    | "add"
                    | "remove"
                    | "stop"
            );
        if !interesting {
            return Ok(());
        }
        if self.ordinal >= 50000 {
            return Err(Error::InvalidConfig);
        }
        let mut generated = Vec::new();
        if let Ok(reply) = result {
            match reply {
                Reply::Job(Some(j)) => generated.push(match j {
                    Job::Vote(q) => Message::Vote(*q),
                    Job::Feature(q) => Message::Feature(*q),
                    Job::Append(q) => Message::Append(q.clone()),
                    Job::Image(q) => Message::Begin(*q),
                }),
                Reply::Message(m) => generated.push(m.clone()),
                Reply::Votes(jobs) => {
                    for j in jobs {
                        if let Job::Vote(q) = j {
                            generated.push(Message::Vote(*q));
                        }
                    }
                }
                _ => {}
            }
        }
        let command = input.0;
        let target = input.2.unwrap_or_else(|| "null".into());
        let input = match input.1 {
            Some((kind, body)) => format!("{{\"kind\":{kind},\"body_hex\":\"{body}\"}}"),
            None => "null".into(),
        };
        let mut output = String::new();
        for m in generated {
            if !output.is_empty() {
                output.push(',');
            }
            output.push_str(&format!(
                "{{\"kind\":{},\"body_hex\":\"{}\"}}",
                m.kind(),
                Self::body(&m, owner.config.limits.frame_bytes)?
            ));
        }
        let voters = match owner.node.voters() {
            Ok(v) => format!("\"{}\"", Self::hex(&v.encode().map_err(|_| Error::Peer)?)?),
            Err(_) => "null".into(),
        };
        let (vote_available, vote) = match owner.node.voted_directory() {
            Ok(v) => (
                true,
                v.map_or_else(
                    || Ok("null".to_owned()),
                    |k| {
                        Ok::<_, Error>(format!(
                            "{{\"id\":{},\"directory\":\"{}\"}}",
                            k.id,
                            Self::hex(&k.directory)?
                        ))
                    },
                )?,
            ),
            Err(_) => (false, "null".into()),
        };
        let selected = owner
            .node
            .selected_snapshot()
            .ok()
            .flatten()
            .map(Self::descriptor)
            .transpose()?
            .unwrap_or_else(|| "null".into());
        let cleanup = owner.cleanup.as_deref().unwrap_or("null");
        let resources = owner.metrics.json()?;
        let row=format!("{{\"ordinal\":{},\"now_ms\":{now},\"command\":\"{command}\",\"target\":{target},\"cleanup\":{cleanup},\"selected_snapshot\":{selected},\"resource_owners\":{resources},\"input\":{input},\"typed_output\":[{output}],\"result_ok\":{},\"term\":{},\"role\":\"{:?}\",\"ready\":{},\"poisoned\":{},\"last_term\":{},\"last_index\":{},\"committed_end\":{},\"voted_directory_available\":{vote_available},\"voted_for\":{vote},\"configuration_hex\":{voters},\"wal_ops\":{},\"election_states\":{}}}\n",self.ordinal,result.is_ok(),s.election.persistent.term,s.election.role,s.ready,s.poisoned,s.last_position.term,s.last_position.index,s.committed_end,s.wal_durable_ops,s.election_durable_states);
        self.charge(row.len() as u64)?;
        self.file.write_all(row.as_bytes())?;
        self.file.sync_all()?;
        if counts != self.last {
            let root = self.root.join(format!("checkpoint-{}", self.ordinal));
            std::fs::create_dir(&root)?;
            for (source, name) in [
                (&paths.wal, "metadata.wal"),
                (&paths.election, "election.wal"),
            ] {
                self.charge(std::fs::metadata(source)?.len())?;
                std::fs::copy(source, root.join(name))?;
                std::fs::File::open(root.join(name))?.sync_all()?;
            }
            let images = root.join("images");
            std::fs::create_dir(&images)?;
            for entry in std::fs::read_dir(&paths.images)? {
                let entry = entry?;
                if entry.file_type()?.is_file() {
                    self.charge(entry.metadata()?.len())?;
                    let destination = images.join(entry.file_name());
                    std::fs::copy(entry.path(), &destination)?;
                    std::fs::File::open(destination)?.sync_all()?;
                }
            }
            std::fs::File::open(images)?.sync_all()?;
            std::fs::File::open(root)?.sync_all()?;
            self.last = counts;
        }
        self.ordinal += 1;
        Ok(())
    }
    fn charge(&mut self, n: u64) -> Result<()> {
        self.disk_bytes = self.disk_bytes.checked_add(n).ok_or(Error::InvalidConfig)?;
        if self.disk_bytes > 16 * 1024 * 1024 {
            Err(Error::InvalidConfig)
        } else {
            Ok(())
        }
    }
}

#[cfg(test)]
mod tests {
    use crate as partitionline_broker;
    // Run the public TCP scenarios in the unit artifact as well, enabling the
    // owner-local raw/WAL hook without adding a production fault surface.
    include!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/tests/common/raft_runtime.rs"
    ));
}

#[cfg(test)]
mod frame_deadline_tests {
    use super::{read_frame, Error, WireBuf};
    use std::pin::Pin;
    use std::task::{Context, Poll};
    use std::time::Duration;
    use tokio::io::{AsyncRead, AsyncWrite, ReadBuf};
    use tokio::time::Instant;

    struct PendingRead;

    impl AsyncRead for PendingRead {
        fn poll_read(
            self: Pin<&mut Self>,
            _cx: &mut Context<'_>,
            _buf: &mut ReadBuf<'_>,
        ) -> Poll<std::io::Result<()>> {
            Poll::Pending
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn a_run_of_minimum_frames_does_not_hold_the_peer_watch() {
        let frame = {
            let mut one = vec![0u8; 32];
            one[..4].copy_from_slice(&28u32.to_be_bytes());
            one
        };
        let frames = (128 * 1024 * 1024) / frame.len();
        let mut unread = Vec::with_capacity(frames.saturating_mul(frame.len()));
        for _ in 0..frames {
            unread.extend_from_slice(&frame);
        }
        let limit = unread.len();
        let mut socket = PendingRead;
        let started = std::time::Instant::now();
        tokio::select! {
            _ = super::peer_socket_closed(&mut socket, &mut unread, limit) => {}
            _ = tokio::time::sleep(Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < Duration::from_millis(80),
            "scanning peer frames held the command wait for {elapsed:?}"
        );
    }

    struct SlowFrame {
        announced: bool,
        left: usize,
    }

    impl AsyncRead for SlowFrame {
        fn poll_read(
            self: Pin<&mut Self>,
            _cx: &mut Context<'_>,
            buf: &mut ReadBuf<'_>,
        ) -> Poll<std::io::Result<()>> {
            let this = self.get_mut();
            let dst = buf.initialize_unfilled();
            if dst.is_empty() {
                return Poll::Ready(Ok(()));
            }
            if !this.announced {
                this.announced = true;
                let len = u32::try_from(this.left).unwrap_or(u32::MAX).to_be_bytes();
                let n = len.len().min(dst.len());
                dst[..n].copy_from_slice(&len[..n]);
                buf.advance(n);
                return Poll::Ready(Ok(()));
            }
            if this.left == 0 {
                return Poll::Pending;
            }
            let n = dst.len().min(this.left).min(1024);
            dst[..n].fill(4);
            buf.advance(n);
            this.left -= n;
            let start = std::time::Instant::now();
            while start.elapsed() < Duration::from_micros(200) {}
            Poll::Ready(Ok(()))
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn read_deadline_stops_a_ready_peer_frame() {
        let mut socket = SlowFrame {
            announced: false,
            left: 512 * 1024,
        };
        let mut wire = WireBuf::new();
        let started = Instant::now();
        let result = read_frame(
            &mut socket,
            2 * 1024 * 1024,
            1024,
            Instant::now() + Duration::from_millis(30),
            &mut wire,
        )
        .await;
        let elapsed = started.elapsed();
        let deadline = matches!(result, Err(Error::Deadline));
        assert!(
            deadline && elapsed < Duration::from_millis(80),
            "a ready peer frame held the read past its deadline: {elapsed:?} deadline {deadline}"
        );
    }

    /// A legal-length body that fills whatever spare capacity the read offered.
    struct GreedyFrame {
        announced: bool,
        left: usize,
    }

    impl AsyncRead for GreedyFrame {
        fn poll_read(
            self: Pin<&mut Self>,
            _cx: &mut Context<'_>,
            buf: &mut ReadBuf<'_>,
        ) -> Poll<std::io::Result<()>> {
            let this = self.get_mut();
            let dst = buf.initialize_unfilled();
            if dst.is_empty() {
                return Poll::Ready(Ok(()));
            }
            if !this.announced {
                this.announced = true;
                let len = u32::try_from(this.left).unwrap_or(u32::MAX).to_be_bytes();
                let n = len.len().min(dst.len());
                dst[..n].copy_from_slice(&len[..n]);
                buf.advance(n);
                return Poll::Ready(Ok(()));
            }
            if this.left == 0 {
                return Poll::Pending;
            }
            let n = dst.len().min(this.left);
            dst[..n].fill(4);
            buf.advance(n);
            this.left -= n;
            let units = u32::try_from(n.div_ceil(1024)).unwrap_or(u32::MAX);
            let start = std::time::Instant::now();
            while start.elapsed() < Duration::from_millis(2).saturating_mul(units) {}
            Poll::Ready(Ok(()))
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn read_deadline_stops_a_greedy_peer_frame() {
        let mut socket = GreedyFrame {
            announced: false,
            left: 64 * 1024,
        };
        let mut wire = WireBuf::new();
        let started = Instant::now();
        let result = read_frame(
            &mut socket,
            2 * 1024 * 1024,
            1024,
            Instant::now() + Duration::from_millis(40),
            &mut wire,
        )
        .await;
        let elapsed = started.elapsed();
        let deadline = matches!(result, Err(Error::Deadline));
        assert!(
            deadline && elapsed < Duration::from_millis(80),
            "a greedy peer frame held the read past its deadline: {elapsed:?} deadline {deadline}"
        );
    }

    struct SlowSink;

    impl AsyncWrite for SlowSink {
        fn poll_write(
            self: Pin<&mut Self>,
            _cx: &mut Context<'_>,
            buf: &[u8],
        ) -> Poll<std::io::Result<usize>> {
            if buf.is_empty() {
                return Poll::Ready(Ok(0));
            }
            let start = std::time::Instant::now();
            while start.elapsed() < Duration::from_millis(3) {}
            Poll::Ready(Ok(1))
        }

        fn poll_flush(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<std::io::Result<()>> {
            Poll::Ready(Ok(()))
        }

        fn poll_shutdown(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<std::io::Result<()>> {
            Poll::Ready(Ok(()))
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn write_deadline_stops_a_ready_peer_frame() {
        use super::super::membership::Key;
        use super::super::peer_codec::{Frame, Group, Hello, Message};

        let key = Key::new(1, [1; 16]).unwrap_or_else(|error| panic!("{error}"));
        let frame = Frame {
            rpc: 0,
            message: Message::Hello(Hello {
                source: key,
                target: key,
                group: Group {
                    cluster: "c".to_string(),
                    topic: "t".to_string(),
                    partition: 0,
                    genesis: vec![1],
                },
            }),
        };
        let mut wire = WireBuf::new();
        let started = Instant::now();
        let result = super::write_frame(
            &mut SlowSink,
            &frame,
            1024 * 1024,
            Instant::now() + Duration::from_millis(30),
            &mut wire,
        )
        .await;
        let elapsed = started.elapsed();
        let deadline = matches!(result, Err(Error::Deadline));
        assert!(
            deadline && elapsed < Duration::from_millis(80),
            "a ready peer write held the frame past its deadline: {elapsed:?} deadline {deadline}"
        );
    }

    /// Accepts every offered byte and spends time in proportion to that copy.
    struct GreedySink;

    impl AsyncWrite for GreedySink {
        fn poll_write(
            self: Pin<&mut Self>,
            _cx: &mut Context<'_>,
            buf: &[u8],
        ) -> Poll<std::io::Result<usize>> {
            if buf.is_empty() {
                return Poll::Ready(Ok(0));
            }
            let units = u32::try_from(buf.len().div_ceil(1024)).unwrap_or(u32::MAX);
            let start = std::time::Instant::now();
            while start.elapsed() < Duration::from_millis(2).saturating_mul(units) {}
            Poll::Ready(Ok(buf.len()))
        }

        fn poll_flush(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<std::io::Result<()>> {
            Poll::Ready(Ok(()))
        }

        fn poll_shutdown(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<std::io::Result<()>> {
            Poll::Ready(Ok(()))
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn write_deadline_stops_a_greedy_peer_frame() {
        use super::super::election::LogPosition;
        use super::super::membership::Key;
        use super::super::peer_codec::{Frame, Message};
        use super::super::replication::{Context, DynamicSnapshotRequest, SnapshotRequest};
        use super::super::snapshot::Descriptor;

        let key = Key::new(1, [1; 16]).unwrap_or_else(|error| panic!("{error}"));
        let frame = Frame {
            rpc: 1,
            message: Message::Chunk {
                offer: DynamicSnapshotRequest {
                    context: Context {
                        leader: key,
                        peer: key,
                        configuration_epoch: 0,
                    },
                    request: SnapshotRequest {
                        leader: key.id,
                        peer: key.id,
                        sequence: 1,
                        term: 2,
                        leader_commit: 1,
                        descriptor: Descriptor {
                            generation: [1; 16],
                            base: LogPosition { term: 1, index: 1 },
                            records: 1,
                            payload_bytes: 0,
                            bytes: 64,
                            checksum: 1,
                        },
                    },
                },
                offset: 0,
                bytes: vec![9u8; 64 * 1024],
            },
        };
        let mut wire = WireBuf::new();
        let started = Instant::now();
        let result = super::write_frame(
            &mut GreedySink,
            &frame,
            2 * 1024 * 1024,
            Instant::now() + Duration::from_millis(40),
            &mut wire,
        )
        .await;
        let elapsed = started.elapsed();
        let deadline = matches!(result, Err(Error::Deadline));
        assert!(
            deadline && elapsed < Duration::from_millis(80),
            "a greedy peer write held the frame past its deadline: {elapsed:?} deadline {deadline}"
        );
    }

    struct PendingWrite;

    impl AsyncWrite for PendingWrite {
        fn poll_write(
            self: Pin<&mut Self>,
            _cx: &mut Context<'_>,
            _buf: &[u8],
        ) -> Poll<std::io::Result<usize>> {
            Poll::Pending
        }

        fn poll_flush(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<std::io::Result<()>> {
            Poll::Ready(Ok(()))
        }

        fn poll_shutdown(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<std::io::Result<()>> {
            Poll::Ready(Ok(()))
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn an_illegal_length_already_buffered_ends_the_peer_write() {
        use super::super::membership::Key;
        use super::super::peer_codec::{Frame, Group, Hello, Message};

        let key = Key::new(1, [1; 16]).unwrap_or_else(|error| panic!("{error}"));
        let frame = Frame {
            rpc: 0,
            message: Message::Hello(Hello {
                source: key,
                target: key,
                group: Group {
                    cluster: "c".to_string(),
                    topic: "t".to_string(),
                    partition: 0,
                    genesis: vec![1],
                },
            }),
        };
        let mut wire = WireBuf::new();
        wire.unread.extend_from_slice(&28u32.to_be_bytes());
        wire.unread.extend_from_slice(&[0u8; 28]);
        wire.unread.extend_from_slice(&1u32.to_be_bytes());
        let result = tokio::time::timeout(
            Duration::from_millis(200),
            super::write_frame(
                &mut PendingWrite,
                &frame,
                1024 * 1024,
                Instant::now() + Duration::from_secs(5),
                &mut wire,
            ),
        )
        .await;
        assert!(
            matches!(result, Ok(Err(Error::Peer))),
            "an illegal length already buffered waited out the peer write"
        );
    }

    struct ReadyFlood {
        left: usize,
    }

    impl AsyncRead for ReadyFlood {
        fn poll_read(
            self: Pin<&mut Self>,
            _cx: &mut Context<'_>,
            buf: &mut ReadBuf<'_>,
        ) -> Poll<std::io::Result<()>> {
            let this = self.get_mut();
            if this.left == 0 {
                return Poll::Pending;
            }
            let dst = buf.initialize_unfilled();
            if dst.is_empty() {
                return Poll::Ready(Ok(()));
            }
            let n = dst.len().min(this.left).min(1024);
            dst[..n].fill(5);
            buf.advance(n);
            this.left -= n;
            let start = std::time::Instant::now();
            while start.elapsed() < Duration::from_micros(200) {}
            Poll::Ready(Ok(()))
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn a_ready_peer_flood_does_not_hold_the_command_wait() {
        let mut socket = ReadyFlood { left: 512 * 1024 };
        let mut unread = Vec::new();
        let started = Instant::now();
        tokio::select! {
            biased;
            _ = super::peer_socket_closed(&mut socket, &mut unread, 1024 * 1024) => {}
            _ = tokio::time::sleep(Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < Duration::from_millis(80),
            "a ready peer flood held the command wait: {elapsed:?}"
        );
    }

    struct IllegalLen {
        sent: bool,
    }

    impl AsyncRead for IllegalLen {
        fn poll_read(
            self: Pin<&mut Self>,
            _cx: &mut Context<'_>,
            buf: &mut ReadBuf<'_>,
        ) -> Poll<std::io::Result<()>> {
            let this = self.get_mut();
            if this.sent {
                return Poll::Pending;
            }
            let dst = buf.initialize_unfilled();
            if dst.len() < 4 {
                return Poll::Pending;
            }
            dst[..4].copy_from_slice(&1u32.to_be_bytes());
            buf.advance(4);
            this.sent = true;
            Poll::Ready(Ok(()))
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn an_illegal_peer_length_ends_the_idle_read() {
        let mut socket = IllegalLen { sent: false };
        let mut unread = Vec::new();
        let result = tokio::time::timeout(
            Duration::from_millis(200),
            super::peer_socket_closed(&mut socket, &mut unread, 1024 * 1024),
        )
        .await;
        assert!(
            result.is_ok(),
            "an illegal peer length left the idle read parked"
        );
    }

    /// A finished minimum frame, then a length below the minimum.
    struct IllegalLenAfterFrame {
        sent: bool,
    }

    impl AsyncRead for IllegalLenAfterFrame {
        fn poll_read(
            self: Pin<&mut Self>,
            _cx: &mut Context<'_>,
            buf: &mut ReadBuf<'_>,
        ) -> Poll<std::io::Result<()>> {
            let this = self.get_mut();
            if this.sent {
                return Poll::Pending;
            }
            let dst = buf.initialize_unfilled();
            if dst.len() < 36 {
                return Poll::Pending;
            }
            dst[..4].copy_from_slice(&28u32.to_be_bytes());
            dst[4..32].fill(0);
            dst[32..36].copy_from_slice(&1u32.to_be_bytes());
            buf.advance(36);
            this.sent = true;
            Poll::Ready(Ok(()))
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn an_illegal_length_after_a_frame_ends_the_idle_read() {
        let mut socket = IllegalLenAfterFrame { sent: false };
        let mut unread = Vec::new();
        let result = tokio::time::timeout(
            Duration::from_millis(200),
            super::peer_socket_closed(&mut socket, &mut unread, 1024 * 1024),
        )
        .await;
        assert!(
            result.is_ok(),
            "an illegal length after a frame left the idle read parked"
        );
    }
}

#[cfg(test)]
mod ownership_tests {
    use super::super::membership::{Endpoint, Voters};
    use super::*;

    type TestResult<T = ()> = std::result::Result<T, Box<dyn std::error::Error + Send + Sync>>;

    #[tokio::test(flavor = "current_thread")]
    async fn abandoned_peer_socket_is_closed_before_the_caller_returns() -> TestResult {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use std::sync::Arc;
        use tokio::io::AsyncReadExt;

        let listener = TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let open = Arc::new(AtomicUsize::new(0));
        let open_flag = Arc::clone(&open);
        let peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = listener.accept().await else {
                return;
            };
            let _started = open_flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = open_flag.fetch_sub(1, Ordering::SeqCst);
        });
        let socket = TcpStream::connect(address).await?;
        while open.load(Ordering::SeqCst) == 0 {
            tokio::task::yield_now().await;
        }
        abandon_peer_socket(socket).await;
        if open.load(Ordering::SeqCst) != 0 {
            return Err("abandoned peer socket still blocked in a read".into());
        }
        peer.abort();
        Ok(())
    }

    #[tokio::test(flavor = "current_thread")]
    async fn abandoned_peer_socket_ends_a_flooded_read() -> TestResult {
        let listener = TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let socket = TcpStream::connect(address).await?;
        let (peer, _) = listener.accept().await?;
        let (mut reader, writer) = peer.into_split();
        // A zero length is not a frame. Leave it unread in the socket we are
        // about to drop. Dropping that unread data resets the peer.
        let flood = vec![0u8; 64 * 1024];
        let mut wrote = 0usize;
        while wrote < flood.len() {
            writer.writable().await.map_err(|_| "flood writable")?;
            let rest = flood.get(wrote..).ok_or("flood range")?;
            match writer.try_write(rest) {
                Ok(0) => break,
                Ok(n) => wrote = wrote.saturating_add(n),
                Err(e) if e.kind() == std::io::ErrorKind::WouldBlock && wrote >= 4 => break,
                Err(_) => return Err("flood write".into()),
            }
        }
        if wrote < 4 {
            return Err("flood did not reach the socket buffer".into());
        }
        let mut waiting = [0u8; 4];
        let arrived = tokio::time::timeout(Duration::from_millis(300), socket.peek(&mut waiting))
            .await
            .map_err(|_| "flood was not queued")?
            .map_err(|_| "peek flood")?;
        if arrived < 4 {
            return Err("flood was not unread".into());
        }
        abandon_peer_socket(socket).await;
        let mut buf = [0u8; 8];
        let saw = tokio::time::timeout(
            Duration::from_millis(300),
            tokio::io::AsyncReadExt::read(&mut reader, &mut buf),
        )
        .await;
        drop(writer);
        match saw {
            Ok(Ok(0)) => Ok(()),
            _ => Err("abandoned socket reset a flooded peer".into()),
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn serve_closes_the_socket_when_frame_admission_fails() -> TestResult {
        use super::super::membership::{Bootstrap, Endpoint, Key, Voter, Voters};
        use super::super::protocol;
        use super::super::snapshot;
        use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
        use std::sync::Arc;
        use tokio::io::AsyncReadExt;
        use tokio::sync::{mpsc, watch, Notify, Semaphore};

        let listener = TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let open = Arc::new(AtomicUsize::new(0));
        let open_flag = Arc::clone(&open);
        let peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = listener.accept().await else {
                return;
            };
            let _started = open_flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = open_flag.fetch_sub(1, Ordering::SeqCst);
        });
        let peer_addr = "127.0.0.1:10".parse::<std::net::SocketAddr>()?;
        let local = Voter::new(
            Key::new(0, [1; 16])?,
            vec![Endpoint::new("CONTROLLER".into(), "127.0.0.1".into(), 9)?],
            0,
            1,
        )?;
        let remote = Voter::new(
            Key::new(1, [2; 16])?,
            vec![Endpoint::new("CONTROLLER".into(), "127.0.0.1".into(), 10)?],
            0,
            1,
        )?;
        let genesis = Voters::new(0, Default::default(), 1, vec![local.clone()])?;
        let bootstrap = Bootstrap::new(local, genesis, "CONTROLLER".into())?;
        let routes = vec![Peer::new(remote, peer_addr)?];
        let mut controller = protocol::Config::new(0, vec![0], "private-serve-stop".into())?;
        controller.timer_seed = 1;
        let storage = StorageLimits {
            record_bytes: 64 * 1024,
            chunk_bytes: 256 * 1024,
            live_entries: 64,
            live_bytes: 1024 * 1024,
            operations: 4096,
            wal_bytes: 8 * 1024 * 1024,
            fetch_bytes: 256 * 1024,
            images: snapshot::Limits::new(
                2 * 1024 * 1024,
                64,
                1024 * 1024,
                64 * 1024,
                32 * 1024,
                8,
                32,
            )?,
        };
        let limits = Limits {
            incoming: 1,
            client_slots: 4,
            frame_bytes: 512 * 1024,
            election_min_ms: 80,
            election_max_ms: 160,
            quorum_ms: 1500,
            tick_ms: 10,
            heartbeat_ms: 40,
            connect_ms: 250,
            rpc_ms: 500,
            transfer_ms: 1000,
            command_ms: 3000,
        };
        let config = Arc::new(Config::new(controller, bootstrap, routes, storage, limits)?);
        let bytes = Arc::new(Semaphore::new(0));
        bytes.close();
        let (_commands_tx, _commands_rx) = mpsc::channel(1);
        let (_ready_tx, ready_rx) = watch::channel(0u8);
        let control = Arc::new(Control {
            stopped: AtomicBool::new(false),
            notify: Notify::new(),
            commands: _commands_tx,
            clients: Arc::new(Semaphore::new(config.limits.client_slots)),
            bytes,
            startup: ready_rx,
            tasks: AtomicUsize::new(0),
            sockets: AtomicUsize::new(0),
            metrics: Arc::new(TestMetrics::default()),
            capture_root: None,
            config,
        });
        let socket = TcpStream::connect(address).await?;
        while open.load(Ordering::SeqCst) == 0 {
            tokio::task::yield_now().await;
        }
        let permit = Arc::new(Semaphore::new(1))
            .acquire_owned()
            .await
            .map_err(|_| "incoming permit closed")?;
        serve(control, socket, permit, Arc::new(Vec::new())).await;
        if open.load(Ordering::SeqCst) != 0 {
            return Err("serve left the accepted socket blocked in a read".into());
        }
        peer.abort();
        Ok(())
    }

    #[tokio::test(flavor = "current_thread")]
    async fn serve_closes_when_the_peer_leaves_during_frame_admission() -> TestResult {
        use super::super::membership::{Bootstrap, Endpoint, Key, Voter, Voters};
        use super::super::protocol;
        use super::super::snapshot;

        let listener = TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let peer_addr = "127.0.0.1:10".parse::<std::net::SocketAddr>()?;
        let local = Voter::new(
            Key::new(0, [1; 16])?,
            vec![Endpoint::new("CONTROLLER".into(), "127.0.0.1".into(), 9)?],
            0,
            1,
        )?;
        let remote = Voter::new(
            Key::new(1, [2; 16])?,
            vec![Endpoint::new("CONTROLLER".into(), "127.0.0.1".into(), 10)?],
            0,
            1,
        )?;
        let genesis = Voters::new(0, Default::default(), 1, vec![local.clone()])?;
        let bootstrap = Bootstrap::new(local, genesis, "CONTROLLER".into())?;
        let routes = vec![Peer::new(remote, peer_addr)?];
        let mut controller = protocol::Config::new(0, vec![0], "private-serve-stop".into())?;
        controller.timer_seed = 1;
        let storage = StorageLimits {
            record_bytes: 64 * 1024,
            chunk_bytes: 256 * 1024,
            live_entries: 64,
            live_bytes: 1024 * 1024,
            operations: 4096,
            wal_bytes: 8 * 1024 * 1024,
            fetch_bytes: 256 * 1024,
            images: snapshot::Limits::new(
                2 * 1024 * 1024,
                64,
                1024 * 1024,
                64 * 1024,
                32 * 1024,
                8,
                32,
            )?,
        };
        let limits = Limits {
            incoming: 1,
            client_slots: 4,
            frame_bytes: 512 * 1024,
            election_min_ms: 80,
            election_max_ms: 160,
            quorum_ms: 1500,
            tick_ms: 10,
            heartbeat_ms: 40,
            connect_ms: 250,
            rpc_ms: 500,
            transfer_ms: 1000,
            command_ms: 3000,
        };
        let config = Arc::new(Config::new(controller, bootstrap, routes, storage, limits)?);
        let (_commands_tx, _commands_rx) = mpsc::channel(1);
        let (_ready_tx, ready_rx) = watch::channel(0u8);
        let control = Arc::new(Control {
            stopped: AtomicBool::new(false),
            notify: Notify::new(),
            commands: _commands_tx,
            clients: Arc::new(Semaphore::new(config.limits.client_slots)),
            bytes: Arc::new(Semaphore::new(0)),
            startup: ready_rx,
            tasks: AtomicUsize::new(0),
            sockets: AtomicUsize::new(0),
            metrics: Arc::new(TestMetrics::default()),
            capture_root: None,
            config,
        });
        let served = tokio::spawn(async move {
            let socket = TcpStream::connect(address).await?;
            let permit = Arc::new(Semaphore::new(1))
                .acquire_owned()
                .await
                .map_err(|_| std::io::Error::other("incoming permit closed"))?;
            serve(control, socket, permit, Arc::new(Vec::new())).await;
            Ok::<_, std::io::Error>(())
        });
        let (mut peer, _) = listener.accept().await?;
        tokio::time::sleep(Duration::from_millis(30)).await;
        peer.shutdown().await.map_err(|_| "shutdown write")?;
        let mut buf = [0u8; 8];
        let saw = tokio::time::timeout(
            Duration::from_millis(300),
            tokio::io::AsyncReadExt::read(&mut peer, &mut buf),
        )
        .await;
        served.abort();
        match saw {
            Ok(Ok(0)) => Ok(()),
            _ => Err("serve kept the socket while frame admission waited".into()),
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn serve_returns_when_the_peer_closes_during_a_command() -> TestResult {
        let owner = LocalOwner::open(0, 2, 16).await?;
        let (envelope, _reply, entered, release) = gate(Command::Tick);
        owner
            .control
            .commands
            .send(envelope)
            .await
            .map_err(|_| "gate admission")?;
        let _entered = entered.await?;
        let listener = TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let control = owner.control.clone();
        let served = tokio::spawn(async move {
            let (server, _) = listener.accept().await?;
            let slots = Arc::new(
                control
                    .config
                    .peers
                    .iter()
                    .map(|_| AtomicBool::new(false))
                    .collect::<Vec<_>>(),
            );
            let permit = Arc::new(Semaphore::new(1))
                .acquire_owned()
                .await
                .map_err(|_| std::io::Error::other("incoming permit closed"))?;
            serve(control, server, permit, slots).await;
            Ok::<_, std::io::Error>(())
        });
        let mut client_socket = TcpStream::connect(address).await?;
        let peer_key = owner.control.config.peers.first().ok_or("peer")?.key();
        let local_key = owner.control.config.bootstrap.local().key();
        let group = owner.control.config.group.clone();
        let bound = owner.control.config.limits.frame_bytes;
        let mut wire = WireBuf::new();
        let deadline = Instant::now() + Duration::from_secs(2);
        let hello = Hello {
            source: peer_key,
            target: local_key,
            group,
        };
        write_frame(
            &mut client_socket,
            &Frame {
                rpc: 0,
                message: Message::Hello(hello.clone()),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        let response = read_frame(&mut client_socket, bound, 64, deadline, &mut wire).await?;
        if response.message != Message::HelloAck(hello.clone()) {
            return Err("hello was not acknowledged".into());
        }
        let request = replication::DynamicVoteRequest {
            context: replication::Context {
                leader: peer_key,
                peer: local_key,
                configuration_epoch: 0,
            },
            sequence: 1,
            request: super::super::election::VoteRequest {
                term: 2,
                candidate: peer_key.id,
                log: LogPosition::default(),
            },
        };
        write_frame(
            &mut client_socket,
            &Frame {
                rpc: 1,
                message: Message::Vote(request),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        write_frame(
            &mut client_socket,
            &Frame {
                rpc: 2,
                message: Message::Vote(replication::DynamicVoteRequest {
                    context: replication::Context {
                        leader: peer_key,
                        peer: local_key,
                        configuration_epoch: 0,
                    },
                    sequence: 2,
                    request: super::super::election::VoteRequest {
                        term: 2,
                        candidate: peer_key.id,
                        log: LogPosition::default(),
                    },
                }),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        client_socket
            .shutdown()
            .await
            .map_err(|_| "shutdown write")?;
        let mut buf = [0u8; 8];
        let saw = tokio::time::timeout(
            Duration::from_millis(300),
            tokio::io::AsyncReadExt::read(&mut client_socket, &mut buf),
        )
        .await;
        let _ = release.send(());
        served.abort();
        match saw {
            Ok(Ok(0)) => Ok(()),
            _ => Err("serve kept the socket while the peer had already closed".into()),
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn serve_closes_when_a_command_is_flooded() -> TestResult {
        let owner = LocalOwner::open(0, 2, 16).await?;
        let (envelope, _reply, entered, release) = gate(Command::Tick);
        owner
            .control
            .commands
            .send(envelope)
            .await
            .map_err(|_| "gate admission")?;
        let _entered = entered.await?;
        let listener = TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let control = owner.control.clone();
        let served = tokio::spawn(async move {
            let (server, _) = listener.accept().await?;
            let slots = Arc::new(
                control
                    .config
                    .peers
                    .iter()
                    .map(|_| AtomicBool::new(false))
                    .collect::<Vec<_>>(),
            );
            let permit = Arc::new(Semaphore::new(1))
                .acquire_owned()
                .await
                .map_err(|_| std::io::Error::other("incoming permit closed"))?;
            serve(control, server, permit, slots).await;
            Ok::<_, std::io::Error>(())
        });
        let mut client_socket = TcpStream::connect(address).await?;
        let peer_key = owner.control.config.peers.first().ok_or("peer")?.key();
        let local_key = owner.control.config.bootstrap.local().key();
        let group = owner.control.config.group.clone();
        let bound = owner.control.config.limits.frame_bytes;
        let mut wire = WireBuf::new();
        let deadline = Instant::now() + Duration::from_secs(2);
        let hello = Hello {
            source: peer_key,
            target: local_key,
            group,
        };
        write_frame(
            &mut client_socket,
            &Frame {
                rpc: 0,
                message: Message::Hello(hello.clone()),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        let response = read_frame(&mut client_socket, bound, 64, deadline, &mut wire).await?;
        if response.message != Message::HelloAck(hello) {
            return Err("hello was not acknowledged".into());
        }
        let request = replication::DynamicVoteRequest {
            context: replication::Context {
                leader: peer_key,
                peer: local_key,
                configuration_epoch: 0,
            },
            sequence: 1,
            request: super::super::election::VoteRequest {
                term: 2,
                candidate: peer_key.id,
                log: LogPosition::default(),
            },
        };
        write_frame(
            &mut client_socket,
            &Frame {
                rpc: 1,
                message: Message::Vote(request),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        let (mut reader, mut writer) = client_socket.into_split();
        // Hold the write half open. Dropping it would look like a disconnect
        // and close the socket without a flood bound.
        let flood = vec![0u8; bound.saturating_add(1)];
        let wrote = writer.write_all(&flood).await;
        let mut buf = [0u8; 8];
        let saw = tokio::time::timeout(
            Duration::from_millis(300),
            tokio::io::AsyncReadExt::read(&mut reader, &mut buf),
        )
        .await;
        let _ = release.send(());
        drop(writer);
        served.abort();
        match (wrote, saw) {
            (_, Ok(Ok(0))) => Ok(()),
            _ => Err("serve kept the socket while a command was flooded".into()),
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn serve_closes_when_hello_is_flooded() -> TestResult {
        let owner = LocalOwner::open(0, 2, 16).await?;
        let listener = TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let control = owner.control.clone();
        let served = tokio::spawn(async move {
            let (server, _) = listener.accept().await?;
            let slots = Arc::new(
                control
                    .config
                    .peers
                    .iter()
                    .map(|_| AtomicBool::new(false))
                    .collect::<Vec<_>>(),
            );
            let permit = Arc::new(Semaphore::new(1))
                .acquire_owned()
                .await
                .map_err(|_| std::io::Error::other("incoming permit closed"))?;
            serve(control, server, permit, slots).await;
            Ok::<_, std::io::Error>(())
        });
        let client_socket = TcpStream::connect(address).await?;
        let bound = owner.control.config.limits.frame_bytes;
        let (mut reader, mut writer) = client_socket.into_split();
        // A zero length is rejected after the first read. The rest stays in
        // the kernel buffer, so dropping the socket without a write shutdown
        // resets the peer instead of ending the read.
        let flood = vec![0u8; bound.saturating_add(1)];
        let wrote = writer.write_all(&flood).await;
        let mut buf = [0u8; 8];
        let saw = tokio::time::timeout(
            Duration::from_millis(300),
            tokio::io::AsyncReadExt::read(&mut reader, &mut buf),
        )
        .await;
        drop(writer);
        served.abort();
        match (wrote, saw) {
            (_, Ok(Ok(0))) => Ok(()),
            _ => Err("serve reset the socket while hello was flooded".into()),
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn outbound_closes_when_the_peer_leaves_during_acknowledge() -> TestResult {
        let owner = LocalOwner::open(0, 2, 16).await?;
        let listener = TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let voter = Voter::new(
            Key::new(1, [2; 16])?,
            vec![Endpoint::new(
                "CONTROLLER".into(),
                "127.0.0.1".into(),
                6001,
            )?],
            0,
            1,
        )?;
        let peer = Peer::new(voter, address)?;
        let peer_key = peer.key();
        let local_key = owner.control.config.bootstrap.local().key();
        let (tx, rx) = mpsc::channel(1);
        let control = owner.control.clone();
        let running = tokio::spawn(async move {
            outbound(control, peer, rx).await;
        });
        let request = replication::DynamicVoteRequest {
            context: replication::Context {
                leader: local_key,
                peer: peer_key,
                configuration_epoch: 0,
            },
            sequence: 1,
            request: super::super::election::VoteRequest {
                term: 2,
                candidate: local_key.id,
                log: LogPosition::default(),
            },
        };
        tx.send(Job::Vote(request)).await.map_err(|_| "send vote")?;
        let (mut socket, _) = listener.accept().await?;
        let bound = owner.control.config.limits.frame_bytes;
        let mut wire = WireBuf::new();
        let deadline = Instant::now() + Duration::from_secs(2);
        let hello = read_frame(&mut socket, bound, 64, deadline, &mut wire).await?;
        let Message::Hello(hello) = hello.message else {
            return Err("hello".into());
        };
        write_frame(
            &mut socket,
            &Frame {
                rpc: 0,
                message: Message::HelloAck(hello),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        let vote = read_frame(&mut socket, bound, 64, deadline, &mut wire).await?;
        let Message::Vote(vote_request) = vote.message else {
            return Err("vote".into());
        };
        let (envelope, _reply, entered, release) = gate(Command::State);
        owner
            .control
            .commands
            .send(envelope)
            .await
            .map_err(|_| "gate admission")?;
        let _entered = entered.await?;
        write_frame(
            &mut socket,
            &Frame {
                rpc: vote.rpc,
                message: Message::VoteReply(replication::DynamicVoteResponse {
                    request: vote_request,
                    response: super::super::election::VoteResponse {
                        term: vote_request.request.term,
                        voter: vote_request.context.peer.id,
                        candidate: vote_request.request.candidate,
                        granted: false,
                    },
                }),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        let mut buf = [0u8; 8];
        let still_open = tokio::time::timeout(
            Duration::from_millis(30),
            tokio::io::AsyncReadExt::read(&mut socket, &mut buf),
        )
        .await;
        if still_open.is_ok() {
            let _ = release.send(());
            running.abort();
            return Err("outbound dropped the socket before the peer closed".into());
        }
        socket.shutdown().await.map_err(|_| "shutdown write")?;
        let saw = tokio::time::timeout(
            Duration::from_millis(300),
            tokio::io::AsyncReadExt::read(&mut socket, &mut buf),
        )
        .await;
        let _ = release.send(());
        running.abort();
        match saw {
            Ok(Ok(0)) => Ok(()),
            _ => Err("outbound kept the socket while the peer had already closed".into()),
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn outbound_closes_when_the_peer_leaves_between_jobs() -> TestResult {
        let owner = LocalOwner::open_profile(0, 5, 5, 16, StorageLimits::standard()?, 1000).await?;
        let voter = LocalOwner::open(1, 5, 16).await?;
        tokio::time::sleep(Duration::from_millis(3)).await;
        let jobs = match owner.control.reliable(Command::Tick).await? {
            Reply::Votes(jobs) => jobs,
            _ => return Err("campaign".into()),
        };
        let request = jobs
            .into_iter()
            .find_map(|job| match job {
                Job::Vote(q) if q.context.peer.id == 1 => Some(q),
                _ => None,
            })
            .ok_or("vote for peer 1")?;
        let before = owner.state().await?.election.granted_votes;
        let granted = grant(&voter, request).await?;
        let Message::VoteReply(granted) = granted else {
            return Err("genuine vote reply".into());
        };
        let listener = TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let route = Peer::new(voter.control.config.bootstrap.local().clone(), address)?;
        let (tx, rx) = mpsc::channel(1);
        let control = owner.control.clone();
        let running = tokio::spawn(async move {
            outbound(control, route, rx).await;
        });
        tokio::time::sleep(Duration::from_millis(20)).await;
        tx.send(Job::Vote(request)).await.map_err(|_| "send vote")?;
        let (mut socket, _) = tokio::time::timeout(Duration::from_secs(2), listener.accept())
            .await
            .map_err(|_| "outbound did not connect")??;
        let bound = owner.control.config.limits.frame_bytes;
        let mut wire = WireBuf::new();
        let deadline = Instant::now() + Duration::from_secs(2);
        let hello = read_frame(&mut socket, bound, 64, deadline, &mut wire).await?;
        let Message::Hello(hello) = hello.message else {
            return Err("hello".into());
        };
        write_frame(
            &mut socket,
            &Frame {
                rpc: 0,
                message: Message::HelloAck(hello),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        let vote = read_frame(&mut socket, bound, 64, deadline, &mut wire).await?;
        let Message::Vote(vote_request) = vote.message else {
            return Err("vote".into());
        };
        if vote_request != granted.request {
            running.abort();
            return Err("wire vote did not match the campaign".into());
        }
        write_frame(
            &mut socket,
            &Frame {
                rpc: vote.rpc,
                message: Message::VoteReply(granted),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        let wait_grant = Instant::now() + Duration::from_millis(500);
        loop {
            if owner.state().await?.election.granted_votes > before {
                break;
            }
            if Instant::now() >= wait_grant {
                running.abort();
                return Err("vote was not acknowledged".into());
            }
            tokio::task::yield_now().await;
        }
        // The acknowledge has finished. Let the outbound task return to the
        // idle wait before the peer closes, so this is not the acknowledge watch.
        tokio::time::sleep(Duration::from_millis(20)).await;
        let mut buf = [0u8; 8];
        let still_open = tokio::time::timeout(
            Duration::from_millis(30),
            tokio::io::AsyncReadExt::read(&mut socket, &mut buf),
        )
        .await;
        if still_open.is_ok() {
            running.abort();
            return Err("outbound dropped the socket after a successful acknowledge".into());
        }
        socket.shutdown().await.map_err(|_| "shutdown write")?;
        let saw = tokio::time::timeout(
            Duration::from_millis(300),
            tokio::io::AsyncReadExt::read(&mut socket, &mut buf),
        )
        .await;
        running.abort();
        match saw {
            Ok(Ok(0)) => Ok(()),
            _ => Err("outbound kept the socket while the peer was idle and closed".into()),
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn outbound_closes_when_the_peer_leaves_during_frame_admission() -> TestResult {
        let owner = LocalOwner::open_profile(0, 5, 5, 16, StorageLimits::standard()?, 1000).await?;
        let voter = LocalOwner::open(1, 5, 16).await?;
        tokio::time::sleep(Duration::from_millis(3)).await;
        let jobs = match owner.control.reliable(Command::Tick).await? {
            Reply::Votes(jobs) => jobs,
            _ => return Err("campaign".into()),
        };
        let request = jobs
            .into_iter()
            .find_map(|job| match job {
                Job::Vote(q) if q.context.peer.id == 1 => Some(q),
                _ => None,
            })
            .ok_or("vote for peer 1")?;
        let before = owner.state().await?.election.granted_votes;
        let granted = grant(&voter, request).await?;
        let Message::VoteReply(granted) = granted else {
            return Err("genuine vote reply".into());
        };
        let listener = TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let route = Peer::new(voter.control.config.bootstrap.local().clone(), address)?;
        let (tx, rx) = mpsc::channel(1);
        let control = owner.control.clone();
        let running = tokio::spawn(async move {
            outbound(control, route, rx).await;
        });
        tokio::time::sleep(Duration::from_millis(20)).await;
        tx.send(Job::Vote(request)).await.map_err(|_| "send vote")?;
        let (mut socket, _) = tokio::time::timeout(Duration::from_secs(2), listener.accept())
            .await
            .map_err(|_| "outbound did not connect")??;
        let bound = owner.control.config.limits.frame_bytes;
        let mut wire = WireBuf::new();
        let deadline = Instant::now() + Duration::from_secs(2);
        let hello = read_frame(&mut socket, bound, 64, deadline, &mut wire).await?;
        let Message::Hello(hello) = hello.message else {
            return Err("hello".into());
        };
        write_frame(
            &mut socket,
            &Frame {
                rpc: 0,
                message: Message::HelloAck(hello),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        let vote = read_frame(&mut socket, bound, 64, deadline, &mut wire).await?;
        let Message::Vote(vote_request) = vote.message else {
            return Err("vote".into());
        };
        if vote_request != granted.request {
            running.abort();
            return Err("wire vote did not match the campaign".into());
        }
        let permits = u32::try_from(owner.control.config.pool).map_err(|_| "pool")?;
        let bytes = owner.control.bytes.clone();
        let holding = tokio::spawn(async move { bytes.acquire_many_owned(permits).await });
        write_frame(
            &mut socket,
            &Frame {
                rpc: vote.rpc,
                message: Message::VoteReply(granted),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        let wait_grant = Instant::now() + Duration::from_millis(500);
        loop {
            if owner.state().await?.election.granted_votes > before {
                break;
            }
            if Instant::now() >= wait_grant {
                running.abort();
                return Err("vote was not acknowledged".into());
            }
            tokio::task::yield_now().await;
        }
        let _held = tokio::time::timeout(Duration::from_millis(500), holding)
            .await
            .map_err(|_| "frame memory was not taken")?
            .map_err(|_| "frame memory task")?
            .map_err(|_| "frame memory closed")?;
        tokio::time::sleep(Duration::from_millis(20)).await;
        let mut buf = [0u8; 8];
        let still_open = tokio::time::timeout(
            Duration::from_millis(30),
            tokio::io::AsyncReadExt::read(&mut socket, &mut buf),
        )
        .await;
        if still_open.is_ok() {
            running.abort();
            return Err("outbound dropped the socket before frame admission waited".into());
        }
        socket.shutdown().await.map_err(|_| "shutdown write")?;
        let saw = tokio::time::timeout(
            Duration::from_millis(300),
            tokio::io::AsyncReadExt::read(&mut socket, &mut buf),
        )
        .await;
        running.abort();
        match saw {
            Ok(Ok(0)) => Ok(()),
            _ => Err("outbound kept the socket while frame admission waited".into()),
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn outbound_closes_when_the_peer_leaves_during_prepare() -> TestResult {
        let owner = LocalOwner::open_profile(0, 5, 5, 16, StorageLimits::standard()?, 40).await?;
        let voter = LocalOwner::open(1, 5, 16).await?;
        tokio::time::sleep(Duration::from_millis(3)).await;
        let jobs = match owner.control.reliable(Command::Tick).await? {
            Reply::Votes(jobs) => jobs,
            _ => return Err("campaign".into()),
        };
        let request = jobs
            .into_iter()
            .find_map(|job| match job {
                Job::Vote(q) if q.context.peer.id == 1 => Some(q),
                _ => None,
            })
            .ok_or("vote for peer 1")?;
        let before = owner.state().await?.election.granted_votes;
        let granted = grant(&voter, request).await?;
        let Message::VoteReply(granted) = granted else {
            return Err("genuine vote reply".into());
        };
        let listener = TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let route = Peer::new(voter.control.config.bootstrap.local().clone(), address)?;
        let (tx, rx) = mpsc::channel(1);
        let control = owner.control.clone();
        let running = tokio::spawn(async move {
            outbound(control, route, rx).await;
        });
        tokio::time::sleep(Duration::from_millis(20)).await;
        tx.send(Job::Vote(request)).await.map_err(|_| "send vote")?;
        let (mut socket, _) = tokio::time::timeout(Duration::from_secs(2), listener.accept())
            .await
            .map_err(|_| "outbound did not connect")??;
        let bound = owner.control.config.limits.frame_bytes;
        let mut wire = WireBuf::new();
        let deadline = Instant::now() + Duration::from_secs(2);
        let hello = read_frame(&mut socket, bound, 64, deadline, &mut wire).await?;
        let Message::Hello(hello) = hello.message else {
            return Err("hello".into());
        };
        write_frame(
            &mut socket,
            &Frame {
                rpc: 0,
                message: Message::HelloAck(hello),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        let vote = read_frame(&mut socket, bound, 64, deadline, &mut wire).await?;
        let Message::Vote(vote_request) = vote.message else {
            return Err("vote".into());
        };
        if vote_request != granted.request {
            running.abort();
            return Err("wire vote did not match the campaign".into());
        }
        write_frame(
            &mut socket,
            &Frame {
                rpc: vote.rpc,
                message: Message::VoteReply(granted),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        let wait_grant = Instant::now() + Duration::from_millis(500);
        loop {
            if owner.state().await?.election.granted_votes > before {
                break;
            }
            if Instant::now() >= wait_grant {
                running.abort();
                return Err("vote was not acknowledged".into());
            }
            tokio::task::yield_now().await;
        }
        tokio::time::sleep(Duration::from_millis(20)).await;
        let (envelope, _reply, entered, release) = gate(Command::State);
        owner
            .control
            .commands
            .send(envelope)
            .await
            .map_err(|_| "gate admission")?;
        let _entered = entered.await?;
        // The next heartbeat blocks in Prepare while the owner is held.
        tokio::time::sleep(Duration::from_millis(100)).await;
        let mut buf = [0u8; 8];
        let still_open = tokio::time::timeout(
            Duration::from_millis(30),
            tokio::io::AsyncReadExt::read(&mut socket, &mut buf),
        )
        .await;
        if still_open.is_ok() {
            let _ = release.send(());
            running.abort();
            return Err("outbound dropped the socket before prepare".into());
        }
        socket.shutdown().await.map_err(|_| "shutdown write")?;
        let saw = tokio::time::timeout(
            Duration::from_millis(300),
            tokio::io::AsyncReadExt::read(&mut socket, &mut buf),
        )
        .await;
        let _ = release.send(());
        running.abort();
        match saw {
            Ok(Ok(0)) => Ok(()),
            _ => Err("outbound kept the socket while prepare waited on the owner".into()),
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn outbound_closes_when_the_peer_leaves_during_a_chunk() -> TestResult {
        let owner = LocalOwner::open(0, 2, 16).await?;
        let listener = TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let voter = Voter::new(
            Key::new(1, [2; 16])?,
            vec![Endpoint::new(
                "CONTROLLER".into(),
                "127.0.0.1".into(),
                6001,
            )?],
            0,
            1,
        )?;
        let peer = Peer::new(voter, address)?;
        let peer_key = peer.key();
        let local_key = owner.control.config.bootstrap.local().key();
        let offer = replication::DynamicSnapshotRequest {
            context: replication::Context {
                leader: local_key,
                peer: peer_key,
                configuration_epoch: 0,
            },
            request: replication::SnapshotRequest {
                leader: local_key.id,
                peer: peer_key.id,
                sequence: 1,
                term: 2,
                leader_commit: 1,
                descriptor: super::super::snapshot::Descriptor {
                    generation: [1; 16],
                    base: LogPosition { term: 1, index: 1 },
                    records: 1,
                    payload_bytes: 0,
                    bytes: 64,
                    checksum: 1,
                },
            },
        };
        let (tx, rx) = mpsc::channel(1);
        let control = owner.control.clone();
        let running = tokio::spawn(async move {
            outbound(control, peer, rx).await;
        });
        tokio::time::sleep(Duration::from_millis(20)).await;
        tx.send(Job::Image(offer)).await.map_err(|_| "send image")?;
        let (mut socket, _) = tokio::time::timeout(Duration::from_secs(2), listener.accept())
            .await
            .map_err(|_| "outbound did not connect")??;
        let bound = owner.control.config.limits.frame_bytes;
        let mut wire = WireBuf::new();
        let deadline = Instant::now() + Duration::from_secs(2);
        let hello = read_frame(&mut socket, bound, 64, deadline, &mut wire).await?;
        let Message::Hello(hello) = hello.message else {
            running.abort();
            return Err("hello".into());
        };
        write_frame(
            &mut socket,
            &Frame {
                rpc: 0,
                message: Message::HelloAck(hello),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        let begin = read_frame(&mut socket, bound, 64, deadline, &mut wire).await?;
        let Message::Begin(begin_offer) = begin.message else {
            running.abort();
            return Err("begin".into());
        };
        let (envelope, _reply, entered, release) = gate(Command::State);
        owner
            .control
            .commands
            .send(envelope)
            .await
            .map_err(|_| "gate admission")?;
        let _entered = entered.await?;
        write_frame(
            &mut socket,
            &Frame {
                rpc: begin.rpc,
                message: Message::Begun(begin_offer),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        let mut buf = [0u8; 8];
        let still_open = tokio::time::timeout(
            Duration::from_millis(30),
            tokio::io::AsyncReadExt::read(&mut socket, &mut buf),
        )
        .await;
        if still_open.is_ok() {
            let _ = release.send(());
            running.abort();
            return Err("outbound dropped the socket before the chunk read".into());
        }
        socket.shutdown().await.map_err(|_| "shutdown write")?;
        let saw = tokio::time::timeout(
            Duration::from_millis(300),
            tokio::io::AsyncReadExt::read(&mut socket, &mut buf),
        )
        .await;
        let _ = release.send(());
        running.abort();
        match saw {
            Ok(Ok(0)) => Ok(()),
            _ => Err("outbound kept the socket while a chunk waited on the owner".into()),
        }
    }

    #[tokio::test]
    async fn peer_socket_configuration_disables_nagle_on_both_directions() -> TestResult {
        let listener = TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let (client, accepted) = tokio::join!(TcpStream::connect(address), listener.accept());
        let client = client?;
        let (server, _) = accepted?;
        configure_peer_socket(&client)?;
        configure_peer_socket(&server)?;
        assert!(client.nodelay()?);
        assert!(server.nodelay()?);
        Ok(())
    }
    struct LocalOwner {
        control: Arc<Control>,
        join: Option<std::thread::JoinHandle<Result<State>>>,
        root: PathBuf,
    }
    impl LocalOwner {
        async fn open(local: u32, count: u32, capacity: usize) -> TestResult<Self> {
            Self::open_profile(
                local,
                count,
                count,
                capacity,
                StorageLimits::standard()?,
                100,
            )
            .await
        }
        async fn open_profile(
            local: u32,
            count: u32,
            genesis_count: u32,
            capacity: usize,
            storage: StorageLimits,
            heartbeat_ms: u64,
        ) -> TestResult<Self> {
            Self::open_profile_with_command_ms(
                local,
                count,
                genesis_count,
                capacity,
                storage,
                heartbeat_ms,
                20,
            )
            .await
        }
        async fn open_profile_with_command_ms(
            local: u32,
            count: u32,
            genesis_count: u32,
            capacity: usize,
            storage: StorageLimits,
            heartbeat_ms: u64,
            command_ms: u64,
        ) -> TestResult<Self> {
            if genesis_count == 0 || genesis_count > count {
                return Err("owner genesis bounds".into());
            }
            static NEXT: AtomicUsize = AtomicUsize::new(0);
            let root = std::env::temp_dir().join(format!(
                "partitionline76-owner-{}-{}",
                std::process::id(),
                NEXT.fetch_add(1, Ordering::Relaxed)
            ));
            std::fs::create_dir(&root)?;
            let voters = (0..count)
                .map(|id| {
                    Ok(Voter::new(
                        Key::new(id, [(id + 1) as u8; 16])?,
                        vec![Endpoint::new(
                            "CONTROLLER".into(),
                            "127.0.0.1".into(),
                            6000 + id as u16,
                        )?],
                        0,
                        1,
                    )?)
                })
                .collect::<TestResult<Vec<_>>>()?;
            let local_voter = voters.get(local as usize).ok_or("local voter")?.clone();
            let genesis = Voters::new(
                0,
                LogPosition::default(),
                1,
                voters[..genesis_count as usize].to_vec(),
            )?;
            let bootstrap = Bootstrap::new(local_voter, genesis, "CONTROLLER".into())?;
            let peers = voters
                .into_iter()
                .filter(|v| v.key().id != local)
                .map(|v| {
                    let address =
                        SocketAddr::new(IpAddr::from([127, 0, 0, 1]), 6000 + v.key().id as u16);
                    Ok(Peer::new(v, address)?)
                })
                .collect::<TestResult<Vec<_>>>()?;
            let controller =
                protocol::Config::new(local, vec![local], "owner-control-test".into())?;
            let config = Arc::new(Config::new(
                controller,
                bootstrap,
                peers,
                storage,
                Limits {
                    election_min_ms: 1,
                    election_max_ms: 1,
                    command_ms,
                    heartbeat_ms,
                    ..Limits::default()
                },
            )?);
            let (tx, rx) = mpsc::channel(capacity);
            let (ready_tx, ready_rx) = watch::channel(0);
            let paths = Paths::new(
                root.join("metadata.wal"),
                root.join("election.wal"),
                root.join("images"),
            )?;
            let control = Arc::new(Control {
                stopped: AtomicBool::new(false),
                notify: Notify::new(),
                commands: tx,
                clients: Arc::new(Semaphore::new(config.limits.client_slots)),
                bytes: Arc::new(Semaphore::new(config.pool)),
                startup: ready_rx,
                tasks: AtomicUsize::new(0),
                sockets: AtomicUsize::new(0),
                metrics: Arc::new(TestMetrics::default()),
                capture_root: TestTrace::capture_root(&paths, &config)?,
                config,
            });
            let child_control = control.clone();
            let join = std::thread::spawn(move || {
                run_owner(
                    child_control,
                    paths,
                    rx,
                    ready_tx,
                    std::time::Instant::now(),
                )
            });
            let mut ready = control.startup.clone();
            while *ready.borrow() != 1 {
                if *ready.borrow() == 2 {
                    return Err("owner startup".into());
                }
                ready.changed().await?;
            }
            Ok(Self {
                control,
                join: Some(join),
                root,
            })
        }
        async fn fixture(&self, phase: &str, command: Command) -> TestResult<Result<Reply>> {
            // Ownership setup/observation is not an ordinary latency-budget
            // assertion. It uses reliable admission with a separate absolute
            // test wait; production call/internal deadlines and the intentional
            // 20ms Stop/expired-write controls retain their original behavior.
            let deadline = Instant::now() + Duration::from_secs(2);
            match tokio::time::timeout_at(deadline, self.control.reliable(command)).await {
                Ok(reply) => Ok(reply),
                Err(_) => Err(format!("fixture phase {phase}: absolute2s wait expired").into()),
            }
        }
        async fn state(&self) -> TestResult<State> {
            match self.fixture("observe-state", Command::State).await?? {
                Reply::State(s) => Ok(s),
                _ => Err("state reply".into()),
            }
        }
        async fn reject_vote(&self, phase: &str, response: Message) -> TestResult {
            let before = self.state().await?;
            match self.fixture(phase, Command::Acknowledge(response)).await? {
                Err(Error::Node(replication::Error::InvalidPeer)) => {}
                Err(other) => {
                    return Err(format!("{phase}: expected Node InvalidPeer, got {other:?}").into());
                }
                Ok(_) => return Err(format!("{phase}: abandoned correlation was accepted").into()),
            }
            let after = self.state().await?;
            assert_eq!(after.election.persistent, before.election.persistent);
            assert_eq!(after.election.role, before.election.role);
            assert_eq!(after.base_position, before.base_position);
            assert_eq!(after.last_position, before.last_position);
            assert_eq!(after.committed_end, before.committed_end);
            assert_eq!(after.active_term, before.active_term);
            assert_eq!(after.wal_durable_ops, before.wal_durable_ops);
            assert_eq!(
                after.election_durable_states,
                before.election_durable_states
            );
            assert_eq!(after.ready, before.ready);
            assert_eq!(after.poisoned, before.poisoned);
            Ok(())
        }
        fn assert_joined(&self) -> TestResult {
            use std::io::Write;
            // This owner helper never starts a listener, supervisor or network
            // worker. Assert its actual constructed owners after thread join;
            // its manually sized channel differs from the public runtime.
            let capacity = self.control.commands.max_capacity();
            let envelope_bound = checked_sum(&[product(capacity, 2)?, 1])?;
            let bounds = [
                self.control.config.limits.client_slots,
                self.control.config.pool,
                0,
                0,
                envelope_bound,
            ];
            for (gauge, bound) in self.control.metrics.gauges.iter().zip(bounds) {
                assert_eq!(gauge.current.load(Ordering::Acquire), 0);
                assert!(gauge.peak.load(Ordering::Acquire) <= bound);
            }
            assert_eq!(self.control.tasks.load(Ordering::Acquire), 0);
            assert_eq!(self.control.sockets.load(Ordering::Acquire), 0);
            assert_eq!(
                self.control.metrics.workers_spawned.load(Ordering::Acquire),
                0
            );
            assert_eq!(
                self.control.metrics.workers_joined.load(Ordering::Acquire),
                0
            );
            assert!(self.control.stopped.load(Ordering::Acquire));
            assert_eq!(
                self.control.clients.available_permits(),
                self.control.config.limits.client_slots
            );
            assert_eq!(
                self.control.bytes.available_permits(),
                self.control.config.pool
            );
            let Some(root) = &self.control.capture_root else {
                return Ok(());
            };
            let now_ms = u64::try_from(
                self.control
                    .metrics
                    .clock
                    .get()
                    .ok_or("owner clock")?
                    .elapsed()
                    .as_millis(),
            )?;
            let text = format!(
                "{{\"schema_version\":1,\"capture_revision\":2,\"scope\":\"direct blocking owner without network workers or supervisor\",\"pid\":{},\"stage\":\"direct-owner-joined\",\"now_ms\":{now_ms},\"clock_basis\":\"same exclusive owner process-local monotonic epoch\",\"source_sha\":\"{}\",\"local_id\":{},\"directory\":\"{}\",\"owner_joined\":true,\"supervisor_joined\":null,\"listener_closed\":null,\"network_workers_spawned\":0,\"network_workers_joined\":0,\"actual_mpsc_capacity\":{capacity},\"command_envelope_owner_bound\":{envelope_bound},\"resource_owners\":{},\"stopping\":true,\"available_client_permits\":{},\"available_transport_permits\":{}}}\n",
                std::process::id(),
                std::env::var("PL_PEER_RUNTIME_SOURCE_SHA")?,
                self.control.config.bootstrap.local().key().id,
                TestTrace::hex(&self.control.config.bootstrap.local().key().directory)?,
                self.control.metrics.json()?,
                self.control.clients.available_permits(),
                self.control.bytes.available_permits()
            );
            assert!(text.len() <= 8192);
            let mut file = std::fs::OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(root.join("lifecycle-direct-owner-joined.json"))?;
            file.write_all(text.as_bytes())?;
            file.sync_all()?;
            std::fs::File::open(root)?.sync_all()?;
            Ok(())
        }
        async fn finish(mut self) -> TestResult {
            self.control.stop();
            self.control.reliable(Command::Stop).await?;
            let joined = self
                .join
                .take()
                .ok_or("owner join already taken")?
                .join()
                .map_err(|_| "owner panic")?;
            joined?;
            self.assert_joined()?;
            std::fs::remove_dir_all(&self.root)?;
            Ok(())
        }
    }
    impl Drop for LocalOwner {
        fn drop(&mut self) {
            self.control.stop();
            if let Some(owner) = self.join.take() {
                let control = self.control.clone();
                let cleanup = std::thread::spawn(move || {
                    let (tx, _rx) = oneshot::channel();
                    let _ = control.commands.blocking_send(Envelope {
                        command: Command::Stop,
                        reply: tx,
                        permit: None,
                        transport: None,
                        started: Arc::new(AtomicBool::new(false)),
                        deadline: None,
                        delivery_gate: None,
                        _counter: None,
                    });
                    let _ = owner.join();
                });
                let _ = cleanup.join();
            }
        }
    }
    #[expect(
        clippy::type_complexity,
        reason = "test gate returns the owned command and its delivery/readiness/release endpoints"
    )]
    fn gate(
        command: Command,
    ) -> (
        Envelope,
        oneshot::Receiver<Delivered>,
        oneshot::Receiver<(Vec<replication::DynamicVoteRequest>, State)>,
        std::sync::mpsc::Sender<()>,
    ) {
        let (reply, rx) = oneshot::channel();
        let (ready, entered) = oneshot::channel();
        let (release, held) = std::sync::mpsc::channel();
        let envelope = Envelope {
            command,
            reply,
            permit: None,
            transport: None,
            started: Arc::new(AtomicBool::new(false)),
            deadline: Some(Instant::now() + Duration::from_secs(2)),
            delivery_gate: Some(DeliveryGate {
                ready,
                release: held,
            }),
            _counter: None,
        };
        (envelope, rx, entered, release)
    }
    async fn grant(
        owner: &LocalOwner,
        request: replication::DynamicVoteRequest,
    ) -> TestResult<Message> {
        match owner
            .fixture(
                "receive-genuine-vote",
                Command::Inbound(request.context.leader, Message::Vote(request)),
            )
            .await??
        {
            Reply::Message(m @ Message::VoteReply(_)) => Ok(m),
            _ => Err("actual vote response".into()),
        }
    }
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn abandoned_vote_vector_and_full_route_release_every_exact_correlation() -> TestResult {
        let source = LocalOwner::open(0, 5, 16).await?;
        tokio::time::sleep(Duration::from_millis(3)).await;
        let (envelope, reply, entered, release) = gate(Command::Tick);
        source
            .control
            .commands
            .send(envelope)
            .await
            .map_err(|_| "gate admission")?;
        let (requests, generated_state) = entered.await?;
        assert_eq!(requests.len(), 4);
        // The real candidacy/WAL has completed, then the whole reply receiver
        // disappears. Owner delivery cleanup must cover all four requests.
        drop(reply);
        release.send(())?;
        let after = source.state().await?;
        assert_eq!(
            after.election.persistent,
            generated_state.election.persistent
        );
        assert_eq!(after.wal_durable_ops, generated_state.wal_durable_ops);
        assert_eq!(
            after.election_durable_states,
            generated_state.election_durable_states
        );
        let mut peers = Vec::new();
        for id in 1..5 {
            peers.push(LocalOwner::open(id, 5, 16).await?);
        }
        for request in &requests {
            let response = grant(&peers[request.context.peer.id as usize - 1], *request).await?;
            source
                .reject_vote("abandoned-vector-genuine-grant", response)
                .await?;
        }
        tokio::time::sleep(Duration::from_millis(3)).await;
        let newer = match source
            .fixture("next-campaign-tick", Command::Tick)
            .await??
        {
            Reply::Votes(jobs) => jobs,
            _ => return Err("campaign reply".into()),
        };
        assert_eq!(newer.len(), 4);
        let new_requests = newer
            .iter()
            .map(|j| match j {
                Job::Vote(q) => Ok(*q),
                _ => Err("vote job"),
            })
            .collect::<std::result::Result<Vec<_>, _>>()?;
        let mut routes = Vec::new();
        let mut receivers = Vec::new();
        // Old jobs are genuinely still queued. The fresh campaign's route
        // send now fails on capacity; it must cancel the fresh correlations.
        for q in &requests {
            let (tx, rx) = mpsc::channel(1);
            tx.try_send(Job::Vote(*q)).map_err(|_| "fill route")?;
            routes.push((q.context.peer, tx));
            receivers.push(rx);
        }
        dispatch_votes(&source.control, &routes, newer).await;
        for request in new_requests {
            let response = grant(&peers[request.context.peer.id as usize - 1], request).await?;
            source
                .reject_vote("full-route-genuine-grant", response)
                .await?;
        }
        drop(routes);
        drop(receivers);
        for peer in peers {
            peer.finish().await?;
        }
        source.finish().await
    }
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn reliable_stop_waits_for_saturated_owner_even_after_command_deadline() -> TestResult {
        let source = LocalOwner::open(0, 1, 1).await?;
        let (held, held_reply, entered, release) = gate(Command::State);
        source
            .control
            .commands
            .send(held)
            .await
            .map_err(|_| "held admission")?;
        entered.await?;
        let (queued, queued_reply) = oneshot::channel();
        source
            .control
            .commands
            .send(Envelope {
                command: Command::State,
                reply: queued,
                permit: None,
                transport: None,
                started: Arc::new(AtomicBool::new(false)),
                deadline: Some(Instant::now() + Duration::from_millis(1)),
                delivery_gate: None,
                _counter: None,
            })
            .await
            .map_err(|_| "fill owner queue")?;
        source.control.stop();
        let stop_control = source.control.clone();
        let mut stop = tokio::spawn(async move { stop_control.reliable(Command::Stop).await });
        assert!(
            tokio::time::timeout(Duration::from_millis(50), &mut stop)
                .await
                .is_err(),
            "stop retains admission beyond ordinary20ms budget"
        );
        release.send(())?;
        drop(held_reply);
        drop(queued_reply);
        assert!(matches!(
            tokio::time::timeout(Duration::from_secs(2), &mut stop).await???,
            Reply::Done
        ));
        let mut source = source;
        source
            .join
            .take()
            .ok_or("owner join")?
            .join()
            .map_err(|_| "owner panic")??;
        source.assert_joined()?;
        std::fs::remove_dir_all(&source.root)?;
        Ok(())
    }
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn expired_outer_budget_cannot_admit_a_genuine_leader_write() -> TestResult {
        let source = LocalOwner::open(0, 5, 16).await?;
        tokio::time::sleep(Duration::from_millis(3)).await;
        let requests = match source.control.internal(Command::Tick).await? {
            Reply::Votes(jobs) => jobs,
            _ => return Err("campaign reply".into()),
        };
        let mut peers = Vec::new();
        for job in requests.into_iter().take(2) {
            let Job::Vote(request) = job else {
                return Err("vote job".into());
            };
            let peer = LocalOwner::open(request.context.peer.id, 5, 16).await?;
            source
                .control
                .internal(Command::Acknowledge(grant(&peer, request).await?))
                .await?;
            peers.push(peer);
        }
        source.control.internal(Command::Tick).await?;
        let before = source.state().await?;
        assert_eq!(before.election.role, Role::Leader);
        assert_eq!(before.active_term, Some(before.election.persistent.term));
        let handle = Handle {
            control: source.control.clone(),
        };
        let expired = Instant::now() - Duration::from_millis(1);
        assert!(matches!(
            handle
                .call_until(Command::Propose(b"expired outer budget".to_vec()), expired)
                .await,
            Err(Error::Deadline)
        ));
        let after = source.state().await?;
        assert_eq!(after.last_position, before.last_position);
        assert_eq!(after.wal_durable_ops, before.wal_durable_ops);
        assert_eq!(
            after.election_durable_states,
            before.election_durable_states
        );
        // A real proposal with a live budget confirms that the old assertion
        // was about expiry, not an inactive/invalid writer or malformed input.
        assert!(matches!(
            handle
                .call(Command::Propose(b"live budget".to_vec()))
                .await?,
            Reply::Position(_)
        ));
        assert!(source.state().await?.last_position.index > before.last_position.index);
        for peer in peers {
            peer.finish().await?;
        }
        source.finish().await
    }
    #[test]
    fn proposal_capacity_check_keeps_the_original_allocation() -> TestResult {
        let mut input = Vec::with_capacity(32);
        input.push(b'x');
        let pointer = input.as_ptr();
        let capacity = input.capacity();
        let accepted = bounded_proposal(input, 1, capacity)?;
        assert_eq!(accepted.as_ptr(), pointer);
        assert_eq!(accepted.capacity(), capacity);
        assert_eq!(accepted.as_slice(), b"x");
        Ok(())
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn proposal_capacity_is_checked_before_admission_and_wal_work() -> TestResult {
        fn read_bounded_wal(path: &Path) -> std::io::Result<Vec<u8>> {
            use std::io::Read;
            let mut bytes = Vec::new();
            std::fs::File::open(path)?
                .take(1024 * 1024 + 1)
                .read_to_end(&mut bytes)?;
            if bytes.len() > 1024 * 1024 {
                return Err(std::io::Error::other("test WAL exceeds snapshot limit"));
            }
            Ok(bytes)
        }

        let storage = StorageLimits::standard()?;
        let source =
            LocalOwner::open_profile_with_command_ms(0, 1, 1, 16, storage, 100, 1000).await?;
        let handle = Handle {
            control: source.control.clone(),
        };
        let before = source.state().await?;
        let wal_path = source.root.join("metadata.wal");
        let wal_before = read_bounded_wal(&wal_path)?;
        let deadline = Instant::now() + Duration::from_secs(2);
        while source.control.metrics.gauges[4]
            .current
            .load(Ordering::Acquire)
            != 0
        {
            if Instant::now() >= deadline {
                return Err("initial observation envelope did not release".into());
            }
            tokio::task::yield_now().await;
        }
        assert_eq!(
            source.control.metrics.gauges[0]
                .current
                .load(Ordering::Acquire),
            0
        );
        source.control.metrics.gauges[0]
            .peak
            .store(0, Ordering::Release);
        source.control.metrics.gauges[4]
            .peak
            .store(0, Ordering::Release);
        let held_permits = source
            .control
            .clients
            .clone()
            .acquire_many_owned(u32::try_from(source.control.config.limits.client_slots)?)
            .await?;
        let permits_before = source.control.clients.available_permits();
        assert_eq!(permits_before, 0);

        let capacity_limit = command_payload_limit(
            &source.control.config.controller,
            storage,
            source.control.config.limits,
        );
        assert!(capacity_limit > storage.record_bytes);
        let mut over_capacity = Vec::with_capacity(capacity_limit + 1);
        over_capacity.push(b'x');
        assert_eq!(over_capacity.len(), 1);
        assert!(over_capacity.capacity() > capacity_limit);
        assert!(matches!(
            tokio::time::timeout(Duration::from_secs(2), handle.propose(over_capacity)).await?,
            Err(Error::InvalidConfig)
        ));
        assert!(matches!(
            handle.propose(Vec::new()).await,
            Err(Error::InvalidConfig)
        ));
        let mut over_length = vec![0; storage.record_bytes + 1];
        over_length[0] = 1;
        assert!(over_length.capacity() <= capacity_limit);
        assert!(matches!(
            handle.propose(over_length).await,
            Err(Error::InvalidConfig)
        ));
        assert_eq!(
            source.control.metrics.gauges[0]
                .peak
                .load(Ordering::Acquire),
            0
        );
        assert_eq!(
            source.control.metrics.gauges[4]
                .peak
                .load(Ordering::Acquire),
            0
        );
        assert_eq!(source.control.clients.available_permits(), permits_before);
        drop(held_permits);
        let after = source.state().await?;
        assert_eq!(after.last_position, before.last_position);
        assert_eq!(after.wal_durable_ops, before.wal_durable_ops);
        assert_eq!(
            after.election_durable_states,
            before.election_durable_states
        );
        assert_eq!(read_bounded_wal(&wal_path)?, wal_before);

        // A bounded input reaches the actual leader and appends normally.
        tokio::time::sleep(Duration::from_millis(3)).await;
        source
            .fixture("single-voter-campaign", Command::Tick)
            .await??;
        let leader = source.state().await?;
        assert_eq!(leader.election.role, Role::Leader);
        let mut over_reserved = Vec::with_capacity(storage.record_bytes + 1);
        over_reserved.extend_from_slice(b"ordinary bounded proposal");
        assert!(over_reserved.capacity() > storage.record_bytes);
        assert!(over_reserved.capacity() <= capacity_limit);
        let accepted = handle.propose(over_reserved).await?;
        let written = source.state().await?;
        assert_eq!(written.last_position, accepted);
        assert!(written.wal_durable_ops > leader.wal_durable_ops);
        source.finish().await
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn configured_route_does_not_authorize_unknown_configuration_leader_over_tcp(
    ) -> TestResult {
        let mut listeners = Vec::new();
        let mut addresses = Vec::new();
        for _ in 0..4 {
            let l = TcpListener::bind("127.0.0.1:0").await?;
            addresses.push(l.local_addr()?);
            listeners.push(l);
        }
        let voters = addresses
            .iter()
            .enumerate()
            .map(|(id, address)| {
                Ok(Voter::new(
                    Key::new(id as u32, [(id + 1) as u8; 16])?,
                    vec![Endpoint::new(
                        "CONTROLLER".into(),
                        address.ip().to_string(),
                        address.port(),
                    )?],
                    0,
                    1,
                )?)
            })
            .collect::<TestResult<Vec<_>>>()?;
        let genesis = Voters::new(0, LogPosition::default(), 1, voters[..3].to_vec())?;
        let bootstrap = Bootstrap::new(voters[0].clone(), genesis, "CONTROLLER".into())?;
        let peers = voters
            .iter()
            .enumerate()
            .skip(1)
            .map(|(id, v)| Ok(Peer::new(v.clone(), addresses[id])?))
            .collect::<TestResult<Vec<_>>>()?;
        // Long elections isolate the incoming request from unrelated timer
        // transitions; this is an actual local TCP/Node rejection test.
        let config = Config::new(
            protocol::Config::new(0, vec![0], "unknown-directory-test".into())?,
            bootstrap,
            peers,
            StorageLimits::standard()?,
            Limits {
                election_min_ms: 600000,
                election_max_ms: 600000,
                ..Limits::default()
            },
        )?;
        let group = config.group.clone();
        let bound = config.limits.frame_bytes;
        let root =
            std::env::temp_dir().join(format!("partitionline76-unknown-{}", std::process::id()));
        std::fs::create_dir(&root)?;
        let listener = listeners.remove(0);
        let address = listener.local_addr()?;
        let mut runtime = Runtime::start(
            listener,
            config,
            Paths::new(
                root.join("metadata.wal"),
                root.join("election.wal"),
                root.join("images"),
            )?,
        )?;
        runtime.wait_ready().await?;
        let handle = runtime.handle();
        let before = handle.state().await?;
        let mut socket = TcpStream::connect(address).await?;
        let mut wire = WireBuf::new();
        let deadline = Instant::now() + Duration::from_secs(2);
        let hello = Hello {
            source: voters[3].key(),
            target: voters[0].key(),
            group,
        };
        write_frame(
            &mut socket,
            &Frame {
                rpc: 0,
                message: Message::Hello(hello.clone()),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        let encoded_capacity = wire.write.capacity();
        assert!(encoded_capacity > 0);
        let response = read_frame(&mut socket, bound, 4096, deadline, &mut wire).await?;
        assert_eq!(response.message, Message::HelloAck(hello));
        let request = replication::DynamicVoteRequest {
            context: replication::Context {
                leader: voters[3].key(),
                peer: voters[0].key(),
                configuration_epoch: 0,
            },
            sequence: 1,
            request: super::super::election::VoteRequest {
                term: 2,
                candidate: 3,
                log: LogPosition::default(),
            },
        };
        write_frame(
            &mut socket,
            &Frame {
                rpc: 1,
                message: Message::Vote(request),
            },
            bound,
            deadline,
            &mut wire,
        )
        .await?;
        assert!(wire.write.capacity() >= encoded_capacity);
        let response = read_frame(&mut socket, bound, 4096, deadline, &mut wire).await?;
        assert_eq!(response.rpc, 1);
        assert!(matches!(
            response.message,
            Message::Failure {
                request_kind: 10,
                code: 1
            }
        ));
        let after = handle.state().await?;
        assert_eq!(after.election.persistent, before.election.persistent);
        assert_eq!(after.wal_durable_ops, before.wal_durable_ops);
        assert_eq!(
            after.election_durable_states,
            before.election_durable_states
        );
        assert_eq!(after.last_position, before.last_position);
        assert_eq!(after.committed_end, before.committed_end);
        drop(socket);
        runtime.shutdown().await?;
        std::fs::remove_dir_all(root)?;
        drop(listeners);
        Ok(())
    }
    async fn owner_append_exchange(source: &LocalOwner, peer: &LocalOwner, key: Key) -> TestResult {
        let request = match source.control.reliable(Command::Prepare(key)).await? {
            Reply::Job(Some(Job::Append(q))) => q,
            _ => return Err("actual prepared Append required".into()),
        };
        let response = match peer
            .control
            .reliable(Command::Inbound(
                request.context.leader,
                Message::Append(request),
            ))
            .await?
        {
            Reply::Message(m @ Message::AppendReply(_)) => m,
            _ => return Err("actual follower Append reply".into()),
        };
        source
            .control
            .reliable(Command::Acknowledge(response))
            .await?;
        Ok(())
    }
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn exact_append_timeout_rejects_real_late_ack_and_cannot_cancel_newer_request(
    ) -> TestResult {
        use std::io::Read;
        fn bounded(path: &Path) -> TestResult<Vec<u8>> {
            let mut bytes = Vec::new();
            std::fs::File::open(path)?
                .take(8 * 1024 * 1024 + 1)
                .read_to_end(&mut bytes)?;
            if bytes.len() > 8 * 1024 * 1024 {
                return Err("actual control journal bound".into());
            }
            Ok(bytes)
        }
        let source = LocalOwner::open(0, 3, 16).await?;
        let peer = LocalOwner::open(1, 3, 16).await?;
        let second = LocalOwner::open(2, 3, 16).await?;
        tokio::time::sleep(Duration::from_millis(3)).await;
        let jobs = match source.control.reliable(Command::Tick).await? {
            Reply::Votes(v) => v,
            _ => return Err("actual campaign".into()),
        };
        assert_eq!(jobs.len(), 2);
        for job in jobs {
            let Job::Vote(q) = job else {
                return Err("actual vote job".into());
            };
            let voter = if q.context.peer.id == 1 {
                &peer
            } else {
                &second
            };
            let response = grant(voter, q).await?;
            source
                .control
                .reliable(Command::Acknowledge(response))
                .await?;
        }
        source.control.reliable(Command::Tick).await?;
        let key = peer.control.config.bootstrap.local().key();
        for _ in 0..2 {
            owner_append_exchange(&source, &peer, key).await?;
        }
        assert!(source.state().await?.committed_end > 0);
        source
            .control
            .reliable(Command::Propose(
                b"synchronized real response abandoned before consume".to_vec(),
            ))
            .await?;
        let request = match source.control.reliable(Command::Prepare(key)).await? {
            Reply::Job(Some(Job::Append(q))) => q,
            _ => return Err("actual prepared data request".into()),
        };
        let response = match peer
            .control
            .reliable(Command::Inbound(
                request.context.leader,
                Message::Append(request.clone()),
            ))
            .await?
        {
            Reply::Message(m @ Message::AppendReply(_)) => m,
            _ => return Err("actual synchronized data reply".into()),
        };
        assert!(matches!(response,Message::AppendReply(r) if r.response.success));
        let old_state = source.state().await?;
        let old_wal = bounded(&source.root.join("metadata.wal"))?;
        let old_election = bounded(&source.root.join("election.wal"))?;
        // A real correct response exists, but its exact correlation is released
        // before consumption. No denial or durable state is fabricated.
        source
            .control
            .reliable(Command::Timeout(key, request.request.sequence, false))
            .await?;
        assert!(source
            .control
            .reliable(Command::Acknowledge(response))
            .await
            .is_err());
        let after = source.state().await?;
        assert_eq!(after.election.persistent, old_state.election.persistent);
        assert_eq!(after.wal_durable_ops, old_state.wal_durable_ops);
        assert_eq!(
            after.election_durable_states,
            old_state.election_durable_states
        );
        assert_eq!(bounded(&source.root.join("metadata.wal"))?, old_wal);
        assert_eq!(bounded(&source.root.join("election.wal"))?, old_election);
        let newer = match source.control.reliable(Command::Prepare(key)).await? {
            Reply::Job(Some(Job::Append(q))) => q,
            _ => return Err("newer retry request".into()),
        };
        assert!(newer.request.sequence > request.request.sequence);
        let newer_response = match peer
            .control
            .reliable(Command::Inbound(
                newer.context.leader,
                Message::Append(newer.clone()),
            ))
            .await?
        {
            Reply::Message(m @ Message::AppendReply(_)) => m,
            _ => return Err("newer actual receipt".into()),
        };
        // Current API returns Done even when this old timeout is rejected by
        // Node. The capture outcome must say released=false; the newer ACK works.
        source
            .control
            .reliable(Command::Timeout(key, request.request.sequence, false))
            .await?;
        source
            .control
            .reliable(Command::Acknowledge(newer_response))
            .await?;
        assert_eq!(
            source.state().await?.committed_end,
            newer
                .request
                .entries
                .last()
                .map_or(newer.request.previous.index, |r| r.index)
        );
        second.finish().await?;
        peer.finish().await?;
        source.finish().await
    }
    async fn observer_addition_during_multichunk_reader_case(live_entries: usize) -> TestResult {
        let storage = StorageLimits {
            record_bytes: 64 * 1024,
            chunk_bytes: 256 * 1024,
            live_entries,
            live_bytes: 1024 * 1024,
            operations: 4096,
            wal_bytes: 8 * 1024 * 1024,
            fetch_bytes: 256 * 1024,
            images: snapshot::Limits::new(
                2 * 1024 * 1024,
                live_entries.min(64),
                1024 * 1024,
                64 * 1024,
                32 * 1024,
                8,
                32,
            )?,
        };
        let source = LocalOwner::open_profile(0, 3, 2, 16, storage, 100).await?;
        let peer = LocalOwner::open_profile(1, 3, 2, 16, storage, 100).await?;
        let observer = LocalOwner::open_profile(2, 3, 2, 16, storage, 100).await?;
        let result: TestResult = async {
            tokio::time::sleep(Duration::from_millis(3)).await;
            let jobs = match source.fixture("observer-campaign", Command::Tick).await?? {
                Reply::Votes(jobs) => jobs,
                _ => return Err("actual observer campaign".into()),
            };
            assert_eq!(jobs.len(), 1);
            for job in jobs {
                let Job::Vote(q) = job else { return Err("actual vote job".into()); };
                let response = grant(&peer, q).await?;
                source.fixture("observer-vote", Command::Acknowledge(response)).await??;
            }
            source.fixture("observer-activate", Command::Tick).await??;
            let key = peer.control.config.bootstrap.local().key();
            for _ in 0..2 { owner_append_exchange(&source, &peer, key).await?; }
            for byte in [71, 72] {
                source.fixture("observer-prefix-proposal", Command::Propose(vec![byte; 40 * 1024])).await??;
                for _ in 0..2 { owner_append_exchange(&source, &peer, key).await?; }
            }
            let image = match source.fixture("observer-selected-image", Command::Checkpoint([62;16])).await?? {
                Reply::Descriptor(d) => d,
                _ => return Err("selected image receipt".into()),
            };
            assert!(image.bytes > 64 * 1024);
            assert_eq!(image.base.index, 3);
            let observer_key = observer.control.config.bootstrap.local().key();
            source.fixture("observer-start-addition", Command::Add(observer_key)).await??;
            let feature = match source.fixture("observer-prepare-feature", Command::Prepare(observer_key)).await?? {
                Reply::Job(Some(Job::Feature(q))) => q,
                _ => return Err("actual feature request".into()),
            };
            let feature_reply = match observer.fixture("observer-feature-response", Command::Inbound(feature.leader, Message::Feature(feature))).await?? {
                Reply::Message(m @ Message::FeatureReply(_)) => m,
                _ => return Err("actual feature response".into()),
            };
            source.fixture("observer-consume-feature", Command::Acknowledge(feature_reply)).await??;
            let offer = match source.fixture("observer-prepare-image", Command::Prepare(observer_key)).await?? {
                Reply::Job(Some(Job::Image(q))) => q,
                _ => return Err("actual selected image offer".into()),
            };
            assert_eq!(offer.request.descriptor, image);
            observer.fixture("observer-begin-image", Command::Inbound(offer.context.leader, Message::Begin(offer))).await??;
            let before_busy = source.state().await?;
            let mut offset = 0;
            let mut chunks = 0;
            while offset < image.bytes {
                // Exercise the exact Owner Tick while its real Node image
                // reader is open. This used to make valid admission terminal.
                source.fixture("observer-tick-during-image", Command::Tick).await??;
                assert!(matches!(source.fixture("observer-pending-during-image", Command::Addition(observer_key)).await??, Reply::Addition(None)));
                let chunk = match source.fixture("observer-read-image-chunk", Command::Chunk(offer)).await?? {
                    Reply::Message(m @ Message::Chunk { .. }) => m,
                    _ => return Err("actual image chunk".into()),
                };
                if let Message::Chunk { offset: actual, bytes, .. } = &chunk {
                    assert_eq!(*actual, offset);
                    assert!(!bytes.is_empty());
                    offset = offset.checked_add(bytes.len() as u64).ok_or("offset overflow")?;
                    assert!(offset <= image.bytes);
                }
                assert!(matches!(observer.fixture("observer-apply-image-chunk", Command::Inbound(offer.context.leader, chunk)).await??, Reply::Message(Message::Chunked { .. })));
                chunks += 1;
            }
            assert!(chunks >= 3);
            let after_busy = source.state().await?;
            assert_eq!(after_busy.wal_durable_ops, before_busy.wal_durable_ops);
            assert_eq!(after_busy.last_position, before_busy.last_position);
            assert_eq!(after_busy.committed_end, before_busy.committed_end);
            let finished = match observer.fixture("observer-install-image", Command::Inbound(offer.context.leader, Message::Finish(offer))).await?? {
                Reply::Message(m @ Message::Finished(_)) => m,
                _ => return Err("actual durable image install".into()),
            };
            source.fixture("observer-consume-image-install", Command::Acknowledge(finished)).await??;
            let before_add = source.state().await?;
            source.fixture("observer-tick-after-catchup", Command::Tick).await??;
            if live_entries == 3 {
                // A real exhausted log budget is terminal, rather than being
                // blindly classified as Busy or repeatedly renewing admission.
                assert!(matches!(source.fixture("observer-terminal-log-budget", Command::Addition(observer_key)).await?, Err(Error::Deadline)));
                let after = source.state().await?;
                assert_eq!(after.wal_durable_ops, before_add.wal_durable_ops);
                assert_eq!(after.last_position, before_add.last_position);
                assert_eq!(after.committed_end, before_add.committed_end);
                assert!(after.ready && !after.poisoned);
                assert_eq!(after.election.role, Role::Leader);
                assert_eq!(after.active_term, before_add.active_term);
            } else {
                let change = match source.fixture("observer-added-after-image", Command::Addition(observer_key)).await?? {
                    Reply::Addition(Some(change)) => change,
                    _ => return Err("actual added configuration receipt".into()),
                };
                assert_eq!(change.position.index, 4);
                assert!(!change.committed);
                for target in [&peer, &observer] {
                    let key = target.control.config.bootstrap.local().key();
                    for _ in 0..2 { owner_append_exchange(&source, target, key).await?; }
                }
                assert_eq!(source.state().await?.committed_end, 4);
                assert_eq!(peer.state().await?.committed_end, 4);
                assert_eq!(observer.state().await?.committed_end, 4);
                assert_eq!(observer.state().await?.base_position, image.base);
                assert!(matches!(source.fixture("observer-confirm-new-majority", Command::Change).await??, Reply::Change(r) if r.committed && r.position == change.position));
            }
            Ok(())
        }.await;
        let mut first_cleanup = None;
        for owner in [observer, peer, source] {
            if let Err(error) = owner.finish().await {
                if first_cleanup.is_none() {
                    first_cleanup = Some(error);
                }
            }
        }
        result?;
        match first_cleanup {
            Some(error) => Err(error),
            None => Ok(()),
        }
    }
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn observer_addition_retries_real_snapshot_busy_then_commits_new_set() -> TestResult {
        observer_addition_during_multichunk_reader_case(64).await
    }
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn observer_addition_keeps_real_log_budget_failure_terminal() -> TestResult {
        observer_addition_during_multichunk_reader_case(3).await
    }
}
