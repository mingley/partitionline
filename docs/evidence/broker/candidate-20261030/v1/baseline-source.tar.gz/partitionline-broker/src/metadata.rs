//! Persistent single-node Kafka metadata and topic administration.
//!
//! [`Router::open`] advertises exactly Metadata0..13, ApiVersions0..4,
//! CreateTopics2..4 and DeleteTopics1..6. Create overrides are rejected with
//! INVALID_CONFIG; automatic creation is disabled. Logical leaders/ISR are this
//! configured node. This is not replicated storage, authorization or production
//! qualification. Flexible Metadata null/all-topic selectors admit exactly
//! three zero tail bytes for the pinned librdkafka2.15 array-reservation defect;
//! all other trailing bytes fail. The catalog journal is the custom format documented in
//! [`catalog`], not an Apache metadata log.
//! The explicit [`Router::open_with_store`] profile adds ordinary Produce,
//! and [`Router::open_with_read_store`] adds persisted Fetch/ListOffsets.
//! [`Router::open_with_retention_store`] explicitly adds DeleteRecords and
//! bounded policy sweeps to ordinary RF1 rolling storage.
//! [`Router::open_with_compaction_store`] enables explicit ordinary keyed
//! cleaning on that owner, retaining the ordinary read/write API advertisement.
//!
//! One bounded blocking actor owns the catalog and optional partition store.
//! Read snapshots serialize with mutations; long polls wait outside that actor.
//! Canceled queued requests are
//! skipped; cancellation during append/sync is ambiguous and cannot retract a
//! durable operation. Look up the result after reconnecting, or reopen after an
//! ambiguous storage failure. Each topic operation is atomic, not the whole
//! multi-topic request. Successful mutations are published only after sync.
//! [`Router::shutdown`] rejects admission, drains pending work and joins; its
//! canceled future can be retried. Drop requests stop without blocking to join.

use crate::{
    catalog::{self, Catalog, Topic, TopicId},
    compaction, fetch, journal, produce,
    protocol::{self, ApiVersionsHandler, RequestHeader},
    retention,
    transport::{ExchangeOutcome, Handler, Peer},
};
use std::{
    collections::{HashMap, HashSet},
    path::PathBuf,
    sync::{
        atomic::{AtomicBool, Ordering},
        Arc, Weak,
    },
    time::{Duration, Instant},
};
use tokio::{
    sync::{mpsc, oneshot, watch, Mutex, Semaphore},
    task::JoinHandle,
};

const ZERO: [u8; 16] = [0; 16];
const TOPIC_OPS: i32 = 8 | 16 | 32 | 64 | 128 | 256 | 1024 | 2048;
const CLUSTER_OPS: i32 = 32 | 128 | 256 | 512 | 1024 | 2048 | 4096;

/// One reachable controller endpoint in an explicit metadata-only quorum.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ControllerEndpoint {
    /// Nonnegative controller/voter ID.
    pub id: i32,
    /// Kafka client-reachable host.
    pub host: String,
    /// Kafka client-reachable nonzero port.
    pub port: u16,
}

/// Validated actor, parser, response and standalone-node configuration.
#[derive(Debug, Clone)]
pub struct Config {
    /// Nonnegative node ID returned as controller, leader and sole replica.
    pub broker_id: i32,
    /// Client-reachable host, independent of the transport bind address.
    pub advertised_host: String,
    /// Client-reachable port; zero is invalid.
    pub advertised_port: u16,
    /// Stable operator-provided cluster ID, reused when reopening the catalog.
    pub cluster_id: String,
    /// Default logical partitions for CreateTopics v4's -1 sentinel.
    pub default_partitions: u32,
    /// Persistent catalog budgets, also applied to validate-only admission.
    pub catalog_limits: catalog::Limits,
    /// Bounded request bytes and per-block tagged-field count.
    pub protocol_limits: protocol::Limits,
    /// Maximum topics or assignments in any request array, 1..=4096.
    pub max_topics: usize,
    /// Maximum queued requests, 1..=1024; full admission closes that connection.
    /// Queue count times maximum request bytes must not exceed512MiB.
    pub max_queued_requests: usize,
    /// Response payload cap, 64bytes..=64MiB; align with transport configuration.
    pub max_response_bytes: usize,
}

/// Host written on Metadata. One surrounding bracket pair is removed so
/// `[::1]` is advertised as `::1`. A host that is empty or still contains
/// brackets after that is not advertisable.
fn wire_advertised_host(host: &str) -> Option<&str> {
    let host = match host
        .strip_prefix('[')
        .and_then(|rest| rest.strip_suffix(']'))
    {
        Some(inner) => inner,
        None => host,
    };
    if host.is_empty()
        || host.len() > 253
        || !host.is_ascii()
        || host.bytes().any(|byte| {
            byte.is_ascii_control() || byte.is_ascii_whitespace() || byte == b'[' || byte == b']'
        })
    {
        None
    } else {
        Some(host)
    }
}

impl Config {
    /// Construct defaults around an explicit stable cluster/node endpoint.
    pub fn new(
        broker_id: i32,
        advertised_host: String,
        advertised_port: u16,
        cluster_id: String,
    ) -> Self {
        Self {
            broker_id,
            advertised_host,
            advertised_port,
            cluster_id,
            default_partitions: 1,
            catalog_limits: catalog::Limits::default(),
            protocol_limits: protocol::Limits::default(),
            max_topics: 1024,
            max_queued_requests: 64,
            max_response_bytes: 8 * 1024 * 1024,
        }
    }
    fn validate(&self) -> Result<(), Error> {
        if self.broker_id < 0
            || self.advertised_port == 0
            || wire_advertised_host(&self.advertised_host).is_none()
            || self.cluster_id.is_empty()
            || self.cluster_id.len() > 32767
            || self.default_partitions == 0
            || self.default_partitions > self.catalog_limits.max_partitions_per_topic()
            || !(1..=4096).contains(&self.max_topics)
            || !(1..=1024).contains(&self.max_queued_requests)
            || self
                .max_queued_requests
                .saturating_mul(self.protocol_limits.max_request_bytes())
                > 512 * 1024 * 1024
            || !(64..=64 * 1024 * 1024).contains(&self.max_response_bytes)
        {
            return Err(Error::InvalidConfig);
        }
        Ok(())
    }
}

/// Structural/admission failures close only the affected transport connection.
#[derive(Debug)]
pub enum Error {
    /// Invalid local endpoint or resource bounds.
    InvalidConfig,
    /// Bounded protocol parsing failed before mutation.
    Protocol(protocol::Error),
    /// API/version is outside this router's implemented range.
    UnsupportedVersion {
        /// API key.
        api_key: i16,
        /// Requested version.
        version: i16,
    },
    /// A request array exceeds its local count or remaining-byte bound.
    RequestCount,
    /// A boolean is not encoded as zero or one.
    InvalidBoolean,
    /// Metadata v12+ supplies neither a topic name nor a nonzero identity.
    /// The complete bounded body was parsed, but no response is fabricated.
    InvalidTarget,
    /// Bounded response reservation failed or would exceed the configured cap.
    ResponseLimit,
    /// Bounded actor queue is full; no operation was admitted.
    QueueFull,
    /// Actor is stopping or stopped; no new operation was admitted.
    Stopped,
    /// Actor task failed to join.
    ActorFailed,
    /// Startup replay/storage failure; no router was returned.
    Catalog(catalog::Error),
    /// Catalog is poisoned after an ambiguous storage failure; reopen it.
    StoragePoisoned,
    /// A canceled in-flight client no longer has a response receiver.
    Canceled,
    /// Ordinary data profile parsing/startup/storage lifecycle failed.
    Produce(produce::Error),
    /// Ordinary Fetch/ListOffsets parsing, scan or response budgets failed.
    Fetch(fetch::Error),
    /// Explicit retention parsing, policy or storage operation failed.
    Retention(retention::Error),
}
impl From<protocol::Error> for Error {
    fn from(value: protocol::Error) -> Self {
        Self::Protocol(value)
    }
}
impl From<produce::Error> for Error {
    fn from(value: produce::Error) -> Self {
        Self::Produce(value)
    }
}
impl From<fetch::Error> for Error {
    fn from(value: fetch::Error) -> Self {
        Self::Fetch(value)
    }
}
impl From<retention::Error> for Error {
    fn from(value: retention::Error) -> Self {
        Self::Retention(value)
    }
}
impl std::fmt::Display for Error {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "metadata router: {self:?}")
    }
}
impl std::error::Error for Error {}

type Handled = Result<(Vec<u8>, Vec<u8>), Error>;

struct Job {
    request: Vec<u8>,
    spare: Vec<u8>,
    admitted: Instant,
    reply: oneshot::Sender<Handled>,
}
enum Command {
    Request(Job),
    Data(DataJob),
    Sweep(SweepJob),
    Compact(CompactJob),
    Stop,
}
struct SweepJob {
    now_ms: i64,
    reply: oneshot::Sender<Result<retention::SweepReport, Error>>,
}
struct CompactJob {
    id: TopicId,
    index: i32,
    now_ms: i64,
    reply: oneshot::Sender<Result<compaction::Outcome, Error>>,
}
#[derive(Clone, Copy)]
struct DataOptions<'a> {
    reads: Option<fetch::Limits>,
    retention: Option<retention::Config>,
    endpoints: &'a [ControllerEndpoint],
}
#[derive(Clone, Copy)]
struct Routing<'a> {
    config: &'a Config,
    endpoints: &'a [ControllerEndpoint],
}
struct DataJob {
    request: Vec<u8>,
    spare: Vec<u8>,
    admitted: Instant,
    reply: oneshot::Sender<Result<DataReply, Error>>,
}
struct Reused {
    response: Option<Vec<u8>>,
    request: Vec<u8>,
    spare: Vec<u8>,
}
enum DataReply {
    Produce {
        response: Option<Vec<u8>>,
        request: Vec<u8>,
        spare: Vec<u8>,
    },
    Read {
        request: Vec<u8>,
        snapshot: fetch::Snapshot,
    },
}

struct QuorumOpening {
    source: crate::raft::runtime::Handle,
    executor: tokio::runtime::Handle,
    limits: crate::metadata_quorum::Limits,
    deadline: Duration,
    endpoints: Vec<ControllerEndpoint>,
}

/// Composed bounded Kafka handler and exclusive asynchronous catalog owner.
///
/// Do not open another catalog owner for the same file. This process-local
/// actor does not add cross-process locks to the journal. Fresh topic IDs are
/// RFC4122 version4 values from getrandom, excluding reserved IDs and Apache
/// Uuid.randomUuid's leading-base64url-minus case, with at most32 attempts.
/// Shutdown must finish before reopening the same file.
#[derive(Debug)]
pub struct Router {
    config: Config,
    sender: mpsc::Sender<Command>,
    stopping: Arc<AtomicBool>,
    failed: AtomicBool,
    task: Mutex<Option<JoinHandle<()>>>,
    data: bool,
    data_slots: Semaphore,
    reads: Option<fetch::Limits>,
    retention: Option<retention::Config>,
    changes: watch::Receiver<()>,
    compaction: bool,
    wakeup: Weak<watch::Sender<()>>,
}
impl Router {
    /// Open/replay on a blocking actor; cancellation before startup drops it.
    pub async fn open(
        path: impl Into<PathBuf>,
        config: Config,
    ) -> Result<(Self, journal::Recovery), Error> {
        Self::open_inner(path.into(), config, None, None, None, None, None).await
    }
    /// Open the ordinary data profile on the same exclusive blocking actor.
    ///
    /// Every catalog lookup/delete and partition append is serialized. Partition
    /// files are bounded retained history, keyed by UUID/index rather than names.
    /// acks-1 has only RF1 local-fsync semantics; no replication is configured.
    pub async fn open_with_store(
        path: impl Into<PathBuf>,
        config: Config,
        store: produce::Config,
    ) -> Result<(Self, journal::Recovery), Error> {
        store.validate()?;
        if config
            .max_queued_requests
            .saturating_mul(config.max_response_bytes)
            > 512 * 1024 * 1024
        {
            return Err(produce::Error::InvalidConfig.into());
        }
        Self::open_inner(path.into(), config, Some(store), None, None, None, None).await
    }
    /// Open the separately advertised ordinary read/write data profile.
    ///
    /// Produce3–13, Fetch4–6 and ListOffsets1–3 share one catalog/store actor.
    /// Snapshot reads serialize with append/delete; min-byte waiting is outside
    /// that actor and keeps its admission permit. The ordinary-only profile
    /// rejects transactional writes, so read-committed LSO equals local HW.
    /// Admission count times (maximum request plus response bytes) must fit
    /// `reads.max_retained_bytes()`, default1GiB. This includes waiting requests
    /// and completed unconsumed replies; actor scan work has separate limits.
    /// Existing metadata-only and Produce-only constructors keep their profiles.
    pub async fn open_with_read_store(
        path: impl Into<PathBuf>,
        config: Config,
        store: produce::Config,
        reads: fetch::Limits,
    ) -> Result<(Self, journal::Recovery), Error> {
        store.validate()?;
        if config
            .max_queued_requests
            .saturating_mul(config.max_response_bytes)
            > 512 * 1024 * 1024
        {
            return Err(produce::Error::InvalidConfig.into());
        }
        if config.max_queued_requests.saturating_mul(
            config
                .protocol_limits
                .max_request_bytes()
                .saturating_add(config.max_response_bytes),
        ) > reads.max_retained_bytes()
        {
            return Err(fetch::Error::InvalidLimits.into());
        }
        Self::open_inner(
            path.into(),
            config,
            Some(store),
            Some(reads),
            None,
            None,
            None,
        )
        .await
    }
    /// Open the explicit rolling RF1 read/write/retention profile, adding API21.
    ///
    /// Legacy profiles retain their API ranges. Deletion/sweeps serialize with
    /// reads and appends; a synced operation may complete after caller cancellation.
    pub async fn open_with_retention_store(
        path: impl Into<PathBuf>,
        config: Config,
        store: produce::Config,
        reads: fetch::Limits,
        retention: retention::Config,
    ) -> Result<(Self, journal::Recovery), Error> {
        retention.validate()?;
        store.validate()?;
        if store.segment_limits.is_none()
            || config
                .max_queued_requests
                .saturating_mul(config.max_response_bytes)
                > 512 * 1024 * 1024
        {
            return Err(produce::Error::InvalidConfig.into());
        }
        if config.max_queued_requests.saturating_mul(
            config
                .protocol_limits
                .max_request_bytes()
                .saturating_add(config.max_response_bytes),
        ) > reads.max_retained_bytes()
        {
            return Err(fetch::Error::InvalidLimits.into());
        }
        Self::open_inner(
            path.into(),
            config,
            Some(store),
            Some(reads),
            Some(retention),
            None,
            None,
        )
        .await
    }
    /// Open explicit bounded ordinary compaction on the rolling RF1 owner.
    ///
    /// The wire profile remains Produce3–13, Fetch4–6, ListOffsets1–3 and the
    /// metadata APIs. Cleaning runs only through [`Self::compact_partition`];
    /// no timer is started. Policy scratch covers the complete cleaner operation
    /// including source and publication buffers. Internal coordination topics
    /// and transactional/control/producer-state batches cannot be cleaned.
    pub async fn open_with_compaction_store(
        path: impl Into<PathBuf>,
        config: Config,
        store: produce::Config,
        reads: fetch::Limits,
        policy: compaction::Policy,
    ) -> Result<(Self, journal::Recovery), Error> {
        store.validate_compaction(policy)?;
        if config
            .max_queued_requests
            .saturating_mul(config.max_response_bytes)
            > 512 * 1024 * 1024
        {
            return Err(produce::Error::InvalidConfig.into());
        }
        if config.max_queued_requests.saturating_mul(
            config
                .protocol_limits
                .max_request_bytes()
                .saturating_add(config.max_response_bytes),
        ) > reads.max_retained_bytes()
        {
            return Err(fetch::Error::InvalidLimits.into());
        }
        Self::open_inner(
            path.into(),
            config,
            Some(store),
            Some(reads),
            None,
            Some(policy),
            None,
        )
        .await
    }
    /// Open an explicit metadata-only quorum application frontend.
    ///
    /// Create/Delete success requires exact source quorum commit and application
    /// journal synchronization. Metadata refreshes the local committed projection
    /// before answering; this is not a linearizable quorum read. Runtime must use
    /// a dedicated command log, with the same cluster ID and canonical application
    /// limits on all replicas. Existing single-broker partition placement remains
    /// unchanged; no Produce/Fetch storage or replicated data partitions attach.
    /// The separately owned runtime outlives this router and is shut down after
    /// `Router::shutdown` joins the application actor. No API cap is raised.
    pub async fn open_quorum(
        path: impl Into<PathBuf>,
        config: Config,
        source: crate::raft::runtime::Handle,
        application: crate::metadata_quorum::Limits,
        deadline: Duration,
    ) -> Result<(Self, journal::Recovery), Error> {
        Self::open_quorum_inner(
            path.into(),
            config,
            source,
            application,
            deadline,
            Vec::new(),
        )
        .await
    }

    /// Open a metadata-only quorum frontend with bounded client-facing controller
    /// endpoints. IDs must exactly match the private quorum's genesis and current
    /// voter set. The caller must keep voter membership fixed for this router's
    /// lifetime and reopen the router before changing it. Metadata reports no
    /// partition leaders or data replicas. The caller joins the private runtime
    /// after the router shuts down.
    pub async fn open_quorum_with_controllers(
        path: impl Into<PathBuf>,
        config: Config,
        source: crate::raft::runtime::Handle,
        application: crate::metadata_quorum::Limits,
        deadline: Duration,
        endpoints: Vec<ControllerEndpoint>,
    ) -> Result<(Self, journal::Recovery), Error> {
        if endpoints.is_empty() {
            return Err(Error::InvalidConfig);
        }
        Self::open_quorum_inner(
            path.into(),
            config,
            source,
            application,
            deadline,
            endpoints,
        )
        .await
    }

    async fn open_quorum_inner(
        path: PathBuf,
        config: Config,
        source: crate::raft::runtime::Handle,
        application: crate::metadata_quorum::Limits,
        deadline: Duration,
        endpoints: Vec<ControllerEndpoint>,
    ) -> Result<(Self, journal::Recovery), Error> {
        let (cluster, _, _, genesis) = source
            .metadata_binding()
            .map_err(|_| Error::InvalidConfig)?;
        if !endpoints.is_empty() {
            if endpoints.len() > 64
                || !endpoints.iter().any(|endpoint| {
                    endpoint.id == config.broker_id
                        && wire_advertised_host(&endpoint.host)
                            == wire_advertised_host(&config.advertised_host)
                        && endpoint.port == config.advertised_port
                })
                || endpoints.iter().enumerate().any(|(index, endpoint)| {
                    endpoint.id < 0
                        || endpoint.port == 0
                        || wire_advertised_host(&endpoint.host).is_none()
                        || endpoints[..index].iter().any(|old| {
                            old.id == endpoint.id
                                || (wire_advertised_host(&old.host)
                                    == wire_advertised_host(&endpoint.host)
                                    && old.port == endpoint.port)
                        })
                })
            {
                return Err(Error::InvalidConfig);
            }
            let genesis = crate::raft::membership::Voters::decode(&genesis)
                .map_err(|_| Error::InvalidConfig)?;
            let current = source.voters().await.map_err(|_| Error::InvalidConfig)?;
            let matches = |voters: &crate::raft::membership::Voters| {
                voters.voters().len() == endpoints.len()
                    && voters.voters().iter().all(|voter| {
                        endpoints
                            .iter()
                            .any(|endpoint| u32::try_from(endpoint.id).ok() == Some(voter.key().id))
                    })
            };
            if !matches(&genesis) || !matches(&current) || genesis.voters() != current.voters() {
                return Err(Error::InvalidConfig);
            }
        }
        if cluster != config.cluster_id || application.catalog != config.catalog_limits {
            return Err(Error::InvalidConfig);
        }
        let opening = QuorumOpening {
            source,
            executor: tokio::runtime::Handle::current(),
            limits: application,
            deadline,
            endpoints,
        };
        Self::open_inner(path, config, None, None, None, None, Some(opening)).await
    }

    async fn open_inner(
        path: PathBuf,
        config: Config,
        store: Option<produce::Config>,
        reads: Option<fetch::Limits>,
        retention: Option<retention::Config>,
        compaction: Option<compaction::Policy>,
        quorum: Option<QuorumOpening>,
    ) -> Result<(Self, journal::Recovery), Error> {
        config.validate()?;
        let data = store.is_some();
        let (sender, receiver) = mpsc::channel(config.max_queued_requests);
        let (ready_tx, ready_rx) = oneshot::channel();
        let stopping = Arc::new(AtomicBool::new(false));
        let worker_stop = Arc::clone(&stopping);
        let worker_config = config.clone();
        let (change_tx, changes) = watch::channel(());
        let change_tx = Arc::new(change_tx);
        let wakeup = Arc::downgrade(&change_tx);
        let task = tokio::task::spawn_blocking(move || {
            let (startup, endpoints) = match quorum {
                Some(opening) => (
                    Catalog::open_quorum(
                        path,
                        opening.source,
                        opening.executor,
                        opening.limits,
                        opening.deadline,
                    ),
                    opening.endpoints,
                ),
                None => (
                    Catalog::open(path, worker_config.catalog_limits),
                    Vec::new(),
                ),
            };
            match startup {
                Ok((catalog, recovery)) => {
                    let store = match store
                        .map(|config| {
                            let mut store = produce::Store::open(config, &catalog)?;
                            if let Some(retention) = retention {
                                store.enable_retention(retention)?;
                            }
                            if let Some(compaction) = compaction {
                                store.enable_compaction(compaction)?;
                            }
                            Ok::<_, produce::Error>(store)
                        })
                        .transpose()
                    {
                        Ok(store) => store,
                        Err(error) => {
                            let _ = ready_tx.send(Err(error.into()));
                            return;
                        }
                    };
                    if ready_tx.send(Ok(recovery)).is_ok() {
                        actor(
                            catalog,
                            store,
                            receiver,
                            &worker_config,
                            &worker_stop,
                            DataOptions {
                                reads,
                                retention,
                                endpoints: &endpoints,
                            },
                            &change_tx,
                        );
                    }
                }
                Err(error) => {
                    let _ = ready_tx.send(Err(Error::Catalog(error)));
                }
            }
        });
        let recovery = match ready_rx.await {
            Ok(Ok(recovery)) => recovery,
            Ok(Err(error)) => {
                // A failed store startup still owned Catalog until its closure
                // exited. Join before returning so immediate reopen cannot race
                // resource/ownership cleanup. Cancellation still requests no
                // blocking destructor: dropping ready_rx makes the worker exit.
                let _ = task.await;
                return Err(error);
            }
            Err(_) => {
                let _ = task.await;
                return Err(Error::ActorFailed);
            }
        };
        let data_slots = Semaphore::new(config.max_queued_requests);
        Ok((
            Self {
                config,
                sender,
                stopping,
                failed: AtomicBool::new(false),
                task: Mutex::new(Some(task)),
                data,
                data_slots,
                reads,
                retention,
                compaction: compaction.is_some(),
                changes,
                wakeup,
            },
            recovery,
        ))
    }
    /// Configuration validated at startup.
    pub fn config(&self) -> &Config {
        &self.config
    }
    /// Execute one bounded deterministic retention sweep on the storage owner.
    /// Defaults disable age/size policies; this method does not start a timer.
    pub async fn sweep_retention(&self, now_ms: i64) -> Result<retention::SweepReport, Error> {
        if self.stopping.load(Ordering::Acquire) {
            return Err(Error::Stopped);
        }
        if self.retention.is_none() {
            return Err(retention::Error::InvalidConfig.into());
        }
        let _slot = self
            .data_slots
            .try_acquire()
            .map_err(|_| Error::QueueFull)?;
        let (reply, receiver) = oneshot::channel();
        self.sender
            .try_send(Command::Sweep(SweepJob { now_ms, reply }))
            .map_err(|error| match error {
                mpsc::error::TrySendError::Full(_) => Error::QueueFull,
                mpsc::error::TrySendError::Closed(_) => Error::Stopped,
            })?;
        receiver.await.map_err(|_| Error::ActorFailed)?
    }
    /// Serialize one bounded sealed-prefix cleaning round with reads/mutations.
    ///
    /// The UUID must identify a live ordinary topic and index. Cancellation
    /// skips queued jobs; a rewrite already admitted to storage can complete
    /// durably after cancellation. Reopen after an ambiguous storage failure.
    /// Completed unconsumed receipts retain the same shared admission permit as
    /// data requests, and shutdown joins the exclusive storage owner.
    pub async fn compact_partition(
        &self,
        id: TopicId,
        index: i32,
        now_ms: i64,
    ) -> Result<compaction::Outcome, Error> {
        if self.stopping.load(Ordering::Acquire) {
            return Err(Error::Stopped);
        }
        if !self.compaction || index < 0 || now_ms < 0 {
            return Err(produce::Error::InvalidConfig.into());
        }
        let _slot = self
            .data_slots
            .try_acquire()
            .map_err(|_| Error::QueueFull)?;
        let (reply, receiver) = oneshot::channel();
        self.sender
            .try_send(Command::Compact(CompactJob {
                id,
                index,
                now_ms,
                reply,
            }))
            .map_err(|error| match error {
                mpsc::error::TrySendError::Full(_) => Error::QueueFull,
                mpsc::error::TrySendError::Closed(_) => Error::Stopped,
            })?;
        receiver.await.map_err(|_| Error::ActorFailed)?
    }
    /// Request stop, drain pending replies, and join without blocking Tokio.
    ///
    /// Awaiting by mutable reference retains the join handle when this future
    /// is canceled. A later shutdown call completes the same join. An operation
    /// already inside append/sync may complete before the actor observes stop.
    pub async fn shutdown(&self) -> Result<(), Error> {
        self.request_stop();
        let mut task = self.task.lock().await;
        if let Some(handle) = task.as_mut() {
            if handle.await.is_err() {
                self.failed.store(true, Ordering::Release);
            }
        }
        let _ = task.take();
        if self.failed.load(Ordering::Acquire) {
            Err(Error::ActorFailed)
        } else {
            Ok(())
        }
    }
    fn request_stop(&self) {
        self.stopping.store(true, Ordering::Release);
        if let Some(wakeup) = self.wakeup.upgrade() {
            wakeup.send_replace(());
        }
        let _ = self.sender.try_send(Command::Stop);
    }
    /// Dispatch one transport-bounded payload; no frame prefix is included.
    pub async fn respond(&self, request: Vec<u8>) -> Result<Vec<u8>, Error> {
        self.dispatch(request)
            .await?
            .ok_or_else(|| produce::Error::NoResponse.into())
    }
    /// Dispatch a bounded payload; `None` means successful acks0 and no wire bytes.
    /// Errors close the transport connection. Metadata-only routers reject Produce.
    pub async fn dispatch(&self, request: Vec<u8>) -> Result<Option<Vec<u8>>, Error> {
        self.dispatch_reusing(request, Vec::new())
            .await
            .map(|reused| reused.response)
    }
    async fn dispatch_reusing(
        &self,
        mut request: Vec<u8>,
        mut spare: Vec<u8>,
    ) -> Result<Reused, Error> {
        if self.stopping.load(Ordering::Acquire) {
            return Err(Error::Stopped);
        }
        let data_key = request
            .get(..2)
            .and_then(|v| <[u8; 2]>::try_from(v).ok())
            .map(i16::from_be_bytes);
        if self.data
            && (data_key == Some(0)
                || (self.reads.is_some() && matches!(data_key, Some(1 | 2)))
                || (self.retention.is_some() && data_key == Some(21)))
        {
            // Keep admitted data jobs and completed, unconsumed actor replies
            // bounded together. Once transferred, Vec ownership/budgets belong
            // to the caller, as for the transport's connection/handler limits.
            let _slot = self
                .data_slots
                .try_acquire()
                .map_err(|_| Error::QueueFull)?;
            if request.len() > self.config.protocol_limits.max_request_bytes() {
                return Err(protocol::Error::RequestTooLarge.into());
            }
            let version = i16::from_be_bytes(
                request
                    .get(2..4)
                    .ok_or(protocol::Error::Truncated)?
                    .try_into()
                    .map_err(|_| protocol::Error::Truncated)?,
            );
            let key = data_key.ok_or(protocol::Error::Truncated)?;
            let supported = match key {
                0 => (3..=13).contains(&version),
                1 => (4..=6).contains(&version),
                2 => (1..=3).contains(&version),
                21 => (0..=2).contains(&version),
                _ => false,
            };
            if !supported {
                return Err(Error::UnsupportedVersion {
                    api_key: key,
                    version,
                });
            }
            let admitted = Instant::now();
            let mut changes = self.changes.clone();
            loop {
                if self.stopping.load(Ordering::Acquire) {
                    return Err(Error::Stopped);
                }
                // Capture before enqueue: an append/delete between this point
                // and the serialized snapshot cannot disappear into a lost wake.
                changes.borrow_and_update();
                let (reply, receiver) = oneshot::channel();
                let job_spare = std::mem::take(&mut spare);
                self.sender
                    .try_send(Command::Data(DataJob {
                        request,
                        spare: job_spare,
                        admitted,
                        reply,
                    }))
                    .map_err(|error| match error {
                        mpsc::error::TrySendError::Full(_) => Error::QueueFull,
                        mpsc::error::TrySendError::Closed(_) => Error::Stopped,
                    })?;
                match receiver.await.map_err(|_| Error::ActorFailed)?? {
                    DataReply::Produce {
                        response,
                        request,
                        spare,
                    } => {
                        return Ok(Reused {
                            response,
                            request,
                            spare,
                        });
                    }
                    DataReply::Read {
                        request: retained,
                        snapshot,
                    } => {
                        let deadline = admitted
                            .checked_add(snapshot.wait)
                            .ok_or(Error::InvalidConfig)?;
                        if snapshot.immediate
                            || snapshot.record_bytes >= snapshot.minimum_bytes
                            || Instant::now() >= deadline
                        {
                            return Ok(Reused {
                                response: Some(snapshot.response),
                                request: retained,
                                spare,
                            });
                        }
                        request = retained;
                        // The candidate body is released. Its allocation stays
                        // so the next attempt does not reserve it again.
                        let mut recycled = snapshot.response;
                        recycled.clear();
                        if recycled.capacity() >= spare.capacity() {
                            spare = recycled;
                        }
                        if self.stopping.load(Ordering::Acquire) {
                            return Err(Error::Stopped);
                        }
                        tokio::select! {
                            result = changes.changed() => {
                                result.map_err(|_| Error::Stopped)?;
                            }
                            _ = tokio::time::sleep_until(deadline.into()) => {}
                        }
                    }
                }
            }
        }
        let (key, _) = prefix(&request, &self.config)?;
        if key == 18 {
            let handler = if self.retention.is_some() {
                ApiVersionsHandler::with_advertised(
                    self.config.protocol_limits,
                    &retention::DATA_API_VERSIONS,
                )
            } else if self.reads.is_some() {
                ApiVersionsHandler::with_advertised(
                    self.config.protocol_limits,
                    &fetch::DATA_API_VERSIONS,
                )
            } else if self.data {
                ApiVersionsHandler::with_advertised(
                    self.config.protocol_limits,
                    &produce::DATA_API_VERSIONS,
                )
            } else {
                ApiVersionsHandler::composed(self.config.protocol_limits)
            };
            let response = handler.respond(&request).map(Some)?;
            return Ok(Reused {
                response,
                request,
                spare,
            });
        }
        let (reply, receiver) = oneshot::channel();
        let job = Job {
            request,
            spare,
            admitted: Instant::now(),
            reply,
        };
        self.sender
            .try_send(Command::Request(job))
            .map_err(|error| match error {
                mpsc::error::TrySendError::Full(_) => Error::QueueFull,
                mpsc::error::TrySendError::Closed(_) => Error::Stopped,
            })?;
        let (response, request) = receiver.await.map_err(|_| Error::ActorFailed)??;
        Ok(Reused {
            response: Some(response),
            request,
            spare: Vec::new(),
        })
    }
}
impl Drop for Router {
    fn drop(&mut self) {
        self.request_stop();
    }
}
impl Handler for Router {
    type Error = Error;
    async fn handle(&self, request: Vec<u8>) -> Result<Option<Vec<u8>>, Error> {
        self.dispatch(request).await
    }

    async fn exchange_request(
        &self,
        _peer: &Peer,
        request: Vec<u8>,
        spare: Vec<u8>,
    ) -> Result<ExchangeOutcome, Error> {
        let reused = self.dispatch_reusing(request, spare).await?;
        Ok(ExchangeOutcome {
            response: reused.response,
            request: reused.request,
            spare: reused.spare,
        })
    }
}
fn reserve_count<T>(items: &mut Vec<T>, count: usize) {
    if items.capacity() < count {
        items.reserve(count - items.len());
    }
}

/// Move one queued produce batch into the parallel lists [`produce::process_queued`] walks.
///
/// Each list is sized for every job before the first request is moved.
fn take_queued_produce(
    jobs: &mut Vec<DataJob>,
    bodies: &mut Vec<Vec<u8>>,
    spares: &mut Vec<Vec<u8>>,
    admitted: &mut Vec<Instant>,
    senders: &mut Vec<oneshot::Sender<Result<DataReply, Error>>>,
) {
    let count = jobs.len();
    bodies.clear();
    spares.clear();
    admitted.clear();
    senders.clear();
    reserve_count(bodies, count);
    reserve_count(spares, count);
    reserve_count(admitted, count);
    reserve_count(senders, count);
    for mut queued in jobs.drain(..) {
        bodies.push(std::mem::take(&mut queued.request));
        spares.push(std::mem::take(&mut queued.spare));
        admitted.push(queued.admitted);
        senders.push(queued.reply);
    }
}

fn actor(
    mut catalog: Catalog,
    mut store: Option<produce::Store>,
    mut receiver: mpsc::Receiver<Command>,
    config: &Config,
    stopping: &AtomicBool,
    options: DataOptions<'_>,
    changes: &watch::Sender<()>,
) {
    let mut pending: Option<Command> = None;
    let mut grouped: Vec<DataJob> = Vec::new();
    let mut queued_jobs: Vec<DataJob> = Vec::new();
    let mut queued_bodies: Vec<Vec<u8>> = Vec::new();
    let mut queued_spares: Vec<Vec<u8>> = Vec::new();
    let mut queued_admitted: Vec<Instant> = Vec::new();
    let mut queued_senders: Vec<oneshot::Sender<Result<DataReply, Error>>> = Vec::new();
    while let Some(command) = pending.take().or_else(|| receiver.blocking_recv()) {
        if stopping.load(Ordering::Acquire) {
            receiver.close();
            reject(command);
            break;
        }
        match command {
            Command::Stop => {
                receiver.close();
                break;
            }
            Command::Request(job) => {
                if job.reply.is_closed() {
                    continue;
                }
                let revision = (catalog.operation_count(), catalog.is_poisoned());
                let Job {
                    request,
                    spare,
                    admitted,
                    reply,
                } = job;
                let result = process(
                    &mut catalog,
                    &request,
                    Routing {
                        config,
                        endpoints: options.endpoints,
                    },
                    admitted,
                    &reply,
                    stopping,
                    spare,
                );
                if revision != (catalog.operation_count(), catalog.is_poisoned()) {
                    changes.send_replace(());
                }
                let _ = reply.send(result.map(|response| (response, request)));
            }
            Command::Sweep(job) => {
                if job.reply.is_closed() {
                    continue;
                }
                let result = if catalog.is_poisoned() {
                    Err(Error::StoragePoisoned)
                } else if let Some(store) = store.as_mut() {
                    store
                        .sweep_retention(&catalog, job.now_ms, || {
                            if job.reply.is_closed() || stopping.load(Ordering::Acquire) {
                                Err(retention::Error::Canceled)
                            } else {
                                Ok(())
                            }
                        })
                        .map_err(Into::into)
                } else {
                    Err(retention::Error::InvalidConfig.into())
                };
                if store.as_mut().is_some_and(produce::Store::take_changed) {
                    changes.send_replace(());
                }
                let _ = job.reply.send(result);
            }
            Command::Data(mut job) => {
                if job.reply.is_closed() {
                    continue;
                }
                let produce_key = job.request.get(..2) == Some(&[0, 0]);
                grouped.clear();
                if produce_key {
                    reserve_count(&mut grouped, 7);
                    while grouped.len() < 7 {
                        match receiver.try_recv() {
                            Ok(Command::Data(next))
                                if next.request.get(..2) == Some(&[0, 0])
                                    && next.request.len() <= 64 * 1024 =>
                            {
                                if next.reply.is_closed() {
                                    continue;
                                }
                                grouped.push(next);
                            }
                            Ok(other) => {
                                pending = Some(other);
                                break;
                            }
                            Err(_) => break,
                        }
                    }
                }
                let result = if catalog.is_poisoned() {
                    for extra in grouped.drain(..) {
                        let _ = extra.reply.send(Err(Error::StoragePoisoned));
                    }
                    Err(Error::StoragePoisoned)
                } else if let Some(store) = store.as_mut() {
                    if produce_key && grouped.is_empty() {
                        store.prepare_response_buf(std::mem::take(&mut job.spare));
                        match produce::process(
                            &catalog,
                            store,
                            &mut job.request,
                            config,
                            job.admitted,
                            || {
                                if job.reply.is_closed() || stopping.load(Ordering::Acquire) {
                                    Err(produce::Error::Canceled)
                                } else {
                                    Ok(())
                                }
                            },
                        ) {
                            Ok(response) => {
                                let spare = store.take_response_buf();
                                let request = std::mem::take(&mut job.request);
                                Ok(DataReply::Produce {
                                    response,
                                    request,
                                    spare,
                                })
                            }
                            Err(error) => Err(error.into()),
                        }
                    } else if produce_key {
                        let count = grouped.len().saturating_add(1);
                        queued_jobs.clear();
                        reserve_count(&mut queued_jobs, count);
                        queued_jobs.push(job);
                        queued_jobs.append(&mut grouped);
                        take_queued_produce(
                            &mut queued_jobs,
                            &mut queued_bodies,
                            &mut queued_spares,
                            &mut queued_admitted,
                            &mut queued_senders,
                        );
                        let mut results = produce::process_queued(
                            &catalog,
                            store,
                            &mut queued_bodies,
                            &queued_admitted,
                            config,
                            &mut queued_spares,
                            |index| {
                                let closed = queued_senders
                                    .get(index)
                                    .is_none_or(|sender| sender.is_closed());
                                if closed || stopping.load(Ordering::Acquire) {
                                    Err(produce::Error::Canceled)
                                } else {
                                    Ok(())
                                }
                            },
                        );
                        if store.take_changed() {
                            changes.send_replace(());
                        }
                        let mut body_iter = queued_bodies.drain(..);
                        let mut spare_iter = queued_spares.drain(..);
                        for (sender, result) in queued_senders.drain(..).zip(results.drain(..)) {
                            let request = body_iter.next().unwrap_or_default();
                            let spare = spare_iter.next().unwrap_or_default();
                            let reply = match result {
                                Ok(response) => Ok(DataReply::Produce {
                                    response,
                                    request,
                                    spare,
                                }),
                                Err(error) => Err(error.into()),
                            };
                            let _ = sender.send(reply);
                        }
                        produce::recycle_queued_replies(store, results);
                        continue;
                    } else if job.request.get(..2) == Some(&[0, 21]) {
                        if let Some(retention) = options.retention {
                            retention::process(
                                &catalog,
                                store,
                                &job.request,
                                config,
                                retention,
                                std::mem::take(&mut job.spare),
                                || {
                                    if job.reply.is_closed() || stopping.load(Ordering::Acquire) {
                                        Err(retention::Error::Canceled)
                                    } else {
                                        Ok(())
                                    }
                                },
                            )
                            .map(|response| DataReply::Produce {
                                response: Some(response),
                                request: std::mem::take(&mut job.request),
                                spare: Vec::new(),
                            })
                            .map_err(Into::into)
                        } else {
                            Err(protocol::Error::UnimplementedApi(21).into())
                        }
                    } else if let Some(reads) = options.reads {
                        store.prepare_response_buf(std::mem::take(&mut job.spare));
                        fetch::process(&catalog, store, &job.request, config, reads, || {
                            if job.reply.is_closed() || stopping.load(Ordering::Acquire) {
                                Err(fetch::Error::Canceled)
                            } else {
                                Ok(())
                            }
                        })
                        .map(|snapshot| DataReply::Read {
                            request: job.request,
                            snapshot,
                        })
                        .map_err(Into::into)
                    } else {
                        Err(protocol::Error::UnimplementedApi(1).into())
                    }
                } else {
                    for extra in grouped.drain(..) {
                        let _ = extra
                            .reply
                            .send(Err(protocol::Error::UnimplementedApi(0).into()));
                    }
                    Err(protocol::Error::UnimplementedApi(0).into())
                };
                if store.as_mut().is_some_and(produce::Store::take_changed) {
                    changes.send_replace(());
                }
                let _ = job.reply.send(result);
            }
            Command::Compact(job) => {
                if job.reply.is_closed() {
                    continue;
                }
                let result = if catalog.is_poisoned() {
                    Err(Error::StoragePoisoned)
                } else if let Some(store) = store.as_mut() {
                    store
                        .compact_partition(&catalog, job.id, job.index, job.now_ms)
                        .map_err(Into::into)
                } else {
                    Err(produce::Error::InvalidConfig.into())
                };
                if store.as_mut().is_some_and(produce::Store::take_changed) {
                    changes.send_replace(());
                }
                let _ = job.reply.send(result);
            }
        }
    }
    receiver.close();
    while let Some(command) = receiver.blocking_recv() {
        reject(command);
    }
}
fn reject(command: Command) {
    match command {
        Command::Request(job) => {
            let _ = job.reply.send(Err(Error::Stopped));
        }
        Command::Data(job) => {
            let _ = job.reply.send(Err(Error::Stopped));
        }
        Command::Sweep(job) => {
            let _ = job.reply.send(Err(Error::Stopped));
        }
        Command::Compact(job) => {
            let _ = job.reply.send(Err(Error::Stopped));
        }
        Command::Stop => {}
    }
}

fn prefix(request: &[u8], config: &Config) -> Result<(i16, i16), Error> {
    if request.len() > config.protocol_limits.max_request_bytes() {
        return Err(protocol::Error::RequestTooLarge.into());
    }
    let mut reader = Reader::new(request, config);
    let key = reader.i16()?;
    let version = reader.i16()?;
    let supported = match key {
        3 => (0..=13).contains(&version),
        18 => true,
        19 => (2..=4).contains(&version),
        20 => (1..=6).contains(&version),
        _ => return Err(protocol::Error::UnimplementedApi(key).into()),
    };
    if !supported {
        return Err(Error::UnsupportedVersion {
            api_key: key,
            version,
        });
    }
    Ok((key, version))
}
fn process(
    catalog: &mut Catalog,
    request: &[u8],
    routing: Routing<'_>,
    admitted: Instant,
    reply: &oneshot::Sender<Handled>,
    stopping: &AtomicBool,
    spare: Vec<u8>,
) -> Result<Vec<u8>, Error> {
    let Routing { config, endpoints } = routing;
    if catalog.is_poisoned() {
        return Err(Error::StoragePoisoned);
    }
    let (key, version) = prefix(request, config)?;
    let flexible = (key == 3 && version >= 9) || (key == 20 && version >= 4);
    let (header, body) = RequestHeader::parse(
        request,
        if flexible { 2 } else { 1 },
        config.protocol_limits,
    )?;
    let mut reader = Reader::new(body, config);
    match key {
        3 => {
            let parsed = read_metadata(&mut reader, version, flexible)?;
            // Pinned librdkafka2.15 leaves its four-byte null-array reservation
            // unshrunk. Apache consumes a canonical null/all-topics request and
            // ignores the three remaining zero bytes. Admit exactly that bounded
            // read-only shape; named/empty selectors and every other tail fail.
            if flexible && parsed.topics.is_none() && reader.remaining == [0, 0, 0] {
                let _ = reader.take(3)?;
            }
            reader.finish()?;
            check_active(reply, stopping)?;
            catalog.refresh().map_err(Error::Catalog)?;
            check_active(reply, stopping)?;
            metadata(catalog, config, endpoints, header, parsed, flexible, spare)
        }
        19 => {
            let mut parsed = read_create(&mut reader)?;
            reader.finish()?;
            check_active(reply, stopping)?;
            if !timed_out(admitted, parsed.timeout) {
                let until = admitted + Duration::from_millis(parsed.timeout as u64);
                match catalog.refresh_until(until) {
                    Ok(()) => {}
                    // No mutation may follow an expired refresh. Reuse the
                    // existing per-topic timeout encoder without a new budget.
                    Err(catalog::Error::QuorumDeadline) => parsed.timeout = 0,
                    Err(error) => return Err(Error::Catalog(error)),
                }
            }
            check_active(reply, stopping)?;
            create(
                catalog, config, header, parsed, admitted, reply, stopping, spare,
            )
        }
        20 => {
            let mut parsed = read_delete(&mut reader, version, flexible)?;
            reader.finish()?;
            check_active(reply, stopping)?;
            if !timed_out(admitted, parsed.timeout) {
                let until = admitted + Duration::from_millis(parsed.timeout as u64);
                match catalog.refresh_until(until) {
                    Ok(()) => {}
                    // No mutation may follow an expired refresh. Reuse the
                    // existing per-topic timeout encoder without a new budget.
                    Err(catalog::Error::QuorumDeadline) => parsed.timeout = 0,
                    Err(error) => return Err(Error::Catalog(error)),
                }
            }
            check_active(reply, stopping)?;
            delete(
                catalog, config, header, parsed, admitted, reply, stopping, spare,
            )
        }
        _ => Err(protocol::Error::UnimplementedApi(key).into()),
    }
}

struct Reader<'a> {
    remaining: &'a [u8],
    max_topics: usize,
    max_tags: usize,
}
impl<'a> Reader<'a> {
    fn new(bytes: &'a [u8], config: &Config) -> Self {
        Self {
            remaining: bytes,
            max_topics: config.max_topics,
            max_tags: config.protocol_limits.max_tagged_fields(),
        }
    }
    fn take(&mut self, length: usize) -> Result<&'a [u8], Error> {
        let value = self
            .remaining
            .get(..length)
            .ok_or(protocol::Error::Truncated)?;
        self.remaining = &self.remaining[length..];
        Ok(value)
    }
    fn i16(&mut self) -> Result<i16, Error> {
        Ok(i16::from_be_bytes(
            self.take(2)?
                .try_into()
                .map_err(|_| protocol::Error::Truncated)?,
        ))
    }
    fn i32(&mut self) -> Result<i32, Error> {
        Ok(i32::from_be_bytes(
            self.take(4)?
                .try_into()
                .map_err(|_| protocol::Error::Truncated)?,
        ))
    }
    fn uuid(&mut self) -> Result<[u8; 16], Error> {
        self.take(16)?
            .try_into()
            .map_err(|_| protocol::Error::Truncated.into())
    }
    fn boolean(&mut self) -> Result<bool, Error> {
        match self.take(1)?[0] {
            0 => Ok(false),
            1 => Ok(true),
            _ => Err(Error::InvalidBoolean),
        }
    }
    fn varint(&mut self) -> Result<u32, Error> {
        let mut value = 0u32;
        for shift in [0, 7, 14, 21, 28] {
            let byte = self.take(1)?[0];
            if shift == 28 && byte > 15 {
                return Err(protocol::Error::InvalidVarint.into());
            }
            value |= u32::from(byte & 127) << shift;
            if byte & 128 == 0 {
                return Ok(value);
            }
        }
        Err(protocol::Error::InvalidVarint.into())
    }
    fn string(&mut self, flexible: bool, nullable: bool) -> Result<Option<&'a str>, Error> {
        let length = if flexible {
            i64::from(self.varint()?) - 1
        } else {
            i64::from(self.i16()?)
        };
        if length == -1 && nullable {
            return Ok(None);
        }
        if !(0..=32767).contains(&length) {
            return Err(protocol::Error::InvalidLength.into());
        }
        let value = std::str::from_utf8(self.take(length as usize)?)
            .map_err(|_| protocol::Error::InvalidUtf8)?;
        Ok(Some(value))
    }
    fn required_string(&mut self, flexible: bool) -> Result<&'a str, Error> {
        self.string(flexible, false)?
            .ok_or_else(|| protocol::Error::InvalidLength.into())
    }
    fn count(
        &mut self,
        flexible: bool,
        nullable: bool,
        minimum: usize,
    ) -> Result<Option<usize>, Error> {
        let count = if flexible {
            i64::from(self.varint()?) - 1
        } else {
            i64::from(self.i32()?)
        };
        if count == -1 && nullable {
            return Ok(None);
        }
        if count < 0 || count > self.max_topics as i64 {
            return Err(Error::RequestCount);
        }
        let count = count as usize;
        if count > self.remaining.len() / minimum.max(1) {
            return Err(Error::RequestCount);
        }
        Ok(Some(count))
    }
    fn array(&mut self, flexible: bool, minimum: usize) -> Result<usize, Error> {
        self.count(flexible, false, minimum)?
            .ok_or(Error::RequestCount)
    }
    fn tags(&mut self) -> Result<(), Error> {
        let count = self.varint()? as usize;
        if count > self.max_tags {
            return Err(protocol::Error::TooManyTags.into());
        }
        let mut previous = None;
        for _ in 0..count {
            let tag = self.varint()?;
            if previous.is_some_and(|v| tag <= v) {
                return Err(protocol::Error::InvalidTagOrder.into());
            }
            previous = Some(tag);
            let length = self.varint()? as usize;
            self.take(length)?;
        }
        Ok(())
    }
    fn finish(&self) -> Result<(), Error> {
        if self.remaining.is_empty() {
            Ok(())
        } else {
            Err(protocol::Error::TrailingBytes.into())
        }
    }
}
fn bounded_vec<T>(count: usize) -> Result<Vec<T>, Error> {
    let mut values = Vec::new();
    values
        .try_reserve_exact(count)
        .map_err(|_| Error::ResponseLimit)?;
    Ok(values)
}
struct Target<'a> {
    name: Option<&'a str>,
    id: [u8; 16],
}
struct MetadataRequest<'a> {
    topics: Option<Vec<Target<'a>>>,
    cluster_ops: bool,
    topic_ops: bool,
}
fn read_metadata<'a>(
    reader: &mut Reader<'a>,
    version: i16,
    flex: bool,
) -> Result<MetadataRequest<'a>, Error> {
    let count = reader.count(flex, version >= 1, if version >= 10 { 17 } else { 2 })?;
    let topics = if let Some(count) = count {
        let mut values = bounded_vec(count)?;
        for _ in 0..count {
            let id = if version >= 10 { reader.uuid()? } else { ZERO };
            let name = reader.string(flex, version >= 10)?;
            if flex {
                reader.tags()?;
            }
            values.push(Target { name, id });
        }
        if version == 0 && count == 0 {
            None
        } else {
            Some(values)
        }
    } else {
        None
    };
    if version >= 4 {
        let _ = reader.boolean()?;
    }
    let cluster_ops = if (8..=10).contains(&version) {
        reader.boolean()?
    } else {
        false
    };
    let topic_ops = if version >= 8 {
        reader.boolean()?
    } else {
        false
    };
    if flex {
        reader.tags()?;
    }
    Ok(MetadataRequest {
        topics,
        cluster_ops,
        topic_ops,
    })
}
struct Assignment {
    index: i32,
    brokers: Vec<i32>,
}
struct CreateTopic<'a> {
    name: &'a str,
    partitions: i32,
    replicas: i16,
    assignments: Vec<Assignment>,
    config_count: usize,
}
struct CreateRequest<'a> {
    topics: Vec<CreateTopic<'a>>,
    timeout: i32,
    validate: bool,
}
fn read_create<'a>(reader: &mut Reader<'a>) -> Result<CreateRequest<'a>, Error> {
    let count = reader.array(false, 16)?;
    let mut topics = bounded_vec(count)?;
    for _ in 0..count {
        let name = reader.required_string(false)?;
        let partitions = reader.i32()?;
        let replicas = reader.i16()?;
        let count = reader.array(false, 8)?;
        let mut assignments = bounded_vec(count)?;
        for _ in 0..count {
            let index = reader.i32()?;
            let count = reader.array(false, 4)?;
            let mut brokers = bounded_vec(count)?;
            for _ in 0..count {
                brokers.push(reader.i32()?);
            }
            assignments.push(Assignment { index, brokers });
        }
        let config_count = reader.array(false, 4)?;
        for _ in 0..config_count {
            let _ = reader.required_string(false)?;
            let _ = reader.string(false, true)?;
        }
        topics.push(CreateTopic {
            name,
            partitions,
            replicas,
            assignments,
            config_count,
        });
    }
    Ok(CreateRequest {
        topics,
        timeout: reader.i32()?,
        validate: reader.boolean()?,
    })
}
struct DeleteRequest<'a> {
    topics: Vec<Target<'a>>,
    timeout: i32,
}
fn read_delete<'a>(
    reader: &mut Reader<'a>,
    version: i16,
    flex: bool,
) -> Result<DeleteRequest<'a>, Error> {
    let count = reader.array(
        flex,
        if version >= 6 {
            18
        } else if flex {
            1
        } else {
            2
        },
    )?;
    let mut topics = bounded_vec(count)?;
    for _ in 0..count {
        let name = reader.string(flex, version >= 6)?;
        let id = if version >= 6 { reader.uuid()? } else { ZERO };
        if flex && version >= 6 {
            reader.tags()?;
        }
        topics.push(Target { name, id });
    }
    let timeout = reader.i32()?;
    if flex {
        reader.tags()?;
    }
    Ok(DeleteRequest { topics, timeout })
}

struct Writer {
    bytes: Vec<u8>,
    cap: usize,
}
impl Writer {
    #[cfg(test)]
    fn new(cap: usize) -> Result<Self, Error> {
        Self::reusing(cap, Vec::new())
    }
    fn reusing(cap: usize, mut bytes: Vec<u8>) -> Result<Self, Error> {
        bytes.clear();
        Ok(Self { bytes, cap })
    }
    fn reserve(&mut self, bytes: usize) -> Result<(), Error> {
        if bytes > self.cap {
            return Err(Error::ResponseLimit);
        }
        if self.bytes.capacity() < bytes {
            self.bytes
                .try_reserve_exact(bytes - self.bytes.len())
                .map_err(|_| Error::ResponseLimit)?;
        }
        Ok(())
    }
    fn put(&mut self, value: &[u8]) -> Result<(), Error> {
        if value.len() > self.cap.saturating_sub(self.bytes.len()) {
            return Err(Error::ResponseLimit);
        }
        self.bytes
            .try_reserve(value.len())
            .map_err(|_| Error::ResponseLimit)?;
        self.bytes.extend_from_slice(value);
        Ok(())
    }
    fn byte(&mut self, value: u8) -> Result<(), Error> {
        self.put(&[value])
    }
    fn i16(&mut self, value: i16) -> Result<(), Error> {
        self.put(&value.to_be_bytes())
    }
    fn i32(&mut self, value: i32) -> Result<(), Error> {
        self.put(&value.to_be_bytes())
    }
    fn varint(&mut self, mut value: u32) -> Result<(), Error> {
        while value >= 128 {
            self.byte((value as u8) | 128)?;
            value >>= 7;
        }
        self.byte(value as u8)
    }
    fn count(&mut self, count: usize, flex: bool) -> Result<(), Error> {
        if flex {
            let count = u32::try_from(count).map_err(|_| Error::ResponseLimit)?;
            self.varint(count.checked_add(1).ok_or(Error::ResponseLimit)?)
        } else {
            self.i32(i32::try_from(count).map_err(|_| Error::ResponseLimit)?)
        }
    }
    fn string(&mut self, value: Option<&str>, flex: bool, nullable: bool) -> Result<(), Error> {
        if let Some(value) = value {
            if value.len() > 32767 {
                return Err(Error::ResponseLimit);
            }
            if flex {
                self.varint((value.len() + 1) as u32)?;
            } else {
                self.i16(value.len() as i16)?;
            }
            self.put(value.as_bytes())
        } else if nullable {
            if flex {
                self.byte(0)
            } else {
                self.i16(-1)
            }
        } else {
            Err(Error::ResponseLimit)
        }
    }
    fn tags(&mut self, flex: bool) -> Result<(), Error> {
        if flex {
            self.byte(0)
        } else {
            Ok(())
        }
    }
    fn header(&mut self, correlation: i32, flex: bool) -> Result<(), Error> {
        self.i32(correlation)?;
        self.tags(flex)
    }
}

fn varint_len(mut value: u32) -> usize {
    let mut len = 1usize;
    while value >= 128 {
        len = len.saturating_add(1);
        value >>= 7;
    }
    len
}

fn count_len(count: usize, flex: bool) -> Result<usize, Error> {
    if flex {
        let count = u32::try_from(count).map_err(|_| Error::ResponseLimit)?;
        Ok(varint_len(
            count.checked_add(1).ok_or(Error::ResponseLimit)?,
        ))
    } else {
        let _count = i32::try_from(count).map_err(|_| Error::ResponseLimit)?;
        Ok(4)
    }
}

fn string_len(value: Option<&str>, flex: bool, nullable: bool) -> Result<usize, Error> {
    if let Some(value) = value {
        if value.len() > 32767 {
            return Err(Error::ResponseLimit);
        }
        let prefix = if flex {
            varint_len((value.len() + 1) as u32)
        } else {
            2
        };
        Ok(prefix.saturating_add(value.len()))
    } else if nullable {
        Ok(if flex { 1 } else { 2 })
    } else {
        Err(Error::ResponseLimit)
    }
}

fn add_len(total: usize, next: usize) -> Result<usize, Error> {
    total.checked_add(next).ok_or(Error::ResponseLimit)
}

fn metadata_response_len(
    config: &Config,
    endpoints: &[ControllerEndpoint],
    version: i16,
    flex: bool,
    semantic_error: bool,
    results: &[MetadataTopic<'_>],
) -> Result<usize, Error> {
    let mut total = 4usize;
    if flex {
        total = add_len(total, 1)?;
    }
    if version >= 3 {
        total = add_len(total, 4)?;
    }
    let quorum = !endpoints.is_empty();
    let brokers = if semantic_error {
        0
    } else if quorum {
        endpoints.len()
    } else {
        1
    };
    total = add_len(total, count_len(brokers, flex)?)?;
    if !semantic_error {
        let hosts = endpoints
            .iter()
            .map(|endpoint| endpoint.host.as_str())
            .chain(std::iter::once(config.advertised_host.as_str()).filter(|_| !quorum));
        for host in hosts {
            total = add_len(total, 4)?;
            total = add_len(total, string_len(wire_advertised_host(host), flex, false)?)?;
            total = add_len(total, 4)?;
            if version >= 1 {
                total = add_len(total, string_len(None, flex, true)?)?;
            }
            if flex {
                total = add_len(total, 1)?;
            }
        }
    }
    if version >= 2 {
        total = add_len(
            total,
            string_len(
                if semantic_error {
                    None
                } else {
                    Some(config.cluster_id.as_str())
                },
                flex,
                true,
            )?,
        )?;
    }
    if version >= 1 {
        total = add_len(total, 4)?;
    }
    total = add_len(total, count_len(results.len(), flex)?)?;
    for result in results {
        total = add_len(total, 2)?;
        total = add_len(total, string_len(result.name, flex, version >= 12)?)?;
        if version >= 10 {
            total = add_len(total, result.id.len())?;
        }
        if version >= 1 {
            total = add_len(total, 1)?;
        }
        let partitions = result.topic.map_or(0, Topic::partition_count) as usize;
        total = add_len(total, count_len(partitions, flex)?)?;
        let mut partition = 2 + 4 + 4;
        if version >= 7 {
            partition += 4;
        }
        partition += count_len(usize::from(!quorum), flex)? + if quorum { 0 } else { 4 };
        partition += count_len(usize::from(!quorum), flex)? + if quorum { 0 } else { 4 };
        if version >= 5 {
            partition += count_len(0, flex)?;
        }
        if flex {
            partition += 1;
        }
        total = add_len(
            total,
            partition
                .checked_mul(partitions)
                .ok_or(Error::ResponseLimit)?,
        )?;
        if version >= 8 {
            total = add_len(total, 4)?;
        }
        if flex {
            total = add_len(total, 1)?;
        }
    }
    if (8..=10).contains(&version) {
        total = add_len(total, 4)?;
    }
    if version >= 13 {
        total = add_len(total, 2)?;
    }
    if flex {
        total = add_len(total, 1)?;
    }
    Ok(total)
}

/// A few values stay on the stack. The seventeenth value allocates a set.
struct ShortSet<T> {
    stack: [Option<T>; 16],
    filled: usize,
    heap: HashSet<T>,
}

impl<T: Copy + Eq + std::hash::Hash> ShortSet<T> {
    fn new() -> Self {
        Self {
            stack: [None; 16],
            filled: 0,
            heap: HashSet::new(),
        }
    }

    fn contains(&self, value: &T) -> bool {
        if self.heap.is_empty() {
            self.stack
                .iter()
                .take(self.filled)
                .any(|slot| slot.as_ref() == Some(value))
        } else {
            self.heap.contains(value)
        }
    }

    fn insert(&mut self, value: T) -> bool {
        if self.contains(&value) {
            return false;
        }
        if self.heap.capacity() == 0 && self.filled < self.stack.len() {
            if let Some(slot) = self.stack.get_mut(self.filled) {
                *slot = Some(value);
            }
            self.filled = self.filled.saturating_add(1);
            return true;
        }
        if self.heap.is_empty() {
            for seen in self.stack.iter().take(self.filled).copied().flatten() {
                let _ = self.heap.insert(seen);
            }
        }
        self.heap.insert(value)
    }
}

fn collect_metadata_topics<'a>(
    catalog: &'a Catalog,
    semantic_error: bool,
    targets: &'a [Target<'a>],
    results: &mut Vec<MetadataTopic<'a>>,
) -> Result<(), Error> {
    // One target cannot repeat. A larger request remembers names and ids already emitted.
    let track = !semantic_error && targets.len() > 1;
    let mut seen_names: ShortSet<Option<&str>> = ShortSet::new();
    let mut seen_ids: ShortSet<[u8; 16]> = ShortSet::new();
    for target in targets {
        // Each topic is resolved on its own. A non-zero id is an id lookup.
        // A zero id is a name lookup, including when the same request also
        // names other topics by id.
        let by_id = !semantic_error && target.id != ZERO;
        if track
            && if by_id {
                seen_ids.contains(&target.id)
            } else {
                seen_names.contains(&target.name)
            }
        {
            continue;
        }
        if semantic_error {
            results.push(MetadataTopic {
                name: Some(target.name.unwrap_or("")),
                id: target.id,
                error: 42,
                topic: None,
            });
            continue;
        }
        let topic = if by_id {
            TopicId::new(target.id)
                .ok()
                .and_then(|id| catalog.by_id(id))
        } else {
            target.name.and_then(|name| catalog.by_name(name))
        };
        let pushed = if let Some(topic) = topic {
            MetadataTopic {
                name: Some(topic.name()),
                id: topic.id().bytes(),
                error: 0,
                topic: Some(topic),
            }
        } else {
            let error = if by_id {
                100
            } else if target
                .name
                .is_some_and(|name| catalog::validate_topic_name(name).is_err())
            {
                17
            } else {
                3
            };
            MetadataTopic {
                name: if by_id { None } else { target.name },
                id: if by_id { target.id } else { ZERO },
                error,
                topic: None,
            }
        };
        if track {
            if pushed.id != ZERO {
                let _ = seen_ids.insert(pushed.id);
            }
            let _ = seen_names.insert(pushed.name);
        }
        results.push(pushed);
    }
    Ok(())
}

struct MetadataTopic<'a> {
    name: Option<&'a str>,
    id: [u8; 16],
    error: i16,
    topic: Option<&'a Topic>,
}
fn metadata(
    catalog: &Catalog,
    config: &Config,
    endpoints: &[ControllerEndpoint],
    header: RequestHeader<'_>,
    request: MetadataRequest<'_>,
    flex: bool,
    spare: Vec<u8>,
) -> Result<Vec<u8>, Error> {
    let version = header.api_version;
    if version >= 12
        && request.topics.as_ref().is_some_and(|topics| {
            topics
                .iter()
                .any(|target| target.name.is_none() && target.id == ZERO)
        })
    {
        return Err(Error::InvalidTarget);
    }
    let semantic_error = request.topics.as_ref().is_some_and(|topics| {
        version < 12 && topics.iter().any(|t| t.name.is_none() || t.id != ZERO)
    });
    let mut results = bounded_vec(
        request
            .topics
            .as_ref()
            .map_or(catalog.topic_count(), Vec::len),
    )?;
    if let Some(targets) = &request.topics {
        collect_metadata_topics(catalog, semantic_error, targets, &mut results)?;
    } else {
        for topic in catalog.topics() {
            results.push(MetadataTopic {
                name: Some(topic.name()),
                id: topic.id().bytes(),
                error: 0,
                topic: Some(topic),
            });
        }
    }
    let planned =
        metadata_response_len(config, endpoints, version, flex, semantic_error, &results)?;
    let mut writer = Writer::reusing(config.max_response_bytes, spare)?;
    writer.reserve(planned)?;
    writer.header(header.correlation_id, flex)?;
    if version >= 3 {
        writer.i32(0)?;
    }
    let quorum = !endpoints.is_empty();
    let brokers = if semantic_error {
        0
    } else if quorum {
        endpoints.len()
    } else {
        1
    };
    writer.count(brokers, flex)?;
    if !semantic_error {
        if quorum {
            for endpoint in endpoints {
                writer.i32(endpoint.id)?;
                writer.string(wire_advertised_host(&endpoint.host), flex, false)?;
                writer.i32(i32::from(endpoint.port))?;
                if version >= 1 {
                    writer.string(None, flex, true)?;
                }
                writer.tags(flex)?;
            }
        } else {
            writer.i32(config.broker_id)?;
            writer.string(wire_advertised_host(&config.advertised_host), flex, false)?;
            writer.i32(i32::from(config.advertised_port))?;
            if version >= 1 {
                writer.string(None, flex, true)?;
            }
            writer.tags(flex)?;
        }
    }
    if version >= 2 {
        writer.string(
            if semantic_error {
                None
            } else {
                Some(&config.cluster_id)
            },
            flex,
            true,
        )?;
    }
    if version >= 1 {
        writer.i32(if semantic_error {
            -1
        } else {
            let controller = catalog.controller_id().unwrap_or(config.broker_id);
            if quorum && !endpoints.iter().any(|endpoint| endpoint.id == controller) {
                -1
            } else {
                controller
            }
        })?;
    }
    writer.count(results.len(), flex)?;
    for result in results {
        writer.i16(result.error)?;
        writer.string(result.name, flex, version >= 12)?;
        if version >= 10 {
            writer.put(&result.id)?;
        }
        if version >= 1 {
            writer.byte(u8::from(
                !semantic_error && result.name.is_some_and(is_internal),
            ))?;
        }
        let partitions = result.topic.map_or(0, Topic::partition_count) as usize;
        writer.count(partitions, flex)?;
        for partition in 0..partitions {
            // A metadata-only controller has no data replica or partition leader.
            writer.i16(if quorum { 5 } else { 0 })?;
            writer.i32(partition as i32)?;
            writer.i32(if quorum { -1 } else { config.broker_id })?;
            if version >= 7 {
                writer.i32(if quorum { -1 } else { 0 })?;
            }
            writer.count(usize::from(!quorum), flex)?;
            if !quorum {
                writer.i32(config.broker_id)?;
            }
            writer.count(usize::from(!quorum), flex)?;
            if !quorum {
                writer.i32(config.broker_id)?;
            }
            if version >= 5 {
                writer.count(0, flex)?;
            }
            writer.tags(flex)?;
        }
        if version >= 8 {
            writer.i32(
                if request.topic_ops && result.error != 100 && !semantic_error {
                    TOPIC_OPS
                } else {
                    i32::MIN
                },
            )?;
        }
        writer.tags(flex)?;
    }
    if (8..=10).contains(&version) {
        writer.i32(if request.cluster_ops && !semantic_error {
            CLUSTER_OPS
        } else {
            i32::MIN
        })?;
    }
    if version >= 13 {
        writer.i16(if semantic_error { 42 } else { 0 })?;
    }
    writer.tags(flex)?;
    debug_assert_eq!(writer.bytes.len(), planned);
    Ok(writer.bytes)
}
fn is_internal(name: &str) -> bool {
    matches!(
        name,
        "__consumer_offsets" | "__transaction_state" | "__share_group_state"
    )
}

#[derive(Clone, Copy)]
struct ApiError {
    code: i16,
    message: Option<&'static str>,
}
const OK: ApiError = ApiError {
    code: 0,
    message: None,
};
const TIMEOUT: ApiError = ApiError {
    code: 7,
    message: None,
};
fn api_error(code: i16, message: &'static str) -> ApiError {
    ApiError {
        code,
        message: Some(message),
    }
}
fn catalog_error(error: &catalog::Error) -> ApiError {
    match error {
        catalog::Error::NotController => api_error(41, "This node is not the metadata controller."),
        catalog::Error::QuorumDeadline => TIMEOUT,
        catalog::Error::InvalidName => api_error(17, "Invalid topic name."),
        catalog::Error::ReservedName => api_error(
            42,
            "Creation of internal topic __cluster_metadata is prohibited.",
        ),
        catalog::Error::DuplicateName => api_error(36, "Topic already exists."),
        catalog::Error::NameCollision => {
            api_error(17, "Topic name collides with an existing topic.")
        }
        catalog::Error::InvalidPartitionCount => api_error(
            37,
            "Number of partitions was set to an invalid non-positive value.",
        ),
        catalog::Error::UnknownIdentity => ApiError {
            code: 100,
            message: None,
        },
        catalog::Error::Journal(journal::Error::FileBudgetExceeded)
        | catalog::Error::TopicBudgetExceeded
        | catalog::Error::IdentityBudgetExceeded
        | catalog::Error::PartitionBudgetExceeded
        | catalog::Error::OperationBudgetExceeded
        | catalog::Error::ReplayBudgetExceeded => {
            api_error(89, "Local catalog resource budget exceeded.")
        }
        _ => api_error(
            56,
            "Local catalog storage operation failed; outcome may be ambiguous.",
        ),
    }
}
fn timed_out(admitted: Instant, timeout: i32) -> bool {
    timeout <= 0 || admitted.elapsed() >= Duration::from_millis(timeout as u64)
}
fn check_active(reply: &oneshot::Sender<Handled>, stopping: &AtomicBool) -> Result<(), Error> {
    if stopping.load(Ordering::Acquire) {
        Err(Error::Stopped)
    } else if reply.is_closed() {
        Err(Error::Canceled)
    } else {
        Ok(())
    }
}
fn create_validation(
    catalog: &Catalog,
    config: &Config,
    version: i16,
    topic: &CreateTopic<'_>,
) -> Result<u32, ApiError> {
    if topic.name == "__cluster_metadata" {
        return Err(api_error(
            42,
            "Creation of internal topic __cluster_metadata is prohibited.",
        ));
    }
    if catalog::validate_topic_name(topic.name).is_err() {
        return Err(api_error(17, "Invalid topic name."));
    }
    if catalog.by_name(topic.name).is_some() {
        return Err(api_error(36, "Topic already exists."));
    }
    if catalog.name_collides(topic.name) {
        return Err(api_error(17, "Topic name collides with an existing topic."));
    }
    if topic.config_count != 0 {
        return Err(api_error(
            40,
            "Topic configuration overrides are not supported by this broker.",
        ));
    }
    let partitions = if !topic.assignments.is_empty() {
        if topic.replicas != -1 {
            return Err(api_error(42,"A manual partition assignment was specified, but replication factor was not set to -1."));
        }
        if topic.partitions != -1 {
            return Err(api_error(
                42,
                "A manual partition assignment was specified, but numPartitions was not set to -1.",
            ));
        }
        let mut seen = vec![false; topic.assignments.len()];
        for assignment in &topic.assignments {
            if !claim_assignment_index(&mut seen, assignment.index) {
                return Err(api_error(
                    39,
                    "partitions should be a consecutive 0-based integer sequence",
                ));
            }
            if assignment.brokers.as_slice() != [config.broker_id] {
                return Err(api_error(
                    39,
                    "Manual assignments must contain only this broker.",
                ));
            }
        }
        topic.assignments.len() as u32
    } else {
        let replicas = if topic.replicas == -1 && version >= 4 {
            1
        } else {
            topic.replicas
        };
        if replicas != 1 {
            return Err(api_error(
                38,
                "Replication factor must be one on this single-node broker.",
            ));
        }
        if topic.partitions == -1 && version >= 4 {
            config.default_partitions
        } else {
            u32::try_from(topic.partitions)
                .ok()
                .filter(|count| *count > 0)
                .ok_or_else(|| {
                    api_error(
                        37,
                        "Number of partitions was set to an invalid non-positive value.",
                    )
                })?
        }
    };
    let limits = config.catalog_limits;
    let payload = 34 + topic.name.len() as u64;
    if partitions > limits.max_partitions_per_topic()
        || catalog.total_partitions() + u64::from(partitions) > limits.max_total_partitions()
        || catalog.topic_count() >= limits.max_live_topics()
        || catalog.identity_count() >= limits.max_identities()
        || catalog.operation_count() >= limits.max_operations()
        || catalog.replay_bytes() + payload > limits.max_replay_bytes()
        || catalog.journal_bytes() + 32 + payload > limits.journal_limits().max_file_bytes()
    {
        return Err(api_error(89, "Local catalog resource budget exceeded."));
    }
    Ok(partitions)
}
/// First copy of each key, and whether a later copy exists.
///
/// One item needs no map. A `None` key is ignored, so an invalid delete target
/// does not hide a later valid one.
fn mark_first_copies<T, K>(
    items: &[T],
    mut key: impl FnMut(&T) -> Option<K>,
) -> Option<(Vec<bool>, Vec<bool>)>
where
    K: Eq + std::hash::Hash,
{
    if items.len() <= 1 {
        return None;
    }
    let mut first = vec![false; items.len()];
    let mut duplicated = vec![false; items.len()];
    let mut owner: HashMap<K, usize> = HashMap::new();
    for (index, item) in items.iter().enumerate() {
        let Some(key) = key(item) else {
            continue;
        };
        if let Some(earlier) = owner.get(&key).copied() {
            if let Some(flag) = duplicated.get_mut(earlier) {
                *flag = true;
            }
        } else {
            if let Some(flag) = first.get_mut(index) {
                *flag = true;
            }
            let _ = owner.insert(key, index);
        }
    }
    Some((first, duplicated))
}

fn delete_alias_sets<'a>(
    topics: &'a [Target<'a>],
    catalog: &Catalog,
) -> (HashSet<[u8; 16]>, HashSet<[u8; 16]>) {
    let mut requested_ids = HashSet::new();
    let mut unique_name_ids = HashSet::new();
    if topics.len() <= 1 {
        return (requested_ids, unique_name_ids);
    }
    let mut name_counts: HashMap<&str, usize> = HashMap::new();
    for target in topics {
        match delete_identity(target) {
            Some(DeleteKey::Id(id)) => {
                let _ = requested_ids.insert(id);
            }
            Some(DeleteKey::Name(name)) => {
                let count = name_counts.entry(name).or_insert(0);
                *count = count.saturating_add(1);
            }
            None => {}
        }
    }
    for (name, count) in &name_counts {
        if *count == 1 {
            if let Some(live) = catalog.by_name(name) {
                let _ = unique_name_ids.insert(live.id().bytes());
            }
        }
    }
    (requested_ids, unique_name_ids)
}

fn delete_identity<'a>(target: &Target<'a>) -> Option<DeleteKey<'a>> {
    match (target.name, target.id == ZERO) {
        (Some(name), true) => Some(DeleteKey::Name(name)),
        (None, false) => Some(DeleteKey::Id(target.id)),
        _ => None,
    }
}

#[derive(Eq, PartialEq, Hash)]
enum DeleteKey<'a> {
    Name(&'a str),
    Id([u8; 16]),
}

fn claim_assignment_index(seen: &mut [bool], index: i32) -> bool {
    let Some(slot) = usize::try_from(index)
        .ok()
        .and_then(|index| seen.get_mut(index))
    else {
        return false;
    };
    if *slot {
        return false;
    }
    *slot = true;
    true
}

fn topic_collision_key(name: &str) -> Vec<u8> {
    name.bytes()
        .map(|byte| if byte == b'.' { b'_' } else { byte })
        .collect()
}

#[cfg(test)]
fn topic_names_collide(left: &str, right: &str) -> bool {
    let fold = |byte: u8| if byte == b'.' { b'_' } else { byte };
    left.len() == right.len()
        && left
            .bytes()
            .zip(right.bytes())
            .all(|(left, right)| fold(left) == fold(right))
}

fn fresh_id(catalog: &Catalog) -> Result<TopicId, ApiError> {
    for _ in 0..32 {
        let mut bytes = [0; 16];
        getrandom::fill(&mut bytes)
            .map_err(|_| api_error(56, "Operating system topic identity allocation failed."))?;
        bytes[6] = (bytes[6] & 15) | 64;
        bytes[8] = (bytes[8] & 63) | 128;
        // Apache Uuid.randomUuid also excludes base64url's leading '-'.
        if bytes[0] >> 2 == 62 {
            continue;
        }
        if let Ok(id) = TopicId::new(bytes) {
            if catalog.by_id(id).is_none() && !catalog.is_tombstoned(id) {
                return Ok(id);
            }
        }
    }
    Err(api_error(
        56,
        "Topic identity collision retry budget exhausted.",
    ))
}
#[expect(
    clippy::too_many_arguments,
    reason = "create threads the catalog, header, deadline, and reused response buffer"
)]
fn create(
    catalog: &mut Catalog,
    config: &Config,
    header: RequestHeader<'_>,
    request: CreateRequest<'_>,
    admitted: Instant,
    reply: &oneshot::Sender<Handled>,
    stopping: &AtomicBool,
    spare: Vec<u8>,
) -> Result<Vec<u8>, Error> {
    let mut writer = Writer::reusing(config.max_response_bytes, spare)?;
    let mut results = bounded_vec(request.topics.len())?;
    // Reserve a conservative complete response before any durable operation.
    let needed = request.topics.iter().try_fold(12usize, |sum, topic| {
        sum.checked_add(topic.name.len() + 260)
            .ok_or(Error::ResponseLimit)
    })?;
    if needed > config.max_response_bytes {
        return Err(Error::ResponseLimit);
    }
    writer.reserve(needed)?;
    let copies = mark_first_copies(&request.topics, |topic| Some(topic.name));
    let mut folded_names: HashSet<Vec<u8>> = HashSet::new();
    let track_folded = request.topics.len() > 1;
    for (position, topic) in request.topics.iter().enumerate() {
        check_active(reply, stopping)?;
        if copies
            .as_ref()
            .is_some_and(|(first, _)| !first.get(position).copied().unwrap_or(false))
        {
            continue;
        }
        let duplicate = copies
            .as_ref()
            .is_some_and(|(_, duplicated)| duplicated.get(position).copied().unwrap_or(false));
        let folded = track_folded.then(|| topic_collision_key(topic.name));
        let collides = folded
            .as_ref()
            .is_some_and(|key| folded_names.contains(key));
        let error = if duplicate {
            api_error(42, "Duplicate topic name.")
        } else if collides {
            // Validate-only does not store the earlier name, so the catalog
            // check cannot see a sibling that differs only by '.' and '_'.
            api_error(17, "Topic name collides with an existing topic.")
        } else {
            match create_validation(catalog, config, header.api_version, topic) {
                Err(error) => error,
                Ok(_) if timed_out(admitted, request.timeout) => TIMEOUT,
                Ok(_) if request.validate => OK,
                Ok(partitions) => match fresh_id(catalog) {
                    Err(error) => error,
                    Ok(id) => {
                        check_active(reply, stopping)?;
                        match catalog.apply_create_until(
                            topic.name,
                            id,
                            partitions,
                            admitted + Duration::from_millis(request.timeout.max(0) as u64),
                        ) {
                            // The timer already refused to start this create.
                            // A completed topic stays visible as success.
                            Ok(_) => OK,
                            Err(error) => catalog_error(&error),
                        }
                    }
                },
            }
        };
        if let Some(key) = folded {
            let _ = folded_names.insert(key);
        }
        results.push((topic.name, error));
        if catalog.is_poisoned() {
            return Err(Error::StoragePoisoned);
        }
    }
    writer.header(header.correlation_id, false)?;
    writer.i32(0)?;
    writer.count(results.len(), false)?;
    for (name, error) in results {
        writer.string(Some(name), false, false)?;
        writer.i16(error.code)?;
        writer.string(error.message, false, true)?;
    }
    Ok(writer.bytes)
}
struct DeleteResult<'a> {
    name: Option<&'a str>,
    id: [u8; 16],
    error: ApiError,
}
#[expect(
    clippy::too_many_arguments,
    reason = "delete threads the catalog, header, deadline, and reused response buffer"
)]
fn delete(
    catalog: &mut Catalog,
    config: &Config,
    header: RequestHeader<'_>,
    request: DeleteRequest<'_>,
    admitted: Instant,
    reply: &oneshot::Sender<Handled>,
    stopping: &AtomicBool,
    spare: Vec<u8>,
) -> Result<Vec<u8>, Error> {
    let flex = header.api_version >= 4;
    let mut writer = Writer::reusing(config.max_response_bytes, spare)?;
    let mut results = bounded_vec(request.topics.len())?;
    // Names resolved from IDs are copied before mutation, bounded by249 bytes.
    let mut names = bounded_vec(request.topics.len())?;
    for target in &request.topics {
        let resolved = if target.id != ZERO && target.name.is_none() {
            TopicId::new(target.id)
                .ok()
                .and_then(|id| catalog.by_id(id))
                .map(Topic::name)
        } else {
            target.name
        };
        let mut name = String::new();
        if let Some(value) = resolved {
            name.try_reserve_exact(value.len())
                .map_err(|_| Error::ResponseLimit)?;
            name.push_str(value);
        }
        names.push(resolved.map(|_| name));
    }
    let needed = request.topics.iter().try_fold(12usize, |sum, target| {
        sum.checked_add(target.name.map_or(249, str::len) + 280)
            .ok_or(Error::ResponseLimit)
    })?;
    if needed > config.max_response_bytes {
        return Err(Error::ResponseLimit);
    }
    writer.reserve(needed)?;
    let copies = mark_first_copies(&request.topics, delete_identity);
    let (requested_ids, unique_name_ids) = delete_alias_sets(&request.topics, catalog);
    for (position, target) in request.topics.iter().enumerate() {
        check_active(reply, stopping)?;
        let neither = target.name.is_none() && target.id == ZERO;
        let both = target.name.is_some() && target.id != ZERO;
        if neither || both {
            results.push(DeleteResult {
                name: target.name,
                id: target.id,
                error: api_error(
                    42,
                    if neither {
                        "Neither topic name nor id were specified."
                    } else {
                        "You may not specify both topic name and topic id."
                    },
                ),
            });
            continue;
        }
        if copies
            .as_ref()
            .is_some_and(|(first, _)| !first.get(position).copied().unwrap_or(false))
        {
            continue;
        }
        if copies
            .as_ref()
            .is_some_and(|(_, duplicated)| duplicated.get(position).copied().unwrap_or(false))
        {
            results.push(DeleteResult {
                name: target.name,
                id: target.id,
                error: api_error(
                    42,
                    if target.name.is_some() {
                        "Duplicate topic name."
                    } else {
                        "Duplicate topic id."
                    },
                ),
            });
            continue;
        }
        let topic = if let Some(name) = target.name {
            catalog.by_name(name)
        } else {
            TopicId::new(target.id)
                .ok()
                .and_then(|id| catalog.by_id(id))
        };
        let Some(topic) = topic else {
            results.push(DeleteResult {
                name: target.name,
                id: target.id,
                error: ApiError {
                    code: if target.name.is_some() { 3 } else { 100 },
                    message: None,
                },
            });
            continue;
        };
        let id = topic.id();
        let bytes = id.bytes();
        // A name and an id for the same topic are one delete. The sets were
        // taken before any tombstone, which matches the old scan: a name is
        // not removed when its id is also in the request.
        let alias = if target.name.is_some() {
            requested_ids.contains(&bytes)
        } else {
            unique_name_ids.contains(&bytes)
        };
        if alias {
            if target.name.is_some() {
                results.push(DeleteResult {
                    name: target.name,
                    id: bytes,
                    error: api_error(
                        42,
                        "The provided topic name maps to an ID that was already supplied.",
                    ),
                });
            }
            continue;
        }
        let error = if timed_out(admitted, request.timeout) {
            TIMEOUT
        } else {
            check_active(reply, stopping)?;
            match catalog.apply_delete_until(
                id,
                admitted + Duration::from_millis(request.timeout.max(0) as u64),
            ) {
                // The timer already refused to start this delete.
                // A completed tombstone stays visible as success.
                Ok(_) => OK,
                Err(error) => catalog_error(&error),
            }
        };
        results.push(DeleteResult {
            name: names[position].as_deref(),
            id: bytes,
            error,
        });
        if catalog.is_poisoned() {
            return Err(Error::StoragePoisoned);
        }
    }
    writer.header(header.correlation_id, flex)?;
    writer.i32(0)?;
    writer.count(results.len(), flex)?;
    for result in results {
        writer.string(result.name, flex, header.api_version >= 6)?;
        if header.api_version >= 6 {
            writer.put(&result.id)?;
        }
        writer.i16(result.error.code)?;
        if header.api_version >= 5 {
            writer.string(result.error.message, flex, true)?;
        }
        writer.tags(flex)?;
    }
    writer.tags(flex)?;
    Ok(writer.bytes)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{error::Error as StdError, sync::atomic::AtomicU64};

    #[test]
    fn reused_job_list_reserves_the_requested_total() {
        let mut items = Vec::with_capacity(32);
        items.extend_from_slice(&[1_u8, 2, 3]);
        let needed = items.capacity() + 1;
        reserve_count(&mut items, needed);
        assert!(items.capacity() >= needed);
        assert_eq!(items, [1, 2, 3]);
        let capacity = items.capacity();
        reserve_count(&mut items, capacity);
        assert_eq!(items.capacity(), capacity);
    }

    #[test]
    fn reused_response_reserves_the_requested_total_and_reports_limits() {
        let spare = vec![7; 32];
        let needed = spare.capacity() + 1;
        let mut writer = Writer::reusing(needed, spare).expect("writer");
        assert!(writer.bytes.is_empty());
        writer.reserve(needed).expect("reserve larger response");
        assert!(writer.bytes.capacity() >= needed);
        let capacity = writer.bytes.capacity();
        writer.put(&vec![9; needed]).expect("write response");
        assert_eq!(writer.bytes.capacity(), capacity);
        assert!(matches!(
            writer.reserve(needed + 1),
            Err(Error::ResponseLimit)
        ));
        assert_eq!(writer.bytes.len(), needed);

        let mut writer = Writer::reusing(1024, Vec::with_capacity(32)).expect("writer");
        writer.put(&[1, 2, 3]).expect("write prefix");
        let needed = writer.bytes.capacity() + 1;
        writer.reserve(needed).expect("reserve with a prefix");
        assert!(writer.bytes.capacity() >= needed);
        assert_eq!(writer.bytes, [1, 2, 3]);

        let mut writer = Writer::new(usize::MAX).expect("writer");
        writer.put(&[1, 2, 3]).expect("write prefix");
        assert!(matches!(
            writer.reserve(usize::MAX),
            Err(Error::ResponseLimit)
        ));
        assert_eq!(writer.bytes, [1, 2, 3]);
    }

    #[test]
    fn a_queued_produce_sizes_its_job_lists_once() {
        let mut jobs = Vec::new();
        let mut parked = Vec::new();
        for index in 0..4 {
            let (reply, receiver) = oneshot::channel();
            parked.push(receiver);
            jobs.push(DataJob {
                request: vec![index],
                spare: vec![index],
                admitted: Instant::now(),
                reply,
            });
        }
        let mut bodies = Vec::new();
        let mut spares = Vec::new();
        let mut admitted = Vec::new();
        let mut senders = Vec::new();
        take_queued_produce(
            &mut jobs,
            &mut bodies,
            &mut spares,
            &mut admitted,
            &mut senders,
        );
        assert!(jobs.is_empty());
        assert_eq!(bodies.len(), 4);
        assert_eq!(spares.len(), 4);
        assert_eq!(admitted.len(), 4);
        assert_eq!(senders.len(), 4);
        let body_capacity = bodies.capacity();
        let spare_capacity = spares.capacity();
        let admitted_capacity = admitted.capacity();
        let sender_capacity = senders.capacity();
        assert!(body_capacity >= 4);
        assert!(spare_capacity >= 4);
        assert!(admitted_capacity >= 4);
        assert!(sender_capacity >= 4);
        for index in 0..4 {
            let (reply, receiver) = oneshot::channel();
            parked.push(receiver);
            jobs.push(DataJob {
                request: vec![index],
                spare: vec![index],
                admitted: Instant::now(),
                reply,
            });
        }
        take_queued_produce(
            &mut jobs,
            &mut bodies,
            &mut spares,
            &mut admitted,
            &mut senders,
        );
        assert_eq!(bodies.capacity(), body_capacity);
        assert_eq!(spares.capacity(), spare_capacity);
        assert_eq!(admitted.capacity(), admitted_capacity);
        assert_eq!(senders.capacity(), sender_capacity);
        assert_eq!(bodies.first().map(Vec::as_slice), Some([0].as_slice()));
    }

    #[test]
    fn a_create_response_reserves_its_budget_before_writing() {
        let path = std::env::temp_dir().join(format!(
            "partitionline-create-size-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        let (catalog, _) = Catalog::open(&path, catalog::Limits::default())
            .unwrap_or_else(|error| panic!("{error}"));
        let mut catalog = catalog;
        let config = Config::new(1, "127.0.0.1".into(), 9092, "create".into());
        let header = protocol::RequestHeader {
            api_key: 19,
            api_version: 4,
            correlation_id: 3,
            client_id: None,
            header_version: 1,
            tagged_fields: 0,
        };
        let (reply, receiver) = oneshot::channel();
        let stopping = AtomicBool::new(false);
        let names = ["orders", "payments", "trades", "quotes"];
        let request = CreateRequest {
            topics: names
                .iter()
                .map(|name| CreateTopic {
                    name,
                    partitions: 1,
                    replicas: 1,
                    assignments: Vec::new(),
                    config_count: 0,
                })
                .collect(),
            timeout: 1_000,
            validate: true,
        };
        let first = create(
            &mut catalog,
            &config,
            header,
            request,
            Instant::now(),
            &reply,
            &stopping,
            Vec::new(),
        )
        .unwrap_or_else(|error| panic!("{error}"));
        assert!(first.len() > 8);
        let capacity = first.capacity();
        assert!(capacity >= first.len());
        assert!(capacity < 64 * 1024);
        let request = CreateRequest {
            topics: names
                .iter()
                .map(|name| CreateTopic {
                    name,
                    partitions: 1,
                    replicas: 1,
                    assignments: Vec::new(),
                    config_count: 0,
                })
                .collect(),
            timeout: 1_000,
            validate: true,
        };
        let again = create(
            &mut catalog,
            &config,
            header,
            request,
            Instant::now(),
            &reply,
            &stopping,
            first,
        )
        .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(again.capacity(), capacity);
        let delete_header = protocol::RequestHeader {
            api_key: 20,
            api_version: 6,
            correlation_id: 4,
            client_id: None,
            header_version: 2,
            tagged_fields: 0,
        };
        let deleted = delete(
            &mut catalog,
            &config,
            delete_header,
            DeleteRequest {
                topics: names
                    .iter()
                    .map(|name| Target {
                        name: Some(*name),
                        id: ZERO,
                    })
                    .collect(),
                timeout: 1_000,
            },
            Instant::now(),
            &reply,
            &stopping,
            Vec::new(),
        )
        .unwrap_or_else(|error| panic!("{error}"));
        assert!(deleted.len() > 8);
        let delete_capacity = deleted.capacity();
        assert!(delete_capacity >= deleted.len());
        assert!(delete_capacity < 64 * 1024);
        let deleted_again = delete(
            &mut catalog,
            &config,
            delete_header,
            DeleteRequest {
                topics: names
                    .iter()
                    .map(|name| Target {
                        name: Some(*name),
                        id: ZERO,
                    })
                    .collect(),
                timeout: 1_000,
            },
            Instant::now(),
            &reply,
            &stopping,
            deleted,
        )
        .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(deleted_again.capacity(), delete_capacity);
        drop(receiver);
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn a_metadata_response_sizes_its_buffer_once() {
        let path = std::env::temp_dir().join(format!(
            "partitionline-metadata-size-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        let (catalog, _) = Catalog::open(&path, catalog::Limits::default())
            .unwrap_or_else(|error| panic!("{error}"));
        let mut id_bytes = [0; 16];
        id_bytes[15] = 9;
        let id = TopicId::new(id_bytes).unwrap_or_else(|error| panic!("{error}"));
        let mut catalog = catalog;
        catalog
            .create("orders", id, 8)
            .unwrap_or_else(|error| panic!("{error}"));
        let config = Config::new(1, "127.0.0.1".into(), 9092, "meta".into());
        let header = protocol::RequestHeader {
            api_key: 3,
            api_version: 9,
            correlation_id: 7,
            client_id: None,
            header_version: 2,
            tagged_fields: 0,
        };
        let request = || MetadataRequest {
            topics: None,
            cluster_ops: false,
            topic_ops: false,
        };
        let first = metadata(&catalog, &config, &[], header, request(), true, Vec::new())
            .unwrap_or_else(|error| panic!("{error}"));
        assert!(first.len() > 8);
        let capacity = first.capacity();
        assert!(capacity >= first.len());
        assert!(capacity < 64 * 1024);
        let again = metadata(&catalog, &config, &[], header, request(), true, first)
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(again.capacity(), capacity);
        assert!(again.capacity() >= again.len());
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn a_metadata_response_does_not_reserve_the_maximum() {
        let mut writer = Writer::new(8 * 1024 * 1024).expect("writer");
        assert_eq!(writer.bytes.capacity(), 0);
        writer.i32(7).expect("int");
        assert!(writer.bytes.capacity() >= 4);
        assert!(writer.bytes.capacity() < 8 * 1024 * 1024);
        let err = writer
            .put(&vec![0; 8 * 1024 * 1024])
            .expect_err("over the cap");
        assert!(matches!(err, Error::ResponseLimit));
        let kept = writer.bytes.capacity();
        let mut again = Writer::reusing(8 * 1024 * 1024, writer.bytes).expect("reuse");
        again.i32(9).expect("int");
        assert!(again.bytes.capacity() >= kept);
        assert_eq!(again.bytes.len(), 4);
    }

    #[test]
    fn a_create_request_collides_when_dot_and_underscore_differ() {
        assert_eq!(
            topic_collision_key("foo.bar"),
            topic_collision_key("foo_bar")
        );
        assert_ne!(
            topic_collision_key("foo.bar"),
            topic_collision_key("foo.baz")
        );
        let mut seen = vec![false; 2];
        assert!(claim_assignment_index(&mut seen, 1));
        assert!(claim_assignment_index(&mut seen, 0));
        assert!(!claim_assignment_index(&mut seen, 0));
        assert!(!claim_assignment_index(&mut [false], -1));
        assert!(topic_names_collide("foo.bar", "foo_bar"));
        assert!(topic_names_collide("foo.bar", "foo.bar"));
        assert!(!topic_names_collide("foo.bar", "foo.baz"));
        assert!(!topic_names_collide("a.b", "ab"));
        assert!(!topic_names_collide("foo.bar", "foo.bars"));
    }

    #[test]
    fn the_first_copy_of_a_name_or_id_is_the_one_that_is_answered() {
        let names = ["orders", "payments", "orders"];
        let copies = mark_first_copies(&names, |name| Some(*name)).unwrap_or_else(|| {
            panic!("two names");
        });
        assert_eq!(copies.0, vec![true, true, false]);
        assert_eq!(copies.1, vec![true, false, false]);
        assert!(mark_first_copies(&["orders"], |name: &&str| Some(*name)).is_none());
        let targets = [
            Target {
                name: Some("orders"),
                id: ZERO,
            },
            Target {
                name: None,
                id: ZERO,
            },
            Target {
                name: Some("orders"),
                id: ZERO,
            },
            Target {
                name: None,
                id: [2u8; 16],
            },
            Target {
                name: None,
                id: [2u8; 16],
            },
        ];
        let copies = mark_first_copies(&targets, delete_identity).unwrap_or_else(|| {
            panic!("several targets");
        });
        assert_eq!(copies.0, vec![true, false, false, true, false]);
        assert_eq!(copies.1, vec![true, false, false, true, false]);
        let path = std::env::temp_dir().join(format!(
            "partitionline-delete-alias-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        let (mut catalog, _) = Catalog::open(&path, catalog::Limits::default())
            .unwrap_or_else(|error| panic!("{error}"));
        let mut id_bytes = [0; 16];
        id_bytes[15] = 4;
        let id = TopicId::new(id_bytes).unwrap_or_else(|error| panic!("{error}"));
        catalog
            .create("orders", id, 1)
            .unwrap_or_else(|error| panic!("{error}"));
        let paired = [
            Target {
                name: Some("orders"),
                id: ZERO,
            },
            Target {
                name: None,
                id: id.bytes(),
            },
        ];
        let (requested, unique) = delete_alias_sets(&paired, &catalog);
        assert!(requested.contains(&id.bytes()));
        assert!(unique.contains(&id.bytes()));
        let repeated = [
            Target {
                name: Some("orders"),
                id: ZERO,
            },
            Target {
                name: Some("orders"),
                id: ZERO,
            },
            Target {
                name: None,
                id: id.bytes(),
            },
        ];
        let (requested, unique) = delete_alias_sets(&repeated, &catalog);
        assert!(requested.contains(&id.bytes()));
        assert!(
            !unique.contains(&id.bytes()),
            "a repeated name is not a single alias of the id"
        );
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn a_metadata_request_resolves_each_topic_by_its_own_id_or_name() {
        let path = std::env::temp_dir().join(format!(
            "partitionline-metadata-mix-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        let (mut catalog, _) = Catalog::open(&path, catalog::Limits::default())
            .unwrap_or_else(|error| panic!("{error}"));
        let mut alpha_bytes = [0; 16];
        alpha_bytes[15] = 2;
        let mut beta_bytes = [0; 16];
        beta_bytes[15] = 3;
        let alpha = TopicId::new(alpha_bytes).unwrap_or_else(|error| panic!("{error}"));
        let beta = TopicId::new(beta_bytes).unwrap_or_else(|error| panic!("{error}"));
        catalog
            .create("alpha", alpha, 1)
            .unwrap_or_else(|error| panic!("{error}"));
        catalog
            .create("beta", beta, 1)
            .unwrap_or_else(|error| panic!("{error}"));
        let targets = [
            Target {
                name: None,
                id: alpha.bytes(),
            },
            Target {
                name: Some("beta"),
                id: ZERO,
            },
            Target {
                name: Some("missing"),
                id: ZERO,
            },
            Target {
                name: None,
                id: [9u8; 16],
            },
            Target {
                name: None,
                id: alpha.bytes(),
            },
            Target {
                name: Some("beta"),
                id: ZERO,
            },
            Target {
                name: Some("alpha"),
                id: ZERO,
            },
            Target {
                name: None,
                id: beta.bytes(),
            },
        ];
        let mut results = Vec::new();
        collect_metadata_topics(&catalog, false, &targets, &mut results)
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(results.len(), 4);
        assert_eq!(results[0].name, Some("alpha"));
        assert_eq!(results[0].error, 0);
        assert_eq!(results[1].name, Some("beta"));
        assert_eq!(results[1].error, 0);
        assert_eq!(results[2].name, Some("missing"));
        assert_eq!(results[2].error, 3);
        assert_eq!(results[3].name, None);
        assert_eq!(results[3].id, [9u8; 16]);
        assert_eq!(results[3].error, 100);
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn a_short_metadata_target_list_does_not_allocate_a_set() {
        let mut names: ShortSet<Option<&str>> = ShortSet::new();
        assert!(names.insert(Some("orders")));
        assert!(names.insert(Some("payments")));
        assert!(!names.insert(Some("orders")));
        assert!(names.contains(&Some("payments")));
        assert!(!names.contains(&Some("trades")));
        assert_eq!(names.heap.capacity(), 0);
        let mut ids: ShortSet<[u8; 16]> = ShortSet::new();
        for index in 0..17u8 {
            let mut id = [0u8; 16];
            id[0] = index;
            assert!(ids.insert(id));
        }
        assert!(ids.heap.capacity() > 0);
        assert!(ids.contains(&[0u8; 16]));
        let mut last = [0u8; 16];
        last[0] = 16;
        assert!(ids.contains(&last));
    }

    #[test]
    fn a_bracketed_advertised_host_is_sent_without_brackets() {
        assert_eq!(wire_advertised_host("[::1]"), Some("::1"));
        assert_eq!(wire_advertised_host("::1"), Some("::1"));
        assert_eq!(wire_advertised_host("127.0.0.1"), Some("127.0.0.1"));
        assert!(wire_advertised_host("[]").is_none());
        assert!(wire_advertised_host("[[::1]]").is_none());
        let mut config = Config::new(0, "[::1]".into(), 9092, "cluster".into());
        assert!(config.validate().is_ok());
        config.advertised_host = "[]".into();
        assert!(config.validate().is_err());
    }
    static NEXT: AtomicU64 = AtomicU64::new(0);
    fn parked_actor() -> (Arc<Router>, std::sync::mpsc::Sender<()>, PathBuf) {
        parked_profile(false)
    }
    fn parked_profile(data: bool) -> (Arc<Router>, std::sync::mpsc::Sender<()>, PathBuf) {
        parked_options(data, None)
    }
    fn parked_options(
        data: bool,
        retention: Option<retention::Config>,
    ) -> (Arc<Router>, std::sync::mpsc::Sender<()>, PathBuf) {
        parked_maintenance(data, retention, false)
    }
    fn parked_maintenance(
        data: bool,
        retention: Option<retention::Config>,
        compaction: bool,
    ) -> (Arc<Router>, std::sync::mpsc::Sender<()>, PathBuf) {
        let path = std::env::temp_dir().join(format!(
            "partitionline-actor-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        let mut config = Config::new(0, "127.0.0.1".into(), 19095, "actor-test".into());
        config.max_queued_requests = 1;
        let (sender, receiver) = mpsc::channel(1);
        let (release, gate) = std::sync::mpsc::channel();
        let stopping = Arc::new(AtomicBool::new(false));
        let worker_stop = Arc::clone(&stopping);
        let worker_config = config.clone();
        let worker_path = path.clone();
        let (change_tx, changes) = watch::channel(());
        let change_tx = Arc::new(change_tx);
        let wakeup = Arc::downgrade(&change_tx);
        let reads = (retention.is_some() || compaction).then(fetch::Limits::default);
        let task = tokio::task::spawn_blocking(move || {
            if gate.recv().is_err() {
                return;
            }
            if let Ok((mut catalog, _)) = Catalog::open(&worker_path, worker_config.catalog_limits)
            {
                let store = if data {
                    let mut id = [0; 16];
                    id[15] = 2;
                    let Ok(id) = TopicId::new(id) else {
                        return;
                    };
                    if catalog.create("alpha", id, 2).is_err() {
                        return;
                    }
                    let mut store_config =
                        produce::Config::new(worker_path.with_extension("parts"));
                    if retention.is_some() {
                        store_config.segment_limits = Some(crate::segments::Limits::default());
                    }
                    if compaction {
                        let Ok(limits) = crate::segments::Limits::new(
                            150,
                            64,
                            4096,
                            16,
                            1 << 30,
                            2 * 1024 * 1024,
                            64 * 1024 * 1024,
                        ) else {
                            return;
                        };
                        store_config.segment_limits = Some(limits);
                        if std::fs::create_dir(&store_config.directory).is_err() {
                            return;
                        }
                        let Ok((mut partition, _)) = crate::partition::Partition::open_segmented(
                            store_config
                                .directory
                                .join("00000000000000000000000000000002-0.segments"),
                            0,
                            store_config.journal_limits,
                            store_config.record_limits,
                            limits,
                        ) else {
                            return;
                        };
                        for _ in 0..3 {
                            if partition
                                .append(
                                    include_bytes!("../tests/fixtures/records/valid-basic.bin",),
                                )
                                .is_err()
                            {
                                return;
                            }
                        }
                    }
                    let Ok(mut store) = produce::Store::open(store_config, &catalog) else {
                        return;
                    };
                    if compaction
                        && store
                            .enable_compaction(compaction::Policy::default())
                            .is_err()
                    {
                        return;
                    }
                    if let Some(policy) = retention {
                        if store.enable_retention(policy).is_err()
                            || produce::process(
                                &catalog,
                                &mut store,
                                &mut include_bytes!(
                                    "../tests/fixtures/produce/4.3.1/produce-v3-acks1.request.bin"
                                )
                                .to_vec(),
                                &worker_config,
                                Instant::now(),
                                || Ok(()),
                            )
                            .is_err()
                        {
                            return;
                        }
                    }
                    Some(store)
                } else {
                    None
                };
                actor(
                    catalog,
                    store,
                    receiver,
                    &worker_config,
                    &worker_stop,
                    DataOptions {
                        reads,
                        retention,
                        endpoints: &[],
                    },
                    &change_tx,
                );
            }
        });
        (
            Arc::new(Router {
                config,
                sender,
                stopping,
                failed: AtomicBool::new(false),
                task: Mutex::new(Some(task)),
                data,
                data_slots: Semaphore::new(1),
                reads,
                retention,
                changes,
                compaction,
                wakeup,
            }),
            release,
            path,
        )
    }
    fn request(key: i16) -> Vec<u8> {
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&key.to_be_bytes());
        bytes.extend_from_slice(&(if key == 19 { 4i16 } else { 1i16 }).to_be_bytes());
        bytes.extend_from_slice(&1i32.to_be_bytes());
        bytes.extend_from_slice(&(-1i16).to_be_bytes());
        if key == 19 {
            bytes.extend_from_slice(&1i32.to_be_bytes());
            bytes.extend_from_slice(&3i16.to_be_bytes());
            bytes.extend_from_slice(b"new");
            bytes.extend_from_slice(&1i32.to_be_bytes());
            bytes.extend_from_slice(&1i16.to_be_bytes());
            bytes.extend_from_slice(&0i32.to_be_bytes());
            bytes.extend_from_slice(&0i32.to_be_bytes());
            bytes.extend_from_slice(&60000i32.to_be_bytes());
            bytes.push(0);
        } else {
            bytes.extend_from_slice(&(-1i32).to_be_bytes());
        }
        bytes
    }
    async fn full(router: &Router) -> Result<(), Box<dyn StdError>> {
        tokio::time::timeout(Duration::from_secs(2), async {
            while router.sender.capacity() != 0 {
                tokio::task::yield_now().await;
            }
        })
        .await?;
        Ok(())
    }
    #[tokio::test]
    async fn queued_cancel_and_full_admission_never_mutate() -> Result<(), Box<dyn StdError>> {
        let (router, release, path) = parked_actor();
        let waiting = tokio::spawn({
            let router = Arc::clone(&router);
            async move { router.respond(request(19)).await }
        });
        full(&router).await?;
        assert!(matches!(
            router.respond(request(3)).await,
            Err(Error::QueueFull)
        ));
        waiting.abort();
        assert!(waiting.await.is_err());
        release.send(())?;
        tokio::time::timeout(Duration::from_secs(2), async {
            while router.sender.capacity() == 0 {
                tokio::task::yield_now().await;
            }
        })
        .await?;
        router.respond(request(3)).await?;
        router.shutdown().await?;
        let verified = tokio::task::spawn_blocking({
            let path = path.clone();
            move || {
                Catalog::open(path, catalog::Limits::default())
                    .map(|(catalog, _)| (catalog.operation_count(), catalog.topic_count()))
            }
        })
        .await??;
        assert_eq!(verified, (0, 0));
        std::fs::remove_file(path)?;
        Ok(())
    }
    #[tokio::test]
    async fn canceled_shutdown_retains_join_and_pending_work_is_rejected(
    ) -> Result<(), Box<dyn StdError>> {
        let (router, release, path) = parked_actor();
        let waiting = tokio::spawn({
            let router = Arc::clone(&router);
            async move { router.respond(request(19)).await }
        });
        full(&router).await?;
        assert!(
            tokio::time::timeout(Duration::from_millis(2), router.shutdown())
                .await
                .is_err()
        );
        assert!(router.task.lock().await.is_some());
        release.send(())?;
        router.shutdown().await?;
        assert!(matches!(waiting.await?, Err(Error::Stopped)));
        assert!(router.task.lock().await.is_none());
        router.shutdown().await?;
        let verified = tokio::task::spawn_blocking({
            let path = path.clone();
            move || {
                Catalog::open(path, catalog::Limits::default())
                    .map(|(catalog, _)| catalog.operation_count())
            }
        })
        .await??;
        assert_eq!(verified, 0);
        std::fs::remove_file(path)?;
        Ok(())
    }
    #[tokio::test]
    async fn committed_operation_with_lost_receipt_replays() -> Result<(), Box<dyn StdError>> {
        let path = std::env::temp_dir().join(format!(
            "partitionline-lost-receipt-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        tokio::task::spawn_blocking({
            let path = path.clone();
            move || -> Result<(), Error> {
                let config = Config::new(0, "127.0.0.1".into(), 19095, "actor-test".into());
                let (mut catalog, _) =
                    Catalog::open(&path, config.catalog_limits).map_err(Error::Catalog)?;
                let (reply, receiver) = oneshot::channel();
                let stop = AtomicBool::new(false);
                let response = process(
                    &mut catalog,
                    &request(19),
                    Routing {
                        config: &config,
                        endpoints: &[],
                    },
                    Instant::now(),
                    &reply,
                    &stop,
                    Vec::new(),
                )?;
                let identity = catalog.by_name("new").ok_or(Error::ActorFailed)?.id();
                drop(receiver);
                assert!(reply.send(Ok((response, Vec::new()))).is_err());
                drop(catalog);
                let (reopened, _) =
                    Catalog::open(&path, config.catalog_limits).map_err(Error::Catalog)?;
                assert_eq!(reopened.by_name("new").map(Topic::id), Some(identity));
                assert_eq!(reopened.operation_count(), 1);
                Ok(())
            }
        })
        .await??;
        std::fs::remove_file(path)?;
        Ok(())
    }
    #[tokio::test]
    async fn failed_actor_join_remains_failed_on_retry() -> Result<(), Box<dyn StdError>> {
        let (router, release, path) = parked_actor();
        drop(release);
        if let Some(old) = router.task.lock().await.take() {
            old.await?;
        }
        let failed = tokio::task::spawn_blocking(|| {
            std::panic::resume_unwind(Box::new("injected actor failure"))
        });
        *router.task.lock().await = Some(failed);
        assert!(matches!(router.shutdown().await, Err(Error::ActorFailed)));
        assert!(matches!(router.shutdown().await, Err(Error::ActorFailed)));
        assert!(!path.exists());
        Ok(())
    }
    #[tokio::test]
    async fn queued_data_cancel_and_full_admission_never_append() -> Result<(), Box<dyn StdError>> {
        let (router, release, path) = parked_profile(true);
        let input =
            include_bytes!("../tests/fixtures/produce/4.3.1/produce-v3-acks1.request.bin").to_vec();
        let waiting = tokio::spawn({
            let router = Arc::clone(&router);
            let input = input.clone();
            async move { router.dispatch(input).await }
        });
        full(&router).await?;
        assert!(matches!(
            router.dispatch(input.clone()).await,
            Err(Error::QueueFull)
        ));
        waiting.abort();
        assert!(waiting.await.is_err());
        release.send(())?;
        tokio::time::timeout(Duration::from_secs(2), async {
            while router.sender.capacity() == 0 {
                tokio::task::yield_now().await;
            }
        })
        .await?;
        let response = router
            .dispatch(input)
            .await?
            .ok_or("missing data response")?;
        assert_eq!(&response[25..33], &0i64.to_be_bytes());
        router.shutdown().await?;
        tokio::task::spawn_blocking(move || -> std::io::Result<()> {
            std::fs::remove_file(&path)?;
            std::fs::remove_dir_all(path.with_extension("parts"))
        })
        .await??;
        Ok(())
    }
    #[tokio::test]
    async fn unconsumed_data_receipt_keeps_admission_bounded() -> Result<(), Box<dyn StdError>> {
        let (router, release, path) = parked_profile(true);
        let input =
            include_bytes!("../tests/fixtures/produce/4.3.1/produce-v3-acks1.request.bin").to_vec();
        let mut pending = Box::pin(router.dispatch(input.clone()));
        std::future::poll_fn(|cx| match std::future::Future::poll(pending.as_mut(), cx) {
            std::task::Poll::Pending => std::task::Poll::Ready(Ok(())),
            std::task::Poll::Ready(_) => {
                std::task::Poll::Ready(Err("parked data actor completed unexpectedly"))
            }
        })
        .await?;
        release.send(())?;
        tokio::time::timeout(Duration::from_secs(2), async {
            while router.sender.capacity() == 0 {
                tokio::task::yield_now().await;
            }
        })
        .await?;
        // FIFO metadata completion proves the prior Produce receipt exists,
        // without polling its receiver or transferring the owned response Vec.
        router.respond(request(3)).await?;
        assert!(matches!(
            router.dispatch(input.clone()).await,
            Err(Error::QueueFull)
        ));
        let result = pending.await?.ok_or("missing receipt")?;
        assert_eq!(&result[25..33], &0i64.to_be_bytes());
        let result = router
            .dispatch(input)
            .await?
            .ok_or("missing second receipt")?;
        assert_eq!(&result[25..33], &1i64.to_be_bytes());
        router.shutdown().await?;
        tokio::task::spawn_blocking(move || -> std::io::Result<()> {
            std::fs::remove_file(&path)?;
            std::fs::remove_dir_all(path.with_extension("parts"))
        })
        .await??;
        Ok(())
    }
    #[tokio::test]
    async fn committed_data_with_lost_receipt_replays_without_deduplication(
    ) -> Result<(), Box<dyn StdError>> {
        let path = std::env::temp_dir().join(format!(
            "partitionline-data-receipt-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        tokio::task::spawn_blocking(move || -> Result<(), Error> {
            let config = Config::new(0, "127.0.0.1".into(), 19095, "data-receipt".into());
            let (mut catalog, _) =
                Catalog::open(&path, config.catalog_limits).map_err(Error::Catalog)?;
            let mut id = [0; 16];
            id[15] = 2;
            catalog
                .create("alpha", TopicId::new(id).map_err(Error::Catalog)?, 2)
                .map_err(Error::Catalog)?;
            let store_config = produce::Config::new(path.with_extension("parts"));
            let mut store = produce::Store::open(store_config.clone(), &catalog)?;
            let mut input =
                include_bytes!("../tests/fixtures/produce/4.3.1/produce-v3-acks1.request.bin")
                    .to_vec();
            let (reply, receiver) = oneshot::channel::<Result<Option<Vec<u8>>, Error>>();
            let result = produce::process(
                &catalog,
                &mut store,
                &mut input,
                &config,
                Instant::now(),
                || Ok(()),
            )?;
            drop(receiver);
            assert!(reply.send(Ok(result)).is_err());
            drop(store);
            let mut recovered = produce::Store::open(store_config, &catalog)?;
            let result = produce::process(
                &catalog,
                &mut recovered,
                &mut input,
                &config,
                Instant::now(),
                || Ok(()),
            )?
            .ok_or(Error::ActorFailed)?;
            assert_eq!(&result[25..33], &1i64.to_be_bytes());
            drop(recovered);
            drop(catalog);
            std::fs::remove_file(&path).map_err(produce::Error::Io)?;
            std::fs::remove_dir_all(path.with_extension("parts")).map_err(produce::Error::Io)?;
            Ok(())
        })
        .await??;
        Ok(())
    }

    fn parked_retention() -> (Arc<Router>, std::sync::mpsc::Sender<()>, PathBuf) {
        parked_options(
            true,
            Some(retention::Config {
                retention_bytes: Some(0),
                ..retention::Config::default()
            }),
        )
    }
    fn parked_compaction(
    ) -> Result<(Arc<Router>, std::sync::mpsc::Sender<()>, PathBuf, TopicId), Error> {
        let (router, release, path) = parked_maintenance(true, None, true);
        let mut id = [0; 16];
        id[15] = 2;
        Ok((
            router,
            release,
            path,
            TopicId::new(id).map_err(|_| Error::ActorFailed)?,
        ))
    }
    async fn compacted_state(path: PathBuf) -> Result<([u8; 8], Vec<i64>), Box<dyn StdError>> {
        Ok(tokio::task::spawn_blocking(move || -> Result<_, Error> {
            use std::io::Read;
            let directory = path
                .with_extension("parts")
                .join("00000000000000000000000000000002-0.segments");
            let mut bytes = Vec::new();
            std::fs::File::open(directory.join("manifest"))
                .map_err(produce::Error::Io)?
                .take(1025)
                .read_to_end(&mut bytes)
                .map_err(produce::Error::Io)?;
            if bytes.len() > 1024 {
                return Err(Error::ActorFailed);
            }
            let mut magic = [0; 8];
            magic.copy_from_slice(bytes.get(..8).ok_or(Error::ActorFailed)?);
            let config = produce::Config::new(path.with_extension("parts"));
            let (mut partition, _) = crate::partition::Partition::open_segmented(
                directory,
                0,
                config.journal_limits,
                config.record_limits,
                crate::segments::Limits::default(),
            )
            .map_err(produce::Error::Partition)?;
            assert_eq!(
                (partition.log_start_offset(), partition.next_offset()),
                (0, 3)
            );
            let mut offsets = Vec::new();
            for entry in partition
                .fetch(0, 16, 2 * 1024 * 1024)
                .map_err(produce::Error::Partition)?
            {
                let records = crate::records::validate_read(&entry.payload, config.record_limits)
                    .map_err(|error| {
                    produce::Error::Partition(crate::partition::Error::Records(error))
                })?;
                for batch in records.batches() {
                    for record in batch
                        .map_err(|error| {
                            produce::Error::Partition(crate::partition::Error::Records(error))
                        })?
                        .records()
                    {
                        offsets.push(
                            record
                                .map_err(|error| {
                                    produce::Error::Partition(crate::partition::Error::Records(
                                        error,
                                    ))
                                })?
                                .offset,
                        );
                    }
                }
            }
            drop(partition);
            std::fs::remove_file(&path).map_err(produce::Error::Io)?;
            std::fs::remove_dir_all(path.with_extension("parts")).map_err(produce::Error::Io)?;
            Ok((magic, offsets))
        })
        .await??)
    }
    #[tokio::test]
    async fn canceled_compaction_skips_rewrite_and_releases_shared_slot(
    ) -> Result<(), Box<dyn StdError>> {
        let (router, release, path, id) = parked_compaction()?;
        let waiting = tokio::spawn({
            let router = Arc::clone(&router);
            async move { router.compact_partition(id, 0, 2000).await }
        });
        full(&router).await?;
        assert!(matches!(
            router.compact_partition(id, 0, 2000).await,
            Err(Error::QueueFull)
        ));
        assert!(matches!(
            router.dispatch(request(0)).await,
            Err(Error::QueueFull)
        ));
        waiting.abort();
        assert!(waiting.await.is_err());
        assert_eq!(router.data_slots.available_permits(), 1);
        release.send(())?;
        tokio::time::timeout(Duration::from_secs(2), async {
            while router.sender.capacity() == 0 {
                tokio::task::yield_now().await;
            }
        })
        .await?;
        router.respond(request(3)).await?;
        assert!(!router.changes.has_changed()?);
        router.shutdown().await?;
        assert_eq!(compacted_state(path).await?, (*b"PLSEGM01", vec![0, 1, 2]));
        Ok(())
    }
    #[tokio::test]
    async fn unconsumed_compaction_receipt_holds_shared_slot_after_publication(
    ) -> Result<(), Box<dyn StdError>> {
        let (router, release, path, id) = parked_compaction()?;
        let mut pending = Box::pin(router.compact_partition(id, 0, 2000));
        std::future::poll_fn(|cx| match std::future::Future::poll(pending.as_mut(), cx) {
            std::task::Poll::Pending => std::task::Poll::Ready(Ok(())),
            std::task::Poll::Ready(_) => std::task::Poll::Ready(Err("parked compact completed")),
        })
        .await?;
        release.send(())?;
        tokio::time::timeout(Duration::from_secs(2), async {
            while router.sender.capacity() == 0 {
                tokio::task::yield_now().await;
            }
        })
        .await?;
        router.respond(request(3)).await?;
        assert!(router.changes.has_changed()?);
        assert!(matches!(
            router.compact_partition(id, 0, 2000).await,
            Err(Error::QueueFull)
        ));
        assert_eq!(router.data_slots.available_permits(), 0);
        let result = pending.await?;
        assert_eq!(
            (
                result.end_offset,
                result.rewritten_segments,
                result.retained_records
            ),
            (2, 2, 1)
        );
        assert_eq!(router.data_slots.available_permits(), 1);
        router.shutdown().await?;
        assert_eq!(compacted_state(path).await?, (*b"PLSEGM03", vec![1, 2]));
        Ok(())
    }
    #[tokio::test]
    async fn compaction_shutdown_rejects_queued_rewrite_and_keeps_join(
    ) -> Result<(), Box<dyn StdError>> {
        let (router, release, path, id) = parked_compaction()?;
        let waiting = tokio::spawn({
            let router = Arc::clone(&router);
            async move { router.compact_partition(id, 0, 2000).await }
        });
        full(&router).await?;
        assert!(
            tokio::time::timeout(Duration::from_millis(2), router.shutdown())
                .await
                .is_err()
        );
        assert!(router.task.lock().await.is_some());
        release.send(())?;
        router.shutdown().await?;
        assert!(matches!(waiting.await?, Err(Error::Stopped)));
        assert!(matches!(
            router.compact_partition(id, 0, 2000).await,
            Err(Error::Stopped)
        ));
        assert!(router.task.lock().await.is_none());
        assert_eq!(compacted_state(path).await?, (*b"PLSEGM01", vec![0, 1, 2]));
        Ok(())
    }
    async fn retained_state(path: PathBuf) -> Result<(i64, i64), Box<dyn StdError>> {
        Ok(
            tokio::task::spawn_blocking(move || -> Result<(i64, i64), Error> {
                let config = produce::Config::new(path.with_extension("parts"));
                let (part, _) = crate::partition::Partition::open_segmented(
                    path.with_extension("parts")
                        .join("00000000000000000000000000000002-0.segments"),
                    0,
                    config.journal_limits,
                    config.record_limits,
                    crate::segments::Limits::default(),
                )
                .map_err(produce::Error::Partition)?;
                let state = (part.log_start_offset(), part.next_offset());
                drop(part);
                std::fs::remove_file(&path).map_err(produce::Error::Io)?;
                std::fs::remove_dir_all(path.with_extension("parts"))
                    .map_err(produce::Error::Io)?;
                Ok(state)
            })
            .await??,
        )
    }
    #[tokio::test]
    async fn canceled_sweep_and_shared_full_admission_never_retire() -> Result<(), Box<dyn StdError>>
    {
        let (router, release, path) = parked_retention();
        let waiting = tokio::spawn({
            let router = Arc::clone(&router);
            async move { router.sweep_retention(0).await }
        });
        full(&router).await?;
        assert!(matches!(
            router.sweep_retention(0).await,
            Err(Error::QueueFull)
        ));
        assert!(matches!(
            router
                .dispatch(
                    include_bytes!("../tests/fixtures/produce/4.3.1/produce-v3-acks1.request.bin")
                        .to_vec()
                )
                .await,
            Err(Error::QueueFull)
        ));
        waiting.abort();
        assert!(waiting.await.is_err());
        assert_eq!(router.data_slots.available_permits(), 1);
        release.send(())?;
        // FIFO metadata completion proves the canceled job has been consumed.
        tokio::time::timeout(Duration::from_secs(2), async {
            while router.sender.capacity() == 0 {
                tokio::task::yield_now().await;
            }
        })
        .await?;
        router.respond(request(3)).await?;
        router.shutdown().await?;
        assert_eq!(retained_state(path).await?, (0, 1));
        Ok(())
    }
    #[tokio::test]
    async fn unconsumed_sweep_receipt_holds_shared_admission() -> Result<(), Box<dyn StdError>> {
        let (router, release, path) = parked_retention();
        let mut pending = Box::pin(router.sweep_retention(0));
        std::future::poll_fn(|cx| match std::future::Future::poll(pending.as_mut(), cx) {
            std::task::Poll::Pending => std::task::Poll::Ready(Ok(())),
            std::task::Poll::Ready(_) => {
                std::task::Poll::Ready(Err("parked sweep completed unexpectedly"))
            }
        })
        .await?;
        release.send(())?;
        tokio::time::timeout(Duration::from_secs(2), async {
            while router.sender.capacity() == 0 {
                tokio::task::yield_now().await;
            }
        })
        .await?;
        router.respond(request(3)).await?;
        assert!(matches!(
            router.sweep_retention(0).await,
            Err(Error::QueueFull)
        ));
        assert_eq!(pending.await?.stores_changed, 1);
        assert_eq!(router.sweep_retention(0).await?.stores_changed, 0);
        router.shutdown().await?;
        assert_eq!(retained_state(path).await?, (1, 1));
        Ok(())
    }
    #[tokio::test]
    async fn canceled_sweep_shutdown_keeps_join_and_rejects_pending_retirement(
    ) -> Result<(), Box<dyn StdError>> {
        let (router, release, path) = parked_retention();
        let waiting = tokio::spawn({
            let router = Arc::clone(&router);
            async move { router.sweep_retention(0).await }
        });
        full(&router).await?;
        assert!(
            tokio::time::timeout(Duration::from_millis(2), router.shutdown())
                .await
                .is_err()
        );
        assert!(router.task.lock().await.is_some());
        release.send(())?;
        router.shutdown().await?;
        assert!(matches!(waiting.await?, Err(Error::Stopped)));
        assert!(matches!(
            router.sweep_retention(0).await,
            Err(Error::Stopped)
        ));
        assert!(router.task.lock().await.is_none());
        router.shutdown().await?;
        assert_eq!(retained_state(path).await?, (0, 1));
        Ok(())
    }
}
