"""Separate immutable baseline and fixed-source broker qualification phases."""
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

BASE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('broker_epoch_runner', BASE/'run-v2.py')
engine = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(engine)
RAW_RUN = engine.run
RESOURCE_CHECKS = []

def memory_events(text):
    if text is None:
        return None
    return {key: int(value) for key, value in
            (line.split() for line in text.splitlines())}

def resource_checked_run(name, command, timeout=600):
    free_before = shutil.disk_usage(engine.ROOT).free
    receipt, output = RAW_RUN(name, command, timeout)
    free_after = shutil.disk_usage(engine.ROOT).free
    before = memory_events(receipt['memory_events_before'])
    after = memory_events(receipt['memory_events_after'])
    assert before is not None and after is not None, 'memory events unavailable'
    deltas = {key: after[key] - before[key]
              for key in ('oom', 'oom_kill', 'oom_group_kill')}
    observed_minimum = min(free_before, free_after,
        *(sample['free_bytes'] for sample in receipt['disk_samples']))
    check = {'command_receipt': name+'.json',
        'disk_stop_bytes': engine.FLOOR,
        'observed_min_free_bytes': observed_minimum,
        'memory_event_deltas': deltas}
    engine.save(name+'-resource-verification.json', check)
    RESOURCE_CHECKS.append(check)
    assert observed_minimum > engine.FLOOR, 'disk floor at command boundary'
    assert all(delta == 0 for delta in deltas.values()), 'new OOM events'
    return receipt, output

engine.run = resource_checked_run

REGRESSIONS = [
    'produce::tests::partial_response_buffer_is_reserved_before_encoding',
    'fetch::tests::partial_response_buffer_is_reserved_before_encoding',
    'retention::tests::partial_response_buffer_is_reserved_before_encoding',
    'raft::protocol::response_buffer_tests::partial_response_buffer_is_reserved_before_encoding',
    'fetch::tests::partially_spare_fetch_buffer_reserves_the_entire_next_field',
]
REUSE_CONTROLS = [
    'produce::tests::a_produce_response_reuses_a_parked_buffer',
    'fetch::tests::a_header_after_records_does_not_double_the_buffer',
    'retention::tests::a_delete_records_response_reuses_its_buffer',
    'raft::protocol::response_buffer_tests::a_controller_response_reuses_its_buffer',
]
CHECKPOINT_MODE_CONTROL = [
    'journal::tests::checkpoint_replacement_preserves_permissions_before_publication',
]
CHECKPOINT_SYNC_CONTROL = [
    'journal::tests::checkpoint_file_sync_error_does_not_publish_the_replacement',
]
EPOCH_MODE_CONTROL = [
    'replication::tests::accepted_epoch_replacement_preserves_private_file_permissions',
]

def exact_case(name, artifact, selected):
    binary = artifact['execution_path']
    assert engine.sha(binary) == artifact['sha256']
    listing = subprocess.check_output([binary, '--list'], text=True)
    names = [line.removesuffix(': test') for line in listing.splitlines()
             if line.endswith(': test')]
    assert selected and all(test in names for test in selected), name
    engine.save(name+'-selection.json', {'selected': selected, 'count': len(selected)})
    receipt, text = engine.run(name, [binary, *selected, '--exact', '--test-threads=1'], 300)
    results = re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)
    assert len(results) == 1 and sum(map(int, results[0])) == len(selected), (name, results)
    assert engine.sha(binary) == artifact['sha256']
    return receipt, tuple(map(int, results[0]))

def cleanup_target_copies(artifacts):
    """Keep verified compressed bytes, remove only their regenerable Cargo copies."""
    executable_users = []
    for path in Path('/proc').iterdir():
        if path.name.isdigit():
            try:
                executable_users.append(os.readlink(path/'exe'))
            except OSError:
                pass
    rows = []
    target_root = Path(engine.ENV['CARGO_TARGET_DIR']).resolve()
    for artifact in artifacts.values():
        path = Path(artifact['execution_path'])
        retained = Path(artifact['retained_gzip'])
        assert path.resolve().is_relative_to(target_root)
        assert str(path) not in executable_users
        assert engine.sha(path) == artifact['sha256']
        assert path.stat().st_size == artifact['bytes']
        with gzip.open(retained, 'rb') as stream:
            restored = hashlib.file_digest(stream, 'sha256').hexdigest()
        with gzip.open(retained, 'rb') as stream:
            restored_bytes = sum(len(chunk) for chunk in iter(lambda: stream.read(1024**2), b''))
        assert restored == artifact['sha256'] and restored_bytes == artifact['bytes']
        rows.append({'path': str(path), 'sha256': restored, 'bytes': restored_bytes,
                     'canonical_gzip': str(retained)})
    free_before = shutil.disk_usage(engine.ROOT).free
    for row in rows:
        assert engine.sha(row['path']) == row['sha256']
        Path(row['path']).unlink()
    engine.save('target-copy-cleanup.json', {'files': rows, 'free_before': free_before,
        'free_after': shutil.disk_usage(engine.ROOT).free,
        'reason': 'Exact regenerated Cargo copies only; verified compressed evidence remains immutable.'})

def full_library(profile, artifact):
    binary = artifact['execution_path']
    assert engine.sha(binary) == artifact['sha256']
    receipt, text = engine.run(profile+'-full-library', [binary, '--test-threads=1'], 900)
    listing = (engine.OUT/(profile+'-partitionline_broker-list.log')).read_text()
    count = sum(line.endswith(': test') for line in listing.splitlines())
    results = re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)
    assert count > 0 and len(results) == 1 and sum(map(int, results[0])) == count
    assert engine.sha(binary) == artifact['sha256']
    return receipt

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=['baseline', 'default', 'all-features', 'clippy'])
    parser.add_argument('--name', help='New evidence directory name for this attempt')
    parser.add_argument('--refresh-receipt', required=True,
        help='Immutable non-broker input refresh receipt in this work directory')
    args = parser.parse_args()
    refresh_path = BASE/args.refresh_receipt
    assert refresh_path.parent == BASE and refresh_path.is_file()
    refresh = json.loads(refresh_path.read_text())
    assert refresh['files']
    for item in refresh['files']:
        assert not item['path'].startswith('partitionline-broker/src/')
        assert not item['path'].startswith('partitionline-broker/tests/')
        assert engine.sha(engine.ROOT/item['path']) == item['sha256']
    phase_name = args.name or args.phase
    assert Path(phase_name).name == phase_name and phase_name not in ('.', '..')
    engine.OUT = BASE/phase_name
    engine.OUT.mkdir()
    engine.FLOOR = 1536 * 1024**2
    engine.initialize()
    engine.save('runner-identity.json', {'qualify_sha256': engine.sha(__file__),
        'engine_sha256': engine.sha(BASE/'run-v2.py'), 'disk_stop_bytes': engine.FLOOR,
        'cargo_build_jobs': engine.ENV['CARGO_BUILD_JOBS'],
        'client_refresh_source': refresh['main_head'],
        'refresh_receipt':refresh_path.name,
        'refresh_receipt_sha256':engine.sha(refresh_path)})
    if args.phase == 'clippy':
        row, _ = engine.run('strict-clippy', ['cargo', '+stable', 'clippy', '--locked',
            '--manifest-path', 'partitionline-broker/Cargo.toml', '--all-features',
            '--all-targets', '--', '-D', 'warnings'], 900)
        assert row['exit'] == 0
    else:
        profile = 'all-features' if args.phase == 'all-features' else 'default'
        artifacts = engine.build(profile)
        receipt, counts = exact_case('reservation-regressions',
            artifacts['partitionline_broker'], REGRESSIONS)
        if args.phase == 'baseline':
            assert receipt['exit'] == 101 and counts == (0, len(REGRESSIONS), 0)
        else:
            assert receipt['exit'] == 0 and counts == (len(REGRESSIONS), 0, 0)
        receipt, counts = exact_case('checkpoint-mode-control',
            artifacts['partitionline_broker'], CHECKPOINT_MODE_CONTROL)
        if args.phase == 'baseline':
            assert receipt['exit'] == 101 and counts == (0, 1, 0)
        else:
            assert receipt['exit'] == 0 and counts == (1, 0, 0)
        receipt, counts = exact_case('epoch-mode-control',
            artifacts['partitionline_broker'], EPOCH_MODE_CONTROL)
        if args.phase == 'baseline':
            assert receipt['exit'] == 101 and counts == (0, 1, 0)
        else:
            assert receipt['exit'] == 0 and counts == (1, 0, 0)
            receipt, counts = exact_case('checkpoint-sync-control',
                artifacts['partitionline_broker'], CHECKPOINT_SYNC_CONTROL)
            assert receipt['exit'] == 0 and counts == (1, 0, 0)
            receipt, counts = exact_case('buffer-reuse-controls',
                artifacts['partitionline_broker'], REUSE_CONTROLS)
            assert receipt['exit'] == 0 and counts == (len(REUSE_CONTROLS), 0, 0)
            engine.suites(profile, artifacts)
            for name in ('replication', 'journal', 'journal-integration'):
                receipt = json.loads((engine.OUT/(profile+'-'+name+'.json')).read_text())
                assert receipt['exit'] == 0 and receipt['inputs_stable'] and not receipt['stop_reason']
            assert full_library(profile, artifacts['partitionline_broker'])['exit'] == 0
        cleanup_target_copies(artifacts)
    after = engine.inputs()
    engine.save('inputs-after.json', after)
    assert after == json.loads((engine.OUT/'inputs-before.json').read_text())
    engine.save('phase-summary.json', {'phase': args.phase, 'inputs_stable': True,
        'expected_reservation_and_permission_failures_observed': args.phase == 'baseline',
        'qualification': 'Recorded failing baseline only' if args.phase == 'baseline' else 'Scoped fixed-source checks passed',
        'disk_stop_bytes': engine.FLOOR,
        'observed_min_free_bytes': min(row['observed_min_free_bytes'] for row in RESOURCE_CHECKS),
        'new_oom_events': sum(sum(row['memory_event_deltas'].values()) for row in RESOURCE_CHECKS),
        'memory_events_after': engine.events()})
    print('Completed', phase_name, flush=True)

if __name__ == '__main__':
    main()
