import argparse
import gzip
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time

ROOT = Path('/workspace/work/replication-epoch-header-candidate')
OUT = Path(__file__).resolve().parent
FLOOR = 2 * 1024**3 + 32 * 1024**2
ENV = dict(os.environ)
ENV.update(RUSTUP_HOME='/workspace/work/rustup', CARGO_HOME='/workspace/work/cargo',
    PATH='/workspace/work/cargo/bin:' + ENV.get('PATH', ''),
    CARGO_TARGET_DIR='/workspace/work/qualification-20261027/broker-check-target',
    CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
for name in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER',
             'RUSTC_WORKSPACE_WRAPPER', 'RUST_TEST_THREADS', 'RUST_MIN_STACK',
             'PLB_JOURNAL_CHECKPOINT_CRASH', 'PLB_EPOCH_HEADER_CRASH_DIR',
             'PLB_REPLICATION_CRASH'):
    ENV.pop(name, None)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def inputs():
    names = []
    for folder in ('.cargo','src','tests','examples','partitionline-broker/src',
                   'partitionline-broker/tests','partitionline-broker/examples'):
        path = ROOT / folder
        if path.exists():
            names.extend(p.relative_to(ROOT) for p in path.rglob('*') if p.is_file())
    for name in ('Cargo.toml','Cargo.lock','rust-toolchain.toml','clippy.toml',
                 'build.rs','partitionline-broker/Cargo.toml',
                 'partitionline-broker/Cargo.lock','partitionline-broker/build.rs'):
        if (ROOT/name).is_file():
            names.append(Path(name))
    return {str(p):sha(ROOT/p) for p in sorted(set(names))
            if '__pycache__' not in p.parts and p.suffix != '.pyc'}

def save(name, value):
    with (OUT/name).open('x') as stream:
        json.dump(value,stream,indent=2)
        stream.write('\n')

def events():
    path=Path('/sys/fs/cgroup/memory.events')
    return path.read_text() if path.exists() else None

def run(name, command, timeout=600):
    expected=json.loads((OUT/'inputs-before.json').read_text())
    assert inputs()==expected, 'source changed before '+name
    assert shutil.disk_usage(ROOT).free > FLOOR, 'disk floor before '+name
    before=events()
    started_utc=datetime.now(timezone.utc).isoformat()
    started=time.monotonic()
    samples=[]
    stop=None
    with (OUT/(name+'.log')).open('xb') as stream:
        proc=subprocess.Popen(command,cwd=ROOT,env=ENV,stdout=stream,
            stderr=subprocess.STDOUT,start_new_session=True)
        while proc.poll() is None:
            free=shutil.disk_usage(ROOT).free
            samples.append({'seconds':round(time.monotonic()-started,3),'free_bytes':free})
            if free<FLOOR:
                stop='disk-floor'
            elif time.monotonic()-started>timeout:
                stop='process-timeout'
            if stop:
                os.killpg(proc.pid,signal.SIGTERM)
                break
            time.sleep(.1)
        try:
            code=proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL)
            code=proc.wait()
    text=(OUT/(name+'.log')).read_text(errors='replace')
    receipt={'command':command,'cwd':str(ROOT),'exit':code,'stop_reason':stop,
        'started_utc':started_utc,'finished_utc':datetime.now(timezone.utc).isoformat(),
        'disk_sampling_interval_seconds':0.1,
        'elapsed_seconds':time.monotonic()-started,'inputs_stable':inputs()==expected,
        'results':re.findall(r'^test result:.*$',text,re.M),
        'failures':re.findall(r'^test (.*?) \.\.\. FAILED$',text,re.M),
        'log_sha256':sha(OUT/(name+'.log')),'disk_stop_bytes':FLOOR,'disk_samples':samples,
        'memory_events_before':before,'memory_events_after':events()}
    save(name+'.json',receipt)
    print(json.dumps({'name':name,**{k:receipt[k] for k in
        ('exit','stop_reason','inputs_stable','results','failures')}}),flush=True)
    assert not stop and receipt['inputs_stable'], 'incomplete/unstable '+name
    return receipt,text

def build(profile):
    for path in (ROOT/'partitionline-broker/src').rglob('*.rs'):
        path.touch()
    command=['cargo','+stable','test','--locked','--manifest-path',
        'partitionline-broker/Cargo.toml','--lib','--test','journal',
        '--no-run','--message-format=json-render-diagnostics']
    if profile=='all-features': command.append('--all-features')
    row,text=run(profile+'-build',command,900)
    assert row['exit']==0, 'compilation failed'
    artifacts={}
    for line in text.splitlines():
        try: event=json.loads(line)
        except json.JSONDecodeError: continue
        if event.get('reason')!='compiler-artifact' or not event.get('executable'): continue
        if Path(event.get('manifest_path','')).parent != ROOT/'partitionline-broker': continue
        target=event['target']['name']
        if target not in ('partitionline_broker','journal'): continue
        assert event.get('fresh') is False,'Cargo reused '+target
        source=Path(event['executable']); digest=sha(source)
        retained=OUT/(profile+'-'+target+'.elf.gz')
        with source.open('rb') as input_stream,retained.open('xb') as raw:
            with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as compressed:
                while chunk:=input_stream.read(1024**2):
                    compressed.write(chunk)
                    assert shutil.disk_usage(ROOT).free>FLOOR,'retention crosses disk floor'
        with gzip.open(retained,'rb') as stream:
            restored=hashlib.file_digest(stream,'sha256').hexdigest()
        with gzip.open(retained,'rb') as stream:
            restored_bytes=sum(len(chunk) for chunk in iter(lambda:stream.read(1024**2),b''))
        assert sha(source)==restored==digest and restored_bytes==source.stat().st_size
        artifacts[target]={'source':str(source),'execution_path':str(source),
            'retained_gzip':str(retained),'retained_gzip_sha256':sha(retained),
            'sha256':digest,'bytes':source.stat().st_size,'fresh':False,'cargo_artifact':event}
    assert set(artifacts)=={'partitionline_broker','journal'},'missing test artifacts'
    save(profile+'-artifacts.json',artifacts)
    for target,artifact in artifacts.items():
        binary=artifact['execution_path']
        _,listing=run(profile+'-'+target+'-list',[binary,'--list'])
        assert re.search(r': test$',listing,re.M),'zero tests in '+target
    return artifacts

def suites(profile, artifacts):
    artifact=artifacts['partitionline_broker']
    binary=artifact['execution_path']
    assert sha(binary)==artifact['sha256']
    listing=(OUT/(profile+'-partitionline_broker-list.log')).read_text()
    for category in ('replication::tests::','journal::tests::'):
        name=profile+'-'+category.split('::')[0]
        selected=[line.removesuffix(': test') for line in listing.splitlines()
                  if line.startswith(category) and line.endswith(': test')]
        required=(['empty_epoch_fence_preserves_one_entry_capacity_and_blocks_old_readers',
                   'unchanged_full_one_entry_log_accepts_later_epochs_without_index_growth',
                   'accepted_epoch_survives_removing_its_last_record',
                   'legacy_event_replay_remembers_epochs_from_truncated_records',
                   'epoch_publication_errors_distinguish_pre_rename_from_ambiguous_outcomes',
                   'epoch_header_recovery_at_each_atomic_publication_stage',
                   'corrupted_or_unsupported_epoch_headers_are_not_repaired',
                   'accepted_epoch_replacement_preserves_private_file_permissions',
                   'detected_source_changes_poison_reads_and_writes_without_repair']
                  if category.startswith('replication') else
                  ['checkpoint_namespace_error_requires_reopen_but_preparation_error_does_not'])
        assert all(category+test in selected for test in required),'missing regression '+name
        # Substring filters also select raft::replication; enumerate exact local
        # names so the intended evidence scope cannot silently broaden.
        row,text=run(name,[binary,*selected,'--exact','--test-threads=1','--nocapture'],300)
        results=re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)
        assert results and sum(map(int,results[-1]))==len(selected),'selection count mismatch '+name
        assert sha(binary)==artifact['sha256']
    artifact=artifacts['journal'];binary=artifact['execution_path']
    assert sha(binary)==artifact['sha256']
    row,text=run(profile+'-journal-integration',[binary,'--test-threads=1'],300)
    assert re.search(r'running [1-9]\d* tests?',text),'empty journal integration'
    assert sha(binary)==artifact['sha256']

def initialize():
    save('inputs-before.json',inputs())
    save('scope.json',{'candidate_v4_patch_sha256':sha(ROOT/'candidate-v4.patch'),
        'input_scope':'Client and broker Rust sources, tests and fixtures, examples, .cargo, build scripts, manifests, lockfiles, toolchain and clippy config; dependency/toolchain bytes and external environment are not exhaustively pinned.',
        'main_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/partitionline',text=True).strip(),
        'candidate_directory':str(ROOT),'executed_source':'Sparse candidate copy; git source SHA unavailable because source differs from committed main.'})
    run('rustc',['rustc','+stable','-Vv'])
    run('cargo',['cargo','+stable','-V'])

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['init','default','all-features','clippy','finish']);args=parser.parse_args()
    if args.action=='init': initialize()
    elif args.action in ('default','all-features'): suites(args.action,build(args.action))
    elif args.action=='clippy':
        run('strict-clippy',['cargo','+stable','clippy','--locked','--manifest-path','partitionline-broker/Cargo.toml','--all-features','--lib','--test','journal','--','-D','warnings'],600)
    elif args.action=='finish':
        after=inputs();save('inputs-after.json',after)
        assert after==json.loads((OUT/'inputs-before.json').read_text())
        rows={p.stem:json.loads(p.read_text()) for p in OUT.glob('*.json') if p.stem not in ('inputs-before','inputs-after','scope','default-artifacts','all-features-artifacts')}
        passed=all(row.get('exit')==0 and row.get('inputs_stable') is True and not row.get('stop_reason') for row in rows.values())
        save('summary.json',{'inputs_stable':True,'all_commands_passed':passed,'results':rows})
        assert passed,'one or more qualification commands failed'
