#!/usr/bin/env python3
"""Check actual supervisor records and seal the additive text publication packet."""
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path

HERE = Path(__file__).parent
spec = importlib.util.spec_from_file_location('four_replay_guard',HERE/'replay-four.py')
replay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(replay)
PACKET = HERE/'publication-packet'


def dump(path,value):
    replay.require(not path.exists(),'fresh seal output')
    path.write_text(json.dumps(value,indent=2)+'\n');path.chmod(0o600)


def main():
    replay.require(os.sched_getaffinity(0) == {2,4},'Python-only actualCPU2,4')
    recorded = json.loads(gzip.decompress((HERE/'input-inventory-before.json.gz').read_bytes()))
    lanes,external,_ = replay.setup_inputs()
    replay.require(replay.audit(external) == recorded,'closed original replay inputs unchanged at finalseal')
    prepared = replay.read(HERE/'publication-stage-manifest.json')
    for row in prepared['files']:
        replay.require(replay.item(PACKET/row['relative_path']) == {k:v for k,v in row.items() if k != 'relative_path'},
                       'all prepared packet objects/restoremanifest unchanged after fresh-root replay')
    supervisor = []
    extra_bindings = {}
    for label in replay.LABELS:
        path = replay.LIVE/'supervision'/label/'attempt-1'/'validation.json'
        s = replay.read(path)
        replay.require(s['passed'] is True and s['failure'] is None and s['exit_code'] == 0
                       and s['actual_peer_jobs'] == 160 and s['actual_operator_calls'] == 45
                       and s['actual_helper_launches'] == 1 and s['actual_Cargo_or_compiler_commands'] == 0
                       and s['disk_monitor_triggered'] is False and s['owned_group_after_exit'] == [], 'actual closed successful supervision')
        for key in ('log','monitor','raw_helper_receipt'):
            replay.check_binding(s[key]);extra_bindings[str(Path(s[key]['path']))] = replay.item(Path(s[key]['path']))
        for row in s['artifacts_before'].values():
            actual = replay.check_binding(row);extra_bindings[actual['path']] = actual
        replay.require(s['artifacts_before'] == s['artifacts_after'] and s['whole_sources_before'] == s['whole_sources_after'],
                       'actual whole-source/artifact byte/fullmode guards')
        monitor_path = Path(s['monitor']['path'])
        data = monitor_path.read_bytes()
        replay.require(len(data) <= 1024*1024,'bounded raw disk monitor')
        monitors = [json.loads(line) for line in data.splitlines()]
        replay.require(len(monitors) == s['disk_monitor_samples'] and 1 <= len(monitors) <= 4096,
                       'actual full monitor sample count')
        minimum = min(row['available_bytes'] for row in monitors)
        replay.require(all(type(row['available_bytes']) is int and row['available_bytes'] >= s['disk_threshold_bytes']
                           and row['threshold_bytes'] == s['disk_threshold_bytes'] for row in monitors), 'all actual raw samples above350MiB')
        replay.require(s['disk_minimum_available_bytes'] <= minimum
                       and s['disk_minimum_available_bytes'] >= s['disk_threshold_bytes'], 'reported initial/probed minimum compatible with raw samples')
        replay.require(all(a['unix'] <= b['unix'] for a,b in zip(monitors,monitors[1:])), 'same supervisor Unix clock ordering')
        replay.require(s['started_unix'] <= monitors[0]['unix'] <= monitors[-1]['unix'] <= s['ended_unix'],
                       'raw monitor falls inside same supervisor clock epoch')
        elapsed = s['ended_unix']-s['started_unix']
        ownership = replay.read(replay.LIVE/(f'ownership-after-{label}-attempt-1.json'))
        replay.require(ownership['matching_members'] == [] and ownership['global_zero_owner_claim'] is False,
                       'owned group closure only, no global process absence inference')
        supervisor.append({'lane':label,'receipt':replay.item(path),'helper_exit_code':s['exit_code'],
                           'source_sha':s['source_sha'],'peer_source_sha':s['peer_source_sha'],
                           'actual_helper_PID':s['pid'],'actual_helper_elapsed_seconds_same_supervisor_epoch':elapsed,
                           'actual_peer_jobs':s['actual_peer_jobs'],'operators':s['actual_operator_calls'],
                           'raw_disk_monitor':replay.item(monitor_path),'actual_raw_sample_count':len(monitors),
                           'actual_raw_sample_minimum_bytes':minimum,'reported_minimum_including_preloop_probe_bytes':s['disk_minimum_available_bytes'],
                           'owned_group_after_exit':s['owned_group_after_exit'],'ownership_after':replay.item(replay.LIVE/(f'ownership-after-{label}-attempt-1.json'))})
    for path, expected in extra_bindings.items():
        replay.require(replay.item(Path(path)) == expected,'extra supervision artifacts unchanged atseal')
    restore = HERE/'restored-public-output-replay.json'
    result = replay.read(restore)
    replay.require(result['passed'] is True and result['totals']['jobs'] == 640 and result['totals']['native_eofs'] == 1080,
                   'actual fresh-root public-output replay pass')
    raw = restore.read_bytes()
    compressed = PACKET/'restored-public-output-replay.json.gz'
    with compressed.open('xb') as out:
        out.write(gzip.compress(raw,mtime=0))
    compressed.chmod(0o600)
    replay.require(gzip.decompress(compressed.read_bytes()) == raw,'lossless supplemental restoration proof')
    seal_source = Path(__file__).read_bytes()
    seal_gzip = PACKET/'sealing-source.py.gz'
    with seal_gzip.open('xb') as out:
        out.write(gzip.compress(seal_source,mtime=0))
    seal_gzip.chmod(0o600)
    replay.require(gzip.decompress(seal_gzip.read_bytes()) == seal_source,'exact sealing source retained')
    receipt = {'schema_version':1,'passed':True,'runtime_source_sha':replay.CORE,'peer_source_sha':replay.PEER,
               'scope':'Independent four-lane public-output replay and bounded provenance/supervision packaging. No task closure or new runtime qualification is inferred.',
               'actual_affinity':[2,4],'actual_new_Cargo_or_broker_or_SDK_or_JVM_executions':0,
               'actual_original_full_replay':replay.item(HERE/'validation.json'),
               'original_all4824_cohort_files_and_external_bindings_unchanged_atseal':True,
               'all829_prepared_packet_payloads_unchanged_after_restoration_replay':True,
               'fresh_root_public_output_replay':dict(replay.item(compressed),uncompressed_sha256=hashlib.sha256(raw).hexdigest(),
                                                     uncompressed_bytes=len(raw),original_full_mode=restore.stat().st_mode & 0o7777,
                                                     restore_path=str(restore),decompression_verified=True),
               'restoration_command_observation':{'argv':['taskset','-c','2,4','env','PYTHONDONTWRITEBYTECODE=1','python3',
                                                         str(HERE/'restore-public-output.py'),'--packet',str(PACKET),
                                                         '--restored-root',str(HERE/'restored-public-output'),'--output',str(restore)],
                                                  'tool_observed_exit_code':0,'receipt_SHA256':replay.sha(restore)},
               'supervision_actual_rows':supervisor,
               'minimum_original_live_reported_disk_available_bytes':min(row['reported_minimum_including_preloop_probe_bytes'] for row in supervisor),
               'deadline_limits':'Actual whole-cohort elapsed durations and raw disk timestamps are from each supervisor own clock epoch.100s child/15s startup-stop/10s operator/10s SDK-reader budgets are pinned source settings; no per-job elapsed or cross-PID deadline reconstruction is claimed.',
               'correlation_limits':'Literal producer-reader-topic-seek-phase/operator UUID-partition-clock and native EOF/Rust digest correlations passed. No low-level Kafka request-response correlation ID trace is present.',
               'complete_source_guards':replay.read(PACKET/'restore-manifest.json')['source_guards_after'],
               'staged_binary_payloads':0,'portable_binary_journal_reconstruction_claimed':False,
               'sealing_source':replay.item(Path(__file__)),
               'sealing_source_gzip':dict(replay.item(seal_gzip),uncompressed_sha256=hashlib.sha256(seal_source).hexdigest(),
                                          uncompressed_bytes=len(seal_source),original_full_mode=Path(__file__).stat().st_mode & 0o7777,
                                          restore_path=str(Path(__file__)),decompression_verified=True)}
    dump(PACKET/'final-review-receipt.json',receipt)
    stage = [dict(replay.item(p),relative_path=str(p.relative_to(PACKET))) for p in sorted(PACKET.rglob('*')) if p.is_file()]
    replay.require(all(row['bytes'] < 12*1024*1024 for row in stage),'no raw/Git blob at12MiB')
    final = {'schema_version':1,'packet_root':str(PACKET),'files':stage,'file_count':len(stage),
             'bytes':sum(row['bytes'] for row in stage),'final_review_receipt':replay.item(PACKET/'final-review-receipt.json'),
             'original_prepared_stage_manifest':replay.item(HERE/'publication-stage-manifest.json'),
             'actual_replay_validation':replay.item(HERE/'validation.json'),
             'all_payloads_text_or_gzip_UTF8_text_without_NUL':True,'no_ELF_JAR_class_or_gzip_binary':True,
             'actual_restored_text_paths':len(result['restore_mapping']),'originals_unchanged':True}
    dump(HERE/'final-publication-stage-manifest.json',final)
    print(json.dumps({'passed':True,'files':final['file_count'],'bytes':final['bytes'],
                      'final_stage_sha256':replay.sha(HERE/'final-publication-stage-manifest.json'),
                      'final_review_sha256':replay.sha(PACKET/'final-review-receipt.json')}),flush=True)


if __name__ == '__main__':
    main()
