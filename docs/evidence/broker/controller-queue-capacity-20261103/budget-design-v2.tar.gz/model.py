#!/usr/bin/env python3
"""Explore a tiny idealized gate protocol, not Rust/Tokio or a liveness proof."""
from collections import deque
from dataclasses import dataclass, replace
import json

@dataclass(frozen=True)
class State:
    queue: tuple[str, ...] = ()
    owner: str = ''                  # producer only; other gate sections are atomic
    producer: str = 'start'          # start / reserved / done
    stop: bool = False
    shutdown: bool = False
    alive: bool = True
    receiver_open: bool = True
    actor: str = 'waiting'           # waiting / popped / checking / processing / closing / dropping / closed
    current: str = ''
    rx_slot: bool = False           # pop happened, slot not yet returned
    reply: str = 'none'             # none / queued / active / resolved

def occupied(s):
    return len(s.queue) + (s.producer == 'reserved') + s.rx_slot

def successors(s, q, valid):
    out = []
    def add(label, **changes):
        out.append((label, replace(s, **changes)))

    # Producer's reserved phase retains the gate until its permit is sent/dropped.
    if s.producer == 'start' and not s.owner:
        if s.stop or not s.alive or occupied(s) == q:
            add('submit_rejected_before_permit', producer='done')
        else:
            add('submit_reserved', owner='p', producer='reserved')
    if s.producer == 'reserved':
        assert s.owner == 'p'
        if valid:
            assert s.alive and s.receiver_open  # no receiver death can cross the held gate
            add('submit_sent', queue=s.queue + ('u',), owner='', producer='done', reply='queued')
        else:
            add('submit_capacity_rejected', owner='', producer='done')

    # Shutdown owns the same gate for stop and send; an unavailable receiver is not sent to.
    if not s.shutdown and not s.owner:
        queue = s.queue
        if s.alive and occupied(s) < q:
            assert s.receiver_open
            queue += ('s',)
        add('shutdown', stop=True, shutdown=True, queue=queue)

    # Separately model a receive pop and channel permit release before the gated stop check.
    if s.actor == 'waiting' and s.queue and s.receiver_open:
        item, queue = s.queue[0], s.queue[1:]
        reply = 'active' if item == 'u' else s.reply
        add('actor_popped', queue=queue, actor='popped', current=item, rx_slot=True, reply=reply)
    if s.actor == 'popped':
        add('actor_released_slot', actor='checking', rx_slot=False)
    if s.actor == 'checking' and not s.owner:
        if s.stop or s.current == 's':
            reply = 'resolved' if s.current == 'u' else s.reply
            add('actor_stop_checked', actor='closing', current='', reply=reply)
        else:
            add('actor_work_started', actor='processing')
    if s.actor == 'processing':
        reply = 'resolved' if s.current == 'u' else s.reply
        add('actor_work_finished', actor='waiting', current='', reply=reply)
    # A processing or blocked-receive failure invokes the same exit guard.
    if s.actor in ('waiting', 'processing'):
        reply = 'resolved' if s.current == 'u' else s.reply
        add('actor_failed', actor='closing', current='', reply=reply)
    if s.actor == 'closing' and not s.owner:
        add('receiver_marked_dead', actor='dropping', alive=False)
    if s.actor == 'dropping':
        reply = 'resolved' if 'u' in s.queue else s.reply
        add('receiver_dropped', actor='closed', receiver_open=False, queue=(), reply=reply)
    return out

def explore(q, valid, seeded):
    initial = State(queue=('x',) if seeded else ())
    todo, seen = deque([initial]), {initial}
    edges = 0
    while todo:
        s = todo.popleft()
        assert occupied(s) <= q, s
        assert (s.owner == 'p') == (s.producer == 'reserved'), s
        assert s.alive or not (s.producer == 'reserved'), s
        # Under the model's ideal send/wake assumption, shutdown cannot leave an
        # empty, open receiver asleep after its own stop-and-signal step.
        assert not (s.shutdown and s.alive and s.receiver_open and s.actor == 'waiting'
                    and not s.queue), s
        if s.actor == 'closed' and s.producer == 'done':
            assert s.reply not in ('queued', 'active'), s
        for _, ns in successors(s, q, valid):
            edges += 1
            if ns not in seen:
                seen.add(ns)
                todo.append(ns)
    return {'states': len(seen), 'edges': edges}

# Counterexample ledgers are facts of the abstract v1 policy, not Tokio executions.
old_q1 = ['producer_reserved_only_slot', 'shutdown_stop_full',
          'producer_rejected_and_dropped_permit', 'open_receiver_still_waiting']
old_q2 = ['producer_reserved', 'shutdown_enqueued_stop', 'receiver_dropped',
          'old_permit_sent_after_receiver_drop']
assert len(old_q1) == 4 and len(old_q2) == 4
cases = {}
for q in (1, 2):
    for valid in (False, True):
        for seeded in (False, True):
            cases[f'q{q}_valid{int(valid)}_seeded{int(seeded)}'] = explore(q, valid, seeded)
print(json.dumps({
    'model_only': True,
    'prior_design_counterexample_ledgers': [old_q1, old_q2],
    'cases': cases,
    'excluded': ['real Tokio or Rust', 'multiple producers', 'byte counter', 'allocation',
                 'panic and poison inside gate or send', 'wake failure', 'reentrant destructors',
                 'memory ordering', 'scheduler fairness', 'actor work that never returns',
                 'transport and WAL'],
    'conclusion': 'No production or concurrency qualification follows from these finite states.'
}, indent=2))
