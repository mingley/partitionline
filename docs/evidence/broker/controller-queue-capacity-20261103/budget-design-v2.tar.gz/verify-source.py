#!/usr/bin/env python3
"""Verify source and review pins plus observations, without compiling Rust."""
from pathlib import Path
import hashlib
import subprocess

root = Path('/workspace/partitionline')
tokio = Path('/workspace/work/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tokio-1.53.3/src/sync/mpsc')
peer = Path('/workspace/work/controller-handler-byte-budget-independent-20261103/review.json')
old = Path('/workspace/work/controller-handler-byte-budget-design-20261103/receipt.json')
files = {
    root / 'partitionline-broker/src/raft/protocol.rs': '47ae96c84080813e4b81cfbfcdbe8bd45e48389c13c8562c0963dfc743137127',
    root / 'partitionline-broker/src/protocol.rs': 'c0c81bcaba200dc27e670146fc6bf37342aadc506547ef606b597d708df5207a',
    root / 'partitionline-broker/src/transport.rs': '802f9923b825bdac96ea0d31663f6f3a1c1d84903c46bb16130b2eb8419a8aa2',
    root / 'partitionline-broker/Cargo.lock': '42eaddf993ab4dfbe99e5af9d7c1a7cd858776a214eedbd6112de6a146933a2c',
    tokio / 'bounded.rs': 'f229ccaa6711bffb17d8021dade6405d17595d5f64dac2f03107c05a4cc381f2',
    tokio / 'chan.rs': 'cbc283b9f4a824e33ec3b137b155dd7044ce296596685070c1acb306a1660542',
    peer: 'a3f75ea849398e10f2425e784812680cebce1047bac95f388f307167e9d5fc98',
    old: '947948212887ccb0cd84f9792a0b41769c71a5b6760db7b8983d2ddb3aa722e7',
}
for path, digest in files.items():
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, path
raft = (root / 'partitionline-broker/src/raft/protocol.rs').read_text()
assert 'while let Some(command) = receiver.blocking_recv() {' in raft
assert 'drop(self.sender.try_send(Command::Stop));' in raft
assert 'receiver.await.map_err(|_| Error::Actor)?' in raft
transport = (root / 'partitionline-broker/src/transport.rs').read_text()
assert '.exchange_request(&peer, dispatch_frame(request), response_buf)' in transport
assert '.map_err(|_| Exit::HandlerError)?;' in transport
assert 'Ok(Exit::HandlerError) => &mut self.handler_errors' in transport
assert 'fn park_request(mut bytes: Vec<u8>)' in transport
assert 'fn park_response(mut current: Vec<u8>, mut incoming: Vec<u8>)' in transport
bounded = (tokio / 'bounded.rs').read_text()
assert 'pub fn try_reserve(&self) -> Result<Permit<' in bounded
assert 'if semaphore.is_closed() && semaphore.is_idle()' in bounded
chan = (tokio / 'chan.rs').read_text()
assert 'Some(Read::Value(value)) => {' in chan and 'self.inner.semaphore.add_permit();' in chan
model = Path(__file__).with_name('model.py')
expected = Path(__file__).with_name('model.out').read_bytes()
actual = subprocess.run(['python3', str(model)], check=True, stdout=subprocess.PIPE).stdout
assert actual == expected
print('Pinned repository, Tokio, prior proposal and independent blocker review verified.')
print('Bounded abstract gate model output reproduced; it is not a Rust or concurrency test.')
