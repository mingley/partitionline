#!/usr/bin/env python3
"""Small capacity arithmetic illustration; no Rust or actor is executed."""
import json
q, limit = 2, 1024
request_len, request_capacity, spare_capacity = 1, 1025, 1025
accepted_by_current_length_check = request_len <= limit
assert accepted_by_current_length_check
assert q * (request_capacity + spare_capacity) > q * limit
assert q * (limit + limit) == 2 * q * limit
print(json.dumps({'queued_slots': q, 'request_limit': limit,
                  'request_len': request_len, 'request_capacity': request_capacity,
                  'spare_capacity': spare_capacity,
                  'length_check_would_accept': accepted_by_current_length_check,
                  'validated_q_times_limit': q * limit,
                  'two_individually_limited_buffers': 2 * q * limit,
                  'model_only': True}, indent=2))
