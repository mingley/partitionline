#!/usr/bin/env python3
"""Verify pinned source observations; no Rust code or actor executes."""
import hashlib
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit('usage: verify.py <repository>')
root = Path(sys.argv[1])
expected = {
    'partitionline-broker/src/raft/protocol.rs': '47ae96c84080813e4b81cfbfcdbe8bd45e48389c13c8562c0963dfc743137127',
    'partitionline-broker/src/protocol.rs': 'c0c81bcaba200dc27e670146fc6bf37342aadc506547ef606b597d708df5207a',
    'partitionline-broker/src/transport.rs': '802f9923b825bdac96ea0d31663f6f3a1c1d84903c46bb16130b2eb8419a8aa2',
    'partitionline-broker/Cargo.lock': '42eaddf993ab4dfbe99e5af9d7c1a7cd858776a214eedbd6112de6a146933a2c',
}
for name, digest in expected.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
source = (root / 'partitionline-broker/src/raft/protocol.rs').read_text()
config = source.split('    pub(crate) fn validate(&self) -> Result<Membership, Error> {', 1)[1].split('\n}\n', 1)[0]
assert '.checked_mul(self.protocol_limits.max_request_bytes())' in config
job = source.split('struct ControllerJob {', 1)[1].split('\n}', 1)[0]
assert 'request: Vec<u8>' in job and 'spare: Vec<u8>' in job
submit = source.split('    async fn submit(&self, request: Vec<u8>, spare: Vec<u8>) -> ControllerReply {', 1)[1].split('\n}\nimpl Handler for ControllerHandler', 1)[0]
assert submit.index('self.stopping.load') < submit.index('request.len()') < submit.index('.try_send(')
assert 'request.capacity()' not in submit and 'spare.capacity()' not in submit
assert 'request,\n                spare,\n                reply: sender,' in submit
assert 'receiver.await.map_err(|_| Error::Actor)?' in submit
assert '.map(|response| (response, request))' in source
transport = (root / 'partitionline-broker/src/transport.rs').read_text()
assert 'pub trait Handler: Send + Sync' in transport
assert 'fn exchange_request(' in transport
print('Pinned queue arithmetic, request/spare ownership, validation ordering and public handler shape verified in source.')
print('No Rust build, actor execution, WAL mutation or network test performed.')
