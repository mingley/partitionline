#!/usr/bin/env python3
"""Illustrate a proposed sequential policy; does not execute Rust or model races."""
import json
MAX_USIZE = 2**64 - 1

def decide(stopped, request_len, limit, slot_free, request_capacity, spare_capacity, used, budget):
    if stopped:
        return 'Stopped'
    if request_len > limit:
        return 'Protocol(RequestTooLarge)'
    if not slot_free:
        return 'Busy(queue)'
    total = request_capacity + spare_capacity
    if total > MAX_USIZE or total > budget:
        return 'InvalidConfig(capacity)'
    if used + total > MAX_USIZE or used + total > budget:
        return 'Busy(bytes)'
    return 'admitted'

q, limit = 2, 1024
budget = q * limit
cases = {
    'stopped_precedes_invalid_and_full': (True, limit + 1, limit, False, budget + 1, 0, 0, budget),
    'length_precedes_full': (False, limit + 1, limit, False, 1, 0, 0, budget),
    'full_precedes_capacity': (False, 1, limit, False, budget + 1, 0, 0, budget),
    'permanent_capacity': (False, 1, limit, True, budget + 1, 0, 0, budget),
    'transient_bytes': (False, 1, limit, True, 400, 200, 1536, budget),
    'exact_budget': (False, 1, limit, True, 1024, 1024, 0, budget),
    'empty_buffers': (False, 0, limit, True, 0, 0, 0, budget),
    'checked_capacity_overflow': (False, 1, limit, True, MAX_USIZE, 1, 0, budget),
}
actual = {name: decide(*args) for name, args in cases.items()}
expected = ['Stopped', 'Protocol(RequestTooLarge)', 'Busy(queue)', 'InvalidConfig(capacity)',
            'Busy(bytes)', 'admitted', 'admitted', 'InvalidConfig(capacity)']
assert list(actual.values()) == expected
# Existing queue+length checks would accept the permanent-capacity example.
assert not cases['permanent_capacity'][0] and cases['permanent_capacity'][1] <= limit and cases['permanent_capacity'][3]
print(json.dumps({'model_only': True, 'queue_slots': q, 'limit': limit,
                  'queue_budget': budget, 'cases': actual,
                  'limitations': 'No Rust, mpsc, allocator, actor, WAL, cancellation or concurrency execution.'}, indent=2))
