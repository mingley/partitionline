#!/usr/bin/env python3
"""Confirm the colon-path failure using the exact preimage and offline fixtures."""
import importlib.util,os,subprocess,tempfile
from pathlib import Path
candidate=Path('/workspace/work/release-ci-attempt-independent-review-20261103/candidate-v6');spec=importlib.util.spec_from_file_location('prior_fake',candidate/'tests/release/test_live_ci_evidence.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory(prefix='old-colon-review-') as outer:
 tmp=Path(outer)/'parent:colon';tmp.mkdir();live,_=m.LiveCIEvidence().run_case(m.fixture(),{'TMPDIR':str(tmp)})
 assert live.returncode!=0 and '[outcome=missing]' in live.stderr
 env=os.environ.copy();env.update(TMPDIR=str(tmp),PATH='/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1')
 selftest=subprocess.run(['bash','scripts/check-main-ci.sh','--self-test'],cwd=candidate,env=env,capture_output=True,text=True,timeout=30)
 assert selftest.returncode!=0 and '[outcome=missing]' in selftest.stderr
 print('PASS reproduced preimage live fake-service and self-test failures for literal colon TMPDIR')
