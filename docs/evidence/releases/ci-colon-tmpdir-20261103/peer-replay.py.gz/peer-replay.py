#!/usr/bin/env python3
"""Replay literal and legacy colon paths through an isolated gate using no network."""
import importlib.util,json,os,subprocess,tempfile
from pathlib import Path
candidate=Path(__file__).resolve().parent/'candidate';p=candidate/'tests/release/test_live_ci_evidence.py';spec=importlib.util.spec_from_file_location('fake_ci',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory(prefix='colon-review-') as outer:
 temp=Path(outer)/'parent:colon';temp.mkdir(); data=m.fixture();run=data['runs'][0];run['attempt']=m.ATTEMPT;jobs=data['jobs'][0]['jobs'];artifact=data['artifacts'][0]['artifacts'][0]
 def write(name,obj):p=temp/name;p.write_text(json.dumps(obj));return str(p)
 env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','CHECK_SHA':m.SHA,'REQUIRE_MAIN_CI':'1','REQUIRE_PROFILE_EVIDENCE':'1','TMPDIR':str(temp),'PL_CI_FIXTURE_SINGLE_PATHS':'1','GH_RUNS_JSON':write('runs',[run]),'GH_JOBS_JSON':write('jobs',{'run_id':m.RUN,'head_sha':m.SHA,'attempt':m.ATTEMPT,'jobs':jobs}),'GH_ARTIFACTS_JSON':write('artifacts',{'artifacts':[artifact]}),'PYTHONDONTWRITEBYTECODE':'1'}
 def gate(e):return subprocess.run(['bash','scripts/check-main-ci.sh'],cwd=candidate,env=e,capture_output=True,text=True,timeout=30)
 ok=gate(env);assert ok.returncode==0 and '[outcome=success]' in ok.stdout,(ok.stdout,ok.stderr);print('PASS literal-colon run/jobs/artifact fixture paths under explicit single mode')
 broken=m.fixture();broken_jobs=broken['jobs'][0]['jobs'];broken_jobs[0]['conclusion']='failure';write('jobs',{'run_id':m.RUN,'head_sha':m.SHA,'attempt':m.ATTEMPT,'jobs':broken_jobs});fail=gate(env);assert fail.returncode!=0 and '[outcome=success]' not in fail.stdout,(fail.stdout,fail.stderr);print('PASS literal fixture failed job remains fail-closed')
 without=env.copy();without.pop('PL_CI_FIXTURE_SINGLE_PATHS');fail=gate(without);assert fail.returncode!=0 and '[outcome=success]' not in fail.stdout;print('PASS legacy delimiter default rejects literal path unless opted in')
 live=m.fixture();live['jobs'][0]['jobs'][0]['conclusion']='failure';result,_=m.LiveCIEvidence().run_case(live,{'TMPDIR':str(temp),'PL_CI_FIXTURE_SINGLE_PATHS':'1'});assert result.returncode!=0 and '[outcome=success]' not in result.stdout;print('PASS inherited single-path flag cannot bypass live required-job failure')
 plain=Path(outer)/'plain';plain.mkdir(); fresh=m.fixture(); original=fresh['runs'][0];original['attempt']=m.ATTEMPT; all_jobs=fresh['jobs'][0]['jobs'];only_artifact=fresh['artifacts'][0]['artifacts'][0]
 def save(name,obj):p=plain/name;p.write_text(json.dumps(obj));return str(p)
 save('r0',[]);save('r1',[original]);save('j0',{'run_id':m.RUN,'head_sha':m.SHA,'attempt':m.ATTEMPT,'jobs':[]});save('j1',{'run_id':m.RUN,'head_sha':m.SHA,'attempt':m.ATTEMPT,'jobs':all_jobs});save('a0',{'artifacts':[]});save('a1',{'artifacts':[only_artifact]})
 base={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','CHECK_SHA':m.SHA,'REQUIRE_MAIN_CI':'1','REQUIRE_PROFILE_EVIDENCE':'1','TMPDIR':str(plain),'GH_RUNS_JSON':str(plain/'r1'),'GH_JOBS_JSON':str(plain/'j1'),'GH_ARTIFACTS_JSON':str(plain/'a1'),'PYTHONDONTWRITEBYTECODE':'1'}
 for field,parts in [('GH_RUNS_JSON',('r0','r1')),('GH_JOBS_JSON',('j0','j1')),('GH_ARTIFACTS_JSON',('a0','a1'))]:
  case={**base,field:':'.join(str(plain/n) for n in parts)};ok=gate(case);assert ok.returncode==0,(field,ok.stdout,ok.stderr)
  fail=gate({**case,'PL_CI_FIXTURE_SINGLE_PATHS':'1'});assert fail.returncode!=0 and '[outcome=success]' not in fail.stdout,(field,fail.stdout,fail.stderr)
  print('PASS same '+field+' string parses as legacy list by default and fails as nonexistent literal in single mode')
