#!/usr/bin/env python3
"""Run v4's rehearsal test suite against an actual outer 0.2.0 manifest."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess

BASE=Path('/workspace/work/release-rehearsal-candidate-20261103/v4')
PATCH=Path('/workspace/work/release-rehearsal-candidate-20261103/v4.patch')
OUT=Path('/workspace/work/release-rehearsal-v4-cross-version-review-20261103')
ROOT=OUT/'fixture'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert digest(PATCH)=='2bfdef9cbddbad38ed27c11c201f4f7bbb8503b8746c5c12d4558c4423d3b929'
spec=importlib.util.spec_from_file_location('frozen_rehearsal',BASE/'scripts/report-release-rehearsal.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
ROOT.mkdir(exist_ok=False)
names=sorted(set(module.SOURCE_FILES)|{
    'tests/release/test_rehearsal.py', 'scripts/owner-cut-release.sh',
    'scripts/ci-publish-ready.sh','scripts/day1-after-publish.sh',
    'scripts/owner-post-installable-handoff.sh'})
for name in names:
    destination=ROOT/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(BASE/name,destination)
manifest=ROOT/'Cargo.toml'
text=manifest.read_text(encoding='utf-8')
assert text.count('version = "0.1.0"') == 1
manifest.write_text(text.replace('version = "0.1.0"','version = "0.2.0"',1),encoding='utf-8')
before={name:digest(ROOT/name) for name in names}
command=['python3','-B','tests/release/test_rehearsal.py']
result=subprocess.run(command,cwd=ROOT,env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8',
    'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True,timeout=90)
after={name:digest(ROOT/name) for name in names}
(OUT/'stdout.log').write_text(result.stdout,encoding='utf-8')
(OUT/'stderr.log').write_text(result.stderr,encoding='utf-8')
receipt={'scope':'Offline local 0.2.0 fixture and shimmed services; no Cargo, credentials, publication or network.',
         'candidate_patch_sha256':digest(PATCH),'fixture_version':'0.2.0',
         'fixture_cargo_toml_sha256':before['Cargo.toml'],
         'source_files_before':before,'source_files_after':after,'source_files_stable':before==after,
         'cwd':str(ROOT),'command':command,'exit_code':result.returncode,
         'stdout_sha256':digest(OUT/'stdout.log'),'stderr_sha256':digest(OUT/'stderr.log')}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'exit_code':receipt['exit_code'],'source_files_stable':receipt['source_files_stable'],
                  'manifest_sha256':receipt['fixture_cargo_toml_sha256']}))
assert receipt['exit_code']==0 and receipt['source_files_stable']
