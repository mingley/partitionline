import datetime,hashlib,json,os,pathlib,re,shutil,subprocess,sys,time
out=pathlib.Path('/workspace/work/release-rehearsal-v4-author-validation-20261103')
candidate=pathlib.Path('/workspace/work/release-rehearsal-candidate-20261103')
source=candidate/'v4'; meta=json.loads((candidate/'v4-receipt.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
patch=candidate/'v4.patch'; assert sha(patch.read_bytes())=='2bfdef9cbddbad38ed27c11c201f4f7bbb8503b8746c5c12d4558c4423d3b929'
def snapshot(root):
 return {p.relative_to(root).as_posix():sha(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file()}
before=snapshot(source)
for name, entry in meta['sources'].items(): assert before[name]==entry['after_sha256'],name
source020=out/'source-0.2.0';shutil.copytree(source,source020)
p=source020/'Cargo.toml'; text=p.read_text(); old='version = "0.1.0"'; assert text.count(old)==1
p.write_text(text.replace(old,'version = "0.2.0"',1)); before020=snapshot(source020)
assert all(before020[k]==before[k] for k in before if k!='Cargo.toml')
fake=out/'refused-commands';fake.mkdir()
for name in ['curl','gh','cargo','rustup','wget','docker','ssh']:
 p=fake/name;p.write_text('#!/bin/sh\necho "unsubstituted external command refused" >&2\nexit 97\n');p.chmod(0o755)
env={'PATH':str(fake)+':/usr/bin:/bin','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1',
     'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'}
checks=[
 ('all-release-tests-0.1.0',source,['/usr/bin/python3','-B','-m','unittest','discover','-s','tests/release','-p','test_*.py','-v'],{}),
 ('all-release-tests-0.2.0',source020,['/usr/bin/python3','-B','-m','unittest','discover','-s','tests/release','-p','test_*.py','-v'],{}),
 ('syntax',source,['bash','-n','scripts/rehearse-partial-release.sh','scripts/ci-publish-ready.sh','scripts/lib/crates-io.sh'],{}),
 ('self-test-0.1.0',source,['bash','scripts/rehearse-partial-release.sh','--self-test'],{}),
 ('self-test-0.2.0',source020,['bash','scripts/rehearse-partial-release.sh','--self-test'],{}),
 ('independent-33-probe-replay',source,['/usr/bin/python3','-B','/workspace/work/release-rehearsal-review-20261103-v2/probe_review.py'],{'REVIEW_SOURCE':str(source)}),
]
results=[]
for name,cwd,command,extra in checks:
 t=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:
  p=subprocess.run(command,cwd=cwd,env={**env,**extra},capture_output=True,timeout=120)
  code=p.returncode;stdout=p.stdout;stderr=p.stderr
 except subprocess.TimeoutExpired as e:
  code=124;stdout=e.stdout or b'';stderr=e.stderr or b''
 (out/(name+'.stdout')).write_bytes(stdout);(out/(name+'.stderr')).write_bytes(stderr)
 results.append({'name':name,'command':command,'cwd':str(cwd),'started_utc':started,
                 'elapsed_seconds':round(time.monotonic()-t,3),'exit':code,
                 'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr)})
 print(name,'exit',code,flush=True)
after=snapshot(source);after020=snapshot(source020)
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
(out/'source-020-before.json').write_text(json.dumps(before020,indent=2)+'\n')
(out/'source-020-after.json').write_text(json.dumps(after020,indent=2)+'\n')
peer=json.loads((out/'independent-33-probe-replay.stdout').read_text()) if results[-1]['exit']==0 else {}
peer_passed=sum(x['passed'] for x in peer.get('probe_controls',[]))
receipt={'scope':'Offline substituted-service validation with two actual manifest versions; no publish or actual network calls',
         'patch_sha256':sha(patch.read_bytes()),'source_hashes_before_sha256':sha((out/'source-before.json').read_bytes()),
         'source_hashes_after_sha256':sha((out/'source-after.json').read_bytes()),'source_stable':before==after,
         'source_020_hashes_before_sha256':sha((out/'source-020-before.json').read_bytes()),
         'source_020_hashes_after_sha256':sha((out/'source-020-after.json').read_bytes()),'source_020_stable':before020==after020,
         'checks':results,'peer_probe_replay_passed':peer_passed,'python_version':sys.version,
         'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'all_passed':before==after and before020==after020 and peer_passed==33 and all(row['exit']==0 for row in results),
         'native_cargo_or_live_network':'not run','release_ready':False,
         'separate_open_issue':'release.yml post-upload confirmation currently checks API only and accepts redirects'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('receipt',sha((out/'receipt.json').read_bytes()),'passed',receipt['all_passed'],flush=True)
if not receipt['all_passed']:sys.exit(1)
