#!/usr/bin/env python3
"""Prove the offline tests reject bypassed confirmation and JSON guards."""
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path('/workspace/work/release-confirmation-candidate-20261103/v3-fixed')
RECEIPT = Path('/workspace/work/release-confirmation-candidate-20261103/mutation-results.json')
PATTERN = '"$PL_CRATES_API_STATUS" == present && "$PL_CRATES_INDEX_STATUS" == present'
mutations = [
    ('no-api-check', '.github/workflows/release.yml', PATTERN,
     '"$PL_CRATES_INDEX_STATUS" == present', 'test_release_confirmation.py',
     'test_index_visible_while_api_unavailable_is_not_confirmation'),
    ('no-index-check', '.github/workflows/release.yml', PATTERN,
     '"$PL_CRATES_API_STATUS" == present', 'test_release_confirmation.py',
     'test_api_only_redirect_index_failure_or_yank_never_confirm'),
    ('accept-index-nan', 'scripts/lib/crates-io.sh',
     'json.loads(line, object_pairs_hook=unique_pairs, parse_constant=reject_constant)',
     'json.loads(line, object_pairs_hook=unique_pairs)', 'test_registry_probe.py',
     'test_non_json_constants_cannot_prove_presence_or_absence'),
    ('accept-api-nan', 'scripts/lib/crates-io.sh',
     'json.load(f, object_pairs_hook=unique_pairs, parse_constant=reject_constant)',
     'json.load(f, object_pairs_hook=unique_pairs)', 'test_release_confirmation.py',
     'test_api_only_redirect_index_failure_or_yank_never_confirm'),
]

rows = []
with tempfile.TemporaryDirectory(prefix='pl-confirm-mutations-', dir='/workspace/work') as d:
    for name, path, old, new, pattern, selected in mutations:
        root = Path(d)/name
        shutil.copytree(ROOT, root)
        file = root/path
        text = file.read_text()
        if text.count(old) != 1:
            raise ValueError('mutation target changed: '+name)
        file.write_text(text.replace(old, new, 1))
        proc = subprocess.run(['python3','-B','-m','unittest','discover','-s','tests/release',
                               '-p',pattern,'-k',selected], cwd=root,
                              text=True,capture_output=True,timeout=60)
        rows.append({'name':name,'expected':'failure','exit':proc.returncode,
                     'stdout':proc.stdout,'stderr':proc.stderr})
RECEIPT.write_text(json.dumps({'scope':'Offline negative mutations, not a release.',
                               'mutations':rows},indent=2)+'\n')
print(json.dumps({'failed_as_expected':[r['name'] for r in rows if r['exit'] != 0],
                  'unexpected_passes':[r['name'] for r in rows if r['exit'] == 0]},indent=2))
raise SystemExit(0 if all(r['exit'] != 0 for r in rows) else 1)
