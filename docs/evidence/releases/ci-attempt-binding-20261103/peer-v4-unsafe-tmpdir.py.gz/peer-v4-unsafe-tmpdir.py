#!/usr/bin/env python3
"""Demonstrate the v4 gate's EXIT cleanup bug using only fake git/gh."""
import importlib.util
from pathlib import Path
import tempfile

root = Path(__file__).resolve().parent
source = root / 'candidate-v4/tests/release/test_live_ci_evidence.py'
spec = importlib.util.spec_from_file_location('release_fake', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
with tempfile.TemporaryDirectory(prefix='tmpdir-space-proof-', dir=root) as outer:
    root_dir = Path(outer)
    sentinel = root_dir / 'sentinel'
    sentinel.write_text('temporary sentinel')
    tmpdir = root_dir / 'sentinel other'
    tmpdir.mkdir()
    result, calls = module.LiveCIEvidence().run_case(module.fixture(), {'TMPDIR': str(tmpdir)})
    print('gate_exit:', result.returncode)
    print('reported_success:', '[outcome=success]' in result.stdout)
    print('unrelated_sentinel_survived:', sentinel.exists())
    print('fake_cli_call_count:', len(calls))
    if result.returncode != 0 or sentinel.exists():
        raise SystemExit('did not reproduce v4 behavior')
