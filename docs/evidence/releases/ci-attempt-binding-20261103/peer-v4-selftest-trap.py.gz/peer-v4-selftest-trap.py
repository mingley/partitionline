#!/usr/bin/env python3
"""Demonstrate the v4 self-test's interpolated trap in an isolated copy."""
from pathlib import Path
import os
import subprocess
import tempfile

root = Path(__file__).resolve().parent
candidate = root / 'candidate-v4'
sentinel = candidate / 'INJECTED'
if sentinel.exists():
    raise SystemExit('refusing to overwrite a pre-existing sentinel')
with tempfile.TemporaryDirectory(prefix='tmpdir-quote-proof-', dir=root) as outer:
    tmpdir = Path(outer) / "before';touch${IFS}INJECTED;#"
    tmpdir.mkdir()
    env = os.environ.copy()
    env.update(TMPDIR=str(tmpdir), PATH='/usr/bin:/bin', PYTHONDONTWRITEBYTECODE='1')
    try:
        result = subprocess.run(['bash', 'scripts/check-main-ci.sh', '--self-test'],
                                cwd=candidate, env=env, capture_output=True, text=True, timeout=30)
        ran = sentinel.exists()
        print('self_test_exit:', result.returncode)
        print('unintended_command_ran:', ran)
        if result.returncode != 0 or not ran:
            raise SystemExit('did not reproduce v4 behavior')
    finally:
        sentinel.unlink(missing_ok=True)
