#!/usr/bin/env python3
"""Replay fake-service cleanup and self-test safety controls on a candidate."""
import importlib.util
from pathlib import Path
import os, subprocess, sys, tempfile

root=Path(__file__).resolve().parent
candidate=Path(sys.argv[1]).resolve()
source=candidate/'tests/release/test_live_ci_evidence.py'
spec=importlib.util.spec_from_file_location('release_fake',source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
with tempfile.TemporaryDirectory(prefix='cleanup-replay-',dir=root) as outer:
 work=Path(outer); sentinel=work/'sentinel';sentinel.write_text('protect');tmpdir=work/'sentinel other';tmpdir.mkdir()
 result,_=module.LiveCIEvidence().run_case(module.fixture(),{'TMPDIR':str(tmpdir)})
 assert result.returncode==0 and '[outcome=success]' in result.stdout and sentinel.read_text()=='protect',(result.stdout,result.stderr)
 assert not list(tmpdir.iterdir()),'live success leaked temporary files'
 print('PASS successful live gate preserves unrelated sentinel with spaced TMPDIR and leaves no temporary files',flush=True)
 data=module.fixture();data['runs'][0]['status']='in_progress';data['runs'][0]['conclusion']=None
 result,_=module.LiveCIEvidence().run_case(data,{'TMPDIR':str(tmpdir)})
 assert result.returncode!=0 and not list(tmpdir.iterdir()),(result.stdout,result.stderr,list(tmpdir.iterdir()))
 print('PASS early run-selection failure removes both temporary files',flush=True)
 env=os.environ.copy();env.update(TMPDIR=str(tmpdir),PATH='/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1')
 result=subprocess.run(['bash','scripts/check-main-ci.sh','--self-test'],cwd=candidate,env=env,capture_output=True,text=True,timeout=30)
 assert result.returncode==0 and 'self-test: OK' in result.stdout,(result.stdout,result.stderr)
 assert not list(tmpdir.iterdir()),'self-test leaked temporary files with spaced TMPDIR'
 print('PASS self-test with spaced TMPDIR',flush=True)
 marker=candidate/'INJECTED';assert not marker.exists();shell_tmp=work/"before';touch${IFS}INJECTED;#";shell_tmp.mkdir();env['TMPDIR']=str(shell_tmp)
 try:
  result=subprocess.run(['bash','scripts/check-main-ci.sh','--self-test'],cwd=candidate,env=env,capture_output=True,text=True,timeout=30)
  assert result.returncode==0 and 'self-test: OK' in result.stdout and not marker.exists(),(result.stdout,result.stderr)
  assert not list(shell_tmp.iterdir()),'self-test leaked temporary files with metacharacter TMPDIR'
  print('PASS self-test treats shell metacharacters in TMPDIR as data',flush=True)
 finally:marker.unlink(missing_ok=True)
