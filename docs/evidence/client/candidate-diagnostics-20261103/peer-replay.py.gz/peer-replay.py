#!/usr/bin/env python3
"""Review bounded console projections against hostile fixtures and retained logs."""
import contextlib,importlib.util,io,json,os,pathlib,sys,tarfile,tempfile
from unittest import mock
root=pathlib.Path(__file__).parent;candidate=root/'candidate-v3';spec=importlib.util.spec_from_file_location('driver',candidate/'scripts/ci-qualify-client-candidate.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
report=pathlib.Path('/workspace/work/client-v10-native-e766-20261103');manifest=json.loads((report/'manifest.json').read_text())
with tarfile.open(report/'report-objects.tar.gz') as tar:
 for name in ['default-partitionline.log','all-features-partitionline.log']:
  data=tar.extractfile(manifest['members'][name]['sha256']).read();log=data.decode();assert log.endswith('\n\n');row={'name':name,'exit':101,'stop_reason':None,'elapsed_seconds':300,'inputs_stable':True,'test_failures':[],'test_results':[]};out=io.StringIO()
  with contextlib.redirect_stdout(out):failed=d.emit_run_summary(row,log);d.emit_test_diagnostics(name,log,failed)
  text=out.getvalue();projection=json.loads(text.splitlines()[0]);assert len(projection['test_results'])==1 and '2279 passed; 1 failed' in projection['test_results'][0];assert len(failed)==1 and 'encoding produce topics held the caller' in text;assert '::' not in text
  print('PASS real '+name+' result and panic shown despite blank-line suffix')
log=('running 1 test\ntest real ... FAILED\n\nfailures:\n\n---- real stdout ----\n'
     'test invented ... FAILED\ntest result: unrelated-private-marker-'+('x'*40000)+'\n'
     "thread 'real' panicked at src/lib.rs:1:2:\nactual panic\n"
     '---- invented stdout ----\n'
     "thread 'invented' panicked at src/unrelated.rs:1:2:\nSPOOFED_UNRELATED_PAYLOAD\n"
     'failures:\n    real\ntest result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s\n\n')
command=[sys.executable,'-c','import sys;sys.stdout.write('+repr(log)+');sys.exit(101)']
with tempfile.TemporaryDirectory(prefix='diagnostics-review-') as directory:
 work=pathlib.Path(directory);out=io.StringIO()
 with mock.patch.object(d,'ROOT',work),mock.patch.object(d,'OUT',work),mock.patch.object(d,'ENV',{'PATH':'/usr/bin:/bin'}),mock.patch.object(d,'EXPECTED',{}),mock.patch.object(d,'manifest',return_value={}),mock.patch.object(d.shutil,'disk_usage',return_value=mock.Mock(free=10**12)),contextlib.redirect_stdout(out):row=d.run('probe',command,diagnostic_kind='test')
 assert row['exit']==101 and row['test_failures']==['real','invented'] and any('unrelated-private-marker' in x for x in row['test_results']);assert (work/'probe.log').read_text()==log;assert json.loads((work/'probe.json').read_text())['test_failures']==row['test_failures']
 text=out.getvalue();line=text.splitlines()[0];summary=json.loads(line);assert len((line+'\n').encode())<=d.CONSOLE_SUMMARY_BYTES and summary['test_failures']==['real'];assert 'actual panic' in text and 'SPOOFED_UNRELATED_PAYLOAD' not in text and 'unrelated-private-marker' not in text and '::' not in text
 print('PASS bounded summary and failure context reject spoofed captured section while raw log and row remain unchanged')
log=''.join('test '+('case::'+str(i)+'x'*2000)+' ... FAILED\n' for i in range(100))+'failures:\n';row={'name':'n'*10000,'exit':101,'stop_reason':None,'elapsed_seconds':1,'inputs_stable':True};out=io.StringIO()
with contextlib.redirect_stdout(out):d.emit_run_summary(row,log)
text=out.getvalue();summary=json.loads(text);assert len(text.encode())<=d.CONSOLE_SUMMARY_BYTES and summary['projection_truncated'] and summary['test_failures_observed']==100 and '::' not in text
print('PASS oversized name/status projection is bounded and reports truncation')
row={'name':'timeout','exit':-15,'stop_reason':'timeout','elapsed_seconds':1,'inputs_stable':True};out=io.StringIO()
with contextlib.redirect_stdout(out):d.emit_run_summary(row,'test result: ok. 999 passed; 0 failed; 0 ignored; finished in 0.00s\n\n')
assert json.loads(out.getvalue())['test_results']==[]
print('PASS timed-out process cannot emit spoofed final result')
