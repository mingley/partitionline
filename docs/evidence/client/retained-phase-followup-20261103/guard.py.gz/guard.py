#!/usr/bin/env python3
"""Run the release suite with network syscalls blocked and real tools guarded."""
import ctypes
import ctypes.util
import errno
import os
from pathlib import Path
import socket
import sys

work=Path('/workspace/work/retained-backing-phase-projection-20261103')
guard=work/'guard-bin'
guard.mkdir(exist_ok=True)
for name in ('cargo','rustc','rustup','curl','wget','gh'):
    path=guard/name
    path.write_text('#!/bin/sh\nprintf "%s\\n" "$0" >> "$PL_FORBIDDEN_LOG"\nexit 91\n')
    path.chmod(0o755)
lib=ctypes.CDLL(ctypes.util.find_library('seccomp'),use_errno=True)
lib.seccomp_init.argtypes=[ctypes.c_uint32]
lib.seccomp_init.restype=ctypes.c_void_p
lib.seccomp_syscall_resolve_name.argtypes=[ctypes.c_char_p]
lib.seccomp_syscall_resolve_name.restype=ctypes.c_int
lib.seccomp_rule_add.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int,ctypes.c_uint]
lib.seccomp_rule_add.restype=ctypes.c_int
lib.seccomp_load.argtypes=[ctypes.c_void_p]
lib.seccomp_load.restype=ctypes.c_int
lib.seccomp_release.argtypes=[ctypes.c_void_p]
ctx=lib.seccomp_init(0x7fff0000)
if not ctx: raise SystemExit('seccomp_init failed')
for name in ('socket','connect','sendto','sendmsg','sendmmsg'):
    number=lib.seccomp_syscall_resolve_name(name.encode())
    if number < 0 or lib.seccomp_rule_add(ctx,0x00050000|errno.EPERM,number,0) != 0:
        raise SystemExit('seccomp rule failed: '+name)
if lib.seccomp_load(ctx) != 0: raise SystemExit('seccomp_load failed')
lib.seccomp_release(ctx)
try:
    socket.socket()
except PermissionError:
    print('network socket guard: active',flush=True)
else:
    raise SystemExit('network socket guard failed')
env={'PATH':str(guard)+':/usr/bin:/bin','LANG':'C.UTF-8',
     'PYTHONDONTWRITEBYTECODE':'1','PL_FORBIDDEN_LOG':str(work/'v1-guarded-forbidden.log')}
os.execve(sys.executable,[sys.executable,'-B','-m','unittest','discover',
                          '-s','tests/ci','-p','test_client_candidate_qualification.py','-v'],env)
