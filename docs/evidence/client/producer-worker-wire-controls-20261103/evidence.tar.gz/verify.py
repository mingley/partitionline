#!/usr/bin/env python3
"""Check v16 source pins, test-only boundaries and patch roundtrip; no Rust execution."""
from pathlib import Path
import hashlib
import json
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/partitionline')
FIXED = ROOT / 'docs/evidence/client/candidate-20261030/v16/fixed-inputs.json'
SOURCES = {
    'src/producer.rs': Path('/workspace/work/client-v14-deadline-fixture-20261103/after/src/producer.rs'),
    'src/net.rs': Path('/workspace/work/client-v10-wire-v3-thin-20261103/fixed/src/net.rs'),
    'src/producer/prepare.rs': Path('/workspace/work/client-v10-wire-v3-thin-20261103/fixed/src/producer/prepare.rs'),
    'src/producer/prepare_tests.rs': Path('/workspace/work/producer-pending-perf-20261103/v2/src/producer/prepare_tests.rs'),
    'src/protocol/api.rs': ROOT / 'src/protocol/api.rs',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    pins = json.loads((HERE / 'pins.json').read_text())
    assert sha(FIXED.read_bytes()) == pins['fixed_catalog_sha256']
    catalog = json.loads(FIXED.read_text())
    for name, path in SOURCES.items():
        assert sha(path.read_bytes()) == catalog[name] == pins['source_sha256'][name], name
    assert sha((HERE / 'wire-controls.patch').read_bytes()) == pins['patch_sha256']
    old_net = (HERE / 'before/src/net.rs').read_text()
    new_net = (HERE / 'after/src/net.rs').read_text()
    assert old_net == SOURCES['src/net.rs'].read_text()
    strip = new_net
    pieces = [
        '#[cfg(test)]\npub(crate) mod test_gated_tcp;\n',
        '    #[cfg(test)]\n    GatedTcp(test_gated_tcp::GatedTcp),\n',
    ]
    for method in ('poll_read(cx, buf)', 'poll_write(cx, buf)', 'poll_flush(cx)', 'poll_shutdown(cx)'):
        pieces.append('            #[cfg(test)]\n            ConnIo::GatedTcp(s) => Pin::new(s).' + method + ',\n')
    start = strip.index('    /// Pause writes to this real TCP stream after `limit` accepted bytes.\n')
    end = strip.index('    /// Kafka `client.id` on this connection.\n', start)
    strip = strip[:start] + strip[end:]
    for piece in pieces:
        assert strip.count(piece) == 1, piece
        strip = strip.replace(piece, '', 1)
    assert strip == old_net, 'non-test network source changed'
    old_tests = SOURCES['src/producer/prepare_tests.rs'].read_bytes()
    new_tests = (HERE / 'after/src/producer/prepare_tests.rs').read_bytes()
    assert new_tests.startswith(old_tests), 'existing test bytes changed'
    added = new_tests[len(old_tests):].decode()
    assert added.count('#[tokio::test(flavor = "current_thread")]') == 2
    for name in ('actual_worker_cancelled_after_real_tcp_prefix_keeps_its_preparing_record',
                 'actual_worker_full_write_tracks_response_outside_connection_counter'):
        assert name in added
    for marker in ('negotiate_api_versions', 'test_gate_tcp_writes(8)', 'gate.reached()',
                   'poll_preparation(fire.as_mut()).await.is_pending()', 'drop(fire)',
                   'worker.in_flight.front().unwrap().correlation', 'worker.wait_one()'):
        assert marker in added, marker
    gate = (HERE / 'after/src/net/test_gated_tcp.rs').read_text()
    for marker in ('TcpStream', 'buf.get(..offered)', 'poll_write(cx, chunk)', 'state.written += *n',
                   'state.writer = Some(cx.waker().clone())', 'writer.wake()'):
        assert marker in gate, marker
    with tempfile.TemporaryDirectory(prefix='worker-wire-controls-', dir=HERE) as temp:
        root = Path(temp)
        for name in ('src/net.rs', 'src/producer/prepare_tests.rs'):
            target = root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((HERE / 'before' / name).read_bytes())
        patch = HERE / 'wire-controls.patch'
        for flags in (['--check'], [], ['--reverse', '--check'], ['--reverse']):
            subprocess.run(['git', 'apply', *flags, str(patch)], cwd=root, check=True, capture_output=True)
            if not flags:
                for name, expected in pins['after_sha256'].items():
                    assert sha((root / name).read_bytes()) == expected, name
        assert (root / 'src/net.rs').read_bytes() == (HERE / 'before/src/net.rs').read_bytes()
        assert (root / 'src/producer/prepare_tests.rs').read_bytes() == old_tests
        assert not (root / 'src/net/test_gated_tcp.rs').exists()
    print(json.dumps({'source_pins': 'pass', 'original_test_prefix': 'pass',
                      'non_test_network_bytes': 'unchanged', 'patch_roundtrip': 'pass',
                      'runtime': 'not compiled or run; no behavior or performance result'}, indent=2))


if __name__ == '__main__':
    main()
