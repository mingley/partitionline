//! Produce one record against the mock broker.

mod common;

use partitionline::error::{NOT_COORDINATOR, NOT_LEADER_OR_FOLLOWER, UNKNOWN_PRODUCER_ID};
use partitionline::protocol::api_keys::END_TXN;
use partitionline::protocol::api_keys::TXN_OFFSET_COMMIT;
use partitionline::{
    Admin, AdminConfig, Error, NewTopic, ProduceRecord, Producer, ProducerConfig, TopicPartition,
};
use std::time::{Duration, Instant};

/// The first produce to the bootstrap broker does not repeat ApiVersions.
#[tokio::test]
async fn produce_reuses_bootstrap_api_versions() {
    let mock = common::Mock::start().await;
    mock.set_topic_partitions("t", 1);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    let producer = Producer::new(cfg).await.unwrap();
    mock.set_api_versions_delay(Duration::from_millis(250));
    let versions_before = mock.api_versions_versions().len();
    let started = Instant::now();
    let _sent = producer
        .send(ProduceRecord::to("t").value(&b"v"[..]))
        .await
        .unwrap();
    let elapsed = started.elapsed();
    assert_eq!(
        mock.api_versions_versions().len(),
        versions_before,
        "the produce socket should reuse the bootstrap broker's versions"
    );
    assert!(
        elapsed < Duration::from_millis(200),
        "the first produce repeated ApiVersions: {elapsed:?}"
    );
    producer.close().await.unwrap();
}

/// An idle produce leader reconnects without ApiVersions.
#[tokio::test]
async fn idle_produce_leader_reuses_learned_api_versions() {
    let mock = common::Mock::start_two_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_partition_leader("t", 0, 2);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.connections_max_idle = Duration::from_millis(40);
    let producer = Producer::new(cfg).await.unwrap();
    let _first = producer
        .send(ProduceRecord::to("t").value(&b"a"[..]))
        .await
        .unwrap();
    tokio::time::sleep(Duration::from_millis(60)).await;
    let versions_before = mock.api_versions_versions().len();
    let accepts_before = mock.accepts();
    mock.set_api_versions_delay(Duration::from_millis(250));
    let started = Instant::now();
    let _second = producer
        .send(ProduceRecord::to("t").value(&b"b"[..]))
        .await
        .unwrap();
    let elapsed = started.elapsed();
    assert_eq!(
        mock.api_versions_versions().len(),
        versions_before,
        "an idle produce leader should reuse the versions already learned"
    );
    assert!(
        mock.accepts() > accepts_before,
        "idle expiry replaces the produce socket"
    );
    assert!(
        elapsed < Duration::from_millis(200),
        "idle produce repeated ApiVersions: {elapsed:?}"
    );
    producer.close().await.unwrap();
}

/// An idle metadata socket reconnects without ApiVersions.
#[tokio::test]
async fn idle_metadata_reuses_learned_api_versions() {
    let mock = common::Mock::start().await;
    mock.set_topic_partitions("t", 1);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.connections_max_idle = Duration::from_millis(40);
    let producer = Producer::new(cfg).await.unwrap();
    let first = producer.partitions_for("t").await.unwrap();
    assert_eq!(first.len(), 1);
    tokio::time::sleep(Duration::from_millis(60)).await;
    let versions_before = mock.api_versions_versions().len();
    let accepts_before = mock.accepts();
    mock.set_api_versions_delay(Duration::from_millis(250));
    let started = Instant::now();
    let second = producer.partitions_for("t").await.unwrap();
    let elapsed = started.elapsed();
    assert_eq!(second.len(), 1);
    assert_eq!(
        mock.api_versions_versions().len(),
        versions_before,
        "an idle metadata refresh should reuse the versions already learned"
    );
    assert_eq!(
        mock.accepts(),
        accepts_before + 1,
        "idle expiry replaces the metadata socket"
    );
    assert!(
        elapsed < Duration::from_millis(200),
        "idle metadata refresh repeated ApiVersions: {elapsed:?}"
    );
    producer.close().await.unwrap();
}

/// A known leader accepts records while an unknown topic is resolved.
#[tokio::test]
async fn send_all_produces_known_topics_while_loading_metadata() {
    let mock = common::Mock::start().await;
    mock.set_topic_partitions("t", 1);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    let producer = Producer::new(cfg).await.unwrap();
    let _warm = producer
        .send(ProduceRecord::to("t").value(&b"warm"[..]))
        .await
        .unwrap();
    mock.set_topic_partitions("u", 1);
    let delay = Duration::from_millis(250);
    mock.set_metadata_delay(delay);
    mock.set_produce_delay_times(delay, 1);
    let started = Instant::now();
    let sent = producer
        .send_all([
            ProduceRecord::to("u").value(&b"new"[..]),
            ProduceRecord::to("t").value(&b"known"[..]),
        ])
        .await
        .unwrap();
    let elapsed = started.elapsed();
    assert_eq!(sent.len(), 2);
    assert!(sent.iter().all(|meta| meta.offset >= 0));
    assert!(
        elapsed < Duration::from_millis(450),
        "known produce waited for the unknown topic: {elapsed:?}"
    );
    producer.close().await.unwrap();
}

#[tokio::test(flavor = "current_thread")]
async fn ack_completes_while_the_next_batch_lingers() {
    let mock = common::Mock::start().await;
    mock.set_produce_delay_times(Duration::from_millis(200), 1);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::from_millis(800);
    cfg.batch_records = 2;
    cfg.client_id = "linger-ack".into();
    let producer = Producer::new(cfg).await.unwrap();
    let first = ProduceRecord::to("t").value(&b"a"[..]);
    loop {
        match producer.try_send(first.clone()) {
            Ok(()) => break,
            Err(Error::QueueFull) => tokio::time::sleep(Duration::from_millis(5)).await,
            Err(error) => panic!("queue the first record: {error}"),
        }
    }
    producer
        .try_send(ProduceRecord::to("t").value(&b"b"[..]))
        .unwrap();
    producer
        .try_send(ProduceRecord::to("t").value(&b"c"[..]))
        .unwrap();
    let started = Instant::now();
    loop {
        if producer.metrics().records_acked >= 2 {
            break;
        }
        assert!(
            started.elapsed() < Duration::from_millis(500),
            "in-flight ack waited out linger: {:?}",
            started.elapsed()
        );
        tokio::time::sleep(Duration::from_millis(10)).await;
    }
    assert!(
        started.elapsed() < Duration::from_millis(500),
        "in-flight ack waited out linger: {:?}",
        started.elapsed()
    );
    producer.close().await.unwrap();
}

#[tokio::test(flavor = "current_thread")]
async fn producer_metadata_refreshes_waiting_topics_together() {
    let mock = common::Mock::start().await;
    mock.set_topic_partitions("t", 1);
    mock.set_topic_partitions("u", 1);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    let producer = Producer::new(cfg).await.unwrap();
    let before = mock.metadata_calls();
    mock.set_metadata_delay(Duration::from_millis(150));
    assert!(matches!(
        producer.try_send(ProduceRecord::to("t").value(&b"a"[..])),
        Err(Error::QueueFull)
    ));
    assert!(matches!(
        producer.try_send(ProduceRecord::to("u").value(&b"b"[..])),
        Err(Error::QueueFull)
    ));
    let started = Instant::now();
    loop {
        if mock.metadata_calls() > before {
            break;
        }
        assert!(
            started.elapsed() < Duration::from_secs(2),
            "metadata was not requested"
        );
        tokio::time::sleep(Duration::from_millis(10)).await;
    }
    assert_eq!(
        mock.metadata_calls(),
        before + 1,
        "topics already waiting should share one metadata request"
    );
    let mut names = mock.last_metadata_topics().unwrap().unwrap();
    names.sort();
    assert_eq!(names, ["t".to_string(), "u".to_string()]);
    producer.close().await.unwrap();
}

#[tokio::test(flavor = "current_thread")]
async fn send_all_refreshes_topics_together() {
    let mock = common::Mock::start().await;
    mock.set_topic_partitions("t", 1);
    mock.set_topic_partitions("u", 1);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    let producer = Producer::new(cfg).await.unwrap();
    let before = mock.metadata_calls();
    mock.set_metadata_delay(Duration::from_millis(200));
    let started = Instant::now();
    let acks = producer
        .send_all([
            ProduceRecord::to("t").value(&b"a"[..]),
            ProduceRecord::to("u").value(&b"b"[..]),
        ])
        .await
        .unwrap();
    assert_eq!(acks.len(), 2);
    assert!(
        started.elapsed() < Duration::from_millis(450),
        "send_all waited for a metadata request per topic: {:?}",
        started.elapsed()
    );
    assert_eq!(
        mock.metadata_calls(),
        before + 1,
        "topics in one send_all should share one metadata request"
    );
    let mut names = mock.last_metadata_topics().unwrap().unwrap();
    names.sort();
    assert_eq!(names, ["t".to_string(), "u".to_string()]);
    producer.close().await.unwrap();
}

/// Records for two leaders start both handshakes before the first ack.
#[tokio::test(flavor = "current_thread")]
async fn send_all_dials_leaders_together() {
    let mock = common::Mock::start_three_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_topic_partitions("u", 1);
    mock.set_partition_leader("t", 0, 2);
    mock.set_partition_leader("u", 0, 3);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    let producer = Producer::new(cfg).await.unwrap();
    mock.set_api_versions_delay(Duration::from_millis(250));
    let started = Instant::now();
    let acks = producer
        .send_all([
            ProduceRecord::to("t").partition(0).value(&b"a"[..]),
            ProduceRecord::to("u").partition(0).value(&b"b"[..]),
        ])
        .await
        .unwrap();
    assert_eq!(acks.len(), 2);
    assert!(
        started.elapsed() < Duration::from_millis(450),
        "send_all waited for one leader handshake at a time: {:?}",
        started.elapsed()
    );
    let mut nodes = mock.produce_request_nodes();
    nodes.sort_unstable();
    nodes.dedup();
    assert_eq!(nodes, vec![2, 3]);
    producer.close().await.unwrap();
}

/// Stale topic metadata reloads while idle leaders redial.
#[tokio::test(flavor = "current_thread")]
async fn send_all_redials_leaders_while_refreshing_metadata() {
    let mock = common::Mock::start_three_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_topic_partitions("u", 1);
    mock.set_partition_leader("t", 0, 2);
    mock.set_partition_leader("u", 0, 3);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.metadata_max_age = Duration::from_millis(30);
    cfg.connections_max_idle = Duration::from_millis(40);
    let producer = Producer::new(cfg).await.unwrap();
    let _warm = producer
        .send_all([
            ProduceRecord::to("t").partition(0).value(&b"a"[..]),
            ProduceRecord::to("u").partition(0).value(&b"b"[..]),
        ])
        .await
        .unwrap();
    tokio::time::sleep(Duration::from_millis(60)).await;
    let delay = Duration::from_millis(250);
    mock.set_metadata_delay(delay);
    mock.set_api_versions_delay(delay);
    let started = Instant::now();
    let acks = producer
        .send_all([
            ProduceRecord::to("t").partition(0).value(&b"c"[..]),
            ProduceRecord::to("u").partition(0).value(&b"d"[..]),
        ])
        .await
        .unwrap();
    let elapsed = started.elapsed();
    assert_eq!(acks.len(), 2);
    assert!(
        elapsed < Duration::from_millis(450),
        "send_all refreshed metadata before redialing leaders: {elapsed:?}"
    );
    producer.close().await.unwrap();
}

#[tokio::test(flavor = "current_thread")]
async fn send_offsets_refreshes_topics_together() {
    let mock = common::Mock::start().await;
    mock.set_topic_partitions("t", 1);
    mock.set_topic_partitions("u", 1);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-offsets-meta".into());
    let producer = Producer::new(cfg).await.unwrap();
    producer.begin_transaction().await.unwrap();
    let before = mock.metadata_calls();
    mock.set_metadata_delay(Duration::from_millis(200));
    let started = Instant::now();
    producer
        .send_offsets_to_transaction(
            "g",
            [
                (TopicPartition::new("t", 0), 1),
                (TopicPartition::new("u", 0), 2),
            ],
        )
        .await
        .unwrap();
    assert!(
        started.elapsed() < Duration::from_millis(450),
        "offset metadata waited once per topic: {:?}",
        started.elapsed()
    );
    assert_eq!(
        mock.metadata_calls(),
        before + 1,
        "offset topics should share one metadata request"
    );
    let mut names = mock.last_metadata_topics().unwrap().unwrap();
    names.sort();
    assert_eq!(names, ["t".to_string(), "u".to_string()]);
    producer.abort_transaction().await.unwrap();
    producer.close().await.unwrap();
}

#[tokio::test(flavor = "current_thread")]
async fn send_offsets_loads_metadata_while_adding_offsets() {
    let mock = common::Mock::start().await;
    mock.set_api_max(TXN_OFFSET_COMMIT, 4);
    mock.set_topic_partitions("t", 1);
    mock.set_topic_partitions("u", 1);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-offsets-overlap".into());
    let producer = Producer::new(cfg).await.unwrap();
    producer.begin_transaction().await.unwrap();
    let delay = Duration::from_millis(250);
    mock.set_add_offsets_delay(delay);
    mock.set_metadata_delay(delay);
    let before = mock.metadata_calls();
    let started = Instant::now();
    producer
        .send_offsets_to_transaction(
            "g",
            [
                (TopicPartition::new("t", 0), 1),
                (TopicPartition::new("u", 0), 2),
            ],
        )
        .await
        .unwrap();
    let elapsed = started.elapsed();
    assert!(
        mock.metadata_calls() > before,
        "offset topics should load metadata"
    );
    assert!(
        mock.last_add_offsets_to_txn_version().is_some(),
        "classic TxnOffsetCommit must send AddOffsetsToTxn"
    );
    assert!(
        elapsed < Duration::from_millis(450),
        "AddOffsetsToTxn waited for topic metadata: {elapsed:?}"
    );
    producer.abort_transaction().await.unwrap();
    producer.close().await.unwrap();
}

#[tokio::test]
async fn multi_broker_produce_dials_overlap() {
    let mock = common::Mock::start_two_node().await;
    mock.set_topic_partitions("t", 2);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    let producer = Producer::new(cfg).await.unwrap();
    let _parts = producer.partitions_for("t").await.unwrap();
    let before = mock.api_versions_versions().len();
    mock.set_api_versions_delay(Duration::from_millis(250));
    let left = producer.clone();
    let right = producer.clone();
    let started = Instant::now();
    let (a, b) = tokio::join!(
        left.send(ProduceRecord::to("t").partition(0).value(&b"a"[..])),
        right.send(ProduceRecord::to("t").partition(1).value(&b"b"[..])),
    );
    let elapsed = started.elapsed();
    let (a, b) = (a.unwrap(), b.unwrap());
    assert_eq!((a.partition, b.partition), (0, 1));
    assert!(
        mock.api_versions_versions().len() > before,
        "the non-bootstrap leader should negotiate"
    );
    assert!(
        elapsed < Duration::from_millis(400),
        "produce leader dials ran one after another: {elapsed:?}"
    );
    producer.close().await.unwrap();
}

#[tokio::test]
async fn produce_one_record_against_mock() {
    let mock = common::Mock::start().await;
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.client_id = "test".into();
    let producer = Producer::new(cfg).await.unwrap();
    let md = producer
        .send(ProduceRecord::to("t").value(&b"hello"[..]))
        .await
        .unwrap();
    assert_eq!(md.topic.as_ref(), "t");
    assert_eq!(md.partition, 0);
    assert_eq!(md.offset, 0);
    let md2 = producer
        .send(ProduceRecord::to("t").key(&b"k"[..]).value(&b"v"[..]))
        .await
        .unwrap();
    assert_eq!(md2.offset, 1);
    producer.close().await.unwrap();
}

/// KL09-14: header-heavy batches must respect the byte bound.
///
/// Each record carries a 16B value plus 10 headers x (5B key + 64B value),
/// ~800B on the wire, while the header-blind `estimate()` sees 16 + 64 =
/// 80B. With `batch_bytes = 2048` the old packing takes all 25 records
/// (~20KB encoded) into one batch; exact packing must split so every
/// observed batch fits the bound. The two callers put the 2048 bound in
/// `batch_bytes` vs `max_request_size` (`produce_batch_bytes` is the min).
async fn header_heavy_bound_case(
    batch_bytes: usize,
    max_request_size: usize,
    bound: i32,
) -> Result<(), String> {
    let mock = common::Mock::start().await;
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.batch_bytes = batch_bytes;
    cfg.max_request_size = max_request_size;
    cfg.batch_records = 100_000;
    cfg.linger = Duration::from_millis(100);
    cfg.client_id = "kl09-14".into();
    let producer = Producer::new(cfg).await.map_err(|e| e.to_string())?;
    // One awaited send spawns the node worker; the try_send burst below
    // finds it immediately instead of racing worker startup (QueueFull).
    let warmup = producer
        .send(ProduceRecord::to("t").value(&b"warmup"[..]))
        .await
        .map_err(|e| e.to_string())?;
    assert_eq!(warmup.offset, 0);
    for i in 0..25u8 {
        let mut rec = ProduceRecord::to("t").value(vec![i; 16]);
        for h in 0..10 {
            rec = rec.header(format!("hk-{h}"), vec![i; 64]);
        }
        producer.try_send(rec).map_err(|e| e.to_string())?;
    }
    producer.close().await.map_err(|e| e.to_string())?;
    let batches = mock.produce_batches();
    assert!(!batches.is_empty(), "no produce batches observed");
    let total: i32 = batches.iter().map(|b| b.2).sum();
    assert_eq!(total, 26, "warmup + burst must be delivered");
    for (topic, partition, nrec, bytes) in &batches {
        assert_eq!(topic, "t");
        assert_eq!(*partition, 0);
        assert!(
            *bytes <= bound,
            "batch of {nrec} records is {bytes}B > bound {bound}"
        );
    }
    Ok(())
}

#[tokio::test]
async fn header_heavy_batches_respect_batch_bytes() {
    header_heavy_bound_case(2048, 1_000_000, 2048)
        .await
        .unwrap();
}

#[tokio::test]
async fn header_heavy_batches_respect_max_request_size() {
    header_heavy_bound_case(1_000_000, 2048, 2048)
        .await
        .unwrap();
}

/// KL09-14: keyed records with empty values and headers respect the bound.
#[tokio::test]
async fn keyed_empty_value_batches_respect_bound() {
    let mock = common::Mock::start().await;
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.batch_bytes = 1024;
    cfg.batch_records = 100_000;
    cfg.linger = Duration::from_millis(100);
    cfg.client_id = "kl09-14".into();
    let producer = Producer::new(cfg).await.unwrap();
    // One awaited send spawns the node worker; the try_send burst below
    // finds it immediately instead of racing worker startup (QueueFull).
    let warmup = producer
        .send(ProduceRecord::to("t").value(&b"warmup"[..]))
        .await
        .unwrap();
    assert_eq!(warmup.offset, 0);
    for i in 0..20u8 {
        let rec = ProduceRecord::to("t")
            .key(vec![i; 64])
            .value(Vec::new())
            .header("hk".to_string(), vec![i; 128])
            .null_header("hn".to_string());
        producer.try_send(rec).unwrap();
    }
    producer.close().await.unwrap();
    let batches = mock.produce_batches();
    let total: i32 = batches.iter().map(|b| b.2).sum();
    assert_eq!(total, 21, "warmup + burst must be delivered");
    for (_, _, nrec, bytes) in &batches {
        assert!(*bytes <= 1024, "batch of {nrec} records is {bytes}B > 1024");
    }
}

/// KL09-14: a single record over `batch_bytes` (but under
/// `max_request_size`) still sends alone — batches cannot split a record
/// (Java `RecordAccumulator` parity; only multi-record packing is bounded).
#[tokio::test]
async fn oversized_single_record_still_sends() {
    let mock = common::Mock::start().await;
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.batch_bytes = 512;
    cfg.batch_records = 100_000;
    cfg.linger = Duration::from_millis(100);
    cfg.client_id = "kl09-14".into();
    let producer = Producer::new(cfg).await.unwrap();
    // One awaited send spawns the node worker (see above).
    let warmup = producer
        .send(ProduceRecord::to("t").value(&b"warmup"[..]))
        .await
        .unwrap();
    assert_eq!(warmup.offset, 0);
    let rec = ProduceRecord::to("t")
        .value(vec![7u8; 16])
        .header("big".to_string(), vec![7u8; 700]);
    producer.try_send(rec).unwrap();
    producer.close().await.unwrap();
    let batches = mock.produce_batches();
    assert_eq!(batches.len(), 2, "warmup + singleton expected");
    let big: Vec<_> = batches.iter().filter(|b| b.2 == 1 && b.3 > 512).collect();
    assert_eq!(
        big.len(),
        1,
        "singleton documents the unsplittable exception: {batches:?}"
    );
}

/// KL09-28: a retried batch refreshes metadata once, not once per record.
///
/// One 10-record batch fails with retriable NOT_LEADER and retries to
/// success. Metadata RPCs after the warmup baseline must be exactly 1
/// (the batch's shared refresh), and all 10 records must be delivered
/// exactly once (offsets 1..=10 after the warmup).
#[tokio::test]
async fn retry_refreshes_metadata_once_per_batch() {
    use partitionline::error::NOT_LEADER_OR_FOLLOWER;

    let mock = common::Mock::start().await;
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.batch_records = 100_000;
    cfg.linger = Duration::from_millis(100);
    cfg.retry_backoff = Duration::from_millis(1);
    cfg.retry_backoff_max = Duration::from_millis(1);
    cfg.client_id = "kl09-28".into();
    let producer = Producer::new(cfg).await.unwrap();
    // One awaited send warms metadata and the node worker.
    let warmup = producer
        .send(ProduceRecord::to("t").value(&b"warmup"[..]))
        .await
        .unwrap();
    assert_eq!(warmup.offset, 0);
    let base_meta = mock.metadata_calls();

    // The next produce fails once; the 10-record batch must retry.
    mock.set_produce_error_times(NOT_LEADER_OR_FOLLOWER, 1);
    for i in 0..10u8 {
        producer
            .try_send(ProduceRecord::to("t").value(vec![i; 16]))
            .unwrap();
    }
    producer.flush().await.unwrap();

    let batches = mock.produce_batches();
    let total: i32 = batches.iter().map(|b| b.2).sum();
    // Warmup + failed burst + retried burst observed on the wire.
    assert_eq!(total, 21, "failed batch must be retried, not dropped");
    // ...but appended exactly once (no duplicates from the retry).
    assert_eq!(mock.log_len("t", 0), 11);
    assert_eq!(
        mock.metadata_calls() - base_meta,
        1,
        "one metadata refresh per retried batch, not per record"
    );
    producer.close().await.unwrap();
}

#[tokio::test(flavor = "current_thread")]
async fn retry_refreshes_waiting_topics_together() {
    use partitionline::error::NOT_LEADER_OR_FOLLOWER;

    let mock = common::Mock::start().await;
    mock.set_topic_partitions("t", 1);
    mock.set_topic_partitions("u", 1);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.batch_records = 100_000;
    cfg.linger = Duration::from_millis(50);
    cfg.retry_backoff = Duration::from_millis(1);
    cfg.retry_backoff_max = Duration::from_millis(1);
    cfg.client_id = "retry-topics".into();
    let producer = Producer::new(cfg).await.unwrap();
    let _warm_t = producer
        .send(ProduceRecord::to("t").value(&b"warm-t"[..]))
        .await
        .unwrap();
    let _warm_u = producer
        .send(ProduceRecord::to("u").value(&b"warm-u"[..]))
        .await
        .unwrap();
    let base_meta = mock.metadata_calls();
    mock.set_produce_error_times(NOT_LEADER_OR_FOLLOWER, 1);
    producer
        .try_send(ProduceRecord::to("t").value(&b"again-t"[..]))
        .unwrap();
    producer
        .try_send(ProduceRecord::to("u").value(&b"again-u"[..]))
        .unwrap();
    producer.flush().await.unwrap();
    assert_eq!(
        mock.metadata_calls() - base_meta,
        1,
        "retried topics already waiting should share one metadata request"
    );
    let mut names = mock.last_metadata_topics().unwrap().unwrap();
    names.sort();
    assert_eq!(names, ["t".to_string(), "u".to_string()]);
    producer.close().await.unwrap();
}

/// After a retriable produce error, the new leaders are dialed together.
#[tokio::test(flavor = "current_thread")]
async fn retry_dials_moved_leaders_together() {
    use partitionline::error::NOT_LEADER_OR_FOLLOWER;

    let mock = common::Mock::start_three_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_topic_partitions("u", 1);
    mock.set_partition_leader("t", 0, 1);
    mock.set_partition_leader("u", 0, 1);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::from_millis(40);
    cfg.batch_records = 100_000;
    cfg.retry_backoff = Duration::from_millis(1);
    cfg.retry_backoff_max = Duration::from_millis(1);
    let producer = Producer::new(cfg).await.unwrap();
    let _warm = producer
        .send_all([
            ProduceRecord::to("t").partition(0).value(&b"warm-t"[..]),
            ProduceRecord::to("u").partition(0).value(&b"warm-u"[..]),
        ])
        .await
        .unwrap();
    mock.set_partition_leader("t", 0, 2);
    mock.set_partition_leader("u", 0, 3);
    mock.set_produce_error_times(NOT_LEADER_OR_FOLLOWER, 1);
    mock.set_api_versions_delay(Duration::from_millis(250));
    let started = Instant::now();
    let acks = producer
        .send_all([
            ProduceRecord::to("t").partition(0).value(&b"a"[..]),
            ProduceRecord::to("u").partition(0).value(&b"b"[..]),
        ])
        .await
        .unwrap();
    assert_eq!(acks.len(), 2);
    assert!(
        started.elapsed() < Duration::from_millis(450),
        "retry waited for one moved leader handshake at a time: {:?}",
        started.elapsed()
    );
    let mut nodes = mock.produce_request_nodes();
    nodes.sort_unstable();
    nodes.dedup();
    assert!(
        nodes.contains(&2) && nodes.contains(&3),
        "retries should reach both new leaders, got {nodes:?}"
    );
    producer.close().await.unwrap();
}

/// KL09-17: the route-cached tracker must produce metrics snapshots
/// identical to the old per-record-lookup path: exact global counters,
/// one sorted per-topic row per active topic with exact counts/bytes,
/// and per-topic ack-latency counts matching acked records. Exercises
/// both the fast path (`try_send`) and the slow path (`send_all`).
#[tokio::test]
async fn tracker_cache_mixed_topic_metrics_snapshot() {
    let mock = common::Mock::start().await;
    // The mock only knows "t"; create the three mixed-topic names first.
    let mut admin = Admin::new(AdminConfig::bootstrap([mock.addr.clone()]))
        .await
        .unwrap();
    let results = admin
        .create_topics(
            &[
                NewTopic::new("mta", 1, 1),
                NewTopic::new("mtb", 1, 1),
                NewTopic::new("mtc", 1, 1),
            ],
            10_000,
            false,
        )
        .await
        .unwrap();
    assert!(
        results.iter().all(|r| r.error_code == 0),
        "create_topics: {results:?}"
    );
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.client_id = "kl09-17".into();
    let producer = Producer::new(cfg).await.unwrap();
    // Warmup spawns the node worker so the try_send burst below never
    // races worker startup (QueueFull).
    let warmup = producer
        .send(ProduceRecord::to("mta").value(&b"warmup"[..]))
        .await
        .unwrap();
    assert_eq!(warmup.offset, 0);
    // Fast path (try_send) across three topics, round-robin: 60 records.
    let topics = ["mta", "mtb", "mtc"];
    for i in 0..60u8 {
        let topic = topics[usize::from(i % 3)];
        let rec = ProduceRecord::to(topic).key(vec![i; 8]).value(vec![i; 32]);
        producer.try_send(rec).unwrap();
    }
    // Slow path (send_all) across the same topics: 9 records.
    let mut batch = Vec::new();
    for i in 0..9u8 {
        let topic = topics[usize::from(i % 3)];
        batch.push(ProduceRecord::to(topic).key(vec![i; 4]).value(vec![i; 16]));
    }
    let acks = producer.send_all(batch).await.unwrap();
    assert_eq!(acks.len(), 9);
    producer.flush().await.unwrap();
    let m = producer.metrics();
    // Global counters: 1 warmup + 60 fast + 9 slow.
    assert_eq!(m.records_queued, 70);
    assert_eq!(m.records_acked, 70);
    assert_eq!(m.produce_errors, 0);
    // Bytes are key + value only: warmup 6, fast 60 * 40, slow 9 * 20.
    assert_eq!(m.bytes_queued, 6 + 2400 + 180);
    assert_eq!(m.bytes_buffered, 0);
    assert_eq!(m.ack_latency.count, 70);
    // Per-topic rows: sorted, exactly one row per active topic.
    // mta: warmup + 20 fast + 3 slow = 24; mtb/mtc: 20 fast + 3 slow = 23.
    assert_eq!(m.topics.len(), 3);
    let names: Vec<&str> = m.topics.iter().map(|t| t.topic.as_str()).collect();
    assert_eq!(names, ["mta", "mtb", "mtc"]);
    let expected = [
        ("mta", 24u64, 6 + 800 + 60),
        ("mtb", 23u64, 860),
        ("mtc", 23u64, 860),
    ];
    let mut sum_queued = 0u64;
    for (row, (topic, n, bytes)) in m.topics.iter().zip(expected.iter()) {
        assert_eq!(row.topic, *topic);
        assert_eq!(row.records_queued, *n, "queued for {topic}");
        assert_eq!(row.records_acked, *n, "acked for {topic}");
        assert_eq!(row.produce_errors, 0, "errors for {topic}");
        assert_eq!(row.bytes_queued, *bytes, "bytes for {topic}");
        assert_eq!(row.ack_latency.count, *n, "latency count for {topic}");
        sum_queued += row.records_queued;
    }
    assert_eq!(sum_queued, m.records_queued);
    producer.close().await.unwrap();
}

/// A not-leader retry reloads metadata while the previous leader reconnects.
#[tokio::test]
async fn list_offsets_redials_while_refreshing_after_not_leader() {
    let mock = common::Mock::start_two_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_partition_leader("t", 0, 2);
    let mut cfg = AdminConfig::bootstrap([mock.addr.clone()]);
    cfg.retry_backoff = Duration::from_millis(1);
    cfg.retry_backoff_max = Duration::from_millis(1);
    let mut admin = Admin::new(cfg).await.unwrap();
    let _warm = admin
        .list_offsets([(TopicPartition::new("t", 0), -2i64)])
        .await
        .unwrap();
    mock.fail_list_offsets_once(NOT_LEADER_OR_FOLLOWER);
    let delay = Duration::from_millis(250);
    mock.set_metadata_delay(delay);
    mock.set_api_versions_delay(delay);
    let started = Instant::now();
    let listed = admin
        .list_offsets([(TopicPartition::new("t", 0), -2i64)])
        .await
        .unwrap();
    let elapsed = started.elapsed();
    assert_eq!(listed.len(), 1);
    assert!(
        elapsed < Duration::from_millis(450),
        "list offsets refreshed metadata before redialing after not-leader: {elapsed:?}"
    );
}

/// Known leaders reconnect while metadata for an unknown topic loads.
#[tokio::test]
async fn list_offsets_dials_known_leaders_while_loading_metadata() {
    let mock = common::Mock::start_two_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_partition_leader("t", 0, 2);
    let mut cfg = AdminConfig::bootstrap([mock.addr.clone()]);
    cfg.connections_max_idle = Duration::from_millis(40);
    let mut admin = Admin::new(cfg).await.unwrap();
    let _warm = admin
        .list_offsets([(TopicPartition::new("t", 0), -2i64)])
        .await
        .unwrap();
    tokio::time::sleep(Duration::from_millis(60)).await;
    let _topics = admin.list_topics().await.unwrap();
    mock.set_topic_partitions("u", 1);
    mock.set_partition_leader("u", 0, 2);
    let delay = Duration::from_millis(250);
    mock.set_metadata_delay(delay);
    mock.set_api_versions_delay(delay);
    let started = Instant::now();
    let listed = admin
        .list_offsets([
            (TopicPartition::new("t", 0), -2i64),
            (TopicPartition::new("u", 0), -2i64),
        ])
        .await
        .unwrap();
    let elapsed = started.elapsed();
    assert_eq!(listed.len(), 2);
    assert!(
        elapsed < Duration::from_millis(450),
        "list offsets loaded metadata before redialing the known leader: {elapsed:?}"
    );
}

/// DeleteRecords redials a known leader while an unknown topic loads.
#[tokio::test]
async fn delete_records_dials_known_leaders_while_loading_metadata() {
    let mock = common::Mock::start_two_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_partition_leader("t", 0, 2);
    let mut cfg = AdminConfig::bootstrap([mock.addr.clone()]);
    cfg.connections_max_idle = Duration::from_millis(40);
    let mut admin = Admin::new(cfg).await.unwrap();
    let _warm = admin
        .delete_records_for([(TopicPartition::new("t", 0), 1i64)])
        .await
        .unwrap();
    tokio::time::sleep(Duration::from_millis(60)).await;
    let _topics = admin.list_topics().await.unwrap();
    mock.set_topic_partitions("u", 1);
    mock.set_partition_leader("u", 0, 2);
    let delay = Duration::from_millis(250);
    mock.set_metadata_delay(delay);
    mock.set_api_versions_delay(delay);
    let started = Instant::now();
    let deleted = admin
        .delete_records_for([
            (TopicPartition::new("t", 0), 1i64),
            (TopicPartition::new("u", 0), 1i64),
        ])
        .await
        .unwrap();
    let elapsed = started.elapsed();
    assert_eq!(deleted.len(), 2);
    assert!(
        elapsed < Duration::from_millis(450),
        "delete records loaded metadata before redialing the known leader: {elapsed:?}"
    );
}

/// A known group coordinator reconnects while another group is being found.
#[tokio::test]
async fn describe_groups_dials_known_coordinators_while_finding_new_ones() {
    let mock = common::Mock::start_two_node().await;
    mock.set_group_coordinator("ga", 2);
    mock.set_group_coordinator("gb", 2);
    let mut cfg = AdminConfig::bootstrap([mock.addr.clone()]);
    cfg.connections_max_idle = Duration::from_millis(40);
    let mut admin = Admin::new(cfg).await.unwrap();
    let _warm = admin.describe_groups(&["ga"], false).await.unwrap();
    tokio::time::sleep(Duration::from_millis(60)).await;
    let _topics = admin.list_topics().await.unwrap();
    let delay = Duration::from_millis(250);
    mock.set_find_coordinator_delay(delay);
    mock.set_api_versions_delay(delay);
    let started = Instant::now();
    let described = admin.describe_groups(&["ga", "gb"], false).await.unwrap();
    let elapsed = started.elapsed();
    assert_eq!(described.len(), 2);
    assert!(
        elapsed < Duration::from_millis(450),
        "describe groups found a coordinator before redialing the known one: {elapsed:?}"
    );
}

/// A not-coordinator retry finds the coordinator while that broker reconnects.
#[tokio::test]
async fn describe_groups_redials_while_finding_coordinator_after_not_coordinator() {
    let mock = common::Mock::start_two_node().await;
    mock.set_group_coordinator("ga", 2);
    let mut admin = Admin::new(
        AdminConfig::bootstrap([mock.addr.clone()])
            .retry_backoff(Duration::from_millis(1))
            .retry_backoff_max(Duration::from_millis(1)),
    )
    .await
    .unwrap();
    let _warm = admin.describe_groups(&["ga"], false).await.unwrap();
    mock.fail_describe_groups_once(NOT_COORDINATOR);
    let delay = Duration::from_millis(250);
    mock.set_find_coordinator_delay(delay);
    mock.set_api_versions_delay(delay);
    let started = Instant::now();
    let described = admin.describe_groups(&["ga"], false).await.unwrap();
    let elapsed = started.elapsed();
    assert_eq!(described.len(), 1);
    assert_eq!(described[0].error_code, 0);
    assert!(
        elapsed < Duration::from_millis(450),
        "describe groups found the coordinator before redialing after not-coordinator: {elapsed:?}"
    );
}

/// Transactional startup sends FindCoordinator on the open bootstrap socket.
#[tokio::test]
async fn transactional_startup_reuses_the_bootstrap_socket() {
    let mock = common::Mock::start_two_node().await;
    mock.set_txn_coordinator(2);
    let delay = Duration::from_millis(250);
    mock.set_api_versions_delay(delay);
    mock.set_find_coordinator_delay(delay);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-startup".into());
    let started = Instant::now();
    let producer = Producer::new(cfg).await.unwrap();
    let elapsed = started.elapsed();
    assert!(
        elapsed < Duration::from_millis(900),
        "transactional startup opened a second bootstrap socket before FindCoordinator: {elapsed:?}"
    );
    producer.close().await.unwrap();
}

/// A transaction coordinator on the bootstrap broker does not repeat ApiVersions.
#[tokio::test]
async fn transactional_startup_skips_a_second_bootstrap_handshake() {
    let mock = common::Mock::start().await;
    let delay = Duration::from_millis(250);
    mock.set_api_versions_delay(delay);
    mock.set_find_coordinator_delay(delay);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-same".into());
    let started = Instant::now();
    let producer = Producer::new(cfg).await.unwrap();
    let elapsed = started.elapsed();
    assert_eq!(
        mock.api_versions_versions().len(),
        1,
        "the coordinator socket should reuse the bootstrap broker's versions"
    );
    assert!(
        elapsed < Duration::from_millis(650),
        "transactional startup repeated ApiVersions on the bootstrap broker: {elapsed:?}"
    );
    producer.close().await.unwrap();
}

/// A coordinator reload on the bootstrap broker does not repeat ApiVersions.
#[tokio::test]
async fn transactional_rediscover_skips_a_second_bootstrap_handshake() {
    let mock = common::Mock::start().await;
    mock.set_api_versions_delay(Duration::from_millis(250));
    mock.fail_init_producer_id_once(partitionline::error::COORDINATOR_LOAD_IN_PROGRESS);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.retry_backoff = Duration::from_millis(1);
    cfg.retry_backoff_max = Duration::from_millis(1);
    cfg.transactional_id = Some("tx-reload".into());
    let started = Instant::now();
    let producer = Producer::new(cfg).await.unwrap();
    let elapsed = started.elapsed();
    assert_eq!(
        mock.api_versions_versions().len(),
        1,
        "reloading the bootstrap coordinator should reuse the versions already learned"
    );
    assert!(
        elapsed < Duration::from_millis(450),
        "transactional rediscovery repeated ApiVersions: {elapsed:?}"
    );
    producer.close().await.unwrap();
}

/// A moved transaction coordinator reuses a handshake learned by produce.
#[tokio::test]
async fn commit_reuses_a_produce_handshake_for_the_moved_coordinator() {
    let mock = common::Mock::start_two_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_partition_leader("t", 0, 2);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-moved-known".into());
    let producer = Producer::new(cfg).await.unwrap();
    producer.begin_transaction().await.unwrap();
    let _sent = producer
        .send(ProduceRecord::to("t").value(&b"v"[..]))
        .await
        .unwrap();
    let versions_before = mock.api_versions_versions().len();
    assert_eq!(versions_before, 2);
    mock.set_txn_coordinator(2);
    mock.set_end_txn_error_times(NOT_COORDINATOR, 1);
    mock.set_api_versions_delay(Duration::from_millis(250));
    let started = Instant::now();
    producer.commit_transaction().await.unwrap();
    let elapsed = started.elapsed();
    assert!(
        elapsed < Duration::from_millis(200),
        "moved coordinator repeated a produce handshake: {elapsed:?}"
    );
    assert_eq!(mock.api_versions_versions().len(), versions_before);
    producer.close().await.unwrap();
}

/// A transaction coordinator that returns to the bootstrap broker reuses that handshake.
#[tokio::test]
async fn commit_reuses_bootstrap_when_the_coordinator_returns() {
    let mock = common::Mock::start_two_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_partition_leader("t", 0, 1);
    mock.set_txn_coordinator(2);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-returned".into());
    let producer = Producer::new(cfg).await.unwrap();
    producer.begin_transaction().await.unwrap();
    let _sent = producer
        .send(ProduceRecord::to("t").value(&b"v"[..]))
        .await
        .unwrap();
    let versions_before = mock.api_versions_versions().len();
    assert_eq!(versions_before, 2);
    mock.set_txn_coordinator(1);
    mock.set_api_versions_delay(Duration::from_millis(250));
    let started = Instant::now();
    producer.commit_transaction().await.unwrap();
    let elapsed = started.elapsed();
    assert!(
        elapsed < Duration::from_millis(200),
        "a coordinator that returned to bootstrap repeated ApiVersions: {elapsed:?}"
    );
    assert_eq!(mock.api_versions_versions().len(), versions_before);
    producer.close().await.unwrap();
}

/// A produce to another bootstrap reuses the handshake that finished at startup.
#[tokio::test]
async fn produce_reuses_a_finished_bootstrap_handshake() {
    let mock = common::Mock::start_two_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_partition_leader("t", 0, 2);
    mock.set_api_versions_delay(Duration::from_millis(250));
    let addr2 = mock.broker_addr(2).unwrap();
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone(), addr2]);
    cfg.linger = Duration::ZERO;
    let started = Instant::now();
    let producer = Producer::new(cfg).await.unwrap();
    let startup = started.elapsed();
    let versions = mock.api_versions_versions().len();
    assert!(
        versions <= 4,
        "startup negotiated a bootstrap more than once: {versions}"
    );
    assert!(
        startup < Duration::from_millis(700),
        "startup repeated a bootstrap handshake: {startup:?}"
    );
    let started = Instant::now();
    let sent = producer
        .send(ProduceRecord::to("t").value(&b"v"[..]))
        .await
        .unwrap();
    let elapsed = started.elapsed();
    assert!(sent.offset >= 0);
    assert_eq!(
        mock.api_versions_versions().len(),
        versions,
        "produce renegotiated a bootstrap that finished at startup"
    );
    assert!(
        elapsed < Duration::from_millis(200),
        "produce repeated ApiVersions: {elapsed:?}"
    );
    producer.close().await.unwrap();
}

/// Two bootstraps share one handshake when the transaction coordinator is the other one.
#[tokio::test]
async fn multi_bootstrap_transaction_reuses_the_other_bootstrap_handshake() {
    let mock = common::Mock::start_two_node().await;
    mock.set_txn_coordinator(2);
    mock.set_api_versions_delay(Duration::from_millis(250));
    let addr2 = mock.broker_addr(2).unwrap();
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone(), addr2]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-multi".into());
    let started = Instant::now();
    let producer = Producer::new(cfg).await.unwrap();
    let elapsed = started.elapsed();
    assert!(
        mock.api_versions_versions().len() <= 2,
        "startup negotiated a bootstrap that was already open: {}",
        mock.api_versions_versions().len()
    );
    assert!(
        elapsed < Duration::from_millis(400),
        "startup repeated a bootstrap handshake: {elapsed:?}"
    );
    producer.close().await.unwrap();
}

/// A multi-bootstrap commit rediscovers the coordinator without repeating ApiVersions.
#[tokio::test]
async fn multi_bootstrap_commit_reuses_known_coordinator_handshakes() {
    let mock = common::Mock::start_two_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_partition_leader("t", 0, 2);
    mock.set_txn_coordinator(2);
    let addr2 = mock.broker_addr(2).unwrap();
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone(), addr2]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-multi-rediscover".into());
    let producer = Producer::new(cfg).await.unwrap();
    producer.begin_transaction().await.unwrap();
    let _sent = producer
        .send(ProduceRecord::to("t").value(&b"v"[..]))
        .await
        .unwrap();
    let versions_before = mock.api_versions_versions().len();
    mock.set_txn_coordinator(1);
    mock.set_api_versions_delay(Duration::from_millis(250));
    let started = Instant::now();
    producer.commit_transaction().await.unwrap();
    let elapsed = started.elapsed();
    assert_eq!(
        mock.api_versions_versions().len(),
        versions_before,
        "rediscovery renegotiated a broker that was already learned"
    );
    assert!(
        elapsed < Duration::from_millis(200),
        "multi-bootstrap rediscovery repeated ApiVersions: {elapsed:?}"
    );
    producer.close().await.unwrap();
}

/// An epoch bump reuses a handshake learned by produce.
#[tokio::test]
async fn epoch_bump_reuses_a_produce_handshake() {
    let mock = common::Mock::start_two_node().await;
    mock.set_api_max(END_TXN, 4);
    mock.set_topic_partitions("t", 1);
    mock.set_partition_leader("t", 0, 2);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-bump-known".into());
    let producer = Producer::new(cfg).await.unwrap();
    producer.begin_transaction().await.unwrap();
    let _sent = producer
        .send(ProduceRecord::to("t").value(&b"v"[..]))
        .await
        .unwrap();
    mock.set_produce_error_times(UNKNOWN_PRODUCER_ID, 1);
    let failed = producer
        .send(ProduceRecord::to("t").value(&b"lost"[..]))
        .await
        .unwrap_err();
    assert_eq!(failed.broker_code(), Some(UNKNOWN_PRODUCER_ID));
    let versions_before = mock.api_versions_versions().len();
    assert_eq!(versions_before, 2);
    mock.set_txn_id_coordinator("tx-bump-known", 2);
    mock.set_api_versions_delay(Duration::from_millis(250));
    let started = Instant::now();
    producer.abort_transaction().await.unwrap();
    let elapsed = started.elapsed();
    assert_eq!(mock.last_init_producer_id_node(), Some(2));
    assert!(
        elapsed < Duration::from_millis(200),
        "epoch bump repeated a produce handshake: {elapsed:?}"
    );
    assert_eq!(mock.api_versions_versions().len(), versions_before);
    producer.close().await.unwrap();
}

/// A produce to the transaction coordinator reuses that broker's handshake.
#[tokio::test]
async fn produce_reuses_the_transaction_coordinator_handshake() {
    let mock = common::Mock::start_two_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_partition_leader("t", 0, 2);
    mock.set_txn_coordinator(2);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-produce-known".into());
    let producer = Producer::new(cfg).await.unwrap();
    producer.begin_transaction().await.unwrap();
    assert_eq!(mock.api_versions_versions().len(), 2);
    mock.set_api_versions_delay(Duration::from_millis(250));
    let started = Instant::now();
    let _sent = producer
        .send(ProduceRecord::to("t").value(&b"v"[..]))
        .await
        .unwrap();
    let elapsed = started.elapsed();
    assert!(
        elapsed < Duration::from_millis(200),
        "produce repeated the transaction coordinator handshake: {elapsed:?}"
    );
    assert_eq!(mock.api_versions_versions().len(), 2);
    producer.abort_transaction().await.unwrap();
    producer.close().await.unwrap();
}

/// TxnOffsetCommit on the bootstrap broker reuses the versions learned at startup.
#[tokio::test]
async fn send_offsets_reuses_bootstrap_api_versions() {
    let mock = common::Mock::start().await;
    mock.set_topic_partitions("t", 1);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-offsets-known".into());
    let producer = Producer::new(cfg).await.unwrap();
    producer.begin_transaction().await.unwrap();
    let versions_before = mock.api_versions_versions().len();
    assert_eq!(versions_before, 1);
    mock.set_api_versions_delay(Duration::from_millis(250));
    let started = Instant::now();
    producer
        .send_offsets_to_transaction("g", [(TopicPartition::new("t", 0), 1)])
        .await
        .unwrap();
    let elapsed = started.elapsed();
    assert!(
        elapsed < Duration::from_millis(200),
        "transactional offset commit repeated ApiVersions: {elapsed:?}"
    );
    assert_eq!(mock.api_versions_versions().len(), versions_before);
    producer.abort_transaction().await.unwrap();
    producer.close().await.unwrap();
}

/// TxnOffsetCommit across several bootstraps reuses handshakes from startup.
#[tokio::test]
async fn multi_bootstrap_send_offsets_reuses_known_handshakes() {
    let mock = common::Mock::start_two_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_partition_leader("t", 0, 1);
    mock.set_coordinator(2);
    let addr2 = mock.broker_addr(2).unwrap();
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone(), addr2]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-multi-offsets".into());
    let producer = Producer::new(cfg).await.unwrap();
    producer.begin_transaction().await.unwrap();
    let versions_before = mock.api_versions_versions().len();
    mock.set_api_versions_delay(Duration::from_millis(250));
    let started = Instant::now();
    producer
        .send_offsets_to_transaction("g", [(TopicPartition::new("t", 0), 1)])
        .await
        .unwrap();
    let elapsed = started.elapsed();
    assert_eq!(
        mock.api_versions_versions().len(),
        versions_before,
        "group coordinator lookup renegotiated a bootstrap"
    );
    assert!(
        elapsed < Duration::from_millis(200),
        "multi-bootstrap offset commit repeated ApiVersions: {elapsed:?}"
    );
    producer.abort_transaction().await.unwrap();
    producer.close().await.unwrap();
}

/// A group coordinator that has never been contacted still negotiates.
#[tokio::test]
async fn send_offsets_negotiates_a_new_group_coordinator() {
    let mock = common::Mock::start_two_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_partition_leader("t", 0, 1);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-offsets-remote".into());
    let producer = Producer::new(cfg).await.unwrap();
    producer.begin_transaction().await.unwrap();
    mock.move_coordinator();
    let versions_before = mock.api_versions_versions().len();
    mock.set_api_versions_delay(Duration::from_millis(250));
    let started = Instant::now();
    producer
        .send_offsets_to_transaction("g", [(TopicPartition::new("t", 0), 1)])
        .await
        .unwrap();
    let elapsed = started.elapsed();
    assert_eq!(mock.api_versions_versions().len(), versions_before + 1);
    assert!(
        elapsed < Duration::from_millis(450),
        "new group coordinator redid the bootstrap handshake: {elapsed:?}"
    );
    producer.abort_transaction().await.unwrap();
    producer.close().await.unwrap();
}

/// A second transactional offset commit reuses the group coordinator handshake.
#[tokio::test]
async fn send_offsets_repeats_a_remote_coordinator_without_another_handshake() {
    let mock = common::Mock::start_two_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_partition_leader("t", 0, 1);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-offsets-again".into());
    let producer = Producer::new(cfg).await.unwrap();
    producer.begin_transaction().await.unwrap();
    mock.move_coordinator();
    producer
        .send_offsets_to_transaction("g", [(TopicPartition::new("t", 0), 1)])
        .await
        .unwrap();
    let versions_before = mock.api_versions_versions().len();
    mock.set_api_versions_delay(Duration::from_millis(250));
    let started = Instant::now();
    producer
        .send_offsets_to_transaction("g", [(TopicPartition::new("t", 0), 2)])
        .await
        .unwrap();
    let elapsed = started.elapsed();
    assert!(
        elapsed < Duration::from_millis(200),
        "repeated group coordinator negotiated again: {elapsed:?}"
    );
    assert_eq!(mock.api_versions_versions().len(), versions_before);
    producer.abort_transaction().await.unwrap();
    producer.close().await.unwrap();
}

/// Reloading a remote transaction coordinator does not repeat the bootstrap handshake.
#[tokio::test]
async fn transactional_rediscover_skips_a_remote_bootstrap_handshake() {
    let mock = common::Mock::start_two_node().await;
    mock.set_txn_coordinator(2);
    mock.fail_init_producer_id_once(partitionline::error::COORDINATOR_LOAD_IN_PROGRESS);
    mock.set_api_versions_delay(Duration::from_millis(250));
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.retry_backoff = Duration::from_millis(1);
    cfg.retry_backoff_max = Duration::from_millis(1);
    cfg.transactional_id = Some("tx-remote-reload".into());
    let started = Instant::now();
    let producer = Producer::new(cfg).await.unwrap();
    let elapsed = started.elapsed();
    assert_eq!(
        mock.api_versions_versions().len(),
        2,
        "reloading a remote coordinator should not negotiate the bootstrap broker again"
    );
    assert!(
        elapsed < Duration::from_millis(650),
        "transactional rediscovery repeated the bootstrap handshake: {elapsed:?}"
    );
    producer.close().await.unwrap();
}

/// An EndTxn coordinator retry looks up the coordinator while that broker reconnects.
#[tokio::test]
async fn commit_redials_txn_coordinator_while_finding_it() {
    let mock = common::Mock::start_two_node().await;
    mock.set_topic_partitions("t", 1);
    mock.set_txn_coordinator(2);
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.transactional_id = Some("tx-redial".into());
    let producer = Producer::new(cfg).await.unwrap();
    producer.begin_transaction().await.unwrap();
    let _sent = producer
        .send(ProduceRecord::to("t").value(&b"v"[..]))
        .await
        .unwrap();
    mock.set_end_txn_error_times(NOT_COORDINATOR, 1);
    let delay = Duration::from_millis(250);
    mock.set_find_coordinator_delay(delay);
    mock.set_api_versions_delay(delay);
    let started = Instant::now();
    producer.commit_transaction().await.unwrap();
    let elapsed = started.elapsed();
    assert!(
        elapsed < Duration::from_millis(650),
        "commit found the transaction coordinator before redialing it: {elapsed:?}"
    );
    producer.close().await.unwrap();
}

/// An AddPartitions retry must drop the coordinator socket when that broker stops writing.
#[tokio::test(flavor = "current_thread")]
async fn add_partitions_drops_the_coordinator_when_it_closes_during_backoff() {
    let mock = common::Mock::start().await;
    mock.set_topic_partitions("t", 1);
    mock.set_transaction_version(Some(1));
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.connections = 1;
    cfg.transactional_id = Some("tx-add-backoff".into());
    cfg.retry_backoff = Duration::from_secs(5);
    cfg.retry_backoff_max = Duration::from_secs(5);
    cfg.request_timeout = Duration::from_secs(30);
    cfg.delivery_timeout = Duration::from_secs(30);
    let producer = Producer::new(cfg).await.unwrap();
    producer.begin_transaction().await.unwrap();
    mock.set_add_partitions_error_times(partitionline::error::CONCURRENT_TRANSACTIONS, 1);
    let sending = producer.clone();
    let mut sending = std::pin::pin!(sending.send(ProduceRecord::to("t").value(&b"v"[..])));
    let started = Instant::now();
    loop {
        if mock.add_partitions_attempts() >= 1 {
            break;
        }
        tokio::select! {
            _ = &mut sending => panic!("send finished before AddPartitions"),
            _ = tokio::time::sleep(Duration::from_millis(10)) => {}
        }
        if started.elapsed() > Duration::from_secs(2) {
            panic!("did not see AddPartitions");
        }
    }
    let settle = Instant::now();
    while settle.elapsed() < Duration::from_millis(80) {
        tokio::select! {
            _ = &mut sending => panic!("send left the add-partitions backoff early"),
            _ = tokio::time::sleep(Duration::from_millis(10)) => {}
        }
    }
    assert_eq!(
        mock.add_partitions_attempts(),
        1,
        "a second AddPartitions means the client is not waiting out the backoff"
    );
    let before = mock.accepts();
    let open = mock.open_conns();
    assert!(open > 0, "add partitions had no socket");
    mock.shutdown_writes();
    let window = Instant::now();
    loop {
        if mock.accepts() > before || mock.open_conns() < open {
            break;
        }
        if window.elapsed() > Duration::from_millis(400) {
            panic!(
                "add partitions kept the coordinator socket during backoff; accepts {before} open {open}"
            );
        }
        tokio::select! {
            result = &mut sending => {
                let _sent = result;
                assert!(
                    mock.accepts() > before || mock.open_conns() < open,
                    "send finished with the coordinator socket still open"
                );
                drop(producer);
                return;
            }
            _ = tokio::time::sleep(Duration::from_millis(10)) => {}
        }
    }
    drop(producer);
}

/// An idle producer must drop its metadata socket when that broker stops writing.
#[tokio::test(flavor = "current_thread")]
async fn idle_metadata_socket_drops_when_the_broker_stops_writing() {
    let mock = common::Mock::start().await;
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.metadata_max_age = Duration::from_secs(300);
    let producer = Producer::new(cfg).await.unwrap();
    tokio::time::sleep(Duration::from_millis(30)).await;
    let open = mock.open_conns();
    assert!(open > 0, "producer had no metadata socket");
    mock.shutdown_writes();
    let window = Instant::now();
    while mock.open_conns() >= open {
        if window.elapsed() > Duration::from_millis(400) {
            panic!("idle metadata socket stayed open; open {open}");
        }
        tokio::task::yield_now().await;
    }
    drop(producer);
}

/// An idle transactional producer must drop its coordinator socket when that broker stops writing.
#[tokio::test(flavor = "current_thread")]
async fn idle_coordinator_socket_drops_when_the_broker_stops_writing() {
    let mock = common::Mock::start().await;
    let mut cfg = ProducerConfig::bootstrap([mock.addr.clone()]);
    cfg.linger = Duration::ZERO;
    cfg.metadata_max_age = Duration::from_secs(300);
    cfg.transactional_id = Some("tx-idle-coord".into());
    let producer = Producer::new(cfg).await.unwrap();
    tokio::time::sleep(Duration::from_millis(30)).await;
    let open = mock.open_conns();
    assert!(
        open >= 2,
        "transactional producer should hold the metadata and coordinator sockets, open {open}"
    );
    mock.shutdown_writes();
    let window = Instant::now();
    while mock.open_conns() > 0 {
        if window.elapsed() > Duration::from_millis(400) {
            panic!(
                "idle coordinator socket stayed open; open {}",
                mock.open_conns()
            );
        }
        tokio::task::yield_now().await;
    }
    drop(producer);
}
