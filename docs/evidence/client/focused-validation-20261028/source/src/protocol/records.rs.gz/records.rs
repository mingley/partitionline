//! Magic-v2 RecordBatch codec (gzip, snappy, LZ4; optional zstd).

use std::fmt;
use std::io::{Read, Write};

use bytes::{Buf, BufMut, Bytes, BytesMut};

use super::buf;
use crate::error::{Error, Result};

/// Record batch magic for Kafka 0.11+ (v2).
pub const MAGIC_V2: i8 = 2;

const OFFSET_OVERFLOW: &str = "record offset overflow";
const TIMESTAMP_OVERFLOW: &str = "record timestamp overflow";

/// Default upper bound on decompressed record-batch bytes (64 MiB).
///
/// This ceiling protects against decompression bombs during gzip, snappy,
/// LZ4 and optional zstd decoding. It is set strictly above `ConsumerConfig::max_partition_fetch_bytes`
/// (16 MiB default) so that legitimate oversized first batches can still make
/// progress under Kafka's oversized-first-batch delivery rule.
pub const DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES: usize = 64 * 1024 * 1024;

// Record and header Vec capacity is bounded separately from decompressed
// bytes. The floor keeps small explicit wire limits usable for ordinary
// records; the ceiling limits metadata retained by any one decoded batch.
const MIN_DECODE_METADATA_BYTES: usize = 64 * 1024;
const MAX_DECODE_METADATA_BYTES: usize = 2 * DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES;

/// Per-response accounting for retained decoded container capacity.
#[derive(Clone, Copy)]
pub(crate) struct DecodeMetadataBudget {
    limit: usize,
    used: usize,
}

impl DecodeMetadataBudget {
    /// Use a validated explicit response metadata limit.
    pub(crate) fn with_limit(limit: usize) -> Self {
        Self { limit, used: 0 }
    }

    pub(crate) fn for_wire_limit(max_decode_bytes: usize) -> Self {
        Self {
            limit: max_decode_bytes
                .min(DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES)
                .saturating_mul(2)
                .clamp(MIN_DECODE_METADATA_BYTES, MAX_DECODE_METADATA_BYTES),
            used: 0,
        }
    }

    pub(crate) fn require<T>(&self, slots: usize) -> Result<()> {
        let bytes = slots
            .checked_mul(std::mem::size_of::<T>())
            .ok_or_else(|| Error::protocol("decoded metadata size overflow"))?;
        if self
            .used
            .checked_add(bytes)
            .is_none_or(|sum| sum > self.limit)
        {
            return Err(Error::protocol(
                "decoded record metadata exceeds maximum allowable size",
            ));
        }
        Ok(())
    }

    /// Additional slots that fit without releasing currently charged capacity.
    pub(crate) fn remaining_slots<T>(&self) -> usize {
        self.limit
            .saturating_sub(self.used)
            .checked_div(std::mem::size_of::<T>())
            .unwrap_or(usize::MAX)
    }

    /// Charge a capacity already retained in an existing vector, exactly once.
    pub(crate) fn charge<T>(&mut self, slots: usize) -> Result<()> {
        self.require::<T>(slots)?;
        let bytes = slots
            .checked_mul(std::mem::size_of::<T>())
            .ok_or_else(|| Error::protocol("decoded metadata size overflow"))?;
        self.used = self
            .used
            .checked_add(bytes)
            .ok_or_else(|| Error::protocol("decoded metadata size overflow"))?;
        Ok(())
    }

    /// Release a capacity charge after the corresponding allocation is freed.
    pub(crate) fn release<T>(&mut self, slots: usize) -> Result<()> {
        let bytes = slots
            .checked_mul(std::mem::size_of::<T>())
            .ok_or_else(|| Error::protocol("decoded metadata size overflow"))?;
        self.used = self
            .used
            .checked_sub(bytes)
            .ok_or_else(|| Error::protocol("decoded metadata accounting underflow"))?;
        Ok(())
    }

    /// Grow a vector whose previous capacity has already been charged.
    ///
    /// Growth is transactional: allocator over-allocation or allocation failure
    /// leaves both the original vector and its charge intact. The old and new
    /// allocations coexist during the move and both count against the budget.
    /// Allocator bookkeeping and excess capacity returned by the allocator may
    /// temporarily exceed the budget before that excess can be rejected.
    pub(crate) fn reserve<T>(&mut self, slots: &mut Vec<T>, target: usize) -> Result<()> {
        self.reserve_using(slots, target, |replacement, capacity| {
            replacement
                .try_reserve_exact(capacity)
                .map_err(|_| Error::protocol("decoded metadata reserve"))
        })
    }

    #[inline]
    fn reserve_using<T>(
        &mut self,
        slots: &mut Vec<T>,
        target: usize,
        allocate: impl FnOnce(&mut Vec<T>, usize) -> Result<()>,
    ) -> Result<()> {
        if target <= slots.capacity() {
            return Ok(());
        }
        let old_capacity = slots.capacity();
        self.require::<T>(target)?;
        let mut replacement = Vec::new();
        allocate(&mut replacement, target)?;
        if replacement.capacity() < target {
            return Err(Error::protocol("decoded metadata reserve"));
        }
        self.charge::<T>(replacement.capacity())?;
        replacement.append(slots);
        let previous = std::mem::replace(slots, replacement);
        drop(previous);
        self.release::<T>(old_capacity)
    }
}

/// Java `Records` log-entry layout (offset + size prefix before the batch body).
pub struct Records;

impl Records {
    /// Java `Records.OFFSET_OFFSET`.
    pub const OFFSET_OFFSET: i32 = 0;
    /// Java `Records.OFFSET_LENGTH`.
    pub const OFFSET_LENGTH: i32 = 8;
    /// Java `Records.SIZE_OFFSET`.
    pub const SIZE_OFFSET: i32 = Self::OFFSET_OFFSET + Self::OFFSET_LENGTH;
    /// Java `Records.SIZE_LENGTH`.
    pub const SIZE_LENGTH: i32 = 4;
    /// Java `Records.LOG_OVERHEAD`.
    pub const LOG_OVERHEAD: i32 = Self::SIZE_OFFSET + Self::SIZE_LENGTH;
    /// Java `Records.MAGIC_OFFSET`.
    pub const MAGIC_OFFSET: i32 = Self::LOG_OVERHEAD + 4;
    /// Java `Records.MAGIC_LENGTH`.
    pub const MAGIC_LENGTH: i32 = 1;
    /// Java `Records.HEADER_SIZE_UP_TO_MAGIC`.
    pub const HEADER_SIZE_UP_TO_MAGIC: i32 = Self::MAGIC_OFFSET + Self::MAGIC_LENGTH;

    /// Java `AbstractRecords.estimateSizeInBytesUpperBound` (magic-v2).
    ///
    /// Compression is ignored: v2 uses
    /// [`RecordBatch::estimate_batch_size_upper_bound`].
    pub fn estimate_size_in_bytes_upper_bound(
        key: Option<&[u8]>,
        value: Option<&[u8]>,
        headers: &[Header],
    ) -> Result<i32> {
        RecordBatch::estimate_batch_size_upper_bound(key, value, headers)
    }

    /// Java `AbstractRecords.estimateSizeInBytes` (magic-v2, offset deltas
    /// `0..n`).
    pub fn estimate_size_in_bytes(compression: Compression, records: &[Record]) -> Result<i32> {
        let size = RecordBatch::size_in_bytes_of(records)?;
        Ok(estimate_compressed_size_in_bytes(size, compression))
    }

    /// Java `AbstractRecords.estimateSizeInBytes` with a base offset (magic-v2).
    pub fn estimate_size_in_bytes_from(
        base_offset: i64,
        compression: Compression,
        records: &[Record],
    ) -> Result<i32> {
        let size = RecordBatch::size_in_bytes_from(base_offset, records)?;
        Ok(estimate_compressed_size_in_bytes(size, compression))
    }

    /// Java `AbstractRecords.recordBatchHeaderSizeInBytes` (magic-v2).
    #[must_use]
    pub const fn record_batch_header_size_in_bytes() -> i32 {
        RecordBatch::RECORD_BATCH_OVERHEAD
    }

    /// Java `AbstractRecords.hasMatchingMagic`. Empty is true (vacuous).
    ///
    /// This crate's [`RecordBatch::magic`] is always
    /// [`RecordBatch::CURRENT_MAGIC_VALUE`] (`2`).
    #[must_use]
    pub fn has_matching_magic(batches: &[RecordBatch], magic: i8) -> bool {
        batches.iter().all(|batch| batch.magic() == magic)
    }

    /// Java `AbstractRecords.firstBatch`. Empty is `None`.
    #[must_use]
    pub fn first_batch(batches: &[RecordBatch]) -> Option<&RecordBatch> {
        batches.first()
    }

    /// Java `AbstractRecords.lastBatch`. Empty is `None` (Java `Optional.empty`).
    #[must_use]
    pub fn last_batch(batches: &[RecordBatch]) -> Option<&RecordBatch> {
        batches.last()
    }

    /// Java `MemoryRecords.firstBatchSize`.
    ///
    /// Fewer than [`Self::HEADER_SIZE_UP_TO_MAGIC`] bytes is `None` (the size
    /// field is not validated). Size below Java `LegacyRecord.RECORD_OVERHEAD_V0`
    /// (14) or magic outside 0 through [`RecordBatch::CURRENT_MAGIC_VALUE`] is
    /// [`crate::Error::protocol`] (`CorruptRecordException`). The returned size includes
    /// [`Self::LOG_OVERHEAD`].
    pub fn first_batch_size(buffer: &[u8]) -> Result<Option<i32>> {
        let header_up_to_magic = buf::usize_from_i32(Self::HEADER_SIZE_UP_TO_MAGIC)?;
        if buffer.len() < header_up_to_magic {
            return Ok(None);
        }
        next_batch_size(buffer, i32::MAX)
    }

    /// Java `MemoryRecords.validBytes`.
    ///
    /// Sum of complete batch sizes (including [`Self::LOG_OVERHEAD`]). A
    /// truncated trailing batch is ignored. Header corruption uses the same
    /// [`crate::Error::protocol`] messages as [`Self::first_batch_size`].
    pub fn valid_bytes(buffer: &[u8]) -> Result<i32> {
        let mut offset = 0;
        let mut bytes = 0i32;
        while let Some(remaining) = buffer.get(offset..) {
            let Some(batch_size) = next_batch_size(remaining, i32::MAX)? else {
                break;
            };
            let need = buf::usize_from_i32(batch_size)?;
            if remaining.len() < need {
                break;
            }
            bytes = bytes.wrapping_add(batch_size);
            offset = offset.saturating_add(need);
        }
        Ok(bytes)
    }
}

/// Java `ByteBufferLogInputStream.nextBatchSize` (`maxMessageSize` is the
/// constructor argument; `MemoryRecords` uses `Integer.MAX_VALUE`).
fn next_batch_size(buffer: &[u8], max_message_size: i32) -> Result<Option<i32>> {
    let log_overhead = buf::usize_from_i32(Records::LOG_OVERHEAD)?;
    if buffer.len() < log_overhead {
        return Ok(None);
    }
    let size_off = buf::usize_from_i32(Records::SIZE_OFFSET)?;
    let record_size = buf::read_int_be(buffer, size_off)?;
    // Java `LegacyRecord.RECORD_OVERHEAD_V0`.
    const RECORD_OVERHEAD_V0: i32 = 14;
    if record_size < RECORD_OVERHEAD_V0 {
        return Err(Error::protocol(format!(
            "Record size {record_size} is less than the minimum record overhead ({RECORD_OVERHEAD_V0})"
        )));
    }
    if record_size > max_message_size {
        return Err(Error::protocol(format!(
            "Record size {record_size} exceeds the largest allowable message size ({max_message_size})."
        )));
    }
    let header_up_to_magic = buf::usize_from_i32(Records::HEADER_SIZE_UP_TO_MAGIC)?;
    if buffer.len() < header_up_to_magic {
        return Ok(None);
    }
    let magic_off = buf::usize_from_i32(Records::MAGIC_OFFSET)?;
    let magic_byte = buffer
        .get(magic_off)
        .copied()
        .ok_or_else(|| Error::protocol("short magic byte"))?;
    let magic = i8::from_ne_bytes([magic_byte]);
    if !(0..=RecordBatch::CURRENT_MAGIC_VALUE).contains(&magic) {
        return Err(Error::protocol(format!(
            "Invalid magic found in record: {magic}"
        )));
    }
    Ok(Some(record_size.wrapping_add(Records::LOG_OVERHEAD)))
}

/// Validated zstd encoder level for the optional `zstd` feature.
///
/// Levels 1 through 19 are supported; 3 is the default. Zero, negative levels
/// and levels above 19 are rejected rather than silently mapped by a backend.
#[cfg(feature = "zstd")]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ZstdLevel(i32);

#[cfg(feature = "zstd")]
impl ZstdLevel {
    /// Lowest supported compression level.
    pub const MIN: i32 = 1;
    /// Highest supported compression level.
    pub const MAX: i32 = 19;
    /// Validate an explicitly selected level.
    pub fn new(level: i32) -> Result<Self> {
        if !(Self::MIN..=Self::MAX).contains(&level) {
            return Err(Error::protocol("zstd level must be between 1 and 19"));
        }
        Ok(Self(level))
    }
    /// The selected level.
    #[must_use]
    pub const fn get(self) -> i32 {
        self.0
    }
}

#[cfg(feature = "zstd")]
impl Default for ZstdLevel {
    fn default() -> Self {
        Self(3)
    }
}

/// Kafka record-batch compression codec.
///
/// The optional `zstd` feature enables bounded decoding and encoding with
/// explicit levels 1 through 19 (default 3).
///
/// [`std::fmt::Display`] is Java `CompressionType.toString` (`gzip`).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
#[repr(i16)]
pub enum Compression {
    /// Uncompressed.
    #[default]
    None = 0,
    /// gzip (`flate2`; zlib-rs with the default `zlib-rs` feature, otherwise
    /// miniz_oxide). See `docs/gzip-backend.md`.
    Gzip = 1,
    /// Snappy.
    Snappy = 2,
    /// LZ4 frame.
    Lz4 = 3,
    /// Zstandard, enabled by the optional `zstd` feature.
    #[cfg(feature = "zstd")]
    Zstd = 4,
}

impl Compression {
    /// Codec from the low 3 bits of batch attributes.
    pub fn from_attributes(attr: i16) -> Result<Self> {
        match attr & ATTR_COMPRESSION_CODEC {
            0 => Ok(Self::None),
            1 => Ok(Self::Gzip),
            2 => Ok(Self::Snappy),
            3 => Ok(Self::Lz4),
            #[cfg(feature = "zstd")]
            4 => Ok(Self::Zstd),
            #[cfg(not(feature = "zstd"))]
            4 => Err(Error::Unsupported("zstd requires the zstd feature".into())),
            n => Err(Error::protocol(format!("unsupported compression {n}"))),
        }
    }

    /// Java `CompressionType.forName` (`none` / `gzip` / `snappy` / `lz4`).
    /// Empty is [`Self::None`]. `zstd` requires the optional feature.
    pub fn from_name(name: &str) -> Result<Self> {
        match name {
            "none" | "" => Ok(Self::None),
            "gzip" => Ok(Self::Gzip),
            "snappy" => Ok(Self::Snappy),
            "lz4" => Ok(Self::Lz4),
            #[cfg(feature = "zstd")]
            "zstd" => Ok(Self::Zstd),
            #[cfg(not(feature = "zstd"))]
            "zstd" => Err(Error::Unsupported("zstd requires the zstd feature".into())),
            other => Err(Error::protocol(format!(
                "Unknown compression name: {other}"
            ))),
        }
    }

    /// Java `CompressionType.id`.
    #[must_use]
    pub fn id(self) -> i8 {
        match self {
            Self::None => 0,
            Self::Gzip => 1,
            Self::Snappy => 2,
            Self::Lz4 => 3,
            #[cfg(feature = "zstd")]
            Self::Zstd => 4,
        }
    }

    /// Java `CompressionType.forId`. Unknown or disabled ids return `None`.
    #[must_use]
    pub fn from_id(id: i32) -> Option<Self> {
        match id {
            0 => Some(Self::None),
            1 => Some(Self::Gzip),
            2 => Some(Self::Snappy),
            3 => Some(Self::Lz4),
            #[cfg(feature = "zstd")]
            4 => Some(Self::Zstd),
            _ => None,
        }
    }

    /// Config name for this codec.
    pub fn as_str(self) -> &'static str {
        match self {
            Self::None => "none",
            Self::Gzip => "gzip",
            Self::Snappy => "snappy",
            Self::Lz4 => "lz4",
            #[cfg(feature = "zstd")]
            Self::Zstd => "zstd",
        }
    }

    /// Java `CompressionType.GZIP.MIN_LEVEL` (`Deflater.BEST_SPEED`).
    pub const GZIP_MIN_LEVEL: i32 = 1;
    /// Java `CompressionType.GZIP.MAX_LEVEL` (`Deflater.BEST_COMPRESSION`).
    pub const GZIP_MAX_LEVEL: i32 = 9;
    /// Java `CompressionType.GZIP.DEFAULT_LEVEL` (`Deflater.DEFAULT_COMPRESSION`).
    pub const GZIP_DEFAULT_LEVEL: i32 = -1;
    /// Java `CompressionType.LZ4` min (`LZ4Constants`).
    pub const LZ4_MIN_LEVEL: i32 = 1;
    /// Java `CompressionType.LZ4` max (`LZ4Constants`).
    pub const LZ4_MAX_LEVEL: i32 = 17;
    /// Java `CompressionType.LZ4` default (`LZ4Constants`).
    pub const LZ4_DEFAULT_LEVEL: i32 = 9;

    fn levels_unsupported(self) -> Error {
        Error::Unsupported(format!(
            "Compression levels are not defined for this compression type: {}",
            self.as_str()
        ))
    }

    /// Java `CompressionType.defaultLevel`.
    ///
    /// Codecs without an encoder level are [`Error::Unsupported`].
    pub fn default_level(self) -> Result<i32> {
        match self {
            Self::Gzip => Ok(Self::GZIP_DEFAULT_LEVEL),
            Self::Lz4 => Ok(Self::LZ4_DEFAULT_LEVEL),
            #[cfg(feature = "zstd")]
            Self::Zstd => Ok(ZstdLevel::default().get()),
            other => Err(other.levels_unsupported()),
        }
    }

    /// Java `CompressionType.minLevel`.
    ///
    /// [`Self::None`] / [`Self::Snappy`] are [`Error::Unsupported`].
    pub fn min_level(self) -> Result<i32> {
        match self {
            Self::Gzip => Ok(Self::GZIP_MIN_LEVEL),
            Self::Lz4 => Ok(Self::LZ4_MIN_LEVEL),
            #[cfg(feature = "zstd")]
            Self::Zstd => Ok(ZstdLevel::MIN),
            other => Err(other.levels_unsupported()),
        }
    }

    /// Java `CompressionType.maxLevel`.
    ///
    /// [`Self::None`] / [`Self::Snappy`] are [`Error::Unsupported`].
    pub fn max_level(self) -> Result<i32> {
        match self {
            Self::Gzip => Ok(Self::GZIP_MAX_LEVEL),
            Self::Lz4 => Ok(Self::LZ4_MAX_LEVEL),
            #[cfg(feature = "zstd")]
            Self::Zstd => Ok(ZstdLevel::MAX),
            other => Err(other.levels_unsupported()),
        }
    }

    /// Compress a payload the way record batches / PushTelemetry do.
    #[cfg(test)]
    pub(crate) fn codec_compress(self, src: &[u8]) -> Result<Vec<u8>> {
        let mut out = Vec::new();
        match self {
            Self::None => out.extend_from_slice(src),
            Self::Gzip => gzip_compress_into(src, &mut out)?,
            Self::Snappy => snappy_compress_into(src, &mut out)?,
            Self::Lz4 => lz4_compress_into(src, &mut out)?,
            #[cfg(feature = "zstd")]
            Self::Zstd => {
                let mut context = None;
                zstd_compress_into(src, &mut out, &mut context, ZstdLevel::default())?;
            }
        }
        Ok(out)
    }

    /// Decompress a payload the way record batches / PushTelemetry do,
    /// enforcing [`DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES`].
    pub(crate) fn codec_decompress(self, src: &[u8]) -> Result<Vec<u8>> {
        self.codec_decompress_bounded(src, DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES)
    }

    /// Decompress a payload enforcing an explicit decoded-byte ceiling.
    pub(crate) fn codec_decompress_bounded(self, src: &[u8], max_bytes: usize) -> Result<Vec<u8>> {
        match self {
            Self::None => {
                if src.len() > max_bytes {
                    return Err(Error::protocol(
                        "Decompressed batch exceeds maximum allowable size",
                    ));
                }
                Ok(src.to_vec())
            }
            Self::Gzip => gzip_decompress(src, max_bytes),
            Self::Snappy => snappy_decompress(src, max_bytes),
            Self::Lz4 => lz4_decompress(src, max_bytes),
            #[cfg(feature = "zstd")]
            Self::Zstd => zstd_decompress(src, max_bytes),
        }
    }
}

/// Decode a finite sequence of ordinary/skippable zstd frames. Header checks
/// run before backend allocation. Limits concern decoded bytes and declared
/// windows, not allocator capacity or process RSS.
#[cfg(feature = "zstd")]
fn zstd_decompress(mut src: &[u8], max_bytes: usize) -> Result<Vec<u8>> {
    const MAX_FRAMES: usize = 1024;
    let max_bytes = max_bytes.min(DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES);
    let max_u64 = u64::try_from(max_bytes)
        .map_err(|_| Error::protocol("zstd decode limit does not fit u64"))?;
    let window_limit = u64::try_from(DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES)
        .map_err(|_| Error::protocol("zstd window limit does not fit u64"))?;
    if src.is_empty() {
        return Err(Error::protocol("empty zstd frame sequence"));
    }
    let mut out = Vec::new();
    let mut decoder = None;
    let mut frames = 0;
    while !src.is_empty() {
        frames += 1;
        if frames > MAX_FRAMES {
            return Err(Error::protocol("zstd frame count exceeds 1024"));
        }
        let magic = u32::from_le_bytes(
            src.get(..4)
                .ok_or_else(|| Error::protocol("truncated zstd magic"))?
                .try_into()
                .map_err(|_| Error::protocol("truncated zstd magic"))?,
        );
        let consumed = if magic & 0xfffffff0 == 0x184d2a50 {
            let size = u32::from_le_bytes(
                src.get(4..8)
                    .ok_or_else(|| Error::protocol("truncated zstd skippable header"))?
                    .try_into()
                    .map_err(|_| Error::protocol("truncated zstd skippable header"))?,
            );
            8usize
                .checked_add(
                    usize::try_from(size)
                        .map_err(|_| Error::protocol("zstd skippable size overflow"))?,
                )
                .filter(|&end| end <= src.len())
                .ok_or_else(|| Error::protocol("truncated zstd skippable frame"))?
        } else {
            let header = zstd_rs::FrameHeader::parse(src)
                .map_err(|e| Error::protocol(format!("zstd frame header: {e}")))?;
            if header.window_size > window_limit {
                return Err(Error::protocol("zstd window exceeds 64 MiB"));
            }
            if header.dict_id != 0 {
                return Err(Error::Unsupported(
                    "zstd dictionaries are not supported".into(),
                ));
            }
            let used = u64::try_from(out.len())
                .map_err(|_| Error::protocol("zstd decoded size overflow"))?;
            if header
                .content_size
                .is_some_and(|size| size > max_u64.saturating_sub(used))
            {
                return Err(Error::protocol(
                    "Decompressed batch exceeds maximum allowable size",
                ));
            }
            decoder
                .get_or_insert_with(zstd_rs::Decompressor::new)
                .decompress_frame(src, None, max_bytes, &mut out)
                .map_err(|e| Error::protocol(format!("zstd decode: {e}")))?
        };
        if consumed == 0 || out.len() > max_bytes {
            return Err(Error::protocol("invalid zstd decoder progress or size"));
        }
        src = src
            .get(consumed..)
            .ok_or_else(|| Error::protocol("invalid zstd frame extent"))?;
    }
    Ok(out)
}

impl fmt::Display for Compression {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

/// One Kafka record header (`RecordHeader`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Header {
    /// Header key.
    pub key: String,
    /// Header value, or `None` when the wire value is null.
    pub value: Option<Bytes>,
}

impl Header {
    /// Header with a non-null value.
    pub fn new(key: impl Into<String>, value: impl Into<Bytes>) -> Self {
        Self {
            key: key.into(),
            value: Some(value.into()),
        }
    }

    /// Header with a null value (Java `RecordHeader(key, null)`).
    #[must_use]
    pub fn null(key: impl Into<String>) -> Self {
        Self {
            key: key.into(),
            value: None,
        }
    }

    /// Java `RecordHeader.key`.
    #[must_use]
    pub fn key(&self) -> &str {
        self.key.as_str()
    }

    /// Java `RecordHeader.value` (`None` is Java `null`).
    #[must_use]
    pub fn value(&self) -> Option<&[u8]> {
        self.value.as_deref()
    }

    /// Last header whose key is `key` (Java `Headers.lastHeader`).
    #[must_use]
    pub fn last_in<'a>(headers: &'a [Self], key: &str) -> Option<&'a Self> {
        headers.iter().rev().find(|h| h.key() == key)
    }

    /// Headers whose key is `key`, in insertion order (Java `Headers.headers(String)`).
    pub fn for_key<'a>(headers: &'a [Self], key: &'a str) -> impl Iterator<Item = &'a Self> + 'a {
        headers.iter().filter(move |h| h.key() == key)
    }
}

impl fmt::Display for Header {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "RecordHeader(key = {}, value = ", self.key())?;
        write_java_byte_array(f, self.value())?;
        f.write_str(")")
    }
}

fn write_java_byte_array(f: &mut fmt::Formatter<'_>, value: Option<&[u8]>) -> fmt::Result {
    let Some(bytes) = value else {
        return f.write_str("null");
    };
    f.write_str("[")?;
    for (i, b) in bytes.iter().enumerate() {
        if i > 0 {
            f.write_str(", ")?;
        }
        write!(f, "{}", i8::from_ne_bytes([*b]))?;
    }
    f.write_str("]")
}

pub(crate) fn write_java_optional_bytes(
    f: &mut fmt::Formatter<'_>,
    bytes: Option<&[u8]>,
) -> fmt::Result {
    match bytes {
        None => f.write_str("null"),
        Some(b) => match std::str::from_utf8(b) {
            Ok(s) => f.write_str(s),
            Err(_) => write_java_byte_array(f, Some(b)),
        },
    }
}

pub(crate) fn write_java_record_headers(
    f: &mut fmt::Formatter<'_>,
    headers: &[Header],
    read_only: bool,
) -> fmt::Result {
    f.write_str("RecordHeaders(headers = [")?;
    for (i, h) in headers.iter().enumerate() {
        if i > 0 {
            f.write_str(", ")?;
        }
        write!(f, "{h}")?;
    }
    write!(f, "], isReadOnly = {read_only})")
}

pub(crate) fn write_java_optional<T: fmt::Display>(
    f: &mut fmt::Formatter<'_>,
    v: Option<T>,
) -> fmt::Result {
    match v {
        Some(n) => write!(f, "{n}"),
        None => f.write_str("null"),
    }
}

fn be_i16_at(buf: &[u8], offset: usize) -> Result<i16> {
    let b0 = buf
        .get(offset)
        .copied()
        .ok_or_else(|| Error::protocol("short control record"))?;
    let b1 = buf
        .get(offset.saturating_add(1))
        .copied()
        .ok_or_else(|| Error::protocol("short control record"))?;
    Ok(i16::from_be_bytes([b0, b1]))
}

fn be_i32_at(buf: &[u8], offset: usize) -> Result<i32> {
    let b0 = buf
        .get(offset)
        .copied()
        .ok_or_else(|| Error::protocol("short control record"))?;
    let b1 = buf
        .get(offset.saturating_add(1))
        .copied()
        .ok_or_else(|| Error::protocol("short control record"))?;
    let b2 = buf
        .get(offset.saturating_add(2))
        .copied()
        .ok_or_else(|| Error::protocol("short control record"))?;
    let b3 = buf
        .get(offset.saturating_add(3))
        .copied()
        .ok_or_else(|| Error::protocol("short control record"))?;
    Ok(i32::from_be_bytes([b0, b1, b2, b3]))
}

/// Java `ControlRecordType` (control-record key `type`).
///
/// [`std::fmt::Display`] is Java `ControlRecordType.toString` (`ABORT` / `COMMIT` /
/// `LEADER_CHANGE` / `SNAPSHOT_HEADER` / `SNAPSHOT_FOOTER` / `KRAFT_VERSION` /
/// `KRAFT_VOTERS` / `UNKNOWN`).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ControlRecordType {
    /// Java `ABORT` (`type` 0).
    Abort,
    /// Java `COMMIT` (`type` 1).
    Commit,
    /// Java `LEADER_CHANGE` (`type` 2).
    LeaderChange,
    /// Java `SNAPSHOT_HEADER` (`type` 3).
    SnapshotHeader,
    /// Java `SNAPSHOT_FOOTER` (`type` 4).
    SnapshotFooter,
    /// Java `KRAFT_VERSION` (`type` 5).
    KraftVersion,
    /// Java `KRAFT_VOTERS` (`type` 6).
    KraftVoters,
    /// Java `UNKNOWN` (`type` -1).
    Unknown,
}

impl ControlRecordType {
    /// Java `ControlRecordType.CURRENT_CONTROL_RECORD_KEY_VERSION` (package-private).
    const CURRENT_CONTROL_RECORD_KEY_VERSION: i16 = 0;
    /// Java `ControlRecordType.CURRENT_CONTROL_RECORD_KEY_SIZE` (package-private).
    const CURRENT_CONTROL_RECORD_KEY_SIZE: usize = 4;

    /// Java `ControlRecordType.type`.
    #[must_use]
    pub const fn type_id(self) -> i16 {
        match self {
            Self::Abort => 0,
            Self::Commit => 1,
            Self::LeaderChange => 2,
            Self::SnapshotHeader => 3,
            Self::SnapshotFooter => 4,
            Self::KraftVersion => 5,
            Self::KraftVoters => 6,
            Self::Unknown => -1,
        }
    }

    /// Java `ControlRecordType.fromTypeId`. Unknown ids are [`Self::Unknown`].
    #[must_use]
    pub const fn from_type_id(type_id: i16) -> Self {
        match type_id {
            0 => Self::Abort,
            1 => Self::Commit,
            2 => Self::LeaderChange,
            3 => Self::SnapshotHeader,
            4 => Self::SnapshotFooter,
            5 => Self::KraftVersion,
            6 => Self::KraftVoters,
            _ => Self::Unknown,
        }
    }

    /// Java `ControlRecordType.toString`.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Abort => "ABORT",
            Self::Commit => "COMMIT",
            Self::LeaderChange => "LEADER_CHANGE",
            Self::SnapshotHeader => "SNAPSHOT_HEADER",
            Self::SnapshotFooter => "SNAPSHOT_FOOTER",
            Self::KraftVersion => "KRAFT_VERSION",
            Self::KraftVoters => "KRAFT_VOTERS",
            Self::Unknown => "UNKNOWN",
        }
    }

    /// Java `ControlRecordType.parseTypeId`.
    pub fn parse_type_id(key: &[u8]) -> Result<i16> {
        if key.len() < Self::CURRENT_CONTROL_RECORD_KEY_SIZE {
            return Err(Error::protocol(format!(
                "Invalid value size found for end control record key. Must have at least {} bytes, but found only {}",
                Self::CURRENT_CONTROL_RECORD_KEY_SIZE,
                key.len()
            )));
        }
        let version = be_i16_at(key, 0)?;
        if version < 0 {
            return Err(Error::protocol(format!(
                "Invalid version found for control record: {version}. May indicate data corruption"
            )));
        }
        be_i16_at(key, 2)
    }

    /// Java `ControlRecordType.parse`.
    pub fn parse(key: &[u8]) -> Result<Self> {
        Ok(Self::from_type_id(Self::parse_type_id(key)?))
    }

    /// Java `ControlRecordType.recordKey` (version 0 key bytes). [`Self::Unknown`]
    /// cannot be serialized.
    pub fn record_key(self) -> Result<[u8; 4]> {
        if matches!(self, Self::Unknown) {
            return Err(Error::protocol(
                "Cannot serialize UNKNOWN control record type",
            ));
        }
        let tid = self.type_id().to_be_bytes();
        let hi = tid.first().copied().unwrap_or(0);
        let lo = tid.get(1).copied().unwrap_or(0);
        let ver = Self::CURRENT_CONTROL_RECORD_KEY_VERSION.to_be_bytes();
        let vh = ver.first().copied().unwrap_or(0);
        let vl = ver.get(1).copied().unwrap_or(0);
        Ok([vh, vl, hi, lo])
    }
}

impl fmt::Display for ControlRecordType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

/// One record inside a magic-v2 batch.
///
/// [`std::fmt::Display`] is Java `DefaultRecord.toString` (`key=N bytes`; null is
/// `0 bytes`, not `keySize` `-1`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Record {
    /// Log offset after decode; relative to the batch base when building with
    /// [`RecordBatch::from_records`].
    pub offset: i64,
    /// Timestamp in milliseconds since the Unix epoch.
    pub timestamp: i64,
    /// Optional key.
    pub key: Option<Bytes>,
    /// Optional value.
    pub value: Option<Bytes>,
    /// Record headers.
    pub headers: Vec<Header>,
}

impl Record {
    /// Java `Record.EMPTY_HEADERS`.
    pub const EMPTY_HEADERS: &'static [Header] = &[];
    /// Java `DefaultRecord.MAX_RECORD_OVERHEAD` (max bytes excluding key, value, and headers).
    pub const MAX_RECORD_OVERHEAD: i32 = 21;

    /// Java `Record.offset`.
    #[must_use]
    pub fn offset(&self) -> i64 {
        self.offset
    }

    /// Java `Record.timestamp`.
    #[must_use]
    pub fn timestamp(&self) -> i64 {
        self.timestamp
    }

    /// Java `Record.key` (`None` is Java `null`).
    #[must_use]
    pub fn key(&self) -> Option<&[u8]> {
        self.key.as_deref()
    }

    /// Java `Record.hasKey`.
    #[must_use]
    pub fn has_key(&self) -> bool {
        self.key.is_some()
    }

    /// Java `Record.value` (`None` is Java `null`).
    #[must_use]
    pub fn value(&self) -> Option<&[u8]> {
        self.value.as_deref()
    }

    /// Java `Record.hasValue`.
    #[must_use]
    pub fn has_value(&self) -> bool {
        self.value.is_some()
    }

    /// Java `Record.keySize` (`-1` when there is no key).
    #[must_use]
    pub fn key_size(&self) -> i32 {
        self.key
            .as_ref()
            .map(|b| i32::try_from(b.len()).unwrap_or(i32::MAX))
            .unwrap_or(-1)
    }

    /// Java `Record.valueSize` (`-1` when the value is null).
    #[must_use]
    pub fn value_size(&self) -> i32 {
        self.value
            .as_ref()
            .map(|b| i32::try_from(b.len()).unwrap_or(i32::MAX))
            .unwrap_or(-1)
    }

    /// Java `Record.headers`.
    #[must_use]
    pub fn headers(&self) -> &[Header] {
        &self.headers
    }

    /// Java `Headers.lastHeader`.
    #[must_use]
    pub fn last_header(&self, key: &str) -> Option<&Header> {
        Header::last_in(&self.headers, key)
    }

    /// Java `Headers.headers(String)`.
    pub fn headers_for_key<'a>(&'a self, key: &'a str) -> impl Iterator<Item = &'a Header> + 'a {
        Header::for_key(&self.headers, key)
    }

    /// Java `Record.hasMagic`. Magic-v2 is `true` when `magic` is 2 or greater.
    #[must_use]
    pub fn has_magic(&self, magic: i8) -> bool {
        magic >= MAGIC_V2
    }

    /// Java `DefaultRecord.isCompressed` (always `false`; compression is on the batch).
    #[must_use]
    pub fn is_compressed(&self) -> bool {
        false
    }

    /// Java `DefaultRecord.hasTimestampType` (always `false`; timestamp type is on the batch).
    #[must_use]
    pub fn has_timestamp_type(&self, _timestamp_type: TimestampType) -> bool {
        false
    }

    /// Java `DefaultRecord.sizeOfBodyInBytes` (no length-prefix varint).
    ///
    /// `offset_delta` / `timestamp_delta` are the magic-v2 relative fields
    /// (`offset - baseOffset`, `timestamp - baseTimestamp`).
    pub fn size_of_body_in_bytes(&self, offset_delta: i32, timestamp_delta: i64) -> Result<i32> {
        record_body_size(
            &EncodeRecord::from_record(self),
            offset_delta,
            timestamp_delta,
        )
    }

    /// Java `DefaultRecord.sizeInBytes(int, long, ByteBuffer, ByteBuffer, Header[])`.
    ///
    /// Body size plus the zigzag varint that prefixes the body on the wire.
    pub fn size_in_bytes(&self, offset_delta: i32, timestamp_delta: i64) -> Result<i32> {
        let body = self.size_of_body_in_bytes(offset_delta, timestamp_delta)?;
        body.checked_add(buf::size_of_varint(body))
            .ok_or_else(|| Error::protocol("length exceeds i32"))
    }

    /// Java `DefaultRecord.recordSizeUpperBound` (`MAX_RECORD_OVERHEAD` plus
    /// key, value, and headers; not the on-wire size).
    pub fn record_size_upper_bound(&self) -> Result<i32> {
        record_size_upper_bound(self.key(), self.value(), self.headers())
    }

    /// Control record for [`EndTransactionMarker`] (Java
    /// `MemoryRecordsBuilder.appendEndTxnMarker`).
    pub fn from_end_transaction_marker(
        timestamp: i64,
        marker: &EndTransactionMarker,
    ) -> Result<Self> {
        let key = marker.control_type().record_key()?;
        Ok(Self {
            offset: 0,
            timestamp,
            key: Some(Bytes::copy_from_slice(&key)),
            value: Some(Bytes::copy_from_slice(&marker.serialize_value())),
            headers: Vec::new(),
        })
    }
}

impl fmt::Display for Record {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("DefaultRecord(offset=")?;
        write!(f, "{}", self.offset())?;
        f.write_str(", timestamp=")?;
        write!(f, "{}", self.timestamp())?;
        f.write_str(", key=")?;
        write!(
            f,
            "{} bytes, value=",
            self.key.as_ref().map_or(0, Bytes::len)
        )?;
        write!(f, "{} bytes)", self.value.as_ref().map_or(0, Bytes::len))
    }
}

/// Java `EndTransactionMarker` (COMMIT/ABORT control record value).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct EndTransactionMarker {
    control_type: ControlRecordType,
    coordinator_epoch: i32,
}

impl EndTransactionMarker {
    /// Java `EndTransactionMarker.CURRENT_END_TXN_MARKER_VERSION` (package-private).
    const CURRENT_END_TXN_MARKER_VERSION: i16 = 0;
    /// Java `EndTransactionMarker.CURRENT_END_TXN_MARKER_VALUE_SIZE` (package-private).
    const CURRENT_END_TXN_MARKER_VALUE_SIZE: usize = 6;

    /// Java `EndTransactionMarker(ControlRecordType, int)`. Only
    /// [`ControlRecordType::Commit`] and [`ControlRecordType::Abort`] are valid.
    pub fn new(control_type: ControlRecordType, coordinator_epoch: i32) -> Result<Self> {
        Self::ensure_transaction_marker_control_type(control_type)?;
        Ok(Self {
            control_type,
            coordinator_epoch,
        })
    }

    /// Java `EndTransactionMarker.coordinatorEpoch`.
    #[must_use]
    pub fn coordinator_epoch(self) -> i32 {
        self.coordinator_epoch
    }

    /// Java `EndTransactionMarker.controlType`.
    #[must_use]
    pub fn control_type(self) -> ControlRecordType {
        self.control_type
    }

    /// Java `EndTransactionMarker.serializeValue`.
    #[must_use]
    pub fn serialize_value(self) -> [u8; 6] {
        let epoch = self.coordinator_epoch.to_be_bytes();
        let ver = Self::CURRENT_END_TXN_MARKER_VERSION.to_be_bytes();
        [
            ver.first().copied().unwrap_or(0),
            ver.get(1).copied().unwrap_or(0),
            epoch.first().copied().unwrap_or(0),
            epoch.get(1).copied().unwrap_or(0),
            epoch.get(2).copied().unwrap_or(0),
            epoch.get(3).copied().unwrap_or(0),
        ]
    }

    /// Java `EndTransactionMarker.deserialize`.
    pub fn deserialize(record: &Record) -> Result<Self> {
        let key = record
            .key
            .as_deref()
            .ok_or_else(|| Error::protocol("end transaction marker key is null"))?;
        let value = record
            .value
            .as_deref()
            .ok_or_else(|| Error::protocol("end transaction marker value is null"))?;
        let control_type = ControlRecordType::parse(key)?;
        Self::deserialize_value(control_type, value)
    }

    fn ensure_transaction_marker_control_type(control_type: ControlRecordType) -> Result<()> {
        if matches!(
            control_type,
            ControlRecordType::Commit | ControlRecordType::Abort
        ) {
            Ok(())
        } else {
            Err(Error::protocol(format!(
                "Invalid control record type for end transaction marker{control_type}"
            )))
        }
    }

    fn deserialize_value(control_type: ControlRecordType, value: &[u8]) -> Result<Self> {
        Self::ensure_transaction_marker_control_type(control_type)?;
        if value.len() < Self::CURRENT_END_TXN_MARKER_VALUE_SIZE {
            return Err(Error::protocol(format!(
                "Invalid value size found for end transaction marker. Must have at least {} bytes, but found only {}",
                Self::CURRENT_END_TXN_MARKER_VALUE_SIZE,
                value.len()
            )));
        }
        let version = be_i16_at(value, 0)?;
        if version < 0 {
            return Err(Error::protocol(format!(
                "Invalid version found for end transaction marker: {version}. May indicate data corruption"
            )));
        }
        let coordinator_epoch = be_i32_at(value, 2)?;
        Ok(Self {
            control_type,
            coordinator_epoch,
        })
    }
}

/// RecordBatch attributes: low three bits, the compression codec.
///
/// Java `DefaultRecordBatch.COMPRESSION_CODEC_MASK`. Codec 0 is uncompressed.
pub const ATTR_COMPRESSION_CODEC: i16 = 0x07;
/// RecordBatch attributes: transactional.
pub const ATTR_TRANSACTIONAL: i16 = 0x10;
/// RecordBatch attributes: control batch (commit/abort marker).
pub const ATTR_CONTROL: i16 = 0x20;
/// RecordBatch attributes: delete horizon. When set,
/// [`RecordBatch::delete_horizon_ms`] is [`RecordBatch::base_timestamp`].
pub const ATTR_DELETE_HORIZON: i16 = 0x40;
/// RecordBatch attributes bit 3: [`TimestampType::LogAppendTime`] when set,
/// [`TimestampType::CreateTime`] when clear (Java `TIMESTAMP_TYPE_MASK`).
pub const ATTR_TIMESTAMP_TYPE: i16 = 0x08;

/// Kafka record timestamp type (Java `TimestampType`).
///
/// Magic-v2 batches encode [`Self::CreateTime`] vs [`Self::LogAppendTime`] in
/// [`ATTR_TIMESTAMP_TYPE`]. [`Self::NoTimestampType`] is the legacy magic-v0
/// value; this crate does not produce it on the wire.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
#[repr(i8)]
pub enum TimestampType {
    /// Java `NO_TIMESTAMP_TYPE` (records without timestamps).
    NoTimestampType = -1,
    /// Java `CREATE_TIME` (producer timestamp).
    #[default]
    CreateTime = 0,
    /// Java `LOG_APPEND_TIME` (broker append time).
    LogAppendTime = 1,
}

impl TimestampType {
    /// Java `TimestampType.id`.
    #[must_use]
    pub fn id(self) -> i32 {
        i32::from(self as i8)
    }

    /// Java `TimestampType.name`.
    #[must_use]
    pub fn as_str(self) -> &'static str {
        match self {
            Self::NoTimestampType => "NoTimestampType",
            Self::CreateTime => "CreateTime",
            Self::LogAppendTime => "LogAppendTime",
        }
    }

    /// Parse Java `TimestampType.id`. Unknown values return `None`.
    #[must_use]
    pub fn from_id(id: i32) -> Option<Self> {
        match id {
            -1 => Some(Self::NoTimestampType),
            0 => Some(Self::CreateTime),
            1 => Some(Self::LogAppendTime),
            _ => None,
        }
    }

    /// Java `TimestampType.forName`.
    pub fn from_name(name: &str) -> Result<Self> {
        match name {
            "NoTimestampType" => Ok(Self::NoTimestampType),
            "CreateTime" => Ok(Self::CreateTime),
            "LogAppendTime" => Ok(Self::LogAppendTime),
            other => Err(Error::protocol(format!("Invalid timestamp type {other}"))),
        }
    }

    /// Magic-v2 batch attributes: bit 3 set is [`Self::LogAppendTime`].
    #[must_use]
    pub fn from_attributes(attr: i16) -> Self {
        if attr & ATTR_TIMESTAMP_TYPE == 0 {
            Self::CreateTime
        } else {
            Self::LogAppendTime
        }
    }
}

impl std::fmt::Display for TimestampType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Magic-v2 record batch (Kafka 0.11+).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RecordBatch {
    /// First offset in this batch.
    pub base_offset: i64,
    /// Partition leader epoch, or [`RecordBatch::NO_PARTITION_LEADER_EPOCH`].
    pub partition_leader_epoch: i32,
    /// Attribute bits: compression in the low 3, plus
    /// [`ATTR_TIMESTAMP_TYPE`] / [`ATTR_TRANSACTIONAL`] / [`ATTR_CONTROL`] /
    /// [`ATTR_DELETE_HORIZON`].
    pub attributes: i16,
    /// Timestamp of the first record (milliseconds since the Unix epoch).
    pub base_timestamp: i64,
    /// Max timestamp among records in this batch.
    pub max_timestamp: i64,
    /// Idempotent / transactional producer id, or [`RecordBatch::NO_PRODUCER_ID`].
    pub producer_id: i64,
    /// Producer epoch, or [`RecordBatch::NO_PRODUCER_EPOCH`].
    pub producer_epoch: i16,
    /// First sequence number in this batch, or [`RecordBatch::NO_SEQUENCE`].
    pub base_sequence: i32,
    /// Records in this batch.
    pub records: Vec<Record>,
}

impl RecordBatch {
    /// Java `RecordBatch.NO_TIMESTAMP`.
    pub const NO_TIMESTAMP: i64 = -1;
    /// Java `RecordBatch.NO_PRODUCER_ID`.
    pub const NO_PRODUCER_ID: i64 = -1;
    /// Java `RecordBatch.NO_PRODUCER_EPOCH`.
    pub const NO_PRODUCER_EPOCH: i16 = -1;
    /// Java `RecordBatch.NO_SEQUENCE`.
    pub const NO_SEQUENCE: i32 = -1;
    /// Java `RecordBatch.NO_PARTITION_LEADER_EPOCH`.
    pub const NO_PARTITION_LEADER_EPOCH: i32 = -1;
    /// Java `RecordBatch.MAGIC_VALUE_V0`. This crate does not encode magic-v0.
    pub const MAGIC_VALUE_V0: i8 = 0;
    /// Java `RecordBatch.MAGIC_VALUE_V1`. This crate does not encode magic-v1.
    pub const MAGIC_VALUE_V1: i8 = 1;
    /// Java `RecordBatch.MAGIC_VALUE_V2`. This crate speaks magic-v2 only.
    pub const MAGIC_VALUE_V2: i8 = MAGIC_V2;
    /// Java `RecordBatch.CURRENT_MAGIC_VALUE` ([`Self::MAGIC_VALUE_V2`]).
    pub const CURRENT_MAGIC_VALUE: i8 = Self::MAGIC_VALUE_V2;
    /// Java `DefaultRecordBatch.RECORD_BATCH_OVERHEAD` (bytes before the records).
    pub const RECORD_BATCH_OVERHEAD: i32 = 61;
    /// Java `DefaultRecordBatch.CRC_OFFSET`.
    pub const CRC_OFFSET: i32 = 17;
    /// Java `DefaultRecordBatch.ATTRIBUTES_OFFSET`.
    pub const ATTRIBUTES_OFFSET: i32 = Self::CRC_OFFSET + 4;
    /// Java `DefaultRecordBatch.LAST_OFFSET_DELTA_OFFSET`.
    pub const LAST_OFFSET_DELTA_OFFSET: i32 = 23;
    /// Java `DefaultRecordBatch.BASE_TIMESTAMP_OFFSET`.
    pub const BASE_TIMESTAMP_OFFSET: i32 = 27;
    /// Java `DefaultRecordBatch.PRODUCER_ID_OFFSET`.
    pub const PRODUCER_ID_OFFSET: i32 = 43;
    /// Java `DefaultRecordBatch.BASE_SEQUENCE_OFFSET`.
    pub const BASE_SEQUENCE_OFFSET: i32 = 53;
    /// Java `DefaultRecordBatch.RECORDS_COUNT_OFFSET`.
    pub const RECORDS_COUNT_OFFSET: i32 = 57;
    /// Default upper bound on decompressed batch bytes (64 MiB).
    pub const DEFAULT_MAX_DECODE_BYTES: usize = DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES;

    /// Build a batch from records. Offsets become `0..n`; timestamps set
    /// `base_timestamp` / `max_timestamp`. Producer id / epoch / sequence
    /// stay [`Self::NO_PRODUCER_ID`].
    pub fn from_records(mut records: Vec<Record>) -> Self {
        for (i, rec) in records.iter_mut().enumerate() {
            rec.offset = i64::try_from(i).unwrap_or(i64::MAX);
        }
        let base_timestamp = records.first().map(|r| r.timestamp).unwrap_or(0);
        let max_timestamp = records
            .iter()
            .map(|r| r.timestamp)
            .max()
            .unwrap_or(base_timestamp);
        Self {
            base_offset: 0,
            partition_leader_epoch: Self::NO_PARTITION_LEADER_EPOCH,
            attributes: 0,
            base_timestamp,
            max_timestamp,
            producer_id: Self::NO_PRODUCER_ID,
            producer_epoch: Self::NO_PRODUCER_EPOCH,
            base_sequence: Self::NO_SEQUENCE,
            records,
        }
    }

    /// Set the compression bits in [`Self::attributes`].
    pub fn with_compression(mut self, compression: Compression) -> Self {
        self.attributes = (self.attributes & !ATTR_COMPRESSION_CODEC) | (compression as i16);
        self
    }

    /// Java `DefaultRecordBatch.timestampType` from [`Self::attributes`].
    #[must_use]
    pub fn timestamp_type(&self) -> TimestampType {
        TimestampType::from_attributes(self.attributes)
    }

    /// Set [`ATTR_TIMESTAMP_TYPE`] for [`TimestampType::LogAppendTime`].
    ///
    /// [`TimestampType::NoTimestampType`] is encoded as
    /// [`TimestampType::CreateTime`] (magic-v2 has no "no timestamp" bit).
    #[must_use]
    pub fn with_timestamp_type(mut self, timestamp_type: TimestampType) -> Self {
        match timestamp_type {
            TimestampType::LogAppendTime => self.attributes |= ATTR_TIMESTAMP_TYPE,
            TimestampType::CreateTime | TimestampType::NoTimestampType => {
                self.attributes &= !ATTR_TIMESTAMP_TYPE;
            }
        }
        self
    }

    /// Java `DefaultRecordBatch.isTransactional`.
    #[must_use]
    pub fn is_transactional(&self) -> bool {
        self.attributes & ATTR_TRANSACTIONAL != 0
    }

    /// Java `DefaultRecordBatch.isControlBatch`.
    #[must_use]
    pub fn is_control_batch(&self) -> bool {
        self.attributes & ATTR_CONTROL != 0
    }

    /// Set [`ATTR_TRANSACTIONAL`].
    #[must_use]
    pub fn with_transactional(mut self, transactional: bool) -> Self {
        if transactional {
            self.attributes |= ATTR_TRANSACTIONAL;
        } else {
            self.attributes &= !ATTR_TRANSACTIONAL;
        }
        self
    }

    /// Set [`ATTR_CONTROL`].
    #[must_use]
    pub fn with_control_batch(mut self, control: bool) -> Self {
        if control {
            self.attributes |= ATTR_CONTROL;
        } else {
            self.attributes &= !ATTR_CONTROL;
        }
        self
    }

    /// Java `MemoryRecords.withEndTransactionMarker`.
    ///
    /// Builds a transactional control batch with one COMMIT/ABORT record.
    /// [`Self::base_sequence`] is [`Self::NO_SEQUENCE`].
    pub fn with_end_transaction_marker(
        initial_offset: i64,
        timestamp: i64,
        partition_leader_epoch: i32,
        producer_id: i64,
        producer_epoch: i16,
        marker: &EndTransactionMarker,
    ) -> Result<Self> {
        let rec = Record::from_end_transaction_marker(timestamp, marker)?;
        let mut batch = Self::from_records(vec![rec])
            .with_transactional(true)
            .with_control_batch(true);
        batch.base_offset = initial_offset;
        batch.partition_leader_epoch = partition_leader_epoch;
        batch.producer_id = producer_id;
        batch.producer_epoch = producer_epoch;
        batch.base_sequence = Self::NO_SEQUENCE;
        Ok(batch)
    }

    /// Java `DefaultRecordBatch.magic` (this crate speaks magic-v2 only).
    #[must_use]
    pub fn magic(&self) -> i8 {
        Self::CURRENT_MAGIC_VALUE
    }

    /// Java `DefaultRecordBatch.baseOffset`.
    #[must_use]
    pub fn base_offset(&self) -> i64 {
        self.base_offset
    }

    /// Java `DefaultRecordBatch.lastOffset` (`baseOffset + count - 1`).
    #[must_use]
    pub fn last_offset(&self) -> i64 {
        self.base_offset.saturating_add(self.record_count_i64() - 1)
    }

    /// Java `DefaultRecordBatch.nextOffset` (`lastOffset + 1`).
    #[must_use]
    pub fn next_offset(&self) -> i64 {
        self.base_offset.saturating_add(self.record_count_i64())
    }

    /// Java `DefaultRecordBatch.count`.
    #[must_use]
    pub fn count(&self) -> usize {
        self.records.len()
    }

    /// Java `RecordBatch.countOrNull`. Magic-v2 always has a count.
    #[must_use]
    pub fn count_or_null(&self) -> Option<i32> {
        Some(i32::try_from(self.records.len()).unwrap_or(i32::MAX))
    }

    /// Records in this batch.
    #[must_use]
    pub fn records(&self) -> &[Record] {
        &self.records
    }

    /// Java `DefaultRecordBatch.partitionLeaderEpoch` (`-1` when unknown).
    #[must_use]
    pub fn partition_leader_epoch(&self) -> i32 {
        self.partition_leader_epoch
    }

    /// Java `DefaultRecordBatch.baseTimestamp`.
    #[must_use]
    pub fn base_timestamp(&self) -> i64 {
        self.base_timestamp
    }

    /// Java `DefaultRecordBatch.maxTimestamp`.
    #[must_use]
    pub fn max_timestamp(&self) -> i64 {
        self.max_timestamp
    }

    /// Java `DefaultRecordBatch.producerId` (`-1` when none).
    #[must_use]
    pub fn producer_id(&self) -> i64 {
        self.producer_id
    }

    /// Java `AbstractRecordBatch.hasProducerId` (`NO_PRODUCER_ID < producerId`).
    #[must_use]
    pub fn has_producer_id(&self) -> bool {
        Self::NO_PRODUCER_ID < self.producer_id
    }

    /// Java `DefaultRecordBatch.producerEpoch` (`-1` when none).
    #[must_use]
    pub fn producer_epoch(&self) -> i16 {
        self.producer_epoch
    }

    /// Java `DefaultRecordBatch.baseSequence` (`-1` when none).
    #[must_use]
    pub fn base_sequence(&self) -> i32 {
        self.base_sequence
    }

    /// Java `DefaultRecordBatch.lastSequence`.
    ///
    /// [`Self::NO_SEQUENCE`] when [`Self::base_sequence`] is unset. Otherwise
    /// [`Self::increment_sequence`] of the base and last-offset delta
    /// (`count - 1`, or `0` when empty — same as the encode path).
    #[must_use]
    pub fn last_sequence(&self) -> i32 {
        if self.base_sequence == Self::NO_SEQUENCE {
            return Self::NO_SEQUENCE;
        }
        Self::increment_sequence(self.base_sequence, self.last_offset_delta())
    }

    /// Java `DefaultRecordBatch.incrementSequence` (wraps past [`i32::MAX`]
    /// to `0`).
    #[must_use]
    pub fn increment_sequence(sequence: i32, increment: i32) -> i32 {
        if sequence > i32::MAX.wrapping_sub(increment) {
            increment
                .wrapping_sub(i32::MAX.wrapping_sub(sequence))
                .wrapping_sub(1)
        } else {
            sequence.wrapping_add(increment)
        }
    }

    /// Java `DefaultRecordBatch.decrementSequence` (wraps below `0` to
    /// [`i32::MAX`]).
    #[must_use]
    pub fn decrement_sequence(sequence: i32, decrement: i32) -> i32 {
        if sequence < decrement {
            i32::MAX
                .wrapping_sub(decrement.wrapping_sub(sequence))
                .wrapping_add(1)
        } else {
            sequence.wrapping_sub(decrement)
        }
    }

    /// Java `DefaultRecordBatch.compressionType`.
    pub fn compression_type(&self) -> Result<Compression> {
        Compression::from_attributes(self.attributes)
    }

    /// Java `RecordBatch.isCompressed` (attributes codec bits are not
    /// [`Compression::None`]).
    #[must_use]
    pub fn is_compressed(&self) -> bool {
        self.attributes & ATTR_COMPRESSION_CODEC != 0
    }

    /// Set [`ATTR_DELETE_HORIZON`]. When set, [`Self::delete_horizon_ms`] is
    /// [`Self::base_timestamp`].
    #[must_use]
    pub fn with_delete_horizon(mut self, delete_horizon: bool) -> Self {
        if delete_horizon {
            self.attributes |= ATTR_DELETE_HORIZON;
        } else {
            self.attributes &= !ATTR_DELETE_HORIZON;
        }
        self
    }

    /// Java `RecordBatch.deleteHorizonMs` (`baseTimestamp` when
    /// [`ATTR_DELETE_HORIZON`] is set).
    #[must_use]
    pub fn delete_horizon_ms(&self) -> Option<i64> {
        if self.attributes & ATTR_DELETE_HORIZON != 0 {
            Some(self.base_timestamp)
        } else {
            None
        }
    }

    /// Java `RecordBatch.offsetOfMaxTimestamp` (earliest offset among records
    /// with [`Self::max_timestamp`]; `None` when none match).
    #[must_use]
    pub fn offset_of_max_timestamp(&self) -> Option<i64> {
        let max = self.max_timestamp;
        self.records
            .iter()
            .find(|r| r.timestamp == max)
            .map(|r| r.offset)
    }

    fn last_offset_delta(&self) -> i32 {
        let count = i32::try_from(self.records.len()).unwrap_or(i32::MAX);
        if count <= 0 {
            0
        } else {
            count - 1
        }
    }

    fn record_count_i64(&self) -> i64 {
        i64::try_from(self.records.len()).unwrap_or(i64::MAX)
    }

    /// Encoded size of this batch, including compression.
    ///
    /// Distinct from [`Self::encoded_size_in_bytes`], which reads the length
    /// field from a buffer (Java `DefaultRecordBatch.sizeInBytes()`).
    pub fn size_in_bytes(&self) -> Result<i32> {
        buf::i32_from_usize(self.encoded()?.len())
    }

    /// Java `DefaultRecordBatch.sizeInBytes()` on a buffer
    /// (`Records.LOG_OVERHEAD` plus the length field at
    /// [`Records::SIZE_OFFSET`]).
    ///
    /// Uses wrapping add (Java `int` overflow). Short size field is
    /// [`crate::Error::protocol`] `need 4 bytes`. Distinct from [`Self::size_in_bytes`],
    /// which encodes this batch.
    pub fn encoded_size_in_bytes(buffer: &[u8]) -> Result<i32> {
        let size_off = buf::usize_from_i32(Records::SIZE_OFFSET)?;
        let record_size = buf::read_int_be(buffer, size_off)?;
        Ok(Records::LOG_OVERHEAD.wrapping_add(record_size))
    }

    fn read_i64_be(buffer: &[u8], offset: usize) -> Result<i64> {
        let have = buffer.len().saturating_sub(offset);
        let end = offset
            .checked_add(8)
            .ok_or_else(|| Error::protocol(format!("need 8 bytes, have {have}")))?;
        let slice = buffer
            .get(offset..end)
            .ok_or_else(|| Error::protocol(format!("need 8 bytes, have {have}")))?;
        let arr = <[u8; 8]>::try_from(slice)
            .map_err(|_| Error::protocol(format!("need 8 bytes, have {have}")))?;
        Ok(i64::from_be_bytes(arr))
    }

    fn read_i16_be(buffer: &[u8], offset: usize) -> Result<i16> {
        let have = buffer.len().saturating_sub(offset);
        let end = offset
            .checked_add(2)
            .ok_or_else(|| Error::protocol(format!("need 2 bytes, have {have}")))?;
        let slice = buffer
            .get(offset..end)
            .ok_or_else(|| Error::protocol(format!("need 2 bytes, have {have}")))?;
        let arr = <[u8; 2]>::try_from(slice)
            .map_err(|_| Error::protocol(format!("need 2 bytes, have {have}")))?;
        Ok(i16::from_be_bytes(arr))
    }

    /// Java `DefaultRecordBatch.lastOffset` on a buffer (`baseOffset` plus
    /// `lastOffsetDelta` at [`Self::LAST_OFFSET_DELTA_OFFSET`]).
    ///
    /// Uses wrapping add (Java `long` overflow). Distinct from
    /// [`Self::last_offset`], which uses `count - 1`. Short base-offset or
    /// last-offset-delta fields are [`crate::Error::protocol`] `need N bytes`.
    pub fn encoded_last_offset(buffer: &[u8]) -> Result<i64> {
        let base_off = buf::usize_from_i32(Records::OFFSET_OFFSET)?;
        let base = Self::read_i64_be(buffer, base_off)?;
        let delta_off = buf::usize_from_i32(Self::LAST_OFFSET_DELTA_OFFSET)?;
        let delta = buf::read_int_be(buffer, delta_off)?;
        Ok(base.wrapping_add(i64::from(delta)))
    }

    /// Read the last-offset delta stored in a magic-v2 batch header.
    ///
    /// Retain this value when re-encoding a compacted batch: the last
    /// surviving record need not be the final offset represented by the batch.
    pub fn encoded_last_offset_delta(buffer: &[u8]) -> Result<i32> {
        let offset = buf::usize_from_i32(Self::LAST_OFFSET_DELTA_OFFSET)?;
        buf::read_int_be(buffer, offset)
    }

    /// Java `DefaultRecordBatch.nextOffset` on a buffer
    /// ([`Self::encoded_last_offset`] plus one).
    pub fn encoded_next_offset(buffer: &[u8]) -> Result<i64> {
        Ok(Self::encoded_last_offset(buffer)?.wrapping_add(1))
    }

    fn write_i64_be(buffer: &mut [u8], offset: usize, value: i64) -> Result<()> {
        let have = buffer.len().saturating_sub(offset);
        let end = offset
            .checked_add(8)
            .ok_or_else(|| Error::protocol(format!("need 8 bytes, have {have}")))?;
        let slice = buffer
            .get_mut(offset..end)
            .ok_or_else(|| Error::protocol(format!("need 8 bytes, have {have}")))?;
        slice.copy_from_slice(&value.to_be_bytes());
        Ok(())
    }

    /// Java `DefaultRecordBatch.setLastOffset` on a buffer.
    ///
    /// Writes `baseOffset` so [`Self::encoded_last_offset`] equals
    /// `last_offset` (`lastOffset` minus header `lastOffsetDelta`, wrapping
    /// subtract). Does not recompute CRC (base offset is before
    /// [`Self::ATTRIBUTES_OFFSET`]). Distinct from mutating this batch's
    /// [`Self::base_offset`]. Short last-offset-delta is
    /// [`crate::Error::protocol`] `need 4 bytes`.
    pub fn set_last_offset(buffer: &mut [u8], last_offset: i64) -> Result<()> {
        let delta_off = buf::usize_from_i32(Self::LAST_OFFSET_DELTA_OFFSET)?;
        let delta = buf::read_int_be(buffer, delta_off)?;
        let base = last_offset.wrapping_sub(i64::from(delta));
        let base_off = buf::usize_from_i32(Records::OFFSET_OFFSET)?;
        Self::write_i64_be(buffer, base_off, base)
    }

    /// Java `DefaultRecordBatch.lastSequence` on a buffer.
    ///
    /// [`Self::NO_SEQUENCE`] when the stored base sequence is unset (delta is
    /// not read). Otherwise [`Self::increment_sequence`] of the base sequence
    /// and header `lastOffsetDelta`. Distinct from [`Self::last_sequence`],
    /// which uses `count - 1`. Short sequence or delta fields are
    /// [`crate::Error::protocol`] `need 4 bytes`.
    pub fn encoded_last_sequence(buffer: &[u8]) -> Result<i32> {
        let seq_off = buf::usize_from_i32(Self::BASE_SEQUENCE_OFFSET)?;
        let base_sequence = buf::read_int_be(buffer, seq_off)?;
        if base_sequence == Self::NO_SEQUENCE {
            return Ok(Self::NO_SEQUENCE);
        }
        let delta_off = buf::usize_from_i32(Self::LAST_OFFSET_DELTA_OFFSET)?;
        let delta = buf::read_int_be(buffer, delta_off)?;
        Ok(Self::increment_sequence(base_sequence, delta))
    }

    fn encoded_attributes(buffer: &[u8]) -> Result<i16> {
        let attr_off = buf::usize_from_i32(Self::ATTRIBUTES_OFFSET)?;
        Self::read_i16_be(buffer, attr_off)
    }

    /// Java `DefaultRecordBatch.deleteHorizonMs` on a buffer.
    ///
    /// Unset [`ATTR_DELETE_HORIZON`] is `None` without reading
    /// [`Self::BASE_TIMESTAMP_OFFSET`]. Otherwise the stored base timestamp.
    /// Distinct from [`Self::delete_horizon_ms`], which uses this batch's
    /// fields. Short attributes or timestamp fields are [`crate::Error::protocol`]
    /// `need N bytes`.
    pub fn encoded_delete_horizon_ms(buffer: &[u8]) -> Result<Option<i64>> {
        let attributes = Self::encoded_attributes(buffer)?;
        if attributes & ATTR_DELETE_HORIZON == 0 {
            return Ok(None);
        }
        let ts_off = buf::usize_from_i32(Self::BASE_TIMESTAMP_OFFSET)?;
        Ok(Some(Self::read_i64_be(buffer, ts_off)?))
    }

    /// Java `DefaultRecordBatch.isTransactional` on a buffer.
    ///
    /// Distinct from [`Self::is_transactional`], which uses this batch's
    /// attributes. Short attributes field is [`crate::Error::protocol`] `need 2 bytes`.
    pub fn encoded_is_transactional(buffer: &[u8]) -> Result<bool> {
        Ok(Self::encoded_attributes(buffer)? & ATTR_TRANSACTIONAL != 0)
    }

    /// Java `DefaultRecordBatch.isControlBatch` on a buffer.
    ///
    /// Distinct from [`Self::is_control_batch`], which uses this batch's
    /// attributes. Short attributes field is [`crate::Error::protocol`] `need 2 bytes`.
    pub fn encoded_is_control_batch(buffer: &[u8]) -> Result<bool> {
        Ok(Self::encoded_attributes(buffer)? & ATTR_CONTROL != 0)
    }

    /// Java `DefaultRecordBatch.timestampType` on a buffer.
    ///
    /// Distinct from [`Self::timestamp_type`], which uses this batch's
    /// attributes. Short attributes field is [`crate::Error::protocol`] `need 2 bytes`.
    pub fn encoded_timestamp_type(buffer: &[u8]) -> Result<TimestampType> {
        Ok(TimestampType::from_attributes(Self::encoded_attributes(
            buffer,
        )?))
    }

    /// Java `AbstractRecordBatch.hasProducerId` on a buffer (producer id is
    /// greater than [`Self::NO_PRODUCER_ID`]).
    ///
    /// Distinct from [`Self::has_producer_id`], which uses this batch's
    /// producer id. Short producer-id field is [`crate::Error::protocol`]
    /// `need 8 bytes`.
    pub fn encoded_has_producer_id(buffer: &[u8]) -> Result<bool> {
        let off = buf::usize_from_i32(Self::PRODUCER_ID_OFFSET)?;
        Ok(Self::NO_PRODUCER_ID < Self::read_i64_be(buffer, off)?)
    }

    /// Java `DefaultRecordBatch.countOrNull` on a buffer (header records
    /// count at [`Self::RECORDS_COUNT_OFFSET`]).
    ///
    /// Magic-v2 is always `Some` (Java never returns null). Distinct from
    /// [`Self::count_or_null`], which uses `records.len()`. Short count field
    /// is [`crate::Error::protocol`] `need 4 bytes`.
    pub fn encoded_count_or_null(buffer: &[u8]) -> Result<Option<i32>> {
        let off = buf::usize_from_i32(Self::RECORDS_COUNT_OFFSET)?;
        Ok(Some(buf::read_int_be(buffer, off)?))
    }

    /// Java `DefaultRecordBatch.checksum` (unsigned CRC32-C as `long`).
    pub fn checksum(&self) -> Result<u32> {
        let buf = self.encoded()?;
        let off = buf::usize_from_i32(Self::CRC_OFFSET)?;
        let end = off.saturating_add(4);
        let bytes = buf
            .get(off..end)
            .ok_or_else(|| Error::protocol("short crc field"))?;
        let arr = <[u8; 4]>::try_from(bytes).map_err(|_| Error::protocol("short crc field"))?;
        Ok(u32::from_be_bytes(arr))
    }

    /// Java `DefaultRecordBatch.isValid`.
    ///
    /// Declared size ([`Self::encoded_size_in_bytes`]) below
    /// [`Self::RECORD_BATCH_OVERHEAD`] is `false`. Otherwise the stored CRC must
    /// match CRC32-C of the bytes from [`Self::ATTRIBUTES_OFFSET`] to the end of
    /// `buffer`. Short size or CRC fields are [`crate::Error::protocol`] `need 4 bytes`.
    pub fn is_valid(buffer: &[u8]) -> Result<bool> {
        if Self::encoded_size_in_bytes(buffer)? < Self::RECORD_BATCH_OVERHEAD {
            return Ok(false);
        }
        let crc_off = buf::usize_from_i32(Self::CRC_OFFSET)?;
        let stored = buf::read_unsigned_int_at(buffer, crc_off)?;
        let attr_off = buf::usize_from_i32(Self::ATTRIBUTES_OFFSET)?;
        let rest = buffer
            .get(attr_off..)
            .ok_or_else(|| Error::protocol("short attributes field"))?;
        Ok(stored == i64::from(crc32c::crc32c(rest)))
    }

    /// Java `DefaultRecordBatch.ensureValid`.
    ///
    /// Declared size ([`Self::encoded_size_in_bytes`]) below
    /// [`Self::RECORD_BATCH_OVERHEAD`] is [`crate::Error::protocol`] matching Java
    /// `CorruptRecordException` (`Record batch is corrupt`). Otherwise a CRC
    /// mismatch is [`crate::Error::protocol`] `Record is corrupt` (stored vs computed
    /// over bytes from [`Self::ATTRIBUTES_OFFSET`] to the end of `buffer`).
    /// Short size or CRC fields are [`crate::Error::protocol`] `need 4 bytes`.
    /// Distinct from [`decode_record_batch`], which CRC-checks the declared
    /// body only.
    pub fn ensure_valid(buffer: &[u8]) -> Result<()> {
        let size_in_bytes = Self::encoded_size_in_bytes(buffer)?;
        if size_in_bytes < Self::RECORD_BATCH_OVERHEAD {
            return Err(Error::protocol(format!(
                "Record batch is corrupt (the size {size_in_bytes} is smaller than the minimum allowed overhead {})",
                Self::RECORD_BATCH_OVERHEAD
            )));
        }
        if Self::is_valid(buffer)? {
            return Ok(());
        }
        let crc_off = buf::usize_from_i32(Self::CRC_OFFSET)?;
        let stored = buf::read_unsigned_int_at(buffer, crc_off)?;
        let attr_off = buf::usize_from_i32(Self::ATTRIBUTES_OFFSET)?;
        let rest = buffer
            .get(attr_off..)
            .ok_or_else(|| Error::protocol("short attributes field"))?;
        let computed = i64::from(crc32c::crc32c(rest));
        Err(Error::protocol(format!(
            "Record is corrupt (stored crc = {stored}, computed crc = {computed})"
        )))
    }

    /// Java `DefaultRecordBatch.sizeInBytes(Iterable)` (uncompressed).
    ///
    /// Empty is `0` (not [`Self::RECORD_BATCH_OVERHEAD`]). Offset deltas are
    /// `0..n`; timestamps are relative to the first record.
    pub fn size_in_bytes_of(records: &[Record]) -> Result<i32> {
        record_batch_size_in_bytes(records, None)
    }

    /// Java `DefaultRecordBatch.sizeInBytes(long, Iterable)` (uncompressed).
    ///
    /// Empty is `0`. Offset deltas are `record.offset - base_offset`;
    /// timestamps are relative to the first record.
    pub fn size_in_bytes_from(base_offset: i64, records: &[Record]) -> Result<i32> {
        record_batch_size_in_bytes(records, Some(base_offset))
    }

    /// Java `DefaultRecordBatch.estimateBatchSizeUpperBound` (one-record batch
    /// overhead; compression is not included).
    pub fn estimate_batch_size_upper_bound(
        key: Option<&[u8]>,
        value: Option<&[u8]>,
        headers: &[Header],
    ) -> Result<i32> {
        buf::i32_from_usize(
            buf::usize_from_i32(Self::RECORD_BATCH_OVERHEAD)?
                + buf::usize_from_i32(record_size_upper_bound(key, value, headers)?)?,
        )
    }

    fn encoded(&self) -> Result<BytesMut> {
        let mut buf = BytesMut::new();
        encode_record_batch(&mut buf, self)?;
        Ok(buf)
    }
}

impl fmt::Display for RecordBatch {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let crc = self.checksum().unwrap_or(0);
        let compression = self.compression_type().unwrap_or(Compression::None);
        f.write_str("RecordBatch(magic=")?;
        write!(f, "{}", self.magic())?;
        f.write_str(", offsets=[")?;
        write!(f, "{}, {}", self.base_offset(), self.last_offset())?;
        f.write_str("], sequence=[")?;
        write!(f, "{}, {}", self.base_sequence(), self.last_sequence())?;
        f.write_str("], isTransactional=")?;
        write!(f, "{}", self.is_transactional())?;
        f.write_str(", isControlBatch=")?;
        write!(f, "{}", self.is_control_batch())?;
        f.write_str(", compression=")?;
        write!(f, "{compression}")?;
        f.write_str(", timestampType=")?;
        write!(f, "{}", self.timestamp_type())?;
        f.write_str(", crc=")?;
        write!(f, "{crc}")?;
        f.write_str(")")
    }
}

fn gzip_compress_into(src: &[u8], out: &mut Vec<u8>) -> Result<()> {
    // KL09-33: pre-size the output with Java's size/2 estimate so the common
    // case allocates once instead of growing through a doubling chain.
    // `reserve` reuses already-held capacity; the encoder takes ownership
    // of the buffer and `finish` hands it back.
    out.clear();
    let est =
        estimate_compressed_size_in_bytes(compress_estimate_input(src.len()), Compression::Gzip);
    out.reserve(buf::usize_from_i32(est).unwrap_or(0));
    let owned = std::mem::take(out);
    let mut encoder = flate2::write::GzEncoder::new(owned, flate2::Compression::default());
    encoder
        .write_all(src)
        .map_err(|e| Error::protocol(e.to_string()))?;
    *out = encoder
        .finish()
        .map_err(|e| Error::protocol(e.to_string()))?;
    Ok(())
}

/// [`gzip_compress_into`], feeding the encoder 8 KiB at a time.
///
/// Slices are written with no flush between them, so the member matches
/// [`gzip_compress_into`]. The pause between slices lets a caller deadline
/// run while a multi-megabyte section is still being packed.
async fn gzip_compress_into_cooperative(src: &[u8], out: &mut Vec<u8>) -> Result<()> {
    out.clear();
    let est =
        estimate_compressed_size_in_bytes(compress_estimate_input(src.len()), Compression::Gzip);
    out.reserve(buf::usize_from_i32(est).unwrap_or(0));
    let owned = std::mem::take(out);
    let mut encoder = flate2::write::GzEncoder::new(owned, flate2::Compression::default());
    let mut offset = 0usize;
    while offset < src.len() {
        let end = offset.saturating_add(8 * 1024).min(src.len());
        let piece = src
            .get(offset..end)
            .ok_or_else(|| Error::protocol("gzip chunk"))?;
        encoder
            .write_all(piece)
            .map_err(|e| Error::protocol(e.to_string()))?;
        offset = end;
        if offset < src.len() {
            tokio::task::yield_now().await;
        }
    }
    *out = encoder
        .finish()
        .map_err(|e| Error::protocol(e.to_string()))?;
    Ok(())
}

fn read_bounded<R: Read>(reader: &mut R, max_bytes: usize, reserve: usize) -> Result<Vec<u8>> {
    let mut out = Vec::new();
    let hint = reserve.min(max_bytes);
    if hint > 0 {
        out.try_reserve(hint)
            .map_err(|_| Error::protocol("decompressed batch reserve"))?;
    }
    let mut chunk = [0u8; 8192];
    loop {
        let remaining_budget_plus_one = max_bytes.saturating_sub(out.len()).saturating_add(1);
        let to_read = chunk.len().min(remaining_budget_plus_one);
        let slice = chunk
            .get_mut(..to_read)
            .ok_or_else(|| Error::protocol("invalid chunk slice"))?;
        let n = reader
            .read(slice)
            .map_err(|e| Error::protocol(e.to_string()))?;
        if n == 0 {
            break;
        }
        if out.len().saturating_add(n) > max_bytes {
            return Err(Error::protocol(
                "Decompressed batch exceeds maximum allowable size",
            ));
        }
        let piece = chunk
            .get(..n)
            .ok_or_else(|| Error::protocol("invalid chunk slice"))?;
        out.extend_from_slice(piece);
    }
    Ok(out)
}

async fn read_bounded_cooperative<R: Read>(
    reader: &mut R,
    max_bytes: usize,
    reserve: usize,
) -> Result<Vec<u8>> {
    let mut out = Vec::new();
    let hint = reserve.min(max_bytes);
    if hint > 0 {
        out.try_reserve(hint)
            .map_err(|_| Error::protocol("decompressed batch reserve"))?;
    }
    let mut chunk = [0u8; 8192];
    let mut since_yield = 0usize;
    loop {
        let remaining_budget_plus_one = max_bytes.saturating_sub(out.len()).saturating_add(1);
        let to_read = chunk.len().min(remaining_budget_plus_one);
        let slice = chunk
            .get_mut(..to_read)
            .ok_or_else(|| Error::protocol("invalid chunk slice"))?;
        let n = reader
            .read(slice)
            .map_err(|e| Error::protocol(e.to_string()))?;
        if n == 0 {
            break;
        }
        if out.len().saturating_add(n) > max_bytes {
            return Err(Error::protocol(
                "Decompressed batch exceeds maximum allowable size",
            ));
        }
        let piece = chunk
            .get(..n)
            .ok_or_else(|| Error::protocol("invalid chunk slice"))?;
        out.extend_from_slice(piece);
        since_yield = since_yield.saturating_add(n);
        if since_yield >= 8 * 1024 && out.len() < max_bytes {
            since_yield = 0;
            tokio::task::yield_now().await;
        }
    }
    Ok(out)
}

fn gzip_isize(src: &[u8]) -> Option<usize> {
    if src.len() < 18 || src.get(..2) != Some(&[0x1f, 0x8b]) {
        return None;
    }
    let tail = src.get(src.len().saturating_sub(4)..)?;
    let bytes: [u8; 4] = tail.try_into().ok()?;
    usize::try_from(u32::from_le_bytes(bytes)).ok()
}

fn gzip_reserve(src: &[u8], max_bytes: usize) -> usize {
    gzip_isize(src)
        .filter(|size| *size <= max_bytes)
        .map(|size| size.min(src.len().saturating_mul(64)))
        .unwrap_or(0)
}

fn gzip_decompress(src: &[u8], max_bytes: usize) -> Result<Vec<u8>> {
    let mut decoder = flate2::read::GzDecoder::new(src);
    read_bounded(&mut decoder, max_bytes, gzip_reserve(src, max_bytes))
}

async fn gzip_decompress_cooperative(src: &[u8], max_bytes: usize) -> Result<Vec<u8>> {
    let mut decoder = flate2::read::GzDecoder::new(src);
    read_bounded_cooperative(&mut decoder, max_bytes, gzip_reserve(src, max_bytes)).await
}

/// xerial snappy-java header used by the Java Kafka client.
/// 8 magic + 4 version + 4 compatible, then chunks of [be32 clen][snappy].
const SNAPPY_JAVA_MAGIC: &[u8] = &[0x82, b'S', b'N', b'A', b'P', b'P', b'Y', 0];

fn snappy_compress_into(src: &[u8], out: &mut Vec<u8>) -> Result<()> {
    // KL09-33: compress directly behind the 20-byte xerial framing in one
    // allocation instead of `compress_vec` plus a framing copy. snap's
    // `compress_vec` allocates `max_compress_len` without shrinking, so the
    // single buffer is no larger than the old first allocation; the emitted
    // chunk bytes are identical (`Encoder::compress` is the same routine).
    let mut encoder = snap::raw::Encoder::new();
    let max = snap::raw::max_compress_len(src.len());
    out.clear();
    out.resize(20usize.saturating_add(max), 0);
    out.get_mut(..8)
        .ok_or_else(|| Error::protocol("snappy framing short"))?
        .copy_from_slice(SNAPPY_JAVA_MAGIC);
    out.get_mut(8..12)
        .ok_or_else(|| Error::protocol("snappy framing short"))?
        .copy_from_slice(&1u32.to_be_bytes());
    out.get_mut(12..16)
        .ok_or_else(|| Error::protocol("snappy framing short"))?
        .copy_from_slice(&1u32.to_be_bytes());
    let dst = out
        .get_mut(20..)
        .ok_or_else(|| Error::protocol("snappy framing short"))?;
    let n = encoder
        .compress(src, dst)
        .map_err(|e| Error::protocol(e.to_string()))?;
    out.truncate(20 + n);
    let clen = buf::u32_from_usize(n)?;
    out.get_mut(16..20)
        .ok_or_else(|| Error::protocol("snappy framing short"))?
        .copy_from_slice(&clen.to_be_bytes());
    Ok(())
}

/// Inline snappy decompress stays on the caller at or below this compressed length.
///
/// A 3.2 MiB frame expanded in 74ms. A 4.6 MiB frame took 110ms, so a larger
/// frame is expanded on the blocking pool. The bytes match [`snappy_decompress`].
const SNAPPY_DECOMPRESS_INLINE: usize = 2 * 1024 * 1024;

async fn snappy_decompress_cooperative(src: Bytes, max_bytes: usize) -> Result<Vec<u8>> {
    if src.len() <= SNAPPY_DECOMPRESS_INLINE {
        return snappy_decompress(&src, max_bytes);
    }
    tokio::task::spawn_blocking(move || snappy_decompress(&src, max_bytes))
        .await
        .map_err(|_| Error::protocol("snappy decode task"))?
}

/// Inline snappy stays on the caller at or below this length.
///
/// 3.8 MiB of record bytes compressed in 43ms. 9.5 MiB took 110ms, so a
/// larger section moves to the blocking pool. The frame is still one
/// snappy-java chunk.
const SNAPPY_INLINE_LIMIT: usize = 4 * 1024 * 1024;

async fn snappy_compress_section(section: &mut BytesMut, out: &mut Vec<u8>) -> Result<()> {
    if section.len() <= SNAPPY_INLINE_LIMIT {
        return snappy_compress_into(section, out);
    }
    let owned = std::mem::take(section);
    let mut buf = std::mem::take(out);
    let joined = tokio::task::spawn_blocking(move || {
        let result = snappy_compress_into(&owned, &mut buf);
        (owned, buf, result)
    })
    .await
    .map_err(|_| Error::protocol("snappy encode task"))?;
    let (owned, buf, result) = joined;
    *section = owned;
    *out = buf;
    result
}

fn snappy_decompress(src: &[u8], max_bytes: usize) -> Result<Vec<u8>> {
    if src.len() > 20 && src.starts_with(SNAPPY_JAVA_MAGIC) {
        let mut cur = src.get(16..).unwrap_or(&[]);
        let mut out = Vec::new();
        let mut decoder = snap::raw::Decoder::new();
        while cur.len() >= 4 {
            let prefix = cur
                .get(..4)
                .ok_or_else(|| Error::protocol("snappy-java short chunk"))?;
            let clen = buf::usize_from_u32(u32::from_be_bytes(
                prefix
                    .try_into()
                    .map_err(|_| Error::protocol("snappy-java short chunk"))?,
            ))?;
            cur = cur.get(4..).unwrap_or(&[]);
            if clen > cur.len() {
                return Err(Error::protocol("snappy-java chunk overruns buffer"));
            }
            let block = cur
                .get(..clen)
                .ok_or_else(|| Error::protocol("snappy-java chunk overruns buffer"))?;
            let chunk_len =
                snap::raw::decompress_len(block).map_err(|e| Error::protocol(e.to_string()))?;
            if out.len().saturating_add(chunk_len) > max_bytes {
                return Err(Error::protocol(
                    "Decompressed batch exceeds maximum allowable size",
                ));
            }
            let start = out.len();
            out.resize(start.saturating_add(chunk_len), 0);
            let dest = out
                .get_mut(start..)
                .ok_or_else(|| Error::protocol("snappy output short"))?;
            let written = decoder
                .decompress(block, dest)
                .map_err(|e| Error::protocol(e.to_string()))?;
            if written != chunk_len {
                return Err(Error::protocol("snappy decompressed length mismatch"));
            }
            cur = cur.get(clen..).unwrap_or(&[]);
        }
        if !cur.is_empty() {
            return Err(Error::protocol("snappy-java short chunk"));
        }
        Ok(out)
    } else {
        let uncompressed_len =
            snap::raw::decompress_len(src).map_err(|e| Error::protocol(e.to_string()))?;
        if uncompressed_len > max_bytes {
            return Err(Error::protocol(
                "Decompressed batch exceeds maximum allowable size",
            ));
        }
        let out = snap::raw::Decoder::new()
            .decompress_vec(src)
            .map_err(|e| Error::protocol(e.to_string()))?;
        if out.len() > max_bytes {
            return Err(Error::protocol(
                "Decompressed batch exceeds maximum allowable size",
            ));
        }
        Ok(out)
    }
}

/// Kafka RecordBatch (magic ≥ 1) uses LZ4 **frame** with independent blocks.
/// Magic 0 used a broken header checksum; we only emit/accept proper HC.
fn lz4_compress_into(src: &[u8], out: &mut Vec<u8>) -> Result<()> {
    use lz4_flex::frame::{BlockMode, BlockSize, FrameEncoder, FrameInfo};
    let info = FrameInfo::new()
        .block_mode(BlockMode::Independent)
        .block_size(BlockSize::Max64KB)
        .block_checksums(false)
        .content_checksum(false)
        .content_size(Some(src.len() as u64));
    // KL09-33: pre-size the output with Java's size/2 estimate (see gzip).
    out.clear();
    let est =
        estimate_compressed_size_in_bytes(compress_estimate_input(src.len()), Compression::Lz4);
    out.reserve(buf::usize_from_i32(est).unwrap_or(0));
    let owned = std::mem::take(out);
    let mut encoder = FrameEncoder::with_frame_info(info, owned);
    encoder
        .write_all(src)
        .map_err(|e| Error::protocol(e.to_string()))?;
    *out = encoder
        .finish()
        .map_err(|e| Error::protocol(e.to_string()))?;
    Ok(())
}

/// [`lz4_compress_into`], feeding the encoder 8 KiB at a time.
///
/// Slices are written with no flush between them, so the frame matches
/// [`lz4_compress_into`]. The pause between slices lets a caller deadline
/// run while a multi-megabyte section is still being packed.
async fn lz4_compress_into_cooperative(src: &[u8], out: &mut Vec<u8>) -> Result<()> {
    use lz4_flex::frame::{BlockMode, BlockSize, FrameEncoder, FrameInfo};
    let info = FrameInfo::new()
        .block_mode(BlockMode::Independent)
        .block_size(BlockSize::Max64KB)
        .block_checksums(false)
        .content_checksum(false)
        .content_size(Some(src.len() as u64));
    out.clear();
    let est =
        estimate_compressed_size_in_bytes(compress_estimate_input(src.len()), Compression::Lz4);
    out.reserve(buf::usize_from_i32(est).unwrap_or(0));
    let owned = std::mem::take(out);
    let mut encoder = FrameEncoder::with_frame_info(info, owned);
    let mut offset = 0usize;
    while offset < src.len() {
        let end = offset.saturating_add(8 * 1024).min(src.len());
        let piece = src
            .get(offset..end)
            .ok_or_else(|| Error::protocol("lz4 chunk"))?;
        encoder
            .write_all(piece)
            .map_err(|e| Error::protocol(e.to_string()))?;
        offset = end;
        if offset < src.len() {
            tokio::task::yield_now().await;
        }
    }
    *out = encoder
        .finish()
        .map_err(|e| Error::protocol(e.to_string()))?;
    Ok(())
}

fn lz4_declared_size(src: &[u8]) -> Option<u64> {
    if src.len() < 14 || !src.starts_with(&[0x04, 0x22, 0x4D, 0x18]) {
        return None;
    }
    if src.get(4).is_none_or(|flg| flg & 0x08 == 0) {
        return None;
    }
    let bytes = src.get(6..14)?.try_into().ok()?;
    Some(u64::from_le_bytes(bytes))
}

fn lz4_decompress_reserve(src: &[u8], max_bytes: usize) -> Result<usize> {
    let mut reserve = 0usize;
    if let Some(declared) = lz4_declared_size(src) {
        if let Ok(max_bytes_u64) = u64::try_from(max_bytes) {
            if declared > max_bytes_u64 {
                return Err(Error::protocol(
                    "Decompressed batch exceeds maximum allowable size",
                ));
            }
        }
        if let Ok(declared) = usize::try_from(declared) {
            // A tiny frame must not reserve a huge claimed size. Honest
            // batches fit well inside 64 times the compressed length.
            reserve = declared.min(src.len().saturating_mul(64));
        }
    }
    Ok(reserve)
}

fn lz4_decompress(src: &[u8], max_bytes: usize) -> Result<Vec<u8>> {
    let reserve = lz4_decompress_reserve(src, max_bytes)?;
    let mut decoder = lz4_flex::frame::FrameDecoder::new(src);
    read_bounded(&mut decoder, max_bytes, reserve)
}

async fn lz4_decompress_cooperative(src: &[u8], max_bytes: usize) -> Result<Vec<u8>> {
    let reserve = lz4_decompress_reserve(src, max_bytes)?;
    let mut decoder = lz4_flex::frame::FrameDecoder::new(src);
    read_bounded_cooperative(&mut decoder, max_bytes, reserve).await
}

/// One record as borrowed slices for the produce encode path.
#[derive(Clone, Copy)]
pub struct EncodeRecord<'a> {
    /// Timestamp in milliseconds since the Unix epoch.
    pub timestamp: i64,
    /// Optional key.
    pub key: Option<&'a [u8]>,
    /// Optional value.
    pub value: Option<&'a [u8]>,
    /// Record headers.
    pub headers: &'a [Header],
}

impl<'a> EncodeRecord<'a> {
    /// Borrow a [`Record`] for encoding.
    pub fn from_record(rec: &'a Record) -> Self {
        Self {
            timestamp: rec.timestamp,
            key: rec.key.as_deref(),
            value: rec.value.as_deref(),
            headers: &rec.headers,
        }
    }
}

/// Magic-v2 batch header fields used by [`write_record_batch`].
pub struct BatchHeader {
    /// First offset in this batch.
    pub base_offset: i64,
    /// Partition leader epoch, or [`RecordBatch::NO_PARTITION_LEADER_EPOCH`].
    pub partition_leader_epoch: i32,
    /// Attribute bits: compression in the low 3, plus
    /// [`ATTR_TIMESTAMP_TYPE`] / [`ATTR_TRANSACTIONAL`] / [`ATTR_CONTROL`] /
    /// [`ATTR_DELETE_HORIZON`].
    pub attributes: i16,
    /// Timestamp of the first record (milliseconds since the Unix epoch).
    pub base_timestamp: i64,
    /// Max timestamp among records in this batch.
    pub max_timestamp: i64,
    /// Idempotent / transactional producer id, or [`RecordBatch::NO_PRODUCER_ID`].
    pub producer_id: i64,
    /// Producer epoch, or [`RecordBatch::NO_PRODUCER_EPOCH`].
    pub producer_epoch: i16,
    /// First sequence number in this batch, or [`RecordBatch::NO_SEQUENCE`].
    pub base_sequence: i32,
    /// Number of records that will be written.
    pub count: i32,
}

impl Default for BatchHeader {
    fn default() -> Self {
        Self {
            base_offset: 0,
            partition_leader_epoch: RecordBatch::NO_PARTITION_LEADER_EPOCH,
            attributes: 0,
            base_timestamp: 0,
            max_timestamp: 0,
            producer_id: RecordBatch::NO_PRODUCER_ID,
            producer_epoch: RecordBatch::NO_PRODUCER_EPOCH,
            base_sequence: RecordBatch::NO_SEQUENCE,
            count: 0,
        }
    }
}

/// Encode a [`RecordBatch`] (CRC32-C, optional compression).
///
/// A decoded wire batch whose sequential offsets cross the signed boundary
/// retains Java's wrapping arithmetic. The producer's borrowed-record writer
/// continues to reject overflowing absolute offsets and timestamps.
pub fn encode_record_batch(buf: &mut BytesMut, batch: &RecordBatch) -> Result<()> {
    let result = write_record_batch(
        buf,
        &batch_header_from(batch)?,
        batch.records.iter().map(EncodeRecord::from_record),
    );
    match result {
        Err(error) if is_wire_arithmetic_overflow(&error) && wire_offsets_sequential(batch) => {
            encode_wrapped_batch(buf, batch)
        }
        result => result,
    }
}

/// Encode decoded record offsets and the original header's last-offset delta.
///
/// Record offsets are absolute and must yield strictly increasing, nonnegative
/// i32 deltas from `batch.base_offset` under Java's signed wrapping arithmetic.
/// Supply the original header value from [`RecordBatch::encoded_last_offset_delta`]
/// to preserve compacted or sparse batches. [`encode_record_batch`] retains its
/// sequential builder behavior. Errors leave the caller's buffer unchanged.
pub fn encode_record_batch_with_offsets(
    buf: &mut BytesMut,
    batch: &RecordBatch,
    last_offset_delta: i32,
) -> Result<()> {
    if last_offset_delta < 0 {
        return Err(Error::protocol("negative last offset delta"));
    }
    let header = batch_header_from(batch)?;
    let compression = Compression::from_attributes(header.attributes)?;
    let mut output = BatchOutputRollback::new(buf);
    let (batch_start, length_pos, crc_pos, crc_start) = start_record_batch(output.buffer, &header);
    let delta_pos = batch_start
        .checked_add(buf::usize_from_i32(RecordBatch::LAST_OFFSET_DELTA_OFFSET)?)
        .ok_or_else(|| Error::protocol("batch offset overflow"))?;
    buf::patch_i32(output.buffer, delta_pos, last_offset_delta)?;

    let mut section = BytesMut::new();
    let mut header_wires = Vec::new();
    let mut previous = None;
    for record in &batch.records {
        let delta = i32::try_from(record.offset.wrapping_sub(batch.base_offset))
            .map_err(|_| Error::protocol("offset delta exceeds i32"))?;
        if delta < 0 || delta > last_offset_delta || previous.is_some_and(|last| delta <= last) {
            return Err(Error::protocol(
                "invalid record offset delta order or range",
            ));
        }
        previous = Some(delta);
        let timestamp = record.timestamp.wrapping_sub(batch.base_timestamp);
        let target = if compression == Compression::None {
            &mut *output.buffer
        } else {
            &mut section
        };
        encode_record(
            target,
            &EncodeRecord::from_record(record),
            delta,
            timestamp,
            &mut header_wires,
        )?;
    }
    if compression != Compression::None {
        let mut packed = Vec::new();
        match compression {
            Compression::Gzip => gzip_compress_into(&section, &mut packed)?,
            Compression::Snappy => snappy_compress_into(&section, &mut packed)?,
            Compression::Lz4 => lz4_compress_into(&section, &mut packed)?,
            #[cfg(feature = "zstd")]
            Compression::Zstd => {
                zstd_compress_into(&section, &mut packed, &mut None, ZstdLevel::default())?
            }
            Compression::None => return Err(Error::protocol("internal: uncompressed pack")),
        }
        output.buffer.extend_from_slice(&packed);
    }
    finish_record_batch(output.buffer, batch_start, length_pos, crc_pos, crc_start)?;
    output.committed = true;
    Ok(())
}

// A cooperative encoder can be dropped at any await point. Keep the caller's
// prefix intact until the entire batch has been encoded successfully.
struct BatchOutputRollback<'a> {
    buffer: &'a mut BytesMut,
    original_len: usize,
    committed: bool,
}

impl<'a> BatchOutputRollback<'a> {
    fn new(buffer: &'a mut BytesMut) -> Self {
        let original_len = buffer.len();
        Self {
            buffer,
            original_len,
            committed: false,
        }
    }
}

impl Drop for BatchOutputRollback<'_> {
    fn drop(&mut self) {
        if !self.committed {
            self.buffer.truncate(self.original_len);
        }
    }
}

/// [`encode_record_batch`], yielding while a long record list is encoded.
pub async fn encode_record_batch_cooperative(
    buf: &mut BytesMut,
    batch: &RecordBatch,
) -> Result<()> {
    let mut output = BatchOutputRollback::new(buf);
    let header = batch_header_from(batch)?;
    let mut scratch = CompressScratch::new();
    let result = if Compression::from_attributes(header.attributes)? == Compression::None {
        write_uncompressed_batch_cooperative(
            output.buffer,
            &header,
            batch.records.iter().map(EncodeRecord::from_record),
            &mut scratch,
        )
        .await
    } else {
        match pack_compressed_batch_cooperative(
            &header,
            batch.records.iter().map(EncodeRecord::from_record),
            &mut scratch,
        )
        .await
        {
            Ok(_) => write_packed_batch(output.buffer, &header, &scratch),
            Err(error) => Err(error),
        }
    };
    match result {
        Err(error) if is_wire_arithmetic_overflow(&error) => {
            output.buffer.truncate(output.original_len);
            if !wire_offsets_sequential_cooperative(batch).await {
                return Err(error);
            }
            let result = encode_wrapped_batch_cooperative(output.buffer, batch).await;
            if result.is_ok() {
                output.committed = true;
            }
            result
        }
        Err(error) => Err(error),
        Ok(()) => {
            scratch.shrink_to_caps();
            output.committed = true;
            Ok(())
        }
    }
}

fn is_wire_arithmetic_overflow(error: &Error) -> bool {
    matches!(error, Error::Protocol(message)
        if message == OFFSET_OVERFLOW || message == TIMESTAMP_OVERFLOW)
}

fn wire_offsets_sequential(batch: &RecordBatch) -> bool {
    batch.records.iter().enumerate().all(|(index, record)| {
        i32::try_from(index)
            .is_ok_and(|delta| record.offset == batch.base_offset.wrapping_add(i64::from(delta)))
    })
}

async fn wire_offsets_sequential_cooperative(batch: &RecordBatch) -> bool {
    for (index, record) in batch.records.iter().enumerate() {
        if !i32::try_from(index)
            .is_ok_and(|delta| record.offset == batch.base_offset.wrapping_add(i64::from(delta)))
        {
            return false;
        }
        if index % (8 * 1024) == (8 * 1024) - 1 {
            tokio::task::yield_now().await;
        }
    }
    true
}

fn normalized_wire_header(batch: &RecordBatch) -> Result<BatchHeader> {
    let mut header = batch_header_from(batch)?;
    header.base_offset = 0;
    header.base_timestamp = 0;
    Ok(header)
}

fn normalized_wire_records(batch: &RecordBatch) -> impl Iterator<Item = EncodeRecord<'_>> {
    batch.records.iter().map(|record| {
        let mut encoded = EncodeRecord::from_record(record);
        encoded.timestamp = record.timestamp.wrapping_sub(batch.base_timestamp);
        encoded
    })
}

// The temporary batch has zero bases so the checked producer writer can encode
// its deltas. Restore the original header and recompute its protected CRC.
fn restore_wire_header(buf: &mut BytesMut, start: usize, batch: &RecordBatch) -> Result<()> {
    let bytes = buf
        .get_mut(start..)
        .ok_or_else(|| Error::protocol("missing encoded batch"))?;
    if bytes.len() < buf::usize_from_i32(RecordBatch::RECORD_BATCH_OVERHEAD)? {
        return Err(Error::protocol("short encoded batch"));
    }
    let base_offset = buf::usize_from_i32(Records::OFFSET_OFFSET)?;
    let base_timestamp = buf::usize_from_i32(RecordBatch::BASE_TIMESTAMP_OFFSET)?;
    let max_timestamp = base_timestamp
        .checked_add(8)
        .ok_or_else(|| Error::protocol("timestamp field offset overflow"))?;
    let crc_offset = buf::usize_from_i32(RecordBatch::CRC_OFFSET)?;
    let crc_end = buf::usize_from_i32(RecordBatch::ATTRIBUTES_OFFSET)?;
    RecordBatch::write_i64_be(bytes, base_offset, batch.base_offset)?;
    RecordBatch::write_i64_be(bytes, base_timestamp, batch.base_timestamp)?;
    RecordBatch::write_i64_be(bytes, max_timestamp, batch.max_timestamp)?;
    let crc = crc32c::crc32c(
        bytes
            .get(crc_end..)
            .ok_or_else(|| Error::protocol("short encoded batch"))?,
    );
    bytes
        .get_mut(crc_offset..crc_end)
        .ok_or_else(|| Error::protocol("short encoded batch"))?
        .copy_from_slice(&crc.to_be_bytes());
    Ok(())
}

fn encode_wrapped_batch(buf: &mut BytesMut, batch: &RecordBatch) -> Result<()> {
    let start = buf.len();
    let result = write_record_batch(
        buf,
        &normalized_wire_header(batch)?,
        normalized_wire_records(batch),
    )
    .and_then(|()| restore_wire_header(buf, start, batch));
    if result.is_err() {
        buf.truncate(start);
    }
    result
}

async fn encode_wrapped_batch_cooperative(buf: &mut BytesMut, batch: &RecordBatch) -> Result<()> {
    let start = buf.len();
    let header = normalized_wire_header(batch)?;
    let mut scratch = CompressScratch::new();
    let result = if Compression::from_attributes(header.attributes)? == Compression::None {
        write_uncompressed_batch_cooperative(
            buf,
            &header,
            normalized_wire_records(batch),
            &mut scratch,
        )
        .await
    } else {
        match pack_compressed_batch_cooperative(
            &header,
            normalized_wire_records(batch),
            &mut scratch,
        )
        .await
        {
            Ok(_) => write_packed_batch(buf, &header, &scratch),
            Err(error) => Err(error),
        }
    };
    let result = result.and_then(|()| restore_wire_header(buf, start, batch));
    if result.is_err() {
        buf.truncate(start);
    }
    result
}

fn batch_header_from(batch: &RecordBatch) -> Result<BatchHeader> {
    Ok(BatchHeader {
        base_offset: batch.base_offset,
        partition_leader_epoch: batch.partition_leader_epoch,
        attributes: batch.attributes,
        base_timestamp: batch.base_timestamp,
        max_timestamp: batch.max_timestamp,
        producer_id: batch.producer_id,
        producer_epoch: batch.producer_epoch,
        base_sequence: batch.base_sequence,
        count: buf::i32_from_usize(batch.records.len())?,
    })
}

/// KL09-33: bounded reusable scratch for compressed batch encoding.
///
/// A produce worker owns one and threads it through every batch; the
/// uncompressed section and the compressor output buffers keep their
/// capacity across batches instead of allocating per batch. Uncompressed
/// batches never touch it. Caps come from the effective produce batch
/// byte cap (see `ProducerConfig::produce_batch_bytes`); after each
/// compressed batch, a buffer holding more than twice its cap is
/// replaced with a cap-sized one (documented in
/// `docs/resource-contract.md`).
pub struct CompressScratch {
    section: BytesMut,
    packed: Vec<u8>,
    /// Header widths for the record being encoded. Cleared per record and kept
    /// across batches.
    pub(crate) header_wires: Vec<HeaderWire>,
    section_cap: usize,
    packed_cap: usize,
    #[cfg(feature = "zstd")]
    zstd_level: ZstdLevel,
    #[cfg(feature = "zstd")]
    zstd_max_batch_bytes: usize,
    #[cfg(feature = "zstd")]
    zstd_encoder: Option<zstd_rs::Compressor>,
}

impl CompressScratch {
    /// Scratch with 1 MiB caps (the Java default batch size).
    pub fn new() -> Self {
        Self::with_caps(1024 * 1024, 1024 * 1024)
    }

    /// Scratch with explicit caps. Caps below 1 KiB are raised to 1 KiB so
    /// the section floor below always applies.
    pub fn with_caps(section_cap: usize, packed_cap: usize) -> Self {
        Self {
            section: BytesMut::new(),
            packed: Vec::new(),
            header_wires: Vec::new(),
            section_cap: section_cap.max(1024),
            packed_cap: packed_cap.max(1024),
            #[cfg(feature = "zstd")]
            zstd_level: ZstdLevel::default(),
            #[cfg(feature = "zstd")]
            zstd_max_batch_bytes: 0,
            #[cfg(feature = "zstd")]
            zstd_encoder: None,
        }
    }

    /// Select a validated zstd level; changing it drops the old encoder context.
    #[cfg(feature = "zstd")]
    pub fn set_zstd_level(&mut self, level: ZstdLevel) {
        if self.zstd_level != level {
            self.zstd_encoder = None;
            self.zstd_level = level;
        }
    }

    /// Limit the complete encoded zstd batch, including its Kafka header.
    /// Zero disables this extra cap; the codec's 64 MiB input limit still applies.
    #[cfg(feature = "zstd")]
    pub fn set_zstd_max_batch_bytes(&mut self, bytes: usize) {
        self.zstd_max_batch_bytes = bytes;
    }

    pub(crate) fn reserve_section(&mut self, bytes: usize) {
        if self.section.capacity() < bytes {
            self.section.reserve(bytes - self.section.capacity());
        }
    }

    pub(crate) fn shrink_to_caps(&mut self) {
        #[cfg(feature = "zstd")]
        if self.section.capacity() > self.section_cap.saturating_mul(2)
            || self.packed.capacity() > self.packed_cap.saturating_mul(2)
        {
            self.zstd_encoder = None;
        }
        if self.section.capacity() > self.section_cap.saturating_mul(2) {
            self.section = BytesMut::with_capacity(self.section_cap);
        }
        if self.packed.capacity() > self.packed_cap.saturating_mul(2) {
            self.packed = Vec::with_capacity(self.packed_cap);
        }
    }
}

impl Default for CompressScratch {
    fn default() -> Self {
        Self::new()
    }
}

/// Encode a magic-v2 batch from a header plus borrowed records (produce hot path).
pub fn write_record_batch<'a, I>(buf: &mut BytesMut, header: &BatchHeader, records: I) -> Result<()>
where
    I: Iterator<Item = EncodeRecord<'a>>,
{
    let mut scratch = CompressScratch::new();
    write_record_batch_scratch(buf, header, records, &mut scratch)
}

/// Like [`write_record_batch`], reusing `scratch` for the uncompressed
/// section and compressor output on compressed batches.
pub fn write_record_batch_scratch<'a, I>(
    buf: &mut BytesMut,
    header: &BatchHeader,
    records: I,
    scratch: &mut CompressScratch,
) -> Result<()>
where
    I: Iterator<Item = EncodeRecord<'a>>,
{
    let compression = Compression::from_attributes(header.attributes)?;
    #[cfg(feature = "zstd")]
    if compression == Compression::Zstd {
        return write_zstd_record_batch(buf, header, records, scratch);
    }
    // A failed record leaves the caller's buffer unchanged. The header is
    // written before the records, so an overflow must roll that prefix back.
    let original = buf.len();
    let encoded = (|| {
        match compression {
            Compression::Gzip | Compression::Snappy | Compression::Lz4 => {
                let _framed = pack_compressed_batch(header, records, scratch)?;
                write_packed_batch(buf, header, scratch)?;
                scratch.shrink_to_caps();
                return Ok(());
            }
            #[cfg(feature = "zstd")]
            Compression::Zstd => {
                return Err(Error::Unsupported(
                    "internal: zstd after non-zstd encoder branch".into(),
                ))
            }
            Compression::None => {}
        }
        let (batch_start, batch_len_pos, crc_pos, crc_start) = start_record_batch(buf, header);
        let mut header_wires = std::mem::take(&mut scratch.header_wires);
        let write_result: Result<usize> = (|| {
            let mut written = 0usize;
            for (i, rec) in records.enumerate() {
                encode_record(
                    buf,
                    &rec,
                    absolute_offset_delta(header.base_offset, i)?,
                    timestamp_delta(header.base_timestamp, rec.timestamp)?,
                    &mut header_wires,
                )?;
                written = i.saturating_add(1);
            }
            Ok(written)
        })();
        scratch.header_wires = header_wires;
        let written = write_result?;
        if header.count != buf::i32_from_usize(written)? {
            return Err(Error::protocol("record count differs from header"));
        }
        finish_record_batch(buf, batch_start, batch_len_pos, crc_pos, crc_start)
    })();
    if encoded.is_err() {
        buf.truncate(original);
    }
    encoded
}

/// [`write_record_batch_scratch`] for an uncompressed batch, yielding between records.
pub async fn write_uncompressed_batch_cooperative<'a, I>(
    buf: &mut BytesMut,
    header: &BatchHeader,
    records: I,
    scratch: &mut CompressScratch,
) -> Result<()>
where
    I: Iterator<Item = EncodeRecord<'a>>,
{
    if Compression::from_attributes(header.attributes)? != Compression::None {
        return Err(Error::protocol("internal: compressed cooperative encode"));
    }
    let mut output = BatchOutputRollback::new(buf);
    let mut header_wires = std::mem::take(&mut scratch.header_wires);
    let (batch_start, batch_len_pos, crc_pos, crc_start) =
        start_record_batch(output.buffer, header);
    let mut written = 0usize;
    let mut walked = 0usize;
    let mut encode_error = None;
    for (index, rec) in records.enumerate() {
        let result = absolute_offset_delta(header.base_offset, index).and_then(|offset| {
            timestamp_delta(header.base_timestamp, rec.timestamp).and_then(|timestamp| {
                encode_record(output.buffer, &rec, offset, timestamp, &mut header_wires)
            })
        });
        if let Err(error) = result {
            encode_error = Some(error);
            break;
        }
        written = index.saturating_add(1);
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    scratch.header_wires = header_wires;
    if let Some(error) = encode_error {
        return Err(error);
    }
    let count = buf::i32_from_usize(written)?;
    if header.count != count {
        return Err(Error::protocol("record count differs from header"));
    }
    finish_record_batch(
        output.buffer,
        batch_start,
        batch_len_pos,
        crc_pos,
        crc_start,
    )?;
    output.committed = true;
    Ok(())
}

/// Compress `records` into the scratch payload and return the framed batch length.
///
/// The length is [`RecordBatch::RECORD_BATCH_OVERHEAD`] plus the packed
/// payload, matching [`write_packed_batch`].
pub fn pack_compressed_batch<'a, I>(
    header: &BatchHeader,
    records: I,
    scratch: &mut CompressScratch,
) -> Result<usize>
where
    I: IntoIterator<Item = EncodeRecord<'a>>,
{
    let compression = Compression::from_attributes(header.attributes)?;
    let result = pack_compressed_batch_inner(header, records, scratch, compression);
    if result.is_err() {
        abandon_packed(scratch);
    }
    result
}

fn pack_compressed_batch_inner<'a, I>(
    header: &BatchHeader,
    records: I,
    scratch: &mut CompressScratch,
    compression: Compression,
) -> Result<usize>
where
    I: IntoIterator<Item = EncodeRecord<'a>>,
{
    // KL09-33: 1 KiB floor kills the early doubling steps for real batches.
    scratch.section.clear();
    scratch.section.reserve(1024);
    let mut header_wires = std::mem::take(&mut scratch.header_wires);
    let mut written = 0usize;
    let encoded: Result<usize> = (|| {
        for (index, rec) in records.into_iter().enumerate() {
            let offset_delta = absolute_offset_delta(header.base_offset, index)?;
            let timestamp_delta = timestamp_delta(header.base_timestamp, rec.timestamp)?;
            #[cfg(feature = "zstd")]
            if compression == Compression::Zstd {
                let body = record_body_size(&rec, offset_delta, timestamp_delta)?;
                let size = buf::usize_from_i32(body)?
                    .checked_add(buf::varint_size(body))
                    .and_then(|n| n.checked_add(scratch.section.len()))
                    .ok_or_else(|| Error::protocol("zstd record section size overflow"))?;
                if size > DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES {
                    return Err(Error::protocol("zstd record section exceeds 64 MiB"));
                }
            }
            encode_record(
                &mut scratch.section,
                &rec,
                offset_delta,
                timestamp_delta,
                &mut header_wires,
            )?;
            written = index.saturating_add(1);
        }
        if header.count != buf::i32_from_usize(written)? {
            return Err(Error::protocol("record count differs from header"));
        }
        match compression {
            Compression::Gzip => gzip_compress_into(&scratch.section, &mut scratch.packed)?,
            Compression::Snappy => snappy_compress_into(&scratch.section, &mut scratch.packed)?,
            Compression::Lz4 => lz4_compress_into(&scratch.section, &mut scratch.packed)?,
            #[cfg(feature = "zstd")]
            Compression::Zstd => zstd_compress_into(
                &scratch.section,
                &mut scratch.packed,
                &mut scratch.zstd_encoder,
                scratch.zstd_level,
            )?,
            Compression::None => {
                return Err(Error::protocol("internal: uncompressed pack"));
            }
        }
        framed_packed_len(scratch, compression)
    })();
    scratch.header_wires = header_wires;
    encoded
}

pub(crate) fn begin_packed_section(scratch: &mut CompressScratch) {
    scratch.section.clear();
    scratch.section.reserve(1024);
}

pub(crate) fn abandon_packed(scratch: &mut CompressScratch) {
    scratch.section.clear();
    scratch.packed.clear();
    #[cfg(feature = "zstd")]
    {
        scratch.zstd_encoder = None;
    }
}

pub(crate) fn append_packed_record(
    scratch: &mut CompressScratch,
    header: &BatchHeader,
    index: usize,
    rec: &EncodeRecord<'_>,
    compression: Compression,
) -> Result<()> {
    let offset_delta = absolute_offset_delta(header.base_offset, index)?;
    let timestamp_delta = timestamp_delta(header.base_timestamp, rec.timestamp)?;
    #[cfg(feature = "zstd")]
    if compression == Compression::Zstd {
        let body = record_body_size(rec, offset_delta, timestamp_delta)?;
        let size = buf::usize_from_i32(body)?
            .checked_add(buf::varint_size(body))
            .and_then(|n| n.checked_add(scratch.section.len()))
            .ok_or_else(|| Error::protocol("zstd record section size overflow"))?;
        if size > DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES {
            return Err(Error::protocol("zstd record section exceeds 64 MiB"));
        }
    }
    #[cfg(not(feature = "zstd"))]
    let _ = compression;
    encode_record(
        &mut scratch.section,
        rec,
        offset_delta,
        timestamp_delta,
        &mut scratch.header_wires,
    )
}

fn framed_packed_len(scratch: &CompressScratch, compression: Compression) -> Result<usize> {
    let framed = scratch
        .packed
        .len()
        .checked_add(buf::usize_from_i32(RecordBatch::RECORD_BATCH_OVERHEAD)?)
        .ok_or_else(|| Error::protocol("compressed batch size overflow"))?;
    #[cfg(feature = "zstd")]
    if compression == Compression::Zstd
        && scratch.zstd_max_batch_bytes != 0
        && framed > scratch.zstd_max_batch_bytes
    {
        return Err(Error::RecordTooLarge {
            size: u64::try_from(framed).unwrap_or(u64::MAX),
            max: u64::try_from(scratch.zstd_max_batch_bytes).unwrap_or(u64::MAX),
            config: Error::MAX_REQUEST_SIZE_CONFIG,
        });
    }
    #[cfg(not(feature = "zstd"))]
    let _ = compression;
    Ok(framed)
}

async fn compress_packed_payload(
    scratch: &mut CompressScratch,
    compression: Compression,
) -> Result<()> {
    match compression {
        Compression::Gzip => {
            gzip_compress_into_cooperative(&scratch.section, &mut scratch.packed).await?
        }
        Compression::Snappy => {
            snappy_compress_section(&mut scratch.section, &mut scratch.packed).await?
        }
        Compression::Lz4 => {
            lz4_compress_into_cooperative(&scratch.section, &mut scratch.packed).await?
        }
        #[cfg(feature = "zstd")]
        Compression::Zstd => zstd_compress_into(
            &scratch.section,
            &mut scratch.packed,
            &mut scratch.zstd_encoder,
            scratch.zstd_level,
        )?,
        Compression::None => {
            return Err(Error::protocol("internal: uncompressed pack"));
        }
    }
    Ok(())
}

pub(crate) async fn finish_packed_section_cooperative(
    scratch: &mut CompressScratch,
    header: &BatchHeader,
    written: usize,
    compression: Compression,
) -> Result<usize> {
    let framed = finish_packed_section(scratch, header, written, compression).await;
    if framed.is_err() {
        abandon_packed(scratch);
    }
    framed
}

async fn finish_packed_section(
    scratch: &mut CompressScratch,
    header: &BatchHeader,
    written: usize,
    compression: Compression,
) -> Result<usize> {
    if header.count != buf::i32_from_usize(written)? {
        return Err(Error::protocol("record count differs from header"));
    }
    compress_packed_payload(scratch, compression).await?;
    framed_packed_len(scratch, compression)
}

async fn pack_compressed_batch_cooperative<'a, I>(
    header: &BatchHeader,
    records: I,
    scratch: &mut CompressScratch,
) -> Result<usize>
where
    I: IntoIterator<Item = EncodeRecord<'a>>,
{
    let compression = Compression::from_attributes(header.attributes)?;
    begin_packed_section(scratch);
    let mut records = records.into_iter().enumerate();
    let mut written = 0usize;
    let mut walked = 0usize;
    let mut encode_error = None;
    loop {
        let appended = {
            let Some((index, rec)) = records.next() else {
                break;
            };
            let appended = append_packed_record(scratch, header, index, &rec, compression);
            written = index.saturating_add(1);
            appended
        };
        if let Err(error) = appended {
            encode_error = Some(error);
            break;
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    if let Some(error) = encode_error {
        abandon_packed(scratch);
        return Err(error);
    }
    finish_packed_section_cooperative(scratch, header, written, compression).await
}

/// Write a batch whose payload is already in `scratch.packed`.
pub fn write_packed_batch(
    buf: &mut BytesMut,
    header: &BatchHeader,
    scratch: &CompressScratch,
) -> Result<()> {
    let original = buf.len();
    let encoded = {
        let (batch_start, batch_len_pos, crc_pos, crc_start) = start_record_batch(buf, header);
        buf.extend_from_slice(&scratch.packed);
        finish_record_batch(buf, batch_start, batch_len_pos, crc_pos, crc_start)
    };
    if encoded.is_err() {
        buf.truncate(original);
    }
    encoded
}

/// On-wire size of an uncompressed magic-v2 batch with this header and records.
///
/// The length matches [`write_record_batch_scratch`] for [`Compression::None`],
/// including [`RecordBatch::RECORD_BATCH_OVERHEAD`].
pub fn uncompressed_batch_len<'a, I>(header: &BatchHeader, records: I) -> Result<usize>
where
    I: IntoIterator<Item = EncodeRecord<'a>>,
{
    let mut size = buf::usize_from_i32(RecordBatch::RECORD_BATCH_OVERHEAD)?;
    for (index, rec) in records.into_iter().enumerate() {
        size = size
            .checked_add(encoded_record_wire(header, index, &rec)?)
            .ok_or_else(|| Error::protocol("batch size overflow"))?;
    }
    Ok(size)
}

pub(crate) fn encoded_record_wire(
    header: &BatchHeader,
    index: usize,
    rec: &EncodeRecord<'_>,
) -> Result<usize> {
    let offset_delta = absolute_offset_delta(header.base_offset, index)?;
    let timestamp_delta = timestamp_delta(header.base_timestamp, rec.timestamp)?;
    let body = record_body_size(rec, offset_delta, timestamp_delta)?;
    let wire = body
        .checked_add(buf::size_of_varint(body))
        .ok_or_else(|| Error::protocol("record size overflow"))?;
    buf::usize_from_i32(wire)
}

/// [`uncompressed_batch_len`], yielding while a long record list is measured.
pub async fn uncompressed_batch_len_cooperative<'a, I>(
    header: &BatchHeader,
    records: I,
) -> Result<usize>
where
    I: IntoIterator<Item = EncodeRecord<'a>>,
{
    let mut size = buf::usize_from_i32(RecordBatch::RECORD_BATCH_OVERHEAD)?;
    let mut walked = 0usize;
    for (index, rec) in records.into_iter().enumerate() {
        let offset_delta = absolute_offset_delta(header.base_offset, index)?;
        let timestamp_delta = timestamp_delta(header.base_timestamp, rec.timestamp)?;
        let body = record_body_size(&rec, offset_delta, timestamp_delta)?;
        let wire = body
            .checked_add(buf::size_of_varint(body))
            .ok_or_else(|| Error::protocol("record size overflow"))?;
        size = size
            .checked_add(buf::usize_from_i32(wire)?)
            .ok_or_else(|| Error::protocol("batch size overflow"))?;
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    Ok(size)
}

/// Uncompressed record bytes that a compressed batch writes before packing.
///
/// This is [`uncompressed_batch_len`] without [`RecordBatch::RECORD_BATCH_OVERHEAD`].
#[cfg(test)]
pub(crate) fn uncompressed_section_len<'a, I>(header: &BatchHeader, records: I) -> Result<usize>
where
    I: IntoIterator<Item = EncodeRecord<'a>>,
{
    let total = uncompressed_batch_len(header, records)?;
    let overhead = buf::usize_from_i32(RecordBatch::RECORD_BATCH_OVERHEAD)?;
    Ok(total.saturating_sub(overhead))
}

pub(crate) fn start_record_batch(
    buf: &mut BytesMut,
    header: &BatchHeader,
) -> (usize, usize, usize, usize) {
    let batch_start = buf.len();
    buf.put_i64(header.base_offset);
    let batch_len_pos = buf.len();
    buf.put_i32(0);
    buf.put_i32(header.partition_leader_epoch);
    buf.put_i8(MAGIC_V2);
    let crc_pos = buf.len();
    buf.put_u32(0);
    let crc_start = buf.len();
    buf.put_i16(header.attributes);
    let last_delta = if header.count <= 0 {
        0
    } else {
        header.count - 1
    };
    buf.put_i32(last_delta);
    buf.put_i64(header.base_timestamp);
    buf.put_i64(header.max_timestamp);
    buf.put_i64(header.producer_id);
    buf.put_i16(header.producer_epoch);
    buf.put_i32(header.base_sequence);
    buf.put_i32(header.count);
    (batch_start, batch_len_pos, crc_pos, crc_start)
}

pub(crate) fn finish_record_batch(
    buf: &mut BytesMut,
    batch_start: usize,
    batch_len_pos: usize,
    crc_pos: usize,
    crc_start: usize,
) -> Result<()> {
    let end = buf.len();
    let batch_len = buf::i32_from_usize(end.saturating_sub(batch_len_pos + 4))?;
    buf::patch_i32(buf, batch_len_pos, batch_len)?;
    let crc_bytes = buf
        .get(crc_start..end)
        .ok_or_else(|| Error::protocol("short crc range"))?;
    let crc = crc32c::crc32c(crc_bytes);
    buf::patch_i32(buf, crc_pos, i32::from_be_bytes(crc.to_be_bytes()))?;
    debug_assert_eq!(
        end.saturating_sub(batch_start),
        Records::LOG_OVERHEAD as usize + buf::usize_from_i32(batch_len).unwrap_or(0)
    );
    Ok(())
}

#[cfg(feature = "zstd")]
fn zstd_compress_into(
    src: &[u8],
    out: &mut Vec<u8>,
    context: &mut Option<zstd_rs::Compressor>,
    level: ZstdLevel,
) -> Result<()> {
    if src.len() > DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES {
        return Err(Error::protocol("zstd record section exceeds 64 MiB"));
    }
    out.clear();
    if context.is_none() {
        *context = Some(
            zstd_rs::Compressor::new(zstd_rs::CompressionConfig {
                level: level.get(),
                window_log: 23,
                checksum: true,
                content_size: true,
                dict_id: false,
                format: zstd_rs::FrameFormat::Standard,
            })
            .map_err(|e| Error::protocol(format!("zstd encoder config: {e}")))?,
        );
    }
    context
        .as_mut()
        .ok_or_else(|| Error::protocol("missing zstd encoder"))?
        .compress(src, None, out)
        .map_err(|e| Error::protocol(format!("zstd encode: {e}")))?;
    if out.len() > DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES.saturating_add(64 * 1024) {
        return Err(Error::protocol(
            "zstd compressed section exceeds output limit",
        ));
    }
    Ok(())
}

#[cfg(feature = "zstd")]
fn write_zstd_record_batch<'a, I>(
    buf: &mut BytesMut,
    header: &BatchHeader,
    records: I,
    scratch: &mut CompressScratch,
) -> Result<()>
where
    I: Iterator<Item = EncodeRecord<'a>>,
{
    let original = buf.len();
    let result = (|| {
        let framed = pack_compressed_batch(header, records, scratch)?;
        let start = buf.len();
        write_packed_batch(buf, header, scratch)?;
        if buf.len().saturating_sub(start) != framed {
            return Err(Error::protocol("zstd batch length mismatch"));
        }
        Ok(())
    })();
    if result.is_err() {
        buf.truncate(original);
        scratch.section.clear();
        scratch.packed.clear();
        scratch.zstd_encoder = None;
    }
    scratch.shrink_to_caps();
    result
}

fn nullable_bytes_len(bytes: Option<&[u8]>) -> usize {
    match bytes {
        None => buf::varint_size(-1),
        Some(b) => buf::varint_size(i32::try_from(b.len()).unwrap_or(i32::MAX)) + b.len(),
    }
}

/// Zigzag length prefix computed once and reused by the record writer.
struct NullablePrefix {
    bits: u32,
    width: usize,
    payload: usize,
}

fn nullable_prefix(bytes: Option<&[u8]>) -> Result<NullablePrefix> {
    let len = match bytes {
        None => -1,
        Some(b) => buf::i32_from_usize(b.len())?,
    };
    let bits = buf::zigzag_bits_i32(len);
    Ok(NullablePrefix {
        bits,
        width: buf::unsigned_varint_size(bits),
        payload: match bytes {
            Some(b) => b.len(),
            None => 0,
        },
    })
}

fn put_nullable(buf: &mut BytesMut, bytes: Option<&[u8]>, prefix: &NullablePrefix) {
    buf::put_unsigned_varint_width(buf, prefix.bits, prefix.width);
    if let Some(b) = bytes {
        buf.extend_from_slice(b);
    }
}

pub(crate) struct HeaderWire {
    key_bits: u32,
    key_width: usize,
    value: NullablePrefix,
}

fn fill_header_wires(headers: &[Header], wires: &mut Vec<HeaderWire>) -> Result<usize> {
    wires.clear();
    if headers.len() > wires.capacity() {
        // try_reserve_exact is relative to length, not current capacity.
        let extra = headers.len().saturating_sub(wires.len());
        wires
            .try_reserve_exact(extra)
            .map_err(|_| Error::protocol("header wire reserve"))?;
    }
    let mut size = 0usize;
    for header in headers {
        let key_bits = buf::zigzag_bits_i32(buf::utf8_length(&header.key));
        let key_width = buf::unsigned_varint_size(key_bits);
        let value = nullable_prefix(header.value.as_deref())?;
        size = size
            .checked_add(key_width)
            .and_then(|n| n.checked_add(header.key.len()))
            .and_then(|n| n.checked_add(value.width))
            .and_then(|n| n.checked_add(value.payload))
            .ok_or_else(|| Error::protocol("header size overflow"))?;
        wires.push(HeaderWire {
            key_bits,
            key_width,
            value,
        });
    }
    Ok(size)
}

/// KL09-33: saturating input for [`estimate_compressed_size_in_bytes`];
/// the estimate clamps to 64 KiB anyway, so saturation only affects
/// absurd (>2 GiB) sections, which keep working with a 64 KiB hint.
fn compress_estimate_input(len: usize) -> i32 {
    i32::try_from(len).unwrap_or(i32::MAX)
}

/// Java `AbstractRecords.estimateCompressedSizeInBytes`.
fn estimate_compressed_size_in_bytes(size: i32, compression: Compression) -> i32 {
    if compression == Compression::None {
        size
    } else {
        (size / 2).clamp(1024, 65_536)
    }
}
fn size_of_key_value_headers(
    key: Option<&[u8]>,
    value: Option<&[u8]>,
    headers: &[Header],
) -> Result<usize> {
    let mut size = nullable_bytes_len(key)
        + nullable_bytes_len(value)
        + buf::varint_size(buf::i32_from_usize(headers.len())?);
    for h in headers {
        let header_key_size = buf::utf8_length(&h.key);
        size += buf::varint_size(header_key_size) + h.key.len();
        size += nullable_bytes_len(h.value.as_deref());
    }
    Ok(size)
}

/// Java `DefaultRecord.recordSizeUpperBound`.
pub(crate) fn record_size_upper_bound(
    key: Option<&[u8]>,
    value: Option<&[u8]>,
    headers: &[Header],
) -> Result<i32> {
    buf::i32_from_usize(
        buf::usize_from_i32(Record::MAX_RECORD_OVERHEAD)?
            + size_of_key_value_headers(key, value, headers)?,
    )
}

/// Java `DefaultRecord.sizeOfBodyInBytes` (attributes + deltas + key/value/headers).
fn record_body_size(
    rec: &EncodeRecord<'_>,
    offset_delta: i32,
    timestamp_delta: i64,
) -> Result<i32> {
    buf::i32_from_usize(
        1 + buf::varlong_size(timestamp_delta)
            + buf::varint_size(offset_delta)
            + size_of_key_value_headers(rec.key, rec.value, rec.headers)?,
    )
}

/// Java `DefaultRecordBatch.sizeInBytes` static helpers.
///
/// `None` base offset is `0..n` deltas (SimpleRecord). `Some` uses
/// `record.offset - base`. Empty is `0`.
fn record_batch_size_in_bytes(records: &[Record], base_offset: Option<i64>) -> Result<i32> {
    let Some((first, rest)) = records.split_first() else {
        return Ok(0);
    };
    let mut size = buf::usize_from_i32(RecordBatch::RECORD_BATCH_OVERHEAD)?;
    let base_timestamp = first.timestamp;
    let first_delta = match base_offset {
        Some(base) => offset_delta_from(base, first.offset)?,
        None => 0,
    };
    size += buf::usize_from_i32(first.size_in_bytes(first_delta, 0)?)?;
    for (i, rec) in rest.iter().enumerate() {
        let offset_delta = match base_offset {
            Some(base) => offset_delta_from(base, rec.offset)?,
            None => buf::i32_from_usize(i.saturating_add(1))?,
        };
        let timestamp_delta = timestamp_delta(base_timestamp, rec.timestamp)?;
        size += buf::usize_from_i32(rec.size_in_bytes(offset_delta, timestamp_delta)?)?;
    }
    buf::i32_from_usize(size)
}

pub(crate) fn encode_record(
    buf: &mut BytesMut,
    rec: &EncodeRecord<'_>,
    offset_delta: i32,
    timestamp_delta: i64,
    header_wires: &mut Vec<HeaderWire>,
) -> crate::error::Result<()> {
    // Widths are derived once from the zigzag bits and reused by the writer.
    let ts_bits = buf::zigzag_bits_i64(timestamp_delta);
    let ts_width = buf::unsigned_varlong_size(ts_bits);
    let offset_bits = buf::zigzag_bits_i32(offset_delta);
    let offset_width = buf::unsigned_varint_size(offset_bits);
    let key = nullable_prefix(rec.key)?;
    let value = nullable_prefix(rec.value)?;
    let header_count = buf::i32_from_usize(rec.headers.len())?;
    let header_bits = buf::zigzag_bits_i32(header_count);
    let header_width = buf::unsigned_varint_size(header_bits);
    let headers_len = fill_header_wires(rec.headers, header_wires)?;
    let body = 1usize
        .checked_add(ts_width)
        .and_then(|n| n.checked_add(offset_width))
        .and_then(|n| n.checked_add(key.width))
        .and_then(|n| n.checked_add(key.payload))
        .and_then(|n| n.checked_add(value.width))
        .and_then(|n| n.checked_add(value.payload))
        .and_then(|n| n.checked_add(header_width))
        .and_then(|n| n.checked_add(headers_len))
        .ok_or_else(|| Error::protocol("record body size overflow"))?;
    let body_len = buf::i32_from_usize(body)?;
    let body_bits = buf::zigzag_bits_i32(body_len);
    let body_width = buf::unsigned_varint_size(body_bits);
    buf::put_unsigned_varint_width(buf, body_bits, body_width);
    buf.put_i8(0);
    buf::put_unsigned_varlong_width(buf, ts_bits, ts_width);
    buf::put_unsigned_varint_width(buf, offset_bits, offset_width);
    put_nullable(buf, rec.key, &key);
    put_nullable(buf, rec.value, &value);
    buf::put_unsigned_varint_width(buf, header_bits, header_width);
    for (header, wire) in rec.headers.iter().zip(header_wires.iter()) {
        buf::put_unsigned_varint_width(buf, wire.key_bits, wire.key_width);
        buf.extend_from_slice(header.key.as_bytes());
        put_nullable(buf, header.value.as_deref(), &wire.value);
    }
    Ok(())
}

/// Decode zero or more consecutive magic-v2 batches until the buffer is too short,
/// enforcing [`DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES`] during decompression.
pub fn decode_record_batches<B: Buf>(buf: &mut B) -> Result<Vec<RecordBatch>> {
    decode_record_batches_with_limit(buf, DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES)
}

/// Decode zero or more consecutive magic-v2 batches until the buffer is too short,
/// enforcing an explicit decoded-byte ceiling during decompression.
pub fn decode_record_batches_with_limit<B: Buf>(
    buf: &mut B,
    max_decode_bytes: usize,
) -> Result<Vec<RecordBatch>> {
    let mut metadata = DecodeMetadataBudget::for_wire_limit(max_decode_bytes);
    decode_record_batches_with_budget(buf, max_decode_bytes, &mut metadata)
}

/// Decode batches while charging their retained metadata to a response budget.
pub(crate) fn decode_record_batches_with_budget<B: Buf>(
    buf: &mut B,
    max_decode_bytes: usize,
    metadata: &mut DecodeMetadataBudget,
) -> Result<Vec<RecordBatch>> {
    let mut out = Vec::new();
    // Reserve only when one bounded slice covers the buffer. A long run of
    // batches must not be counted in full before the first batch is decoded.
    if buf.chunk().len() == buf.remaining() {
        if let Ok((count, next)) = count_framed_batches_from(buf.chunk(), 0, 64 * 1024) {
            let done = next >= buf.chunk().len() || buf.chunk().len().saturating_sub(next) < 12;
            if done && count > 1 {
                metadata.reserve(&mut out, count)?;
            }
        }
    }
    while buf.remaining() >= 12 {
        let chunk = buf.chunk();
        if chunk.len() < 12 {
            let mut rest = buf.copy_to_bytes(buf.remaining());
            let mut more =
                decode_record_batches_with_budget(&mut rest, max_decode_bytes, metadata)?;
            let more_capacity = more.capacity();
            let target = out
                .len()
                .checked_add(more.len())
                .ok_or_else(|| Error::protocol("record batch count overflow"))?;
            metadata.reserve(&mut out, target)?;
            out.append(&mut more);
            drop(more);
            metadata.release::<RecordBatch>(more_capacity)?;
            break;
        }
        let len_bytes = chunk
            .get(8..12)
            .ok_or_else(|| Error::protocol("short batch length"))?;
        let batch_len = i32::from_be_bytes(
            len_bytes
                .try_into()
                .map_err(|_| Error::protocol("short batch length"))?,
        );
        if batch_len < 0 {
            return Err(Error::protocol("negative record batch length"));
        }
        let need = 12usize.saturating_add(buf::usize_from_i32(batch_len)?);
        if buf.remaining() < need {
            break;
        }
        let batch = decode_record_batch_wire_budgeted(buf, max_decode_bytes, metadata)?;
        if out.len() == out.capacity() {
            let target = out
                .capacity()
                .saturating_mul(2)
                .max(4)
                .min(metadata.remaining_slots::<RecordBatch>());
            if target <= out.capacity() {
                return Err(Error::protocol(
                    "decoded record metadata exceeds maximum allowable size",
                ));
            }
            metadata.reserve(&mut out, target)?;
        }
        out.push(batch);
    }
    Ok(out)
}

/// One framed, CRC-checked magic-v2 batch whose records are decoded (and
/// decompressed) only when [`EncodedBatch::decode`] is called.
#[derive(Clone, Debug)]
pub(crate) struct EncodedBatch {
    base_offset: i64,
    attributes: i16,
    body: Bytes,
}

impl EncodedBatch {
    /// A one-byte body for tests that need many batches.
    #[cfg(test)]
    pub(crate) fn test_tiny() -> Self {
        Self {
            base_offset: 0,
            attributes: 0,
            body: bytes::Bytes::from_static(b"x"),
        }
    }

    /// Batch attribute transactional bit.
    pub(crate) fn is_transactional(&self) -> bool {
        self.attributes & ATTR_TRANSACTIONAL != 0
    }

    /// Batch attribute control bit.
    pub(crate) fn is_control_batch(&self) -> bool {
        self.attributes & ATTR_CONTROL != 0
    }

    /// Decode without consuming the framed body, yielding for long batches and
    /// charging metadata to the budget shared across the enclosing response.
    pub(crate) async fn decode_shared_cooperative_with_budget(
        &self,
        metadata: &mut DecodeMetadataBudget,
    ) -> Result<RecordBatch> {
        decode_checked_batch_cooperative_with_budget(
            self.base_offset,
            self.body.clone(),
            DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES,
            Vec::new(),
            metadata,
        )
        .await
    }

    /// Visit uncompressed records whose keys are at most 24 bytes.
    ///
    /// Returns [`None`] when the batch is not that shape. The callback may
    /// already have run; the caller discards those records and uses
    /// [`Self::decode_shared_cooperative_with_budget`].
    #[cfg(test)]
    pub(crate) fn try_visit_short_keys(
        &self,
        mut on_record: impl FnMut(ShortKeyRecord),
    ) -> Result<Option<ShortKeyBatch>> {
        let Some(mut visit) = self.start_short_visit()? else {
            return Ok(None);
        };
        match pull_short_visit(&mut visit, usize::MAX, &mut on_record)? {
            ShortPull::Done => Ok(Some(visit.meta)),
            ShortPull::Mismatch | ShortPull::More => Ok(None),
        }
    }

    /// [`Self::try_visit_short_keys`], yielding so a long batch does not hold the caller.
    pub(crate) async fn try_visit_short_keys_cooperative(
        &self,
        mut on_record: impl FnMut(ShortKeyRecord),
    ) -> Result<Option<ShortKeyBatch>> {
        let Some(mut visit) = self.start_short_visit()? else {
            return Ok(None);
        };
        loop {
            match pull_short_visit(&mut visit, 8 * 1024, &mut on_record)? {
                ShortPull::More => tokio::task::yield_now().await,
                ShortPull::Done => return Ok(Some(visit.meta)),
                ShortPull::Mismatch => return Ok(None),
            }
        }
    }

    fn start_short_visit(&self) -> Result<Option<ShortVisit>> {
        let mut body = self.body.clone();
        if body.remaining() < 49 {
            return Ok(None);
        }
        let Ok(partition_leader_epoch) = buf::get_i32(&mut body) else {
            return Ok(None);
        };
        let Ok(magic) = buf::get_i8(&mut body) else {
            return Ok(None);
        };
        if magic != MAGIC_V2 {
            return Ok(None);
        }
        if buf::get_u32(&mut body).is_err() {
            return Ok(None);
        }
        let Ok(attributes) = buf::get_i16(&mut body) else {
            return Ok(None);
        };
        if Compression::from_attributes(attributes).ok() != Some(Compression::None) {
            return Ok(None);
        }
        if buf::get_i32(&mut body).is_err() {
            return Ok(None);
        }
        let Ok(base_timestamp) = buf::get_i64(&mut body) else {
            return Ok(None);
        };
        let Ok(max_timestamp) = buf::get_i64(&mut body) else {
            return Ok(None);
        };
        if buf::get_i64(&mut body).is_err()
            || buf::get_i16(&mut body).is_err()
            || buf::get_i32(&mut body).is_err()
        {
            return Ok(None);
        }
        let Ok(count) = buf::get_i32(&mut body) else {
            return Ok(None);
        };
        if count < 0 {
            return Ok(None);
        }
        let count_usize = usize::try_from(count).unwrap_or(usize::MAX);
        if count_usize > body.remaining() {
            return Ok(None);
        }
        Ok(Some(ShortVisit {
            body,
            base_offset: self.base_offset,
            base_timestamp,
            left: count_usize,
            meta: ShortKeyBatch {
                partition_leader_epoch,
                attributes,
                max_timestamp,
            },
        }))
    }

    /// Offset after this batch, from the header `lastOffsetDelta`.
    ///
    /// Compaction deletes tail records and still writes the original batch end
    /// into that field. `None` when the header is short or the sum does not fit
    /// in `i64`.
    pub(crate) fn header_exclusive_end(&self) -> Option<i64> {
        let raw = self.body.get(11..15)?;
        let bytes = <[u8; 4]>::try_from(raw).ok()?;
        let delta = i32::from_be_bytes(bytes);
        self.base_offset
            .checked_add(i64::from(delta))
            .and_then(|last| last.checked_add(1))
    }

    /// Offset prefix plus the framed body. Used to cap retained fetch bytes.
    pub(crate) fn framed_len(&self) -> usize {
        self.body.len().saturating_add(12)
    }

    /// Declared record count from the batch header, or zero when the header
    /// is short or the count is negative. Does not decode records.
    pub(crate) fn declared_count(&self) -> usize {
        // partitionLeaderEpoch(4) magic(1) crc(4) attributes(2)
        // lastOffsetDelta(4) baseTimestamp(8) maxTimestamp(8)
        // producerId(8) producerEpoch(2) baseSequence(4) = 45.
        let Some(raw) = self.body.get(45..49) else {
            return 0;
        };
        let Ok(bytes) = <[u8; 4]>::try_from(raw) else {
            return 0;
        };
        let count = i32::from_be_bytes(bytes);
        usize::try_from(count).unwrap_or(0)
    }

    /// How many `FetchedRecord` slots a caller can reserve without trusting
    /// a count the decoder would reject.
    ///
    /// Compressed batches return zero (the inflated count is only known after
    /// decompression). An uncompressed count larger than the records section
    /// returns zero so a hostile header cannot reserve more slots than a
    /// successful decode would allocate.
    pub(crate) fn reserve_hint(&self) -> usize {
        let Some(raw) = self.body.get(9..11) else {
            return 0;
        };
        let Ok(bytes) = <[u8; 2]>::try_from(raw) else {
            return 0;
        };
        if i16::from_be_bytes(bytes) & ATTR_COMPRESSION_CODEC != 0 {
            return 0;
        }
        let count = self.declared_count();
        let section = self.body.len().saturating_sub(49);
        if count > section {
            0
        } else {
            count
        }
    }
}

/// A short list that keeps its first item inline.
pub(crate) enum SlotList<T> {
    /// The list has no items.
    Empty,
    /// The list has one item.
    One(T),
    /// The list has more than one item.
    Many(Vec<T>),
}

impl<T> SlotList<T> {
    /// A list with a bounded initial hint for `count` items.
    ///
    /// Zero and one stay inline. Longer lists initially reserve at most 256 slots.
    pub(crate) fn with_capacity(count: usize) -> Self {
        if count <= 1 {
            Self::Empty
        } else {
            Self::Many(Vec::with_capacity(count.min(256)))
        }
    }

    /// Reserve a bounded initial hint against a shared metadata budget.
    pub(crate) fn try_with_budget(count: usize, budget: &mut DecodeMetadataBudget) -> Result<Self> {
        let target = count.min(256).min(budget.remaining_slots::<T>());
        if target <= 1 {
            return Ok(Self::Empty);
        }
        let mut items = Vec::new();
        budget.reserve(&mut items, target)?;
        Ok(Self::Many(items))
    }

    /// Append while charging actual vector growth to a shared budget.
    pub(crate) fn try_push_with_budget(
        &mut self,
        item: T,
        budget: &mut DecodeMetadataBudget,
    ) -> Result<()> {
        match self {
            Self::Empty => *self = Self::One(item),
            Self::One(_) => {
                let mut items = Vec::new();
                budget.reserve(&mut items, 2)?;
                let previous = std::mem::replace(self, Self::Empty);
                if let Self::One(first) = previous {
                    items.push(first);
                    items.push(item);
                    *self = Self::Many(items);
                } else {
                    *self = previous;
                    return Err(Error::protocol("list state changed"));
                }
            }
            Self::Many(items) => {
                if items.len() == items.capacity() {
                    let maximum = budget.remaining_slots::<T>();
                    let target = items.capacity().saturating_mul(2).max(4).min(maximum);
                    if target <= items.capacity() {
                        return Err(Error::protocol(
                            "decoded record metadata exceeds maximum allowable size",
                        ));
                    }
                    budget.reserve(items, target)?;
                }
                items.push(item);
            }
        }
        Ok(())
    }

    /// Append one item. The second item moves the list into a vector.
    pub(crate) fn push(&mut self, item: T) {
        match std::mem::replace(self, Self::Empty) {
            Self::Empty => *self = Self::One(item),
            Self::One(first) => *self = Self::Many(vec![first, item]),
            Self::Many(mut items) => {
                items.push(item);
                *self = Self::Many(items);
            }
        }
    }
}

impl<T> std::ops::Deref for SlotList<T> {
    type Target = [T];

    fn deref(&self) -> &Self::Target {
        match self {
            Self::Empty => &[],
            Self::One(item) => std::slice::from_ref(item),
            Self::Many(items) => items,
        }
    }
}

impl<'a, T> IntoIterator for &'a SlotList<T> {
    type Item = &'a T;
    type IntoIter = std::slice::Iter<'a, T>;

    fn into_iter(self) -> Self::IntoIter {
        self.iter()
    }
}

impl<T> IntoIterator for SlotList<T> {
    type Item = T;
    type IntoIter = SlotListIntoIter<T>;

    fn into_iter(self) -> Self::IntoIter {
        match self {
            Self::Empty => SlotListIntoIter {
                one: None,
                many: Vec::new().into_iter(),
            },
            Self::One(item) => SlotListIntoIter {
                one: Some(item),
                many: Vec::new().into_iter(),
            },
            Self::Many(items) => SlotListIntoIter {
                one: None,
                many: items.into_iter(),
            },
        }
    }
}

impl<T> FromIterator<T> for SlotList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::Empty;
        for item in iter {
            list.push(item);
        }
        list
    }
}

/// Owned walk of a [`SlotList`].
pub(crate) struct SlotListIntoIter<T> {
    one: Option<T>,
    many: std::vec::IntoIter<T>,
}

impl<T> Iterator for SlotListIntoIter<T> {
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.one.take().or_else(|| self.many.next())
    }
}

/// Framed batches from one partition.
///
/// No batches and one batch stay inline. Several batches own a vector.
pub(crate) enum BatchList {
    /// The partition returned no record batches.
    Empty,
    /// The partition returned one record batch.
    One(EncodedBatch),
    /// The partition returned more than one record batch.
    Many(Vec<EncodedBatch>),
}

impl BatchList {
    fn push(&mut self, item: EncodedBatch) {
        match std::mem::replace(self, Self::Empty) {
            Self::Empty => *self = Self::One(item),
            Self::One(first) => *self = Self::Many(vec![first, item]),
            Self::Many(mut items) => {
                items.push(item);
                *self = Self::Many(items);
            }
        }
    }
}

impl std::ops::Deref for BatchList {
    type Target = [EncodedBatch];

    fn deref(&self) -> &Self::Target {
        match self {
            Self::Empty => &[],
            Self::One(batch) => std::slice::from_ref(batch),
            Self::Many(batches) => batches,
        }
    }
}

impl<'a> IntoIterator for &'a BatchList {
    type Item = &'a EncodedBatch;
    type IntoIter = std::slice::Iter<'a, EncodedBatch>;

    fn into_iter(self) -> Self::IntoIter {
        self.iter()
    }
}

impl IntoIterator for BatchList {
    type Item = EncodedBatch;
    type IntoIter = BatchListIntoIter;

    fn into_iter(self) -> Self::IntoIter {
        match self {
            Self::Empty => BatchListIntoIter {
                one: None,
                many: Vec::new().into_iter(),
            },
            Self::One(batch) => BatchListIntoIter {
                one: Some(batch),
                many: Vec::new().into_iter(),
            },
            Self::Many(batches) => BatchListIntoIter {
                one: None,
                many: batches.into_iter(),
            },
        }
    }
}

impl FromIterator<EncodedBatch> for BatchList {
    fn from_iter<I: IntoIterator<Item = EncodedBatch>>(iter: I) -> Self {
        let mut list = Self::Empty;
        for batch in iter {
            list.push(batch);
        }
        list
    }
}

/// Owned walk of a [`BatchList`].
pub(crate) struct BatchListIntoIter {
    one: Option<EncodedBatch>,
    many: std::vec::IntoIter<EncodedBatch>,
}

impl Iterator for BatchListIntoIter {
    type Item = EncodedBatch;

    fn next(&mut self) -> Option<Self::Item> {
        self.one.take().or_else(|| self.many.next())
    }
}

/// Split consecutive magic-v2 batches like [`decode_record_batches`] (a
/// trailing partial batch is ignored), checking framing, magic, CRC32-C and
/// codec without decompressing anything.
#[cfg(test)]
pub(crate) fn split_record_batches(mut buf: Bytes) -> Result<BatchList> {
    let Some(first) = next_framed_batch(&mut buf)? else {
        return Ok(BatchList::Empty);
    };
    if buf.remaining() < 12 {
        return Ok(BatchList::One(first));
    }
    let extra = count_framed_batches(buf.as_ref())?;
    if extra == 0 {
        return Ok(BatchList::One(first));
    }
    let mut many = Vec::new();
    many.try_reserve_exact(extra.saturating_add(1))
        .map_err(|_| Error::protocol("record batch reserve"))?;
    many.push(first);
    while let Some(batch) = next_framed_batch(&mut buf)? {
        many.push(batch);
    }
    Ok(BatchList::Many(many))
}

/// [`split_record_batches`], yielding while a long run of batches is counted.
pub(crate) async fn split_record_batches_cooperative_with_budget(
    mut buf: Bytes,
    metadata: &mut DecodeMetadataBudget,
) -> Result<BatchList> {
    let Some(first) = next_framed_batch(&mut buf)? else {
        return Ok(BatchList::Empty);
    };
    if buf.remaining() < 12 {
        return Ok(BatchList::One(first));
    }
    let extra = count_framed_batches_cooperative(buf.as_ref()).await?;
    if extra == 0 {
        return Ok(BatchList::One(first));
    }
    let mut many = Vec::new();
    metadata.reserve(&mut many, extra.saturating_add(1))?;
    many.push(first);
    let mut walked = 0usize;
    while let Some(batch) = next_framed_batch(&mut buf)? {
        many.push(batch);
        walked = walked.saturating_add(1);
        if walked == 64 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    Ok(BatchList::Many(many))
}

fn next_framed_batch(buf: &mut Bytes) -> Result<Option<EncodedBatch>> {
    if buf.remaining() < 12 {
        return Ok(None);
    }
    let len_bytes = buf
        .get(8..12)
        .ok_or_else(|| Error::protocol("short batch length"))?;
    let batch_len = i32::from_be_bytes(
        len_bytes
            .try_into()
            .map_err(|_| Error::protocol("short batch length"))?,
    );
    if batch_len < 0 {
        return Err(Error::protocol("negative record batch length"));
    }
    let need = 12usize.saturating_add(buf::usize_from_i32(batch_len)?);
    if buf.remaining() < need {
        return Ok(None);
    }
    let (base_offset, body) = take_checked_batch(buf)?;
    let attr_bytes = body
        .get(9..11)
        .ok_or_else(|| Error::protocol("short batch attributes"))?;
    let attributes = i16::from_be_bytes(
        attr_bytes
            .try_into()
            .map_err(|_| Error::protocol("short batch attributes"))?,
    );
    Ok(Some(EncodedBatch {
        base_offset,
        attributes,
        body,
    }))
}

/// How many complete magic-v2 batches `bytes` holds.
///
/// A truncated tail is not counted. A negative batch length is an error.
#[cfg(test)]
pub(crate) fn count_framed_batches(bytes: &[u8]) -> Result<usize> {
    count_framed_batches_from(bytes, 0, usize::MAX).map(|(count, _)| count)
}

/// Count complete batches from `start`, stopping after `budget` bytes.
///
/// Returns the number of batches in this slice and the offset to resume at.
/// A long run of batches is still legal. Counting all of it in one turn
/// keeps the caller from running until the walk finishes.
fn count_framed_batches_from(bytes: &[u8], start: usize, budget: usize) -> Result<(usize, usize)> {
    let mut offset = start.min(bytes.len());
    let limit = offset.saturating_add(budget.max(12));
    let mut count = 0usize;
    while bytes.len().saturating_sub(offset) >= 12 {
        if offset >= limit && count > 0 {
            return Ok((count, offset));
        }
        let len_at = offset.saturating_add(8);
        let len_bytes = bytes
            .get(len_at..len_at.saturating_add(4))
            .ok_or_else(|| Error::protocol("short batch length"))?;
        let batch_len = i32::from_be_bytes(
            len_bytes
                .try_into()
                .map_err(|_| Error::protocol("short batch length"))?,
        );
        if batch_len < 0 {
            return Err(Error::protocol("negative record batch length"));
        }
        let need = 12usize.saturating_add(buf::usize_from_i32(batch_len)?);
        if bytes.len().saturating_sub(offset) < need {
            break;
        }
        offset = offset.saturating_add(need);
        count = count.saturating_add(1);
    }
    Ok((count, offset))
}

/// [`count_framed_batches`], yielding between slices so a caller can run.
pub(crate) async fn count_framed_batches_cooperative(bytes: &[u8]) -> Result<usize> {
    let mut offset = 0usize;
    let mut total = 0usize;
    loop {
        let (count, next) = count_framed_batches_from(bytes, offset, 64 * 1024)?;
        total = total.saturating_add(count);
        if next <= offset || next >= bytes.len() || bytes.len().saturating_sub(next) < 12 {
            return Ok(total);
        }
        offset = next;
        tokio::task::yield_now().await;
    }
}

/// Decode one magic-v2 batch (CRC32-C checked), enforcing [`DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES`].
///
/// Nested records match Java `DefaultRecord.readFrom`: a negative header
/// count, a header count larger than remaining bytes, a negative header
/// key size, a declared body larger than remaining, and leftover payload
/// bytes after headers use the Java `InvalidRecordException` messages.
/// Batch record-count checks match Java `DefaultRecordBatch.RecordIterator`
/// (`Found invalid record count`, leftover records after the declared
/// count, premature EOF when the count is larger than the payload).
/// Size and CRC checks match Java `DefaultRecordBatch.ensureValid`.
pub fn decode_record_batch<B: Buf>(buf: &mut B) -> Result<RecordBatch> {
    decode_record_batch_with_limit(buf, DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES)
}

/// Decode one magic-v2 batch (CRC32-C checked), enforcing an explicit decoded-byte ceiling.
///
/// This wire codec follows Java's signed wrapping arithmetic for record offsets
/// and timestamps. The consumer's internal decode path separately rejects
/// arithmetic overflow before applying records to positions or storage.
/// Record and header vector capacity has a separate aggregate ceiling of twice
/// `max_decode_bytes`, with a 64 KiB floor and a 128 MiB maximum. Payload and
/// copied header-key bytes are accounted for by the decoded-byte ceiling.
pub fn decode_record_batch_with_limit<B: Buf>(
    buf: &mut B,
    max_decode_bytes: usize,
) -> Result<RecordBatch> {
    let mut metadata = DecodeMetadataBudget::for_wire_limit(max_decode_bytes);
    decode_record_batch_wire_budgeted(buf, max_decode_bytes, &mut metadata)
}

fn decode_record_batch_wire_budgeted<B: Buf>(
    buf: &mut B,
    max_decode_bytes: usize,
    metadata: &mut DecodeMetadataBudget,
) -> Result<RecordBatch> {
    let (base_offset, body) = take_checked_batch(buf)?;
    let mut open =
        open_checked_batch_with_budget(base_offset, body, max_decode_bytes, Vec::new(), *metadata)?;
    let remaining = open.remaining;
    if remaining > 0 {
        pull_records::<true>(&mut open, remaining)?;
    }
    let updated = open.metadata;
    let batch = finish_checked_batch(open)?;
    *metadata = updated;
    Ok(batch)
}

/// Decode one batch, refilling `records` when that buffer already has room.
pub(crate) fn decode_record_batch_reusing<B: Buf>(
    buf: &mut B,
    max_decode_bytes: usize,
    records: Vec<Record>,
) -> Result<RecordBatch> {
    let (base_offset, body) = take_checked_batch(buf)?;
    decode_checked_batch(base_offset, body, max_decode_bytes, records)
}

/// [`decode_record_batch_reusing`], yielding while a long record list is decoded.
pub(crate) async fn decode_record_batch_reusing_cooperative<B: Buf>(
    buf: &mut B,
    max_decode_bytes: usize,
    records: Vec<Record>,
) -> Result<RecordBatch> {
    let (base_offset, body) = take_checked_batch(buf)?;
    decode_checked_batch_cooperative(base_offset, body, max_decode_bytes, records).await
}

/// Frame one magic-v2 batch and check its size, magic, CRC32-C and codec
/// without decompressing it. Returns the base offset and the batch body from
/// `partitionLeaderEpoch` on.
fn take_checked_batch<B: Buf>(buf: &mut B) -> Result<(i64, Bytes)> {
    let base_offset = buf::get_i64(buf)?;
    let batch_len = buf::get_i32(buf)?;
    let size_in_bytes = Records::LOG_OVERHEAD.wrapping_add(batch_len);
    if size_in_bytes < RecordBatch::RECORD_BATCH_OVERHEAD {
        return Err(Error::protocol(format!(
            "Record batch is corrupt (the size {size_in_bytes} is smaller than the minimum allowed overhead {})",
            RecordBatch::RECORD_BATCH_OVERHEAD
        )));
    }
    let batch_len_usize = buf::usize_from_i32(batch_len)?;
    buf::need(buf, batch_len_usize)?;
    let body = buf.copy_to_bytes(batch_len_usize);
    // Peek through slices: cloning a freshly copied `Bytes` would allocate.
    let mut head: &[u8] = &body;
    let _partition_leader_epoch = buf::get_i32(&mut head)?;
    let magic = buf::get_i8(&mut head)?;
    if magic != MAGIC_V2 {
        return Err(Error::protocol(format!("unsupported record magic {magic}")));
    }
    let crc = buf::get_u32(&mut head)?;
    let computed = crc32c::crc32c(head);
    if computed != crc {
        return Err(Error::protocol(format!(
            "Record is corrupt (stored crc = {crc}, computed crc = {computed})"
        )));
    }
    let _codec = Compression::from_attributes(buf::get_i16(&mut head)?)?;
    Ok((base_offset, body))
}

/// Decode a body that [`take_checked_batch`] already framed and checked.
fn decode_checked_batch(
    base_offset: i64,
    body: Bytes,
    max_decode_bytes: usize,
    records: Vec<Record>,
) -> Result<RecordBatch> {
    let mut open = open_checked_batch(base_offset, body, max_decode_bytes, records)?;
    let remaining = open.remaining;
    if remaining > 0 {
        pull_checked_records(&mut open, remaining)?;
    }
    finish_checked_batch(open)
}

/// [`decode_checked_batch`], yielding between slices of a long record list.
pub(crate) async fn decode_checked_batch_cooperative(
    base_offset: i64,
    body: Bytes,
    max_decode_bytes: usize,
    records: Vec<Record>,
) -> Result<RecordBatch> {
    let mut metadata = DecodeMetadataBudget::for_wire_limit(max_decode_bytes);
    decode_checked_batch_cooperative_with_budget(
        base_offset,
        body,
        max_decode_bytes,
        records,
        &mut metadata,
    )
    .await
}

async fn decode_checked_batch_cooperative_with_budget(
    base_offset: i64,
    body: Bytes,
    max_decode_bytes: usize,
    records: Vec<Record>,
    metadata: &mut DecodeMetadataBudget,
) -> Result<RecordBatch> {
    let mut open =
        open_checked_batch_cooperative(base_offset, body, max_decode_bytes, records, *metadata)
            .await?;
    while open.remaining > 0 {
        pull_checked_records(&mut open, 8 * 1024)?;
        if open.remaining > 0 {
            tokio::task::yield_now().await;
        }
    }
    let updated = open.metadata;
    let batch = finish_checked_batch(open)?;
    *metadata = updated;
    Ok(batch)
}

struct OpenBatch {
    base_offset: i64,
    partition_leader_epoch: i32,
    attributes: i16,
    base_timestamp: i64,
    max_timestamp: i64,
    producer_id: i64,
    producer_epoch: i16,
    base_sequence: i32,
    records_cur: Bytes,
    remaining: usize,
    records: Vec<Record>,
    metadata: DecodeMetadataBudget,
}

struct BatchPrefix {
    partition_leader_epoch: i32,
    attributes: i16,
    compression: Compression,
    base_timestamp: i64,
    max_timestamp: i64,
    producer_id: i64,
    producer_epoch: i16,
    base_sequence: i32,
    count: i32,
}

fn read_batch_prefix(body: &mut Bytes) -> Result<BatchPrefix> {
    let partition_leader_epoch = buf::get_i32(body)?;
    let magic = buf::get_i8(body)?;
    let _crc = buf::get_u32(body)?;
    let attributes = buf::get_i16(body)?;
    let compression = Compression::from_attributes(attributes)?;
    let _last_delta = buf::get_i32(body)?;
    let base_timestamp = buf::get_i64(body)?;
    let max_timestamp = buf::get_i64(body)?;
    let producer_id = buf::get_i64(body)?;
    let producer_epoch = buf::get_i16(body)?;
    let base_sequence = buf::get_i32(body)?;
    let count = buf::get_i32(body)?;
    if count < 0 {
        return Err(Error::protocol(format!(
            "Found invalid record count {count} in magic v{magic} batch"
        )));
    }
    Ok(BatchPrefix {
        partition_leader_epoch,
        attributes,
        compression,
        base_timestamp,
        max_timestamp,
        producer_id,
        producer_epoch,
        base_sequence,
        count,
    })
}

fn uncompressed_records(body: Bytes, max_decode_bytes: usize) -> Result<Bytes> {
    if body.len() > max_decode_bytes {
        return Err(Error::protocol(
            "Decompressed batch exceeds maximum allowable size",
        ));
    }
    Ok(body)
}

fn assemble_open_batch(
    base_offset: i64,
    prefix: BatchPrefix,
    records_cur: Bytes,
    mut records: Vec<Record>,
    mut metadata: DecodeMetadataBudget,
) -> Result<OpenBatch> {
    let count_usize = buf::usize_from_i32(prefix.count)?;
    // A magic-v2 record requires a length prefix plus six one-byte fields.
    if count_usize > records_cur.remaining() / 7 {
        return Err(Error::protocol(
            "Incorrect declared record count, exceeds remaining bytes",
        ));
    }
    metadata.require::<Record>(count_usize)?;
    records.clear();
    let retained_bytes = records
        .capacity()
        .checked_mul(std::mem::size_of::<Record>());
    if retained_bytes.is_none_or(|bytes| {
        metadata
            .used
            .checked_add(bytes)
            .is_none_or(|sum| sum > metadata.limit)
    }) {
        records = Vec::new();
    } else {
        metadata.charge::<Record>(records.capacity())?;
    }
    metadata.reserve(&mut records, count_usize.min(64))?;
    Ok(OpenBatch {
        base_offset,
        partition_leader_epoch: prefix.partition_leader_epoch,
        attributes: prefix.attributes,
        base_timestamp: prefix.base_timestamp,
        max_timestamp: prefix.max_timestamp,
        producer_id: prefix.producer_id,
        producer_epoch: prefix.producer_epoch,
        base_sequence: prefix.base_sequence,
        records_cur,
        remaining: count_usize,
        records,
        metadata,
    })
}

fn open_checked_batch(
    base_offset: i64,
    body: Bytes,
    max_decode_bytes: usize,
    records: Vec<Record>,
) -> Result<OpenBatch> {
    open_checked_batch_with_budget(
        base_offset,
        body,
        max_decode_bytes,
        records,
        DecodeMetadataBudget::for_wire_limit(max_decode_bytes),
    )
}

fn open_checked_batch_with_budget(
    base_offset: i64,
    mut body: Bytes,
    max_decode_bytes: usize,
    records: Vec<Record>,
    metadata: DecodeMetadataBudget,
) -> Result<OpenBatch> {
    let prefix = read_batch_prefix(&mut body)?;
    let records_cur = if prefix.compression == Compression::None {
        uncompressed_records(body, max_decode_bytes)?
    } else {
        Bytes::from(decompress_batch(
            prefix.compression,
            &body,
            max_decode_bytes,
        )?)
    };
    assemble_open_batch(base_offset, prefix, records_cur, records, metadata)
}

async fn open_checked_batch_cooperative(
    base_offset: i64,
    mut body: Bytes,
    max_decode_bytes: usize,
    records: Vec<Record>,
    metadata: DecodeMetadataBudget,
) -> Result<OpenBatch> {
    let prefix = read_batch_prefix(&mut body)?;
    let records_cur = if prefix.compression == Compression::None {
        uncompressed_records(body, max_decode_bytes)?
    } else {
        Bytes::from(
            decompress_batch_cooperative(prefix.compression, &body, max_decode_bytes).await?,
        )
    };
    assemble_open_batch(base_offset, prefix, records_cur, records, metadata)
}

fn decompress_batch(
    compression: Compression,
    body: &[u8],
    max_decode_bytes: usize,
) -> Result<Vec<u8>> {
    match compression {
        Compression::None => Err(Error::protocol("internal: uncompressed decompress")),
        Compression::Gzip => gzip_decompress(body, max_decode_bytes),
        Compression::Snappy => snappy_decompress(body, max_decode_bytes),
        Compression::Lz4 => lz4_decompress(body, max_decode_bytes),
        #[cfg(feature = "zstd")]
        Compression::Zstd => zstd_decompress(body, max_decode_bytes),
    }
}

async fn decompress_batch_cooperative(
    compression: Compression,
    body: &Bytes,
    max_decode_bytes: usize,
) -> Result<Vec<u8>> {
    match compression {
        Compression::None => Err(Error::protocol("internal: uncompressed decompress")),
        Compression::Gzip => gzip_decompress_cooperative(body, max_decode_bytes).await,
        Compression::Snappy => snappy_decompress_cooperative(body.clone(), max_decode_bytes).await,
        Compression::Lz4 => lz4_decompress_cooperative(body, max_decode_bytes).await,
        #[cfg(feature = "zstd")]
        Compression::Zstd => zstd_decompress(body, max_decode_bytes),
    }
}

fn pull_checked_records(open: &mut OpenBatch, limit: usize) -> Result<()> {
    pull_records::<false>(open, limit)
}

fn pull_records<const WIRE_WRAP: bool>(open: &mut OpenBatch, limit: usize) -> Result<()> {
    let mut left = limit.max(1).min(open.remaining);
    while left > 0 {
        if !open.records_cur.has_remaining() {
            return Err(Error::protocol(
                "Incorrect declared batch size, premature EOF reached",
            ));
        }
        let record = decode_record_from_bytes_mode::<WIRE_WRAP>(
            &mut open.records_cur,
            open.base_offset,
            open.base_timestamp,
            &mut open.metadata,
        )?;
        if open.records.len() == open.records.capacity() {
            let total = open.records.len().saturating_add(open.remaining);
            let target = open
                .records
                .capacity()
                .saturating_mul(2)
                .max(64)
                .min(total)
                .min(open.metadata.remaining_slots::<Record>());
            if target <= open.records.capacity() {
                return Err(Error::protocol(
                    "decoded record metadata exceeds maximum allowable size",
                ));
            }
            open.metadata.reserve(&mut open.records, target)?;
        }
        open.records.push(record);
        open.remaining = open.remaining.saturating_sub(1);
        left = left.saturating_sub(1);
    }
    Ok(())
}

fn finish_checked_batch(open: OpenBatch) -> Result<RecordBatch> {
    if open.remaining > 0 {
        return Err(Error::protocol(
            "Incorrect declared batch size, premature EOF reached",
        ));
    }
    if open.records_cur.has_remaining() {
        return Err(Error::protocol(
            "Incorrect declared batch size, records still remaining in file",
        ));
    }
    Ok(RecordBatch {
        base_offset: open.base_offset,
        partition_leader_epoch: open.partition_leader_epoch,
        attributes: open.attributes,
        base_timestamp: open.base_timestamp,
        max_timestamp: open.max_timestamp,
        producer_id: open.producer_id,
        producer_epoch: open.producer_epoch,
        base_sequence: open.base_sequence,
        records: open.records,
    })
}

#[cfg(test)]
fn decode_record_from_bytes(
    buf: &mut Bytes,
    base_offset: i64,
    base_timestamp: i64,
) -> Result<Record> {
    let mut metadata = DecodeMetadataBudget::for_wire_limit(DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES);
    decode_record_from_bytes_mode::<false>(buf, base_offset, base_timestamp, &mut metadata)
}

fn decode_record_from_bytes_mode<const WIRE_WRAP: bool>(
    buf: &mut Bytes,
    base_offset: i64,
    base_timestamp: i64,
    metadata: &mut DecodeMetadataBudget,
) -> Result<Record> {
    if let Some(record) = try_plain_record(buf, base_offset, base_timestamp) {
        return Ok(record);
    }
    decode_record_mode::<WIRE_WRAP, _>(buf, base_offset, base_timestamp, metadata)
}

/// One- or two-byte zigzag varint. Longer encodings return `None` so the
/// generic reader can handle them.
fn read_short_zigzag_i32(chunk: &[u8], index: usize) -> Option<(i32, usize)> {
    let first = *chunk.get(index)?;
    if first & 0x80 == 0 {
        return Some((
            buf::unzigzag_varint(u32::from(first)),
            index.saturating_add(1),
        ));
    }
    let second = *chunk.get(index.saturating_add(1))?;
    if second & 0x80 != 0 {
        return None;
    }
    let raw = u32::from(first & 0x7f) | (u32::from(second) << 7);
    Some((buf::unzigzag_varint(raw), index.saturating_add(2)))
}

fn read_short_zigzag_i64(chunk: &[u8], index: usize) -> Option<(i64, usize)> {
    let first = *chunk.get(index)?;
    if first & 0x80 == 0 {
        return Some((
            buf::unzigzag_varlong(u64::from(first)),
            index.saturating_add(1),
        ));
    }
    let second = *chunk.get(index.saturating_add(1))?;
    if second & 0x80 != 0 {
        return None;
    }
    let raw = u64::from(first & 0x7f) | (u64::from(second) << 7);
    Some((buf::unzigzag_varlong(raw), index.saturating_add(2)))
}

/// Uncompressed record with no headers and one- or two-byte lengths.
///
/// Leaves `buf` unchanged when the shape does not match, so the generic
/// decoder still reports the Java error text.
fn try_plain_record(buf: &mut Bytes, base_offset: i64, base_timestamp: i64) -> Option<Record> {
    let chunk = buf.chunk();
    let (body_len, mut index) = read_short_zigzag_i32(chunk, 0)?;
    if body_len < 0 {
        return None;
    }
    let body_len = usize::try_from(body_len).ok()?;
    let body_end = index.checked_add(body_len)?;
    if chunk.len() < body_end {
        return None;
    }
    let attributes = *chunk.get(index)?;
    if attributes != 0 {
        return None;
    }
    index = index.saturating_add(1);
    let (timestamp_delta, next) = read_short_zigzag_i64(chunk, index)?;
    index = next;
    let (offset_delta, next) = read_short_zigzag_i32(chunk, index)?;
    index = next;
    let (key_len, next) = read_short_zigzag_i32(chunk, index)?;
    index = next;
    let key_range = if key_len < 0 {
        if key_len != -1 {
            return None;
        }
        None
    } else {
        let len = usize::try_from(key_len).ok()?;
        let end = index.checked_add(len)?;
        if end > body_end {
            return None;
        }
        let range = (index, end);
        index = end;
        Some(range)
    };
    let (value_len, next) = read_short_zigzag_i32(chunk, index)?;
    index = next;
    let value_range = if value_len < 0 {
        if value_len != -1 {
            return None;
        }
        None
    } else {
        let len = usize::try_from(value_len).ok()?;
        let end = index.checked_add(len)?;
        if end > body_end {
            return None;
        }
        let range = (index, end);
        index = end;
        Some(range)
    };
    let (header_count, next) = read_short_zigzag_i32(chunk, index)?;
    if header_count != 0 {
        return None;
    }
    index = next;
    if index != body_end {
        return None;
    }
    let offset = record_offset(base_offset, offset_delta)?;
    let timestamp = record_timestamp(base_timestamp, timestamp_delta)?;
    let key = key_range.map(|(start, end)| buf.slice(start..end));
    let value = value_range.map(|(start, end)| buf.slice(start..end));
    buf.advance(body_end);
    Some(Record {
        offset,
        timestamp,
        key,
        value,
        headers: Vec::new(),
    })
}

/// Like [`try_plain_record`], but copies a key of at most 24 bytes instead of
/// sharing it. Longer keys and every other mismatch leave `buf` unchanged.
pub(crate) struct ShortKeyRecord {
    pub(crate) offset: i64,
    pub(crate) timestamp: i64,
    pub(crate) key: Option<([u8; 24], u8)>,
    pub(crate) value: Option<Bytes>,
}

pub(crate) struct ShortKeyBatch {
    pub(crate) partition_leader_epoch: i32,
    pub(crate) attributes: i16,
    pub(crate) max_timestamp: i64,
}

struct ShortVisit {
    body: Bytes,
    base_offset: i64,
    base_timestamp: i64,
    left: usize,
    meta: ShortKeyBatch,
}

enum ShortPull {
    More,
    Done,
    Mismatch,
}

fn pull_short_visit(
    visit: &mut ShortVisit,
    limit: usize,
    on_record: &mut impl FnMut(ShortKeyRecord),
) -> Result<ShortPull> {
    let mut left = limit.max(1);
    while visit.left > 0 && left > 0 {
        let Some(record) =
            try_plain_short_key(&mut visit.body, visit.base_offset, visit.base_timestamp)
        else {
            return Ok(ShortPull::Mismatch);
        };
        on_record(record);
        visit.left = visit.left.saturating_sub(1);
        left = left.saturating_sub(1);
    }
    if visit.left > 0 {
        return Ok(ShortPull::More);
    }
    if visit.body.has_remaining() {
        return Ok(ShortPull::Mismatch);
    }
    Ok(ShortPull::Done)
}

fn try_plain_short_key(
    buf: &mut Bytes,
    base_offset: i64,
    base_timestamp: i64,
) -> Option<ShortKeyRecord> {
    let chunk = buf.chunk();
    let (body_len, mut index) = read_short_zigzag_i32(chunk, 0)?;
    if body_len < 0 {
        return None;
    }
    let body_len = usize::try_from(body_len).ok()?;
    let body_end = index.checked_add(body_len)?;
    if chunk.len() < body_end {
        return None;
    }
    let attributes = *chunk.get(index)?;
    if attributes != 0 {
        return None;
    }
    index = index.saturating_add(1);
    let (timestamp_delta, next) = read_short_zigzag_i64(chunk, index)?;
    index = next;
    let (offset_delta, next) = read_short_zigzag_i32(chunk, index)?;
    index = next;
    let (key_len, next) = read_short_zigzag_i32(chunk, index)?;
    index = next;
    let key = if key_len < 0 {
        if key_len != -1 {
            return None;
        }
        None
    } else {
        let len = usize::try_from(key_len).ok()?;
        if len > 24 {
            return None;
        }
        let end = index.checked_add(len)?;
        if end > body_end {
            return None;
        }
        let bytes = chunk.get(index..end)?;
        let mut copied = [0u8; 24];
        copied.get_mut(..len)?.copy_from_slice(bytes);
        index = end;
        Some((copied, u8::try_from(len).ok()?))
    };
    let (value_len, next) = read_short_zigzag_i32(chunk, index)?;
    index = next;
    let value_range = if value_len < 0 {
        if value_len != -1 {
            return None;
        }
        None
    } else {
        let len = usize::try_from(value_len).ok()?;
        let end = index.checked_add(len)?;
        if end > body_end {
            return None;
        }
        let range = (index, end);
        index = end;
        Some(range)
    };
    let (header_count, next) = read_short_zigzag_i32(chunk, index)?;
    if header_count != 0 {
        return None;
    }
    index = next;
    if index != body_end {
        return None;
    }
    let offset = record_offset(base_offset, offset_delta)?;
    let timestamp = record_timestamp(base_timestamp, timestamp_delta)?;
    let value = value_range.map(|(start, end)| buf.slice(start..end));
    buf.advance(body_end);
    Some(ShortKeyRecord {
        offset,
        timestamp,
        key,
        value,
    })
}

pub(crate) fn absolute_offset_delta(base: i64, index: usize) -> Result<i32> {
    let delta = buf::i32_from_usize(index)?;
    if base.checked_add(i64::from(delta)).is_none() {
        return Err(Error::protocol(OFFSET_OVERFLOW));
    }
    Ok(delta)
}

pub(crate) fn timestamp_delta(base: i64, timestamp: i64) -> Result<i64> {
    timestamp
        .checked_sub(base)
        .ok_or_else(|| Error::protocol(TIMESTAMP_OVERFLOW))
}

fn offset_delta_from(base: i64, offset: i64) -> Result<i32> {
    let delta = offset
        .checked_sub(base)
        .ok_or_else(|| Error::protocol("offset delta exceeds i32"))?;
    i32::try_from(delta).map_err(|_| Error::protocol("offset delta exceeds i32"))
}

fn record_offset(base: i64, delta: i32) -> Option<i64> {
    base.checked_add(i64::from(delta))
}

fn record_timestamp(base: i64, delta: i64) -> Option<i64> {
    base.checked_add(delta)
}

/// Java `DefaultRecord.readFrom` (magic-v2 inner record).
#[cfg(test)]
fn decode_record<B: Buf>(buf: &mut B, base_offset: i64, base_timestamp: i64) -> Result<Record> {
    let mut metadata = DecodeMetadataBudget::for_wire_limit(DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES);
    decode_record_mode::<false, _>(buf, base_offset, base_timestamp, &mut metadata)
}

fn decode_record_mode<const WIRE_WRAP: bool, B: Buf>(
    buf: &mut B,
    base_offset: i64,
    base_timestamp: i64,
    metadata: &mut DecodeMetadataBudget,
) -> Result<Record> {
    let size_of_body_in_bytes = buf::get_varint(buf)?;
    if size_of_body_in_bytes < 0 {
        return Err(Error::protocol("negative record length"));
    }
    let remaining = buf.remaining();
    let len_usize = buf::usize_from_i32(size_of_body_in_bytes)?;
    if remaining < len_usize {
        return Err(Error::protocol(format!(
            "Invalid record size: expected {size_of_body_in_bytes} bytes in record payload, but instead the buffer has only {remaining} remaining bytes."
        )));
    }
    let mut inner = buf.copy_to_bytes(len_usize);
    let attributes = buf::get_i8(&mut inner)?;
    if attributes != 0 {
        return Err(Error::protocol(format!(
            "Unexpected attributes in DefaultRecord: {attributes}"
        )));
    }
    let timestamp_delta = buf::get_varlong(&mut inner)?;
    let offset_delta = buf::get_varint(&mut inner)?;
    let key = read_bytes_varint(&mut inner)?;
    let value = read_bytes_varint(&mut inner)?;
    let num_headers = buf::get_varint(&mut inner)?;
    if num_headers < 0 {
        return Err(Error::protocol(format!(
            "Found invalid number of record headers {num_headers}"
        )));
    }
    let num_headers_usize = buf::usize_from_i32(num_headers)?;
    // A header needs at least one byte each for key and value lengths.
    if num_headers_usize > inner.remaining() / 2 {
        return Err(Error::protocol(format!(
            "Found invalid number of record headers. {num_headers} is larger than the remaining size of the buffer"
        )));
    }
    metadata.require::<Header>(num_headers_usize)?;
    let mut headers = Vec::new();
    for _ in 0..num_headers_usize {
        let header_key_size = buf::get_varint(&mut inner)?;
        if header_key_size < 0 {
            return Err(Error::protocol(format!(
                "Invalid negative header key size {header_key_size}"
            )));
        }
        let key_len_usize = buf::usize_from_i32(header_key_size)?;
        buf::need(&inner, key_len_usize)?;
        let key_buf = buf::copy_exact(&mut inner, key_len_usize)?;
        let key = String::from_utf8(key_buf).map_err(|e| Error::protocol(e.to_string()))?;
        let value = read_bytes_varint(&mut inner)?;
        if headers.len() == headers.capacity() {
            let target = headers
                .capacity()
                .saturating_mul(2)
                .max(8)
                .min(num_headers_usize)
                .min(metadata.remaining_slots::<Header>());
            if target <= headers.capacity() {
                return Err(Error::protocol(
                    "decoded record metadata exceeds maximum allowable size",
                ));
            }
            metadata.reserve(&mut headers, target)?;
        }
        headers.push(Header { key, value });
    }
    if inner.remaining() != 0 {
        let consumed = len_usize - inner.remaining();
        return Err(Error::protocol(format!(
            "Invalid record size: expected to read {size_of_body_in_bytes} bytes in record payload, but instead read {consumed}"
        )));
    }
    Ok(Record {
        offset: if WIRE_WRAP {
            base_offset.wrapping_add(i64::from(offset_delta))
        } else {
            record_offset(base_offset, offset_delta)
                .ok_or_else(|| Error::protocol(OFFSET_OVERFLOW))?
        },
        timestamp: if WIRE_WRAP {
            base_timestamp.wrapping_add(timestamp_delta)
        } else {
            record_timestamp(base_timestamp, timestamp_delta)
                .ok_or_else(|| Error::protocol(TIMESTAMP_OVERFLOW))?
        },
        key,
        value,
        headers,
    })
}

fn read_bytes_varint<B: Buf>(buf: &mut B) -> Result<Option<Bytes>> {
    let len = buf::get_varint(buf)?;
    buf::read_bytes(buf, len)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn put_be_i32(bytes: &mut [u8], at: i32, value: i32) {
        let at = usize::try_from(at).unwrap();
        bytes[at..at + 4].copy_from_slice(&value.to_be_bytes());
    }

    fn put_batch_length(bytes: &mut [u8], length: i32) {
        put_be_i32(bytes, Records::SIZE_OFFSET, length);
    }

    fn put_record_count(bytes: &mut [u8], count: i32) {
        put_be_i32(bytes, RecordBatch::RECORDS_COUNT_OFFSET, count);
    }

    fn put_last_offset_delta(bytes: &mut [u8], delta: i32) {
        put_be_i32(bytes, RecordBatch::LAST_OFFSET_DELTA_OFFSET, delta);
    }

    fn put_base_timestamp(bytes: &mut [u8], timestamp: i64) {
        let at = usize::try_from(RecordBatch::BASE_TIMESTAMP_OFFSET).unwrap();
        bytes[at..at + 8].copy_from_slice(&timestamp.to_be_bytes());
    }

    fn put_attributes(bytes: &mut [u8], attributes: i16) {
        let at = usize::try_from(RecordBatch::ATTRIBUTES_OFFSET).unwrap();
        let end = usize::try_from(RecordBatch::LAST_OFFSET_DELTA_OFFSET).unwrap();
        bytes[at..end].copy_from_slice(&attributes.to_be_bytes());
    }

    fn put_magic(bytes: &mut [u8], magic: u8) {
        bytes[usize::try_from(Records::MAGIC_OFFSET).unwrap()] = magic;
    }

    fn restamp_crc(bytes: &mut [u8]) {
        let crc_at = usize::try_from(RecordBatch::CRC_OFFSET).unwrap();
        let attributes_at = usize::try_from(RecordBatch::ATTRIBUTES_OFFSET).unwrap();
        let crc = crc32c::crc32c(&bytes[attributes_at..]);
        bytes[crc_at..attributes_at].copy_from_slice(&crc.to_be_bytes());
    }

    #[test]
    fn magic_v2_header_offsets_match_the_broker_layout() {
        // Same positions as `partitionline-broker/src/batch.rs`.
        assert_eq!(Records::OFFSET_OFFSET, 0);
        assert_eq!(Records::OFFSET_LENGTH, 8);
        assert_eq!(Records::SIZE_OFFSET, 8);
        assert_eq!(Records::SIZE_LENGTH, 4);
        assert_eq!(Records::LOG_OVERHEAD, 12);
        assert_eq!(Records::MAGIC_OFFSET, 16);
        assert_eq!(Records::MAGIC_LENGTH, 1);
        assert_eq!(Records::HEADER_SIZE_UP_TO_MAGIC, 17);
        assert_eq!(RecordBatch::RECORD_BATCH_OVERHEAD, 61);
        assert_eq!(MAGIC_V2, 2);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn measuring_many_record_bytes_does_not_hold_the_caller() {
        // 2_000_000 records: measuring the batch held the caller 365ms.
        let header = BatchHeader::default();
        let records: Vec<EncodeRecord<'_>> = (0..2_000_000)
            .map(|_| EncodeRecord {
                timestamp: 1,
                key: None,
                value: Some(b"x"),
                headers: &[],
            })
            .collect();
        let started = std::time::Instant::now();
        tokio::select! {
            size = uncompressed_batch_len_cooperative(&header, records) => {
                let size = size.unwrap_or_else(|error| panic!("{error}"));
                assert!(size > 0);
            }
            () = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "measuring record bytes held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_a_long_batch_run_does_not_hold_the_caller() {
        let raw = vec![0u8; 48 * 1024 * 1024];
        let started = std::time::Instant::now();
        tokio::select! {
            _ = async { let _ = decode_record_batches(&mut &raw[..]); } => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding framed batches held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_one_long_batch_does_not_hold_the_caller() {
        let record = [0x0cu8, 0x00, 0x00, 0x00, 0x01, 0x01, 0x00];
        let count = 900_000usize;
        let records_len = count.saturating_mul(record.len());
        let overhead = RecordBatch::RECORD_BATCH_OVERHEAD as usize;
        let prefix = Records::LOG_OVERHEAD as usize;
        let length_at = Records::SIZE_OFFSET as usize;
        let magic_at = Records::MAGIC_OFFSET as usize;
        let count_at = RecordBatch::RECORDS_COUNT_OFFSET as usize;
        let crc_at = RecordBatch::CRC_OFFSET as usize;
        let attributes_at = RecordBatch::ATTRIBUTES_OFFSET as usize;
        let mut frame = Vec::with_capacity(overhead.saturating_add(records_len));
        frame.resize(overhead, 0);
        let batch_len = i32::try_from((overhead - prefix).saturating_add(records_len)).unwrap();
        frame[length_at..prefix].copy_from_slice(&batch_len.to_be_bytes());
        frame[magic_at] = u8::try_from(RecordBatch::MAGIC_VALUE_V2).unwrap();
        frame[count_at..overhead].copy_from_slice(&i32::try_from(count).unwrap().to_be_bytes());
        for _ in 0..count {
            frame.extend_from_slice(&record);
        }
        let crc = crc32c::crc32c(&frame[attributes_at..]);
        frame[crc_at..attributes_at].copy_from_slice(&crc.to_be_bytes());
        let batch = EncodedBatch {
            base_offset: 0,
            attributes: 0,
            body: Bytes::copy_from_slice(&frame[prefix..]),
        };
        let started = std::time::Instant::now();
        tokio::select! {
            _ = batch.try_visit_short_keys_cooperative(|_| {}) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "visiting one batch held the caller for {elapsed:?}"
        );
        let mut cursor: &[u8] = &frame;
        let started = std::time::Instant::now();
        tokio::select! {
            _ = decode_record_batch_reusing_cooperative(&mut cursor, usize::MAX, Vec::new()) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding one batch held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn counting_framed_batches_does_not_hold_the_caller() {
        let raw = vec![0u8; 48 * 1024 * 1024];
        let started = std::time::Instant::now();
        tokio::select! {
            _ = count_framed_batches_cooperative(&raw) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "counting framed batches held the caller for {elapsed:?}"
        );
    }

    fn gzip_batch(count: u32) -> RecordBatch {
        let records = (0..count)
            .map(|index| Record {
                offset: i64::from(index),
                timestamp: 1,
                key: None,
                value: Some(Bytes::from_static(b"x")),
                headers: Vec::new(),
            })
            .collect();
        RecordBatch {
            base_offset: 0,
            partition_leader_epoch: RecordBatch::NO_PARTITION_LEADER_EPOCH,
            attributes: Compression::Gzip as i16,
            base_timestamp: 1,
            max_timestamp: 1,
            producer_id: RecordBatch::NO_PRODUCER_ID,
            producer_epoch: RecordBatch::NO_PRODUCER_EPOCH,
            base_sequence: RecordBatch::NO_SEQUENCE,
            records,
        }
    }

    async fn decode_holds_for(buf: &[u8]) -> std::time::Duration {
        let started = std::time::Instant::now();
        tokio::select! {
            _ = async {
                let mut cursor = buf;
                let _decoded = decode_record_batch_reusing_cooperative(
                    &mut cursor,
                    usize::MAX,
                    Vec::new(),
                )
                .await;
            } => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        started.elapsed()
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decompressing_a_long_batch_does_not_hold_the_caller() {
        // 1_200_000 records: gzip expand held the caller 122ms, LZ4 130ms,
        // and snappy 110ms, all before the record loop could yield.
        let mut batch = gzip_batch(1_200_000);
        let mut gz = BytesMut::new();
        encode_record_batch(&mut gz, &batch).unwrap();
        batch.attributes = Compression::Lz4 as i16;
        let mut lz = BytesMut::new();
        encode_record_batch(&mut lz, &batch).unwrap();
        batch.attributes = Compression::Snappy as i16;
        let mut sn = BytesMut::new();
        encode_record_batch(&mut sn, &batch).unwrap();
        let gz_elapsed = decode_holds_for(&gz).await;
        let lz_elapsed = decode_holds_for(&lz).await;
        let sn_elapsed = decode_holds_for(&sn).await;
        assert!(
            gz_elapsed < std::time::Duration::from_millis(80),
            "gzip decode held the caller for {gz_elapsed:?}"
        );
        assert!(
            lz_elapsed < std::time::Duration::from_millis(80),
            "lz4 decode held the caller for {lz_elapsed:?}"
        );
        assert!(
            sn_elapsed < std::time::Duration::from_millis(80),
            "snappy decode held the caller for {sn_elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn cooperative_compressed_decode_matches_one_shot() {
        for compression in [Compression::Gzip, Compression::Lz4, Compression::Snappy] {
            let mut batch = gzip_batch(30_000);
            batch.attributes = compression as i16;
            let mut buf = BytesMut::new();
            encode_record_batch(&mut buf, &batch).unwrap();
            let one = decode_record_batch(&mut &buf[..]).unwrap();
            let mut cursor: &[u8] = &buf;
            let two = decode_record_batch_reusing_cooperative(&mut cursor, usize::MAX, Vec::new())
                .await
                .unwrap();
            assert_eq!(one.records.len(), two.records.len());
            assert_eq!(
                one.records.first().map(|rec| rec.value.clone()),
                two.records.first().map(|rec| rec.value.clone())
            );
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn offloaded_snappy_decompress_matches_one_shot() {
        let mut state = 0x1234_5678u32;
        let src: Vec<u8> = (0..4_000_000)
            .map(|_| {
                state ^= state << 13;
                state ^= state >> 17;
                state ^= state << 5;
                state as u8
            })
            .collect();
        let mut framed = Vec::new();
        snappy_compress_into(&src, &mut framed).unwrap();
        assert!(framed.len() > SNAPPY_DECOMPRESS_INLINE);
        let one = snappy_decompress(&framed, usize::MAX).unwrap();
        let two = snappy_decompress_cooperative(Bytes::from(framed), usize::MAX)
            .await
            .unwrap();
        assert_eq!(one, two);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn encoding_a_long_gzip_batch_does_not_hold_the_caller() {
        // 200_000 records: writing the section held the caller 107ms before
        // the 1.9 MiB gzip, which itself held the caller 271ms.
        let batch = gzip_batch(200_000);
        let mut buf = BytesMut::new();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = encode_record_batch_cooperative(&mut buf, &batch) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "encoding a gzip batch held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn compressing_a_long_gzip_section_does_not_hold_the_caller() {
        let batch = gzip_batch(200_000);
        let header = batch_header_from(&batch).unwrap();
        let mut scratch = CompressScratch::new();
        begin_packed_section(&mut scratch);
        for (index, rec) in batch.records.iter().enumerate() {
            let enc = EncodeRecord::from_record(rec);
            append_packed_record(&mut scratch, &header, index, &enc, Compression::Gzip).unwrap();
        }
        let started = std::time::Instant::now();
        tokio::select! {
            _ = gzip_compress_into_cooperative(&scratch.section, &mut scratch.packed) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "gzip of a record section held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn compressing_a_long_snappy_section_does_not_hold_the_caller() {
        // 1_000_000 records: one snappy of the 9.5 MiB section held the caller 110ms.
        let batch = gzip_batch(1_000_000);
        let header = batch_header_from(&batch).unwrap();
        let mut scratch = CompressScratch::new();
        begin_packed_section(&mut scratch);
        for (index, rec) in batch.records.iter().enumerate() {
            let enc = EncodeRecord::from_record(rec);
            append_packed_record(&mut scratch, &header, index, &enc, Compression::Snappy).unwrap();
        }
        let started = std::time::Instant::now();
        tokio::select! {
            _ = snappy_compress_section(&mut scratch.section, &mut scratch.packed) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "snappy of a record section held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn offloaded_snappy_matches_one_shot() {
        let src = vec![b'x'; SNAPPY_INLINE_LIMIT.saturating_add(1)];
        let mut one = Vec::new();
        snappy_compress_into(&src, &mut one).unwrap();
        let mut section = BytesMut::from(src.as_slice());
        let mut two = Vec::new();
        snappy_compress_section(&mut section, &mut two)
            .await
            .unwrap();
        assert_eq!(one, two);
        assert_eq!(section, src.as_slice());
    }

    #[tokio::test(flavor = "current_thread")]
    async fn cooperative_snappy_batch_matches_one_shot() {
        let mut batch = gzip_batch(8_000);
        batch.attributes = Compression::Snappy as i16;
        let mut one = BytesMut::new();
        encode_record_batch(&mut one, &batch).unwrap();
        let mut two = BytesMut::new();
        encode_record_batch_cooperative(&mut two, &batch)
            .await
            .unwrap();
        assert_eq!(one, two);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn compressing_a_long_lz4_section_does_not_hold_the_caller() {
        // 400_000 records: one LZ4 of the 3.8 MiB section held the caller 103ms.
        let batch = gzip_batch(400_000);
        let header = batch_header_from(&batch).unwrap();
        let mut scratch = CompressScratch::new();
        begin_packed_section(&mut scratch);
        for (index, rec) in batch.records.iter().enumerate() {
            let enc = EncodeRecord::from_record(rec);
            append_packed_record(&mut scratch, &header, index, &enc, Compression::Lz4).unwrap();
        }
        let started = std::time::Instant::now();
        tokio::select! {
            _ = lz4_compress_into_cooperative(&scratch.section, &mut scratch.packed) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "lz4 of a record section held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn cooperative_lz4_batch_matches_one_shot() {
        let mut batch = gzip_batch(10_000);
        batch.attributes = Compression::Lz4 as i16;
        let mut one = BytesMut::new();
        encode_record_batch(&mut one, &batch).unwrap();
        let mut two = BytesMut::new();
        encode_record_batch_cooperative(&mut two, &batch)
            .await
            .unwrap();
        assert_eq!(one, two);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn cooperative_gzip_batch_matches_one_shot() {
        let batch = gzip_batch(4_000);
        let mut one = BytesMut::new();
        encode_record_batch(&mut one, &batch).unwrap();
        let mut two = BytesMut::new();
        encode_record_batch_cooperative(&mut two, &batch)
            .await
            .unwrap();
        assert_eq!(one, two);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn encoding_a_long_batch_does_not_hold_the_caller() {
        let records: Vec<Record> = (0..400_000)
            .map(|index| Record {
                offset: i64::from(index),
                timestamp: 1,
                key: None,
                value: Some(Bytes::from_static(b"x")),
                headers: Vec::new(),
            })
            .collect();
        let batch = RecordBatch {
            base_offset: 0,
            partition_leader_epoch: RecordBatch::NO_PARTITION_LEADER_EPOCH,
            attributes: 0,
            base_timestamp: 1,
            max_timestamp: 1,
            producer_id: RecordBatch::NO_PRODUCER_ID,
            producer_epoch: RecordBatch::NO_PRODUCER_EPOCH,
            base_sequence: RecordBatch::NO_SEQUENCE,
            records,
        };
        let mut buf = BytesMut::new();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = encode_record_batch_cooperative(&mut buf, &batch) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "encoding a record batch held the caller for {elapsed:?}"
        );
    }

    #[test]
    fn header_getters_match_java() {
        let h = Header::new("k", Bytes::from_static(b"v"));
        assert_eq!(h.key(), "k");
        assert_eq!(h.value(), Some(&b"v"[..]));
        let n = Header::null("n");
        assert_eq!(n.key(), "n");
        assert!(n.value().is_none());
        assert_eq!(h.to_string(), "RecordHeader(key = k, value = [118])");
        assert_eq!(n.to_string(), "RecordHeader(key = n, value = null)");
        let signed = Header::new("s", Bytes::from_static(&[0xff]));
        assert_eq!(signed.to_string(), "RecordHeader(key = s, value = [-1])");
        let many = [
            Header::new("k", Bytes::from_static(b"1")),
            Header::new("k", Bytes::from_static(b"2")),
            Header::null("empty"),
        ];
        assert_eq!(
            Header::last_in(&many, "k").and_then(Header::value),
            Some(&b"2"[..])
        );
        assert!(Header::last_in(&many, "missing").is_none());
        let keyed: Vec<_> = Header::for_key(&many, "k").map(Header::key).collect();
        assert_eq!(keyed, vec!["k", "k"]);
    }

    #[test]
    fn record_and_batch_getters_match_java() {
        let rec = Record {
            offset: 7,
            timestamp: 9,
            key: Some(Bytes::from_static(b"k")),
            value: Some(Bytes::from_static(b"val")),
            headers: vec![Header::new("h", Bytes::from_static(b"v"))],
        };
        assert_eq!(rec.offset(), 7);
        assert_eq!(rec.timestamp(), 9);
        assert_eq!(rec.key(), Some(&b"k"[..]));
        assert!(rec.has_key());
        assert_eq!(rec.key_size(), 1);
        assert_eq!(rec.value(), Some(&b"val"[..]));
        assert!(rec.has_value());
        assert_eq!(rec.value_size(), 3);
        assert_eq!(rec.headers().len(), 1);
        assert_eq!(rec.last_header("h").map(Header::key), Some("h"));
        assert_eq!(rec.headers_for_key("h").count(), 1);
        assert!(rec.has_magic(MAGIC_V2));
        assert!(rec.has_magic(3));
        assert!(!rec.has_magic(1));
        assert!(!rec.is_compressed());
        assert!(!rec.has_timestamp_type(TimestampType::CreateTime));
        assert!(!rec.has_timestamp_type(TimestampType::LogAppendTime));
        assert_eq!(
            rec.to_string(),
            "DefaultRecord(offset=7, timestamp=9, key=1 bytes, value=3 bytes)"
        );
        let empty = Record {
            offset: 0,
            timestamp: 0,
            key: None,
            value: None,
            headers: vec![],
        };
        assert!(!empty.has_key());
        assert!(!empty.has_value());
        assert_eq!(empty.key_size(), -1);
        assert_eq!(empty.value_size(), -1);
        assert_eq!(empty.headers(), Record::EMPTY_HEADERS);
        assert_eq!(Record::MAX_RECORD_OVERHEAD, 21);
        assert_eq!(
            empty.to_string(),
            "DefaultRecord(offset=0, timestamp=0, key=0 bytes, value=0 bytes)"
        );
        let batch = RecordBatch::from_records(vec![rec])
            .with_transactional(true)
            .with_control_batch(true);
        assert!(batch.is_transactional());
        assert!(batch.is_control_batch());
        assert_eq!(batch.magic(), MAGIC_V2);
        assert_eq!(batch.magic(), RecordBatch::MAGIC_VALUE_V2);
        assert_eq!(batch.magic(), RecordBatch::CURRENT_MAGIC_VALUE);
        assert_eq!(RecordBatch::MAGIC_VALUE_V0, 0);
        assert_eq!(RecordBatch::MAGIC_VALUE_V1, 1);
        assert_eq!(RecordBatch::MAGIC_VALUE_V2, 2);
        assert_eq!(RecordBatch::CURRENT_MAGIC_VALUE, 2);
        assert_eq!(RecordBatch::RECORD_BATCH_OVERHEAD, 61);
        assert_eq!(RecordBatch::CRC_OFFSET, 17);
        assert_eq!(RecordBatch::ATTRIBUTES_OFFSET, 21);
        assert_eq!(RecordBatch::LAST_OFFSET_DELTA_OFFSET, 23);
        assert_eq!(RecordBatch::BASE_TIMESTAMP_OFFSET, 27);
        assert_eq!(RecordBatch::PRODUCER_ID_OFFSET, 43);
        assert_eq!(RecordBatch::BASE_SEQUENCE_OFFSET, 53);
        assert_eq!(RecordBatch::RECORDS_COUNT_OFFSET, 57);
        assert_eq!(batch.base_offset(), 0);
        assert_eq!(batch.last_offset(), 0);
        assert_eq!(batch.next_offset(), 1);
        assert_eq!(batch.last_sequence(), RecordBatch::NO_SEQUENCE);
        assert!(!batch.is_compressed());
        assert_eq!(batch.count(), 1);
        assert_eq!(batch.count_or_null(), Some(1));
        assert_eq!(batch.records().len(), 1);
        assert_eq!(
            batch.partition_leader_epoch(),
            RecordBatch::NO_PARTITION_LEADER_EPOCH
        );
        assert_eq!(batch.base_timestamp(), 9);
        assert_eq!(batch.max_timestamp(), 9);
        assert_eq!(batch.offset_of_max_timestamp(), Some(0));
        assert!(batch.delete_horizon_ms().is_none());
        let horizon = batch.clone().with_delete_horizon(true);
        assert_eq!(horizon.delete_horizon_ms(), Some(9));
        assert!(horizon
            .with_delete_horizon(false)
            .delete_horizon_ms()
            .is_none());
        assert_eq!(batch.producer_id(), RecordBatch::NO_PRODUCER_ID);
        assert!(!batch.has_producer_id());
        assert_eq!(batch.producer_epoch(), RecordBatch::NO_PRODUCER_EPOCH);
        assert_eq!(batch.base_sequence(), RecordBatch::NO_SEQUENCE);
        assert_eq!(batch.compression_type().unwrap(), Compression::None);
        let empty_batch = RecordBatch::from_records(vec![]);
        assert_eq!(empty_batch.count(), 0);
        assert_eq!(empty_batch.count_or_null(), Some(0));
        assert_eq!(empty_batch.last_offset(), -1);
        assert_eq!(empty_batch.next_offset(), 0);
        assert_eq!(empty_batch.last_sequence(), RecordBatch::NO_SEQUENCE);
        assert!(empty_batch.offset_of_max_timestamp().is_none());
        let mut early = empty.clone();
        early.timestamp = 5;
        let mut late = empty.clone();
        late.timestamp = 9;
        let mixed = RecordBatch::from_records(vec![early, late]);
        assert_eq!(mixed.max_timestamp(), 9);
        assert_eq!(mixed.offset_of_max_timestamp(), Some(1));
        let mut first = empty.clone();
        first.timestamp = 9;
        let mut second = empty.clone();
        second.timestamp = 9;
        let tie = RecordBatch::from_records(vec![first, second]);
        assert_eq!(tie.offset_of_max_timestamp(), Some(0));
        assert_eq!(RecordBatch::NO_TIMESTAMP, -1);
        assert_eq!(RecordBatch::NO_PRODUCER_ID, -1);
        assert_eq!(RecordBatch::NO_PRODUCER_EPOCH, -1);
        assert_eq!(RecordBatch::NO_SEQUENCE, -1);
        assert_eq!(RecordBatch::NO_PARTITION_LEADER_EPOCH, -1);
        let header = BatchHeader::default();
        assert_eq!(
            header.partition_leader_epoch,
            RecordBatch::NO_PARTITION_LEADER_EPOCH
        );
        assert_eq!(header.producer_id, RecordBatch::NO_PRODUCER_ID);
        assert_eq!(header.producer_epoch, RecordBatch::NO_PRODUCER_EPOCH);
        assert_eq!(header.base_sequence, RecordBatch::NO_SEQUENCE);
        let mut zero_pid = RecordBatch::from_records(vec![empty.clone()]);
        zero_pid.producer_id = 0;
        assert!(
            RecordBatch::NO_PRODUCER_ID < zero_pid.producer_id,
            "Java AbstractRecordBatch.hasProducerId is NO_PRODUCER_ID < producerId"
        );
        assert!(zero_pid.has_producer_id());
        let mut with_pid = RecordBatch::from_records(vec![empty.clone()]);
        with_pid.producer_id = 5;
        with_pid.producer_epoch = 1;
        with_pid.base_sequence = 0;
        with_pid.partition_leader_epoch = 3;
        assert!(with_pid.has_producer_id());
        assert_eq!(with_pid.producer_id(), 5);
        assert_eq!(with_pid.producer_epoch(), 1);
        assert_eq!(with_pid.base_sequence(), 0);
        assert_eq!(with_pid.last_sequence(), 0);
        assert_eq!(with_pid.partition_leader_epoch(), 3);
        let mut three =
            RecordBatch::from_records(vec![empty.clone(), empty.clone(), empty.clone()]);
        three.base_sequence = 10;
        assert_eq!(three.last_sequence(), 12);
        let mut wrap = RecordBatch::from_records(vec![empty.clone(), empty]);
        wrap.base_sequence = i32::MAX;
        assert_eq!(wrap.last_sequence(), 0);
        assert_eq!(RecordBatch::increment_sequence(i32::MAX, 1), 0);
        assert_eq!(RecordBatch::decrement_sequence(0, 1), i32::MAX);
        let mut buf = BytesMut::new();
        encode_record_batch(&mut buf, &batch).unwrap();
        let decoded = decode_record_batch(&mut &buf[..]).unwrap();
        assert!(decoded.is_transactional());
        assert!(decoded.is_control_batch());
        assert_eq!(decoded.records[0].offset(), 0);
        assert_eq!(decoded.records[0].value(), Some(&b"val"[..]));
        let cleared = decoded.with_transactional(false).with_control_batch(false);
        assert!(!cleared.is_transactional());
        assert!(!cleared.is_control_batch());
    }

    #[test]
    fn control_record_type_and_end_txn_marker_match_java() {
        assert_eq!(ControlRecordType::Abort.type_id(), 0);
        assert_eq!(ControlRecordType::Commit.type_id(), 1);
        assert_eq!(ControlRecordType::LeaderChange.type_id(), 2);
        assert_eq!(ControlRecordType::SnapshotHeader.type_id(), 3);
        assert_eq!(ControlRecordType::SnapshotFooter.type_id(), 4);
        assert_eq!(ControlRecordType::KraftVersion.type_id(), 5);
        assert_eq!(ControlRecordType::KraftVoters.type_id(), 6);
        assert_eq!(ControlRecordType::Unknown.type_id(), -1);
        assert_eq!(ControlRecordType::from_type_id(0), ControlRecordType::Abort);
        assert_eq!(
            ControlRecordType::from_type_id(1),
            ControlRecordType::Commit
        );
        assert_eq!(
            ControlRecordType::from_type_id(99),
            ControlRecordType::Unknown
        );
        assert_eq!(ControlRecordType::Abort.to_string(), "ABORT");
        assert_eq!(ControlRecordType::Commit.to_string(), "COMMIT");
        assert_eq!(ControlRecordType::LeaderChange.to_string(), "LEADER_CHANGE");
        assert_eq!(ControlRecordType::Unknown.to_string(), "UNKNOWN");
        let commit_key = ControlRecordType::Commit.record_key().unwrap();
        assert_eq!(commit_key, [0, 0, 0, 1]);
        assert_eq!(
            ControlRecordType::parse(&commit_key).unwrap(),
            ControlRecordType::Commit
        );
        assert_eq!(
            ControlRecordType::parse_type_id(&[0, 1, 0, 0]).unwrap(),
            0,
            "newer key version still reads type at offset 2"
        );
        assert!(ControlRecordType::parse_type_id(&[0, 0, 0]).is_err());
        assert!(ControlRecordType::parse_type_id(&[0xff, 0xff, 0, 1]).is_err());
        assert!(ControlRecordType::Unknown.record_key().is_err());
        assert!(EndTransactionMarker::new(ControlRecordType::LeaderChange, 1).is_err());
        let marker = EndTransactionMarker::new(ControlRecordType::Abort, 7).unwrap();
        assert_eq!(marker.control_type(), ControlRecordType::Abort);
        assert_eq!(marker.coordinator_epoch(), 7);
        assert_eq!(marker.serialize_value(), [0, 0, 0, 0, 0, 7]);
        let batch = RecordBatch::with_end_transaction_marker(10, 99, 3, 42, 1, &marker).unwrap();
        assert!(batch.is_transactional());
        assert!(batch.is_control_batch());
        assert_eq!(batch.base_offset(), 10);
        assert_eq!(batch.partition_leader_epoch(), 3);
        assert_eq!(batch.producer_id(), 42);
        assert_eq!(batch.producer_epoch(), 1);
        assert_eq!(batch.base_sequence(), RecordBatch::NO_SEQUENCE);
        assert_eq!(batch.count(), 1);
        let decoded_marker =
            EndTransactionMarker::deserialize(batch.records().first().expect("marker record"))
                .unwrap();
        assert_eq!(decoded_marker, marker);
        let mut buf = BytesMut::new();
        encode_record_batch(&mut buf, &batch).unwrap();
        let decoded = decode_record_batch(&mut &buf[..]).unwrap();
        assert!(decoded.is_control_batch());
        assert!(decoded.is_transactional());
        assert_eq!(decoded.base_offset(), 10);
        assert_eq!(
            EndTransactionMarker::deserialize(decoded.records().first().expect("marker record"))
                .unwrap(),
            marker
        );
        let commit = EndTransactionMarker::new(ControlRecordType::Commit, 0).unwrap();
        assert_eq!(
            EndTransactionMarker::deserialize(
                &Record::from_end_transaction_marker(0, &commit).unwrap()
            )
            .unwrap(),
            commit
        );
        assert!(EndTransactionMarker::deserialize(&Record {
            offset: 0,
            timestamp: 0,
            key: Some(Bytes::copy_from_slice(
                &ControlRecordType::LeaderChange.record_key().unwrap()
            )),
            value: Some(Bytes::from_static(&[0, 0, 0, 0, 0, 0])),
            headers: vec![],
        })
        .is_err());
        assert!(EndTransactionMarker::deserialize(&Record {
            offset: 0,
            timestamp: 0,
            key: Some(Bytes::copy_from_slice(
                &ControlRecordType::Abort.record_key().unwrap()
            )),
            value: Some(Bytes::from_static(&[0, 0, 0])),
            headers: vec![],
        })
        .is_err());
        assert_eq!(Records::OFFSET_OFFSET, 0);
        assert_eq!(Records::OFFSET_LENGTH, 8);
        assert_eq!(Records::SIZE_OFFSET, 8);
        assert_eq!(Records::SIZE_LENGTH, 4);
        assert_eq!(Records::LOG_OVERHEAD, 12);
        assert_eq!(Records::MAGIC_OFFSET, 16);
        assert_eq!(Records::MAGIC_LENGTH, 1);
        assert_eq!(Records::HEADER_SIZE_UP_TO_MAGIC, 17);
        assert_eq!(RecordBatch::CRC_OFFSET, Records::HEADER_SIZE_UP_TO_MAGIC);
        assert_eq!(
            RecordBatch::RECORD_BATCH_OVERHEAD - Records::LOG_OVERHEAD,
            49
        );
    }

    #[test]
    fn timestamp_type_matches_java() {
        assert_eq!(TimestampType::NoTimestampType.id(), -1);
        assert_eq!(TimestampType::CreateTime.id(), 0);
        assert_eq!(TimestampType::LogAppendTime.id(), 1);
        assert_eq!(TimestampType::CreateTime.as_str(), "CreateTime");
        assert_eq!(TimestampType::LogAppendTime.as_str(), "LogAppendTime");
        assert_eq!(TimestampType::NoTimestampType.as_str(), "NoTimestampType");
        assert_eq!(TimestampType::CreateTime.to_string(), "CreateTime");
        assert_eq!(Compression::None.to_string(), "none");
        assert_eq!(Compression::Gzip.to_string(), "gzip");
        assert_eq!(Compression::Snappy.to_string(), "snappy");
        assert_eq!(Compression::Lz4.to_string(), "lz4");
        assert_eq!(Compression::None.id(), 0);
        assert_eq!(Compression::Gzip.id(), 1);
        assert_eq!(Compression::Snappy.id(), 2);
        assert_eq!(Compression::Lz4.id(), 3);
        assert_eq!(Compression::from_id(0), Some(Compression::None));
        assert_eq!(Compression::from_id(1), Some(Compression::Gzip));
        assert_eq!(Compression::from_id(2), Some(Compression::Snappy));
        assert_eq!(Compression::from_id(3), Some(Compression::Lz4));
        #[cfg(not(feature = "zstd"))]
        assert!(Compression::from_id(4).is_none());
        #[cfg(feature = "zstd")]
        assert_eq!(Compression::from_id(4), Some(Compression::Zstd));
        assert!(Compression::from_id(-1).is_none());
        assert_eq!(TimestampType::from_id(0), Some(TimestampType::CreateTime));
        assert_eq!(
            TimestampType::from_id(1),
            Some(TimestampType::LogAppendTime)
        );
        assert_eq!(
            TimestampType::from_id(-1),
            Some(TimestampType::NoTimestampType)
        );
        assert!(TimestampType::from_id(2).is_none());
        assert_eq!(
            TimestampType::from_name("LogAppendTime").unwrap(),
            TimestampType::LogAppendTime
        );
        let unknown = TimestampType::from_name("bogus").unwrap_err();
        assert!(
            unknown.to_string().contains("Invalid timestamp type bogus"),
            "{unknown}"
        );
        let unknown_codec = Compression::from_name("bogus").unwrap_err();
        assert!(
            unknown_codec
                .to_string()
                .contains("Unknown compression name: bogus"),
            "{unknown_codec}"
        );
        assert_eq!(Compression::from_name("gzip").unwrap(), Compression::Gzip);
        assert_eq!(Compression::from_name("").unwrap(), Compression::None);
        assert_eq!(
            Compression::Gzip.default_level().unwrap(),
            Compression::GZIP_DEFAULT_LEVEL
        );
        assert_eq!(
            Compression::Gzip.min_level().unwrap(),
            Compression::GZIP_MIN_LEVEL
        );
        assert_eq!(
            Compression::Gzip.max_level().unwrap(),
            Compression::GZIP_MAX_LEVEL
        );
        assert_eq!(Compression::GZIP_DEFAULT_LEVEL, -1);
        assert_eq!(Compression::GZIP_MIN_LEVEL, 1);
        assert_eq!(Compression::GZIP_MAX_LEVEL, 9);
        assert_eq!(
            Compression::Lz4.default_level().unwrap(),
            Compression::LZ4_DEFAULT_LEVEL
        );
        assert_eq!(
            Compression::Lz4.min_level().unwrap(),
            Compression::LZ4_MIN_LEVEL
        );
        assert_eq!(
            Compression::Lz4.max_level().unwrap(),
            Compression::LZ4_MAX_LEVEL
        );
        assert_eq!(Compression::LZ4_DEFAULT_LEVEL, 9);
        assert_eq!(Compression::LZ4_MIN_LEVEL, 1);
        assert_eq!(Compression::LZ4_MAX_LEVEL, 17);
        let none_lvl = Compression::None.default_level().unwrap_err();
        assert!(
            matches!(none_lvl, crate::error::Error::Unsupported(_)),
            "{none_lvl}"
        );
        assert!(
            none_lvl
                .to_string()
                .contains("Compression levels are not defined for this compression type: none"),
            "{none_lvl}"
        );
        let snappy_lvl = Compression::Snappy.min_level().unwrap_err();
        assert!(
            snappy_lvl
                .to_string()
                .contains("Compression levels are not defined for this compression type: snappy"),
            "{snappy_lvl}"
        );
        assert_eq!(TimestampType::from_attributes(0), TimestampType::CreateTime);
        assert_eq!(
            TimestampType::from_attributes(ATTR_TIMESTAMP_TYPE),
            TimestampType::LogAppendTime
        );
        assert_eq!(
            TimestampType::from_attributes(ATTR_TIMESTAMP_TYPE | Compression::Gzip as i16),
            TimestampType::LogAppendTime
        );
        let rec = Record {
            offset: 0,
            timestamp: 1,
            key: None,
            value: Some(Bytes::from_static(b"ts")),
            headers: vec![],
        };
        let create = RecordBatch::from_records(vec![rec.clone()]);
        assert_eq!(create.timestamp_type(), TimestampType::CreateTime);
        let append = create
            .clone()
            .with_timestamp_type(TimestampType::LogAppendTime);
        assert_eq!(append.timestamp_type(), TimestampType::LogAppendTime);
        assert_eq!(append.attributes & ATTR_TIMESTAMP_TYPE, ATTR_TIMESTAMP_TYPE);
        let mut buf = BytesMut::new();
        encode_record_batch(&mut buf, &append).unwrap();
        let decoded = decode_record_batch(&mut &buf[..]).unwrap();
        assert_eq!(decoded.timestamp_type(), TimestampType::LogAppendTime);
        let cleared = append.with_timestamp_type(TimestampType::NoTimestampType);
        assert_eq!(cleared.timestamp_type(), TimestampType::CreateTime);
        assert_eq!(TimestampType::LogAppendTime.to_string(), "LogAppendTime");
    }

    #[test]
    fn idempotent_batch_preserves_pid_and_seq() {
        let rec = Record {
            offset: 0,
            timestamp: 1,
            key: None,
            value: Some(Bytes::from_static(b"idem")),
            headers: vec![],
        };
        let mut batch = RecordBatch::from_records(vec![rec]);
        batch.producer_id = 99;
        batch.producer_epoch = 2;
        batch.base_sequence = 17;
        let mut buf = BytesMut::new();
        encode_record_batch(&mut buf, &batch).unwrap();
        let decoded = decode_record_batch(&mut &buf[..]).unwrap();
        assert_eq!(decoded.producer_id, 99);
        assert_eq!(decoded.producer_epoch, 2);
        assert_eq!(decoded.base_sequence, 17);
        assert_eq!(decoded.records[0].value.as_deref(), Some(&b"idem"[..]));
    }

    #[test]
    fn record_batch_roundtrip() {
        let rec = Record {
            offset: 0,
            timestamp: 1_700_000_000_000,
            key: Some(Bytes::from_static(b"k")),
            value: Some(Bytes::from_static(b"hello")),
            headers: vec![
                Header::new("h", Bytes::from_static(b"v")),
                Header::null("empty"),
            ],
        };
        let batch = RecordBatch::from_records(vec![rec]);
        let mut buf = BytesMut::new();
        encode_record_batch(&mut buf, &batch).unwrap();
        let decoded = decode_record_batch(&mut &buf[..]).unwrap();
        assert_eq!(decoded, batch);
    }

    #[test]
    fn null_key_is_not_empty_key() {
        let null_key = Record {
            offset: 0,
            timestamp: 0,
            key: None,
            value: Some(Bytes::from_static(b"v")),
            headers: vec![],
        };
        let empty_key = Record {
            offset: 0,
            timestamp: 0,
            key: Some(Bytes::new()),
            value: Some(Bytes::from_static(b"v")),
            headers: vec![],
        };
        let mut a = BytesMut::new();
        let mut b = BytesMut::new();
        encode_record_batch(&mut a, &RecordBatch::from_records(vec![null_key.clone()])).unwrap();
        encode_record_batch(&mut b, &RecordBatch::from_records(vec![empty_key.clone()])).unwrap();
        assert_ne!(&a[..], &b[..]);
        assert_eq!(
            null_key.to_string(),
            "DefaultRecord(offset=0, timestamp=0, key=0 bytes, value=1 bytes)"
        );
        assert_eq!(
            empty_key.to_string(),
            "DefaultRecord(offset=0, timestamp=0, key=0 bytes, value=1 bytes)"
        );
        assert_eq!(
            decode_record_batch(&mut &a[..]).unwrap().records[0].key,
            None
        );
        assert_eq!(
            decode_record_batch(&mut &b[..]).unwrap().records[0].key,
            Some(Bytes::new())
        );
    }

    #[test]
    fn gzip_record_batch_roundtrip() {
        let rec = Record {
            offset: 0,
            timestamp: 9,
            key: None,
            value: Some(Bytes::from_static(b"gzip-payload")),
            headers: vec![],
        };
        let batch = RecordBatch::from_records(vec![rec]).with_compression(Compression::Gzip);
        assert_eq!(
            batch.attributes & ATTR_COMPRESSION_CODEC,
            Compression::Gzip as i16
        );
        assert!(batch.is_compressed());
        let mut buf = BytesMut::new();
        encode_record_batch(&mut buf, &batch).unwrap();
        let decoded = decode_record_batch(&mut &buf[..]).unwrap();
        assert_eq!(
            decoded.records[0].value.as_deref(),
            Some(&b"gzip-payload"[..])
        );
        assert_eq!(
            decoded.attributes & ATTR_COMPRESSION_CODEC,
            Compression::Gzip as i16
        );
    }

    #[test]
    fn snappy_record_batch_roundtrip() {
        let rec = Record {
            offset: 0,
            timestamp: 11,
            key: None,
            value: Some(Bytes::from_static(b"snappy-payload")),
            headers: vec![],
        };
        let batch = RecordBatch::from_records(vec![rec]).with_compression(Compression::Snappy);
        assert_eq!(
            batch.attributes & ATTR_COMPRESSION_CODEC,
            Compression::Snappy as i16
        );
        let mut buf = BytesMut::new();
        encode_record_batch(&mut buf, &batch).unwrap();
        assert!(
            buf.windows(SNAPPY_JAVA_MAGIC.len())
                .any(|w| w == SNAPPY_JAVA_MAGIC),
            "produce path must emit snappy-java framing"
        );
        let decoded = decode_record_batch(&mut &buf[..]).unwrap();
        assert_eq!(
            decoded.records[0].value.as_deref(),
            Some(&b"snappy-payload"[..])
        );
        assert_eq!(
            decoded.attributes & ATTR_COMPRESSION_CODEC,
            Compression::Snappy as i16
        );
    }

    #[test]
    fn snappy_decompress_raw_block_from_librdkafka() {
        let payload = b"raw-snappy-from-c-client";
        let raw = snap::raw::Encoder::new().compress_vec(payload).unwrap();
        assert_eq!(
            snappy_decompress(&raw, DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES).unwrap(),
            payload
        );
        let framed = Compression::Snappy.codec_compress(payload).unwrap();
        assert!(framed.starts_with(SNAPPY_JAVA_MAGIC));
        assert_eq!(
            snappy_decompress(&framed, DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES).unwrap(),
            payload
        );
    }

    #[test]
    fn lz4_record_batch_roundtrip() {
        let rec = Record {
            offset: 0,
            timestamp: 13,
            key: None,
            value: Some(Bytes::from_static(b"lz4-payload")),
            headers: vec![],
        };
        let batch = RecordBatch::from_records(vec![rec]).with_compression(Compression::Lz4);
        assert_eq!(
            batch.attributes & ATTR_COMPRESSION_CODEC,
            Compression::Lz4 as i16
        );
        let mut buf = BytesMut::new();
        encode_record_batch(&mut buf, &batch).unwrap();
        assert!(
            buf.windows(4).any(|w| w == [0x04, 0x22, 0x4d, 0x18]),
            "produce path must emit LZ4 frame magic"
        );
        let decoded = decode_record_batch(&mut &buf[..]).unwrap();
        assert_eq!(
            decoded.records[0].value.as_deref(),
            Some(&b"lz4-payload"[..])
        );
        assert_eq!(
            decoded.attributes & ATTR_COMPRESSION_CODEC,
            Compression::Lz4 as i16
        );
    }

    #[test]
    fn lz4_frame_roundtrip_shipped_codec() {
        let payload = vec![b'x'; 4096];
        let framed = Compression::Lz4.codec_compress(&payload).unwrap();
        assert_eq!(&framed[..4], &[0x04, 0x22, 0x4d, 0x18]);
        let decoded = lz4_decompress(&framed, DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES).unwrap();
        assert_eq!(decoded, payload);
        assert!(decoded.capacity() >= payload.len());
    }

    fn one_batch(value: &'static [u8]) -> BytesMut {
        let rec = Record {
            offset: 0,
            timestamp: 1,
            key: None,
            value: Some(Bytes::from_static(value)),
            headers: vec![],
        };
        let mut buf = BytesMut::new();
        encode_record_batch(&mut buf, &RecordBatch::from_records(vec![rec])).unwrap();
        buf
    }

    #[test]
    fn decode_record_batches_stops_at_truncated_tail() {
        let mut raw = one_batch(b"one");
        raw.extend_from_slice(&one_batch(b"two"));
        raw.extend_from_slice(&[0u8; 8]);
        let batches = decode_record_batches(&mut &raw[..]).unwrap();
        assert_eq!(batches.len(), 2);
        assert_eq!(
            batches.capacity(),
            Vec::<RecordBatch>::with_capacity(2).capacity()
        );
        let mut five = one_batch(b"one");
        for _ in 0..4 {
            five.extend_from_slice(&one_batch(b"two"));
        }
        let batches = decode_record_batches(&mut &five[..]).unwrap();
        assert_eq!(batches.len(), 5);
        assert_eq!(
            batches.capacity(),
            Vec::<RecordBatch>::with_capacity(5).capacity()
        );
        assert_eq!(batches[0].records[0].value.as_deref(), Some(&b"one"[..]));
        assert_eq!(batches[1].records[0].value.as_deref(), Some(&b"two"[..]));
    }

    fn ptr_in_bytes(ptr: *const u8, buf: &Bytes) -> bool {
        let start = buf.as_ptr();
        let end = start.wrapping_add(buf.len());
        ptr >= start && ptr < end
    }

    #[test]
    fn decode_record_batch_from_bytes_shares_value() {
        let rec = Record {
            offset: 0,
            timestamp: 1,
            key: Some(Bytes::from_static(b"k")),
            value: Some(Bytes::from_static(b"zero-copy-value")),
            headers: vec![],
        };
        let mut buf = BytesMut::new();
        encode_record_batch(&mut buf, &RecordBatch::from_records(vec![rec])).unwrap();
        let frozen = buf.freeze();
        let decoded = decode_record_batch(&mut frozen.clone()).unwrap();
        let key = decoded.records[0].key.as_ref().unwrap();
        let value = decoded.records[0].value.as_ref().unwrap();
        assert!(
            ptr_in_bytes(key.as_ptr(), &frozen),
            "key must be a view into the fetch frame"
        );
        assert!(
            ptr_in_bytes(value.as_ptr(), &frozen),
            "value must be a view into the fetch frame"
        );
    }

    #[test]
    fn encoded_batch_declared_count_matches_header() {
        let rec = Record {
            offset: 0,
            timestamp: 1,
            key: None,
            value: Some(Bytes::from_static(b"n")),
            headers: vec![],
        };
        let mut buf = BytesMut::new();
        encode_record_batch(
            &mut buf,
            &RecordBatch::from_records(vec![rec.clone(), rec.clone()]),
        )
        .unwrap();
        let batches = split_record_batches(buf.freeze()).unwrap();
        assert!(matches!(batches, BatchList::One(_)));
        assert_eq!(batches.len(), 1);
        assert_eq!(batches.first().map(EncodedBatch::declared_count), Some(2));
        assert_eq!(batches.first().map(EncodedBatch::reserve_hint), Some(2));
        assert!(matches!(
            split_record_batches(Bytes::new()).unwrap(),
            BatchList::Empty
        ));
        let mut two = BytesMut::new();
        encode_record_batch(&mut two, &RecordBatch::from_records(vec![rec.clone()])).unwrap();
        encode_record_batch(&mut two, &RecordBatch::from_records(vec![rec.clone()])).unwrap();
        let split = split_record_batches(two.freeze()).unwrap();
        assert!(matches!(split, BatchList::Many(_)));
        assert_eq!(split.len(), 2);
        let BatchList::Many(many) = split else {
            panic!("two batches");
        };
        assert_eq!(
            many.capacity(),
            Vec::<EncodedBatch>::with_capacity(2).capacity()
        );
        let mut five = BytesMut::new();
        for _ in 0..5 {
            encode_record_batch(&mut five, &RecordBatch::from_records(vec![rec.clone()])).unwrap();
        }
        let split = split_record_batches(five.freeze()).unwrap();
        let BatchList::Many(many) = split else {
            panic!("five batches");
        };
        assert_eq!(many.len(), 5);
        assert_eq!(
            many.capacity(),
            Vec::<EncodedBatch>::with_capacity(5).capacity()
        );
        let mut sized = SlotList::with_capacity(5);
        for value in 0..5 {
            sized.push(value);
        }
        let SlotList::Many(values) = sized else {
            panic!("five slots");
        };
        assert_eq!(values.len(), 5);
        assert_eq!(values.capacity(), Vec::<i32>::with_capacity(5).capacity());
        let mut slots = SlotList::with_capacity(1);
        assert!(slots.is_empty());
        slots.push(1);
        assert!(matches!(slots, SlotList::One(1)));
        slots.push(2);
        assert!(matches!(slots, SlotList::Many(_)));
        assert_eq!(&*slots, &[1, 2]);
    }

    #[test]
    fn reserve_hint_ignores_a_count_larger_than_the_section() {
        let mut body = vec![0u8; 45];
        body.extend_from_slice(&i32::MAX.to_be_bytes());
        let batch = EncodedBatch {
            base_offset: 0,
            attributes: 0,
            body: Bytes::from(body),
        };
        assert_eq!(batch.declared_count(), usize::try_from(i32::MAX).unwrap());
        assert_eq!(batch.reserve_hint(), 0);
    }

    #[test]
    fn slot_list_hints_and_growth_obey_the_shared_budget() {
        let hinted = SlotList::<u8>::with_capacity(usize::MAX);
        let SlotList::Many(hinted) = hinted else {
            panic!("many slots")
        };
        assert!(hinted.capacity() <= 256);

        let mut budget = DecodeMetadataBudget::for_wire_limit(1);
        let mut slots = SlotList::<[u8; 512]>::try_with_budget(usize::MAX, &mut budget).unwrap();
        let initial = match &slots {
            SlotList::Many(items) => items.capacity(),
            _ => panic!("budget permits a bounded initial allocation"),
        };
        assert!(initial.saturating_mul(512) <= MIN_DECODE_METADATA_BYTES);
        for index in 0..initial {
            slots
                .try_push_with_budget([u8::try_from(index % 256).unwrap(); 512], &mut budget)
                .unwrap();
        }
        assert!(slots.try_push_with_budget([0; 512], &mut budget).is_err());
        assert_eq!(slots.len(), initial);
        assert_eq!(slots.first().unwrap().first(), Some(&0));
    }

    #[test]
    fn excess_allocator_capacity_preserves_vector_and_budget() {
        let mut values = Vec::with_capacity(2);
        values.extend([11_u32, 22]);
        let original_capacity = values.capacity();
        let target = original_capacity + 2;
        let limit = original_capacity + target;
        let mut budget = DecodeMetadataBudget::with_limit(limit * std::mem::size_of::<u32>());
        budget.charge::<u32>(original_capacity).unwrap();
        let remaining = budget.remaining_slots::<u32>();
        let result = budget.reserve_using(&mut values, target, |replacement, requested| {
            replacement
                .try_reserve_exact(requested + 1)
                .map_err(|_| Error::protocol("test allocation failed"))
        });
        assert!(result.is_err());
        assert_eq!(values, [11, 22]);
        assert_eq!(values.capacity(), original_capacity);
        assert_eq!(budget.remaining_slots::<u32>(), remaining);

        let peak = std::cell::Cell::new(0);
        budget
            .reserve_using(&mut values, target, |replacement, requested| {
                replacement
                    .try_reserve_exact(requested)
                    .map_err(|_| Error::protocol("test allocation failed"))?;
                peak.set(original_capacity + replacement.capacity());
                Ok(())
            })
            .unwrap();
        assert_eq!(values, [11, 22]);
        assert!(values.capacity() >= target);
        assert!(peak.get() <= limit);
        assert_eq!(budget.remaining_slots::<u32>(), limit - values.capacity());
    }

    fn wrap_record_body(inner: &[u8]) -> BytesMut {
        let mut rec = BytesMut::new();
        buf::put_varint(&mut rec, buf::i32_from_usize(inner.len()).unwrap());
        rec.extend_from_slice(inner);
        rec
    }

    fn decode_record_err(inner: &[u8]) -> String {
        let rec = wrap_record_body(inner);
        decode_record(&mut &rec[..], 0, 0).unwrap_err().to_string()
    }

    fn record_body_before_headers() -> BytesMut {
        let mut inner = BytesMut::new();
        inner.put_i8(0);
        buf::put_varlong(&mut inner, 0);
        buf::put_varint(&mut inner, 0);
        buf::put_varint(&mut inner, -1);
        buf::put_varint(&mut inner, -1);
        inner
    }

    #[test]
    fn decode_record_invalid_headers_match_java() {
        let mut negative_count = record_body_before_headers();
        buf::put_varint(&mut negative_count, -1);
        let negative_count_err = decode_record_err(&negative_count);
        assert!(
            negative_count_err.contains("Found invalid number of record headers -1"),
            "{negative_count_err}"
        );

        let mut too_many = record_body_before_headers();
        buf::put_varint(&mut too_many, 10);
        let too_many_err = decode_record_err(&too_many);
        assert!(
            too_many_err.contains(
                "Found invalid number of record headers. 10 is larger than the remaining size of the buffer"
            ),
            "{too_many_err}"
        );

        let mut negative_key = record_body_before_headers();
        buf::put_varint(&mut negative_key, 1);
        buf::put_varint(&mut negative_key, -1);
        let negative_key_err = decode_record_err(&negative_key);
        assert!(
            negative_key_err.contains("Invalid negative header key size -1"),
            "{negative_key_err}"
        );

        let mut leftover = record_body_before_headers();
        buf::put_varint(&mut leftover, 0);
        let consumed = leftover.len();
        leftover.put_u8(0);
        let size = leftover.len();
        let leftover_err = decode_record_err(&leftover);
        assert!(
            leftover_err.contains(&format!(
                "Invalid record size: expected to read {size} bytes in record payload, but instead read {consumed}"
            )),
            "{leftover_err}"
        );

        let mut short = BytesMut::new();
        buf::put_varint(&mut short, 10);
        short.extend_from_slice(&[0, 1, 2]);
        let short_err = decode_record(&mut &short[..], 0, 0)
            .unwrap_err()
            .to_string();
        assert!(
            short_err.contains(
                "Invalid record size: expected 10 bytes in record payload, but instead the buffer has only 3 remaining bytes."
            ),
            "{short_err}"
        );
    }

    fn sample_record() -> Record {
        Record {
            offset: 0,
            timestamp: 1,
            key: None,
            value: Some(Bytes::from_static(b"x")),
            headers: vec![],
        }
    }

    fn patch_batch_count(buf: &mut [u8], count: i32) {
        let count_off = RecordBatch::RECORDS_COUNT_OFFSET as usize;
        let crc_off = RecordBatch::CRC_OFFSET as usize;
        buf[count_off..count_off + 4].copy_from_slice(&count.to_be_bytes());
        let crc_start = crc_off + 4;
        let crc = crc32c::crc32c(&buf[crc_start..]);
        buf[crc_off..crc_off + 4].copy_from_slice(&crc.to_be_bytes());
    }

    #[test]
    fn decode_record_batch_count_checks_match_java() {
        let rec = sample_record();
        let mut two = BytesMut::new();
        encode_record_batch(
            &mut two,
            &RecordBatch::from_records(vec![rec.clone(), rec.clone()]),
        )
        .unwrap();

        let mut leftover = two.clone();
        patch_batch_count(&mut leftover, 1);
        let leftover_err = decode_record_batch(&mut leftover.as_ref())
            .unwrap_err()
            .to_string();
        assert!(
            leftover_err.contains("Incorrect declared batch size, records still remaining in file"),
            "{leftover_err}"
        );

        let mut one = BytesMut::new();
        encode_record_batch(&mut one, &RecordBatch::from_records(vec![rec.clone()])).unwrap();
        let mut eof = one.clone();
        patch_batch_count(&mut eof, 2);
        let eof_err = decode_record_batch(&mut eof.as_ref())
            .unwrap_err()
            .to_string();
        assert!(
            eof_err.contains("Incorrect declared batch size, premature EOF reached"),
            "{eof_err}"
        );

        let mut negative = one.clone();
        patch_batch_count(&mut negative, -1);
        let negative_err = decode_record_batch(&mut negative.as_ref())
            .unwrap_err()
            .to_string();
        assert!(
            negative_err.contains("Found invalid record count -1 in magic v2 batch"),
            "{negative_err}"
        );

        let mut zero = two.clone();
        patch_batch_count(&mut zero, 0);
        let zero_err = decode_record_batch(&mut zero.as_ref())
            .unwrap_err()
            .to_string();
        assert!(
            zero_err.contains("Incorrect declared batch size, records still remaining in file"),
            "{zero_err}"
        );

        let mut empty = vec![0u8; RecordBatch::RECORD_BATCH_OVERHEAD as usize];
        put_batch_length(
            &mut empty,
            RecordBatch::RECORD_BATCH_OVERHEAD - Records::LOG_OVERHEAD,
        );
        put_magic(
            &mut empty,
            u8::try_from(RecordBatch::MAGIC_VALUE_V2).unwrap(),
        );
        put_record_count(&mut empty, 0);
        restamp_crc(&mut empty);
        let skipped = decode_record_batch(&mut empty.as_slice()).unwrap();
        assert!(skipped.records.is_empty());
    }

    #[test]
    fn decode_record_batch_ensure_valid_match_java() {
        let mut too_small = BytesMut::new();
        too_small.put_i64(0);
        too_small.put_i32(0);
        let small_err = decode_record_batch(&mut too_small.as_ref())
            .unwrap_err()
            .to_string();
        assert!(
            small_err.contains(
                "Record batch is corrupt (the size 12 is smaller than the minimum allowed overhead 61)"
            ),
            "{small_err}"
        );

        let mut buf = BytesMut::new();
        encode_record_batch(&mut buf, &RecordBatch::from_records(vec![sample_record()])).unwrap();
        let crc_off = RecordBatch::CRC_OFFSET as usize;
        let attr = crc_off + 4;
        buf[attr] ^= 0xff;
        let stored = u32::from_be_bytes(buf[crc_off..crc_off + 4].try_into().unwrap());
        let computed = crc32c::crc32c(&buf[attr..]);
        let crc_err = decode_record_batch(&mut buf.as_ref())
            .unwrap_err()
            .to_string();
        assert!(
            crc_err.contains(&format!(
                "Record is corrupt (stored crc = {stored}, computed crc = {computed})"
            )),
            "{crc_err}"
        );
    }

    #[test]
    fn is_valid_matches_java_default_record_batch() {
        let mut encoded = BytesMut::new();
        encode_record_batch(
            &mut encoded,
            &RecordBatch::from_records(vec![sample_record()]),
        )
        .unwrap();
        assert!(RecordBatch::is_valid(&encoded).unwrap());

        let mut flipped = encoded.clone();
        let attr = RecordBatch::ATTRIBUTES_OFFSET as usize;
        flipped[attr] ^= 0xff;
        assert!(!RecordBatch::is_valid(&flipped).unwrap());

        assert!(!RecordBatch::is_valid(&[0; 12]).unwrap());
        let err = RecordBatch::is_valid(&[0; 11]).unwrap_err().to_string();
        assert!(err.contains("need 4 bytes"), "{err}");

        let mut undersized = encoded.clone();
        put_batch_length(&mut undersized, 0i32);
        assert!(!RecordBatch::is_valid(&undersized).unwrap());

        let mut short_crc = [0u8; 12];
        put_batch_length(&mut short_crc, 49i32);
        let err = RecordBatch::is_valid(&short_crc).unwrap_err().to_string();
        assert!(err.contains("need 4 bytes"), "{err}");

        let mut header_only = [0u8; 21];
        put_batch_length(&mut header_only, 49i32);
        assert!(RecordBatch::is_valid(&header_only).unwrap());
    }

    #[test]
    fn encoded_size_in_bytes_matches_java_default_record_batch() {
        let mut encoded = BytesMut::new();
        encode_record_batch(
            &mut encoded,
            &RecordBatch::from_records(vec![sample_record()]),
        )
        .unwrap();
        let encoded_len = i32::try_from(encoded.len()).unwrap();
        assert_eq!(
            RecordBatch::encoded_size_in_bytes(&encoded).unwrap(),
            encoded_len
        );
        assert_eq!(
            RecordBatch::from_records(vec![sample_record()])
                .size_in_bytes()
                .unwrap(),
            encoded_len
        );

        assert_eq!(RecordBatch::encoded_size_in_bytes(&[0; 12]).unwrap(), 12);

        let err = RecordBatch::encoded_size_in_bytes(&[0; 11])
            .unwrap_err()
            .to_string();
        assert!(err.contains("need 4 bytes"), "{err}");

        let mut wrap = [0u8; 12];
        put_batch_length(&mut wrap, i32::MAX);
        assert_eq!(
            RecordBatch::encoded_size_in_bytes(&wrap).unwrap(),
            Records::LOG_OVERHEAD.wrapping_add(i32::MAX)
        );

        let mut declared = encoded.clone();
        put_batch_length(&mut declared, 100i32);
        assert_eq!(RecordBatch::encoded_size_in_bytes(&declared).unwrap(), 112);
        assert_ne!(
            RecordBatch::encoded_size_in_bytes(&declared).unwrap(),
            encoded_len
        );
    }

    #[test]
    fn ensure_valid_matches_java_default_record_batch() {
        let mut encoded = BytesMut::new();
        encode_record_batch(
            &mut encoded,
            &RecordBatch::from_records(vec![sample_record()]),
        )
        .unwrap();
        RecordBatch::ensure_valid(&encoded).unwrap();

        let size_err = RecordBatch::ensure_valid(&[0; 12]).unwrap_err().to_string();
        assert!(
            size_err.contains(
                "Record batch is corrupt (the size 12 is smaller than the minimum allowed overhead 61)"
            ),
            "{size_err}"
        );

        let short = RecordBatch::ensure_valid(&[0; 11]).unwrap_err().to_string();
        assert!(short.contains("need 4 bytes"), "{short}");

        let mut undersized = encoded.clone();
        put_batch_length(&mut undersized, 0i32);
        let under = RecordBatch::ensure_valid(&undersized)
            .unwrap_err()
            .to_string();
        assert!(
            under.contains(
                "Record batch is corrupt (the size 12 is smaller than the minimum allowed overhead 61)"
            ),
            "{under}"
        );

        let mut flipped = encoded.clone();
        let attr = RecordBatch::ATTRIBUTES_OFFSET as usize;
        flipped[attr] ^= 0xff;
        let crc_off = RecordBatch::CRC_OFFSET as usize;
        let stored = u32::from_be_bytes(flipped[crc_off..crc_off + 4].try_into().unwrap());
        let computed = crc32c::crc32c(&flipped[attr..]);
        let crc_err = RecordBatch::ensure_valid(&flipped).unwrap_err().to_string();
        assert!(
            crc_err.contains(&format!(
                "Record is corrupt (stored crc = {stored}, computed crc = {computed})"
            )),
            "{crc_err}"
        );

        let mut short_crc = [0u8; 12];
        put_batch_length(&mut short_crc, 49i32);
        let err = RecordBatch::ensure_valid(&short_crc)
            .unwrap_err()
            .to_string();
        assert!(err.contains("need 4 bytes"), "{err}");

        let mut header_only = [0u8; 21];
        put_batch_length(&mut header_only, 49i32);
        RecordBatch::ensure_valid(&header_only).unwrap();

        let mut trailing = encoded.clone();
        trailing.put_u8(0xff);
        assert!(!RecordBatch::is_valid(&trailing).unwrap());
        let trail_err = RecordBatch::ensure_valid(&trailing)
            .unwrap_err()
            .to_string();
        assert!(trail_err.contains("Record is corrupt"), "{trail_err}");
        let mut trail_slice = trailing.as_ref();
        drop(decode_record_batch(&mut trail_slice).unwrap());
        assert_eq!(trail_slice, &[0xff]);
    }

    #[test]
    fn encoded_last_offset_matches_java_default_record_batch() {
        let empty = RecordBatch::from_records(vec![]);
        let mut empty_buf = BytesMut::new();
        encode_record_batch(&mut empty_buf, &empty).unwrap();
        assert_eq!(RecordBatch::encoded_last_offset(&empty_buf).unwrap(), 0);
        assert_eq!(empty.last_offset(), -1);
        assert_eq!(RecordBatch::encoded_next_offset(&empty_buf).unwrap(), 1);
        assert_eq!(empty.next_offset(), 0);

        let mut two = BytesMut::new();
        encode_record_batch(
            &mut two,
            &RecordBatch::from_records(vec![sample_record(), sample_record()]),
        )
        .unwrap();
        assert_eq!(RecordBatch::encoded_last_offset(&two).unwrap(), 1);
        assert_eq!(RecordBatch::encoded_next_offset(&two).unwrap(), 2);

        let mut mutated = two.clone();
        put_last_offset_delta(&mut mutated, 5i32);
        assert_eq!(RecordBatch::encoded_last_offset(&mutated).unwrap(), 5);
        assert_eq!(RecordBatch::encoded_next_offset(&mutated).unwrap(), 6);

        let mut wrap = [0u8; 27];
        wrap[0..8].copy_from_slice(&i64::MAX.to_be_bytes());
        put_last_offset_delta(&mut wrap, 1i32);
        assert_eq!(RecordBatch::encoded_last_offset(&wrap).unwrap(), i64::MIN);
        assert_eq!(
            RecordBatch::encoded_next_offset(&wrap).unwrap(),
            i64::MIN.wrapping_add(1)
        );

        let short_base = RecordBatch::encoded_last_offset(&[0; 7])
            .unwrap_err()
            .to_string();
        assert!(short_base.contains("need 8 bytes"), "{short_base}");

        let short_delta = RecordBatch::encoded_last_offset(&[0; 26])
            .unwrap_err()
            .to_string();
        assert!(short_delta.contains("need 4 bytes"), "{short_delta}");
    }

    #[test]
    fn encoded_last_sequence_matches_java_default_record_batch() {
        let empty = RecordBatch::from_records(vec![]);
        let mut empty_buf = BytesMut::new();
        encode_record_batch(&mut empty_buf, &empty).unwrap();
        assert_eq!(
            RecordBatch::encoded_last_sequence(&empty_buf).unwrap(),
            RecordBatch::NO_SEQUENCE
        );
        assert_eq!(empty.last_sequence(), RecordBatch::NO_SEQUENCE);

        let mut batch = RecordBatch::from_records(vec![sample_record(), sample_record()]);
        batch.base_sequence = 5;
        let mut encoded = BytesMut::new();
        encode_record_batch(&mut encoded, &batch).unwrap();
        assert_eq!(RecordBatch::encoded_last_sequence(&encoded).unwrap(), 6);
        assert_eq!(batch.last_sequence(), 6);

        let mut mutated = encoded.clone();
        put_last_offset_delta(&mut mutated, 5i32);
        assert_eq!(RecordBatch::encoded_last_sequence(&mutated).unwrap(), 10);
        assert_eq!(batch.last_sequence(), 6);

        let mut no_seq = [0u8; 57];
        put_last_offset_delta(&mut no_seq, 5i32);
        no_seq[53..57].copy_from_slice(&RecordBatch::NO_SEQUENCE.to_be_bytes());
        assert_eq!(
            RecordBatch::encoded_last_sequence(&no_seq).unwrap(),
            RecordBatch::NO_SEQUENCE
        );

        let mut wrap = [0u8; 57];
        put_last_offset_delta(&mut wrap, 1i32);
        wrap[53..57].copy_from_slice(&i32::MAX.to_be_bytes());
        assert_eq!(
            RecordBatch::encoded_last_sequence(&wrap).unwrap(),
            RecordBatch::increment_sequence(i32::MAX, 1)
        );

        let short = RecordBatch::encoded_last_sequence(&[0; 52])
            .unwrap_err()
            .to_string();
        assert!(short.contains("need 4 bytes"), "{short}");
    }

    #[test]
    fn encoded_delete_horizon_ms_matches_java_default_record_batch() {
        let plain = RecordBatch::from_records(vec![sample_record()]);
        let mut plain_buf = BytesMut::new();
        encode_record_batch(&mut plain_buf, &plain).unwrap();
        assert_eq!(
            RecordBatch::encoded_delete_horizon_ms(&plain_buf).unwrap(),
            None
        );
        assert!(plain.delete_horizon_ms().is_none());

        let horizon = plain.clone().with_delete_horizon(true);
        let mut horizon_buf = BytesMut::new();
        encode_record_batch(&mut horizon_buf, &horizon).unwrap();
        assert_eq!(
            RecordBatch::encoded_delete_horizon_ms(&horizon_buf).unwrap(),
            Some(1)
        );
        assert_eq!(horizon.delete_horizon_ms(), Some(1));

        let mut mutated = horizon_buf.clone();
        put_base_timestamp(&mut mutated, 99i64);
        assert_eq!(
            RecordBatch::encoded_delete_horizon_ms(&mutated).unwrap(),
            Some(99)
        );
        assert_eq!(horizon.delete_horizon_ms(), Some(1));

        assert_eq!(
            RecordBatch::encoded_delete_horizon_ms(&[0; 23]).unwrap(),
            None
        );
        let short_attr = RecordBatch::encoded_delete_horizon_ms(&[0; 22])
            .unwrap_err()
            .to_string();
        assert!(short_attr.contains("need 2 bytes"), "{short_attr}");

        let mut flag_only = [0u8; 23];
        put_attributes(&mut flag_only, ATTR_DELETE_HORIZON);
        let short_ts = RecordBatch::encoded_delete_horizon_ms(&flag_only)
            .unwrap_err()
            .to_string();
        assert!(short_ts.contains("need 8 bytes"), "{short_ts}");
    }

    #[test]
    fn encoded_is_transactional_matches_java_default_record_batch() {
        let plain = RecordBatch::from_records(vec![sample_record()]);
        let mut plain_buf = BytesMut::new();
        encode_record_batch(&mut plain_buf, &plain).unwrap();
        assert!(!RecordBatch::encoded_is_transactional(&plain_buf).unwrap());
        assert!(!RecordBatch::encoded_is_control_batch(&plain_buf).unwrap());
        assert_eq!(
            RecordBatch::encoded_timestamp_type(&plain_buf).unwrap(),
            TimestampType::CreateTime
        );

        let flagged = plain
            .clone()
            .with_transactional(true)
            .with_control_batch(true)
            .with_timestamp_type(TimestampType::LogAppendTime);
        let mut flagged_buf = BytesMut::new();
        encode_record_batch(&mut flagged_buf, &flagged).unwrap();
        assert!(RecordBatch::encoded_is_transactional(&flagged_buf).unwrap());
        assert!(RecordBatch::encoded_is_control_batch(&flagged_buf).unwrap());
        assert_eq!(
            RecordBatch::encoded_timestamp_type(&flagged_buf).unwrap(),
            TimestampType::LogAppendTime
        );
        assert!(flagged.is_transactional());
        assert!(flagged.is_control_batch());
        assert_eq!(flagged.timestamp_type(), TimestampType::LogAppendTime);

        let mut mutated = flagged_buf.clone();
        put_attributes(&mut mutated, 0i16);
        assert!(!RecordBatch::encoded_is_transactional(&mutated).unwrap());
        assert!(!RecordBatch::encoded_is_control_batch(&mutated).unwrap());
        assert_eq!(
            RecordBatch::encoded_timestamp_type(&mutated).unwrap(),
            TimestampType::CreateTime
        );
        assert!(flagged.is_transactional());
        assert!(flagged.is_control_batch());
        assert_eq!(flagged.timestamp_type(), TimestampType::LogAppendTime);

        assert!(!RecordBatch::encoded_is_transactional(&[0; 23]).unwrap());
        assert!(!RecordBatch::encoded_is_control_batch(&[0; 23]).unwrap());
        assert_eq!(
            RecordBatch::encoded_timestamp_type(&[0; 23]).unwrap(),
            TimestampType::CreateTime
        );
        let short = RecordBatch::encoded_is_transactional(&[0; 22])
            .unwrap_err()
            .to_string();
        assert!(short.contains("need 2 bytes"), "{short}");
        let short_ctrl = RecordBatch::encoded_is_control_batch(&[0; 22])
            .unwrap_err()
            .to_string();
        assert!(short_ctrl.contains("need 2 bytes"), "{short_ctrl}");
        let short_ts = RecordBatch::encoded_timestamp_type(&[0; 22])
            .unwrap_err()
            .to_string();
        assert!(short_ts.contains("need 2 bytes"), "{short_ts}");
    }

    #[test]
    fn encoded_has_producer_id_matches_java_abstract_record_batch() {
        let plain = RecordBatch::from_records(vec![sample_record()]);
        let mut plain_buf = BytesMut::new();
        encode_record_batch(&mut plain_buf, &plain).unwrap();
        assert!(!RecordBatch::encoded_has_producer_id(&plain_buf).unwrap());
        assert!(!plain.has_producer_id());

        let mut with_id = plain.clone();
        with_id.producer_id = 7;
        let mut with_id_buf = BytesMut::new();
        encode_record_batch(&mut with_id_buf, &with_id).unwrap();
        assert!(RecordBatch::encoded_has_producer_id(&with_id_buf).unwrap());
        assert!(with_id.has_producer_id());

        let mut mutated = with_id_buf.clone();
        mutated[43..51].copy_from_slice(&RecordBatch::NO_PRODUCER_ID.to_be_bytes());
        assert!(!RecordBatch::encoded_has_producer_id(&mutated).unwrap());
        assert!(with_id.has_producer_id());

        // Java `NO_PRODUCER_ID < 0` is true: a zero producer id counts as set.
        assert!(RecordBatch::encoded_has_producer_id(&[0; 51]).unwrap());

        let short = RecordBatch::encoded_has_producer_id(&[0; 42])
            .unwrap_err()
            .to_string();
        assert!(short.contains("need 8 bytes"), "{short}");
    }

    #[test]
    fn encoded_count_or_null_matches_java_default_record_batch() {
        let empty = RecordBatch::from_records(vec![]);
        let mut empty_buf = BytesMut::new();
        encode_record_batch(&mut empty_buf, &empty).unwrap();
        assert_eq!(
            RecordBatch::encoded_count_or_null(&empty_buf).unwrap(),
            Some(0)
        );
        assert_eq!(empty.count_or_null(), Some(0));

        let one = RecordBatch::from_records(vec![sample_record()]);
        let mut one_buf = BytesMut::new();
        encode_record_batch(&mut one_buf, &one).unwrap();
        assert_eq!(
            RecordBatch::encoded_count_or_null(&one_buf).unwrap(),
            Some(1)
        );
        assert_eq!(one.count_or_null(), Some(1));

        let mut mutated = one_buf.clone();
        put_record_count(&mut mutated, 99i32);
        assert_eq!(
            RecordBatch::encoded_count_or_null(&mutated).unwrap(),
            Some(99)
        );
        assert_eq!(one.count_or_null(), Some(1));

        let mut negative = [0u8; 61];
        put_record_count(&mut negative, -1i32);
        assert_eq!(
            RecordBatch::encoded_count_or_null(&negative).unwrap(),
            Some(-1)
        );

        assert_eq!(
            RecordBatch::encoded_count_or_null(&[0; 61]).unwrap(),
            Some(0)
        );
        let short = RecordBatch::encoded_count_or_null(&[0; 56])
            .unwrap_err()
            .to_string();
        assert!(short.contains("need 4 bytes"), "{short}");
    }

    #[test]
    fn set_last_offset_matches_java_default_record_batch() {
        let one = RecordBatch::from_records(vec![sample_record()]);
        let mut one_buf = BytesMut::new();
        encode_record_batch(&mut one_buf, &one).unwrap();
        assert_eq!(RecordBatch::encoded_last_offset(&one_buf).unwrap(), 0);
        RecordBatch::set_last_offset(&mut one_buf, 10).unwrap();
        assert_eq!(RecordBatch::encoded_last_offset(&one_buf).unwrap(), 10);
        assert_eq!(RecordBatch::encoded_next_offset(&one_buf).unwrap(), 11);
        assert_eq!(one.last_offset(), 0);
        assert!(RecordBatch::is_valid(&one_buf).unwrap());
        let decoded = decode_record_batch(&mut &one_buf[..]).unwrap();
        assert_eq!(decoded.base_offset, 10);
        assert_eq!(decoded.records[0].offset, 10);

        let mut two = BytesMut::new();
        encode_record_batch(
            &mut two,
            &RecordBatch::from_records(vec![sample_record(), sample_record()]),
        )
        .unwrap();
        put_last_offset_delta(&mut two, 5i32);
        RecordBatch::set_last_offset(&mut two, 10).unwrap();
        assert_eq!(&two[0..8], &5i64.to_be_bytes());
        assert_eq!(RecordBatch::encoded_last_offset(&two).unwrap(), 10);

        let empty = RecordBatch::from_records(vec![]);
        let mut empty_buf = BytesMut::new();
        encode_record_batch(&mut empty_buf, &empty).unwrap();
        RecordBatch::set_last_offset(&mut empty_buf, 7).unwrap();
        assert_eq!(RecordBatch::encoded_last_offset(&empty_buf).unwrap(), 7);
        assert_eq!(empty.last_offset(), -1);

        let mut wrap = [0u8; 27];
        put_last_offset_delta(&mut wrap, 1i32);
        RecordBatch::set_last_offset(&mut wrap, i64::MIN).unwrap();
        assert_eq!(&wrap[0..8], &i64::MAX.to_be_bytes());
        assert_eq!(RecordBatch::encoded_last_offset(&wrap).unwrap(), i64::MIN);

        let mut zeros = [0u8; 27];
        RecordBatch::set_last_offset(&mut zeros, 42).unwrap();
        assert_eq!(&zeros[0..8], &42i64.to_be_bytes());

        let short = RecordBatch::set_last_offset(&mut [0u8; 26], 1)
            .unwrap_err()
            .to_string();
        assert!(short.contains("need 4 bytes"), "{short}");
    }

    #[test]
    fn header_exclusive_end_keeps_a_compacted_batch_tail() {
        let mut encoded = BytesMut::new();
        encode_record_batch(
            &mut encoded,
            &RecordBatch::from_records(vec![
                Record {
                    offset: 0,
                    timestamp: 1,
                    key: None,
                    value: Some(Bytes::from_static(b"a")),
                    headers: Vec::new(),
                },
                Record {
                    offset: 0,
                    timestamp: 2,
                    key: None,
                    value: Some(Bytes::from_static(b"b")),
                    headers: Vec::new(),
                },
            ]),
        )
        .unwrap();
        put_last_offset_delta(&mut encoded, 10i32);
        restamp_crc(&mut encoded);
        let batches = split_record_batches(Bytes::from(encoded)).unwrap();
        let end = batches.first().and_then(EncodedBatch::header_exclusive_end);
        assert_eq!(end, Some(11));
    }

    #[test]
    fn a_zero_count_batch_with_trailing_bytes_is_rejected() {
        let mut empty = vec![0u8; 49];
        let magic_at = usize::try_from(Records::MAGIC_OFFSET - Records::LOG_OVERHEAD).unwrap();
        let crc_at = usize::try_from(RecordBatch::CRC_OFFSET - Records::LOG_OVERHEAD).unwrap();
        let attributes_at =
            usize::try_from(RecordBatch::ATTRIBUTES_OFFSET - Records::LOG_OVERHEAD).unwrap();
        empty[magic_at] = u8::try_from(RecordBatch::MAGIC_VALUE_V2).unwrap();
        let crc = crc32c::crc32c(&empty[attributes_at..]);
        empty[crc_at..attributes_at].copy_from_slice(&crc.to_be_bytes());
        assert!(decode_checked_batch(0, Bytes::from(empty.clone()), 1024, Vec::new()).is_ok());
        let mut trailing = empty;
        trailing.push(1);
        let crc = crc32c::crc32c(&trailing[attributes_at..]);
        trailing[crc_at..attributes_at].copy_from_slice(&crc.to_be_bytes());
        let body = Bytes::from(trailing);
        assert!(decode_checked_batch(0, body.clone(), 1024, Vec::new()).is_err());
        let framed = EncodedBatch {
            base_offset: 0,
            attributes: 0,
            body,
        };
        let visited = framed.try_visit_short_keys(|_| {});
        assert!(visited.is_ok());
        if let Ok(visited) = visited {
            assert!(visited.is_none());
        }
    }

    #[test]
    fn decode_record_rejects_nonzero_attributes() {
        let mut encoded = BytesMut::new();
        assert!(encode_record(
            &mut encoded,
            &EncodeRecord {
                timestamp: 0,
                key: None,
                value: None,
                headers: &[],
            },
            0,
            0,
            &mut Vec::new(),
        )
        .is_ok());
        let bytes = encoded.to_vec();
        assert_eq!(bytes.get(1).copied(), Some(0));
        let mut good = Bytes::from(bytes.clone());
        assert!(decode_record_from_bytes(&mut good, 0, 0).is_ok());
        let mut flipped = bytes;
        if let Some(slot) = flipped.get_mut(1) {
            *slot = 1;
        }
        let mut bad = Bytes::from(flipped.clone());
        assert!(decode_record_from_bytes(&mut bad, 0, 0).is_err());
        assert!(try_plain_short_key(&mut Bytes::from(flipped), 0, 0).is_none());
    }

    #[test]
    fn decode_record_rejects_offset_and_timestamp_overflow() {
        assert_eq!(record_offset(10, 3), Some(13));
        assert_eq!(record_timestamp(1_000, 3), Some(1_003));
        assert_eq!(record_offset(i64::MAX, 1), None);
        assert_eq!(record_timestamp(i64::MAX, 1), None);

        let mut offset_body = BytesMut::new();
        offset_body.put_i8(0);
        buf::put_varlong(&mut offset_body, 0);
        buf::put_varint(&mut offset_body, 1);
        buf::put_varint(&mut offset_body, -1);
        buf::put_varint(&mut offset_body, -1);
        buf::put_varint(&mut offset_body, 0);
        let offset_rec = wrap_record_body(&offset_body);
        let offset_err = decode_record(&mut &offset_rec[..], i64::MAX, 0)
            .unwrap_err()
            .to_string();
        assert!(
            offset_err.contains("record offset overflow"),
            "{offset_err}"
        );

        let mut timestamp_body = BytesMut::new();
        timestamp_body.put_i8(0);
        buf::put_varlong(&mut timestamp_body, 1);
        buf::put_varint(&mut timestamp_body, 0);
        buf::put_varint(&mut timestamp_body, -1);
        buf::put_varint(&mut timestamp_body, -1);
        buf::put_varint(&mut timestamp_body, 0);
        let timestamp_rec = wrap_record_body(&timestamp_body);
        let timestamp_err = decode_record(&mut &timestamp_rec[..], 0, i64::MAX)
            .unwrap_err()
            .to_string();
        assert!(
            timestamp_err.contains("record timestamp overflow"),
            "{timestamp_err}"
        );

        let rec = Record {
            offset: 0,
            timestamp: 0,
            key: None,
            value: Some(Bytes::from_static(b"x")),
            headers: vec![],
        };
        let mut encoded = BytesMut::new();
        encode_record_batch(
            &mut encoded,
            &RecordBatch::from_records(vec![rec.clone(), rec]),
        )
        .unwrap();
        RecordBatch::set_last_offset(&mut encoded, i64::MIN).unwrap();
        assert_eq!(
            RecordBatch::encoded_last_offset(&encoded).unwrap(),
            i64::MIN
        );

        let overflow = Record {
            offset: 0,
            timestamp: i64::MIN,
            key: None,
            value: Some(Bytes::from_static(b"x")),
            headers: vec![],
        };
        let mut batch = RecordBatch::from_records(vec![
            Record {
                timestamp: i64::MAX,
                ..overflow.clone()
            },
            overflow,
        ]);
        batch.base_timestamp = i64::MAX;
        let err = write_record_batch(
            &mut BytesMut::new(),
            &batch_header_from(&batch).unwrap(),
            batch.records.iter().map(EncodeRecord::from_record),
        )
        .unwrap_err()
        .to_string();
        assert!(err.contains("record timestamp overflow"), "{err}");
        let size_err = RecordBatch::size_in_bytes_from(0, &batch.records)
            .unwrap_err()
            .to_string();
        assert!(size_err.contains("record timestamp overflow"), "{size_err}");
        let offset_err = RecordBatch::size_in_bytes_from(i64::MAX, &batch.records)
            .unwrap_err()
            .to_string();
        assert!(
            offset_err.contains("offset delta exceeds i32"),
            "{offset_err}"
        );

        let mut at_end = RecordBatch::from_records(vec![
            Record {
                offset: 0,
                timestamp: 0,
                key: None,
                value: Some(Bytes::from_static(b"a")),
                headers: vec![],
            },
            Record {
                offset: 1,
                timestamp: 0,
                key: None,
                value: Some(Bytes::from_static(b"b")),
                headers: vec![],
            },
        ]);
        at_end.base_offset = i64::MAX;
        let mut buf = BytesMut::from(&b"prefix"[..]);
        let encode_err = encode_record_batch(&mut buf, &at_end)
            .unwrap_err()
            .to_string();
        assert!(
            encode_err.contains("record offset overflow"),
            "{encode_err}"
        );
        assert_eq!(&buf[..], b"prefix");

        let one = Record {
            offset: 0,
            timestamp: 1,
            key: None,
            value: Some(Bytes::from_static(b"a")),
            headers: vec![],
        };
        let mut mismatched = BytesMut::from(&b"keep"[..]);
        let count_err = write_record_batch(
            &mut mismatched,
            &BatchHeader {
                count: 2,
                base_timestamp: 1,
                max_timestamp: 1,
                ..BatchHeader::default()
            },
            std::iter::once(EncodeRecord::from_record(&one)),
        )
        .unwrap_err()
        .to_string();
        assert!(
            count_err.contains("record count differs from header"),
            "{count_err}"
        );
        assert_eq!(&mismatched[..], b"keep");
        let batch_err = decode_record_batch_reusing(
            &mut &encoded[..],
            DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES,
            Vec::new(),
        )
        .unwrap_err()
        .to_string();
        assert!(batch_err.contains("record offset overflow"), "{batch_err}");
    }

    #[tokio::test]
    async fn wire_signed_wrap_roundtrips_but_consumer_and_producer_reject_overflow() {
        let records = vec![
            Record {
                offset: i64::MAX,
                timestamp: i64::MAX,
                key: Some(Bytes::from_static(b"first")),
                value: None,
                headers: Vec::new(),
            },
            Record {
                offset: i64::MIN,
                timestamp: i64::MIN,
                key: None,
                value: Some(Bytes::from_static(b"second")),
                headers: Vec::new(),
            },
        ];
        let mut batch = RecordBatch::from_records(records.clone());
        batch.records = records.clone();
        batch.base_offset = i64::MAX;
        batch.base_timestamp = i64::MAX;
        batch.max_timestamp = i64::MAX;
        for codec in [
            Compression::None,
            Compression::Gzip,
            Compression::Snappy,
            Compression::Lz4,
            #[cfg(feature = "zstd")]
            Compression::Zstd,
        ] {
            let batch = batch.clone().with_compression(codec);
            let mut encoded = BytesMut::from(&b"prefix"[..]);
            encode_record_batch(&mut encoded, &batch).unwrap();
            let wire = encoded.get(6..).unwrap();
            let decoded = decode_record_batch(&mut &*wire).unwrap();
            assert_eq!(decoded.records, records);
            let strict = decode_record_batch_reusing(
                &mut &*wire,
                DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES,
                Vec::new(),
            );
            assert!(strict.is_err());

            let mut cooperative = BytesMut::from(&b"prefix"[..]);
            encode_record_batch_cooperative(&mut cooperative, &batch)
                .await
                .unwrap();
            let cooperative_wire = cooperative.get(6..).unwrap();
            let decoded_cooperative = decode_record_batch(&mut &*cooperative_wire).unwrap();
            assert_eq!(decoded_cooperative.records, records);

            let mut producer = BytesMut::from(&b"prefix"[..]);
            assert!(write_record_batch(
                &mut producer,
                &batch_header_from(&batch).unwrap(),
                batch.records.iter().map(EncodeRecord::from_record),
            )
            .is_err());
            assert_eq!(producer.as_ref(), b"prefix");
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn cancel_cooperative_encoders_restores_the_caller_prefix() {
        use std::future::{poll_fn, Future};
        use std::task::Poll;

        let make_record = || Record {
            offset: 0,
            timestamp: 0,
            key: None,
            value: Some(Bytes::from_static(b"x")),
            headers: Vec::new(),
        };
        let normal = RecordBatch::from_records(vec![make_record(); 8 * 1024 + 1]);
        let mut wrapped = normal.clone();
        wrapped.base_offset = i64::MAX;
        for (index, record) in wrapped.records.iter_mut().enumerate() {
            record.offset = i64::MAX.wrapping_add(i64::try_from(index).unwrap());
        }

        for (batch, polls) in [(&normal, 1), (&wrapped, 2)] {
            let mut output = BytesMut::from(&b"prefix"[..]);
            {
                let mut future = Box::pin(encode_record_batch_cooperative(&mut output, batch));
                for _ in 0..polls {
                    poll_fn(|cx| {
                        assert!(future.as_mut().poll(cx).is_pending());
                        Poll::Ready(())
                    })
                    .await;
                }
            }
            assert_eq!(output.as_ref(), b"prefix");
        }

        let mut output = BytesMut::from(&b"prefix"[..]);
        let mut scratch = CompressScratch::new();
        let header = batch_header_from(&normal).unwrap();
        {
            let mut future = Box::pin(write_uncompressed_batch_cooperative(
                &mut output,
                &header,
                normal.records.iter().map(EncodeRecord::from_record),
                &mut scratch,
            ));
            poll_fn(|cx| {
                assert!(future.as_mut().poll(cx).is_pending());
                Poll::Ready(())
            })
            .await;
        }
        assert_eq!(output.as_ref(), b"prefix");
    }

    fn test_batch_with_records(count: i32, attributes: i16, payload: &[u8]) -> BytesMut {
        let mut frame = BytesMut::new();
        let header = BatchHeader {
            count,
            attributes,
            ..BatchHeader::default()
        };
        let (start, length, crc, crc_start) = start_record_batch(&mut frame, &header);
        frame.extend_from_slice(payload);
        finish_record_batch(&mut frame, start, length, crc, crc_start).unwrap();
        assert!(RecordBatch::is_valid(&frame).unwrap());
        frame
    }

    #[test]
    fn crc_valid_inflated_counts_obey_the_shared_metadata_budget() {
        let raw = vec![0u8; 1024 * 1024];
        let count = 120_000;
        let plain = test_batch_with_records(count, 0, &raw);
        let error = decode_record_batch_with_limit(&mut plain.as_ref(), raw.len()).unwrap_err();
        assert!(error.to_string().contains("decoded record metadata"));

        let mut compressed = Vec::new();
        gzip_compress_into(&raw, &mut compressed).unwrap();
        assert!(compressed.len() < raw.len() / 10);
        let gzip = test_batch_with_records(count, Compression::Gzip as i16, &compressed);
        let error = decode_record_batch_with_limit(&mut gzip.as_ref(), raw.len()).unwrap_err();
        assert!(error.to_string().contains("decoded record metadata"));

        let mut body = BytesMut::new();
        body.put_i8(0);
        buf::put_varlong(&mut body, 0);
        buf::put_varint(&mut body, 0);
        buf::put_varint(&mut body, -1);
        buf::put_varint(&mut body, -1);
        buf::put_varint(&mut body, 3_000);
        body.resize(body.len() + 6_000, 0);
        let record = wrap_record_body(&body);
        let frame = test_batch_with_records(1, 0, &record);
        let error = decode_record_batch_with_limit(&mut frame.as_ref(), record.len()).unwrap_err();
        assert!(error.to_string().contains("decoded record metadata"));
    }

    #[test]
    fn tiny_limits_and_reused_capacity_are_accounted_without_losing_valid_records() {
        let minimal = [0x0cu8, 0, 0, 0, 1, 1, 0];
        let one = test_batch_with_records(1, 0, &minimal);
        let reused_slots = MIN_DECODE_METADATA_BYTES / std::mem::size_of::<Record>() + 1;
        let reused = Vec::with_capacity(reused_slots);
        let decoded =
            decode_record_batch_reusing(&mut one.as_ref(), minimal.len(), reused).unwrap();
        assert_eq!(decoded.records.len(), 1);
        assert!(
            decoded
                .records
                .capacity()
                .saturating_mul(std::mem::size_of::<Record>())
                <= MIN_DECODE_METADATA_BYTES
        );

        let mut four_bytes = Vec::new();
        for _ in 0..4 {
            four_bytes.extend_from_slice(&minimal);
        }
        let four = test_batch_with_records(4, 0, &four_bytes);
        let decoded = decode_record_batch_reusing(
            &mut four.as_ref(),
            four_bytes.len(),
            Vec::with_capacity(2),
        )
        .unwrap();
        assert_eq!(decoded.records.len(), 4);
        assert!(decoded.records.capacity() >= 4);
    }

    #[test]
    fn header_metadata_is_aggregated_across_records_and_batches() {
        let make_record = |count: i32| {
            let mut body = BytesMut::new();
            body.put_i8(0);
            buf::put_varlong(&mut body, 0);
            buf::put_varint(&mut body, 0);
            buf::put_varint(&mut body, -1);
            buf::put_varint(&mut body, -1);
            buf::put_varint(&mut body, count);
            body.resize(body.len() + usize::try_from(count).unwrap() * 2, 0);
            wrap_record_body(&body)
        };
        let larger_record = make_record(700);
        let larger_batch = test_batch_with_records(1, 0, &larger_record);
        assert!(decode_record_batch(&mut larger_batch.as_ref()).is_ok());

        // 600 headers fit the 64 KiB floor including the temporary 512-to-600
        // Vec growth peak, but two retained 600-header Vecs do not.
        let record = make_record(600);
        let one = test_batch_with_records(1, 0, &record);
        assert!(decode_record_batch_with_limit(&mut one.as_ref(), record.len()).is_ok());
        let mut two_records = BytesMut::new();
        two_records.extend_from_slice(&record);
        two_records.extend_from_slice(&record);
        let two = test_batch_with_records(2, 0, &two_records);
        let error =
            decode_record_batch_with_limit(&mut two.as_ref(), two_records.len()).unwrap_err();
        assert!(error.to_string().contains("decoded record metadata"));

        let mut batches = BytesMut::new();
        batches.extend_from_slice(&one);
        batches.extend_from_slice(&one);
        let error =
            decode_record_batches_with_limit(&mut batches.as_ref(), record.len()).unwrap_err();
        assert!(error.to_string().contains("decoded record metadata"));
    }

    #[test]
    fn wire_negative_delta_wrap_is_not_accepted_by_checked_decoder() {
        let mut body = BytesMut::new();
        body.put_i8(0);
        buf::put_varlong(&mut body, -1);
        buf::put_varint(&mut body, -1);
        buf::put_varint(&mut body, -1);
        buf::put_varint(&mut body, -1);
        buf::put_varint(&mut body, 0);
        let encoded = wrap_record_body(&body);
        let mut wrapped: &[u8] = encoded.as_ref();
        let mut metadata =
            DecodeMetadataBudget::for_wire_limit(DEFAULT_MAX_RECORD_BATCH_DECODE_BYTES);
        let decoded =
            decode_record_mode::<true, _>(&mut wrapped, i64::MIN, i64::MIN, &mut metadata).unwrap();
        assert_eq!(decoded.offset, i64::MAX);
        assert_eq!(decoded.timestamp, i64::MAX);
        let mut checked: &[u8] = encoded.as_ref();
        assert!(decode_record(&mut checked, i64::MIN, i64::MIN).is_err());
    }

    #[test]
    fn decode_record_uses_wire_offset_delta() {
        let mut inner = BytesMut::new();
        inner.put_i8(0);
        buf::put_varlong(&mut inner, 3);
        buf::put_varint(&mut inner, 7);
        buf::put_varint(&mut inner, -1);
        buf::put_varint(&mut inner, 1);
        inner.extend_from_slice(b"x");
        buf::put_varint(&mut inner, 0);
        let mut rec = BytesMut::new();
        buf::put_varint(&mut rec, buf::i32_from_usize(inner.len()).unwrap());
        rec.extend_from_slice(&inner);
        let decoded = decode_record(&mut &rec[..], 100, 1_000).unwrap();
        assert_eq!(decoded.offset, 107);
        assert_eq!(decoded.timestamp, 1_003);
        assert_eq!(decoded.value.as_deref(), Some(&b"x"[..]));
    }

    #[test]
    fn decode_record_batch_honors_base_offset_plus_delta() {
        let rec = Record {
            offset: 0,
            timestamp: 5,
            key: None,
            value: Some(Bytes::from_static(b"off")),
            headers: vec![],
        };
        let mut batch = RecordBatch::from_records(vec![rec.clone(), rec]);
        batch.base_offset = 50;
        let mut buf = BytesMut::new();
        encode_record_batch(&mut buf, &batch).unwrap();
        let decoded = decode_record_batch(&mut &buf[..]).unwrap();
        assert_eq!(decoded.records[0].offset, 50);
        assert_eq!(decoded.records[1].offset, 51);
    }

    #[test]
    fn compress_scratch_reuse_is_byte_identical_and_bounded() {
        let rec = Record {
            offset: 0,
            timestamp: 5,
            key: Some(Bytes::from_static(b"key-key!")),
            value: Some(Bytes::from_static(
                b"0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
            )),
            headers: vec![],
        };
        let records = vec![rec; 200];
        let header = BatchHeader {
            attributes: Compression::Snappy as i16,
            base_timestamp: 0,
            max_timestamp: 5,
            count: 200,
            ..BatchHeader::default()
        };
        let mut reference = BytesMut::new();
        write_record_batch(
            &mut reference,
            &header,
            records.iter().map(EncodeRecord::from_record),
        )
        .unwrap();
        // 1 KiB caps with a ~15 KiB section: reuse must stay byte-identical
        // while the shrink policy keeps retained capacity bounded.
        let mut scratch = CompressScratch::with_caps(1024, 1024);
        for _ in 0..2 {
            let mut buf = BytesMut::new();
            write_record_batch_scratch(
                &mut buf,
                &header,
                records.iter().map(EncodeRecord::from_record),
                &mut scratch,
            )
            .unwrap();
            assert_eq!(buf, reference);
        }
        assert!(
            scratch.section.capacity() <= 2048,
            "section capacity {} exceeds 2x cap",
            scratch.section.capacity()
        );
        assert!(
            scratch.packed.capacity() <= 2048,
            "packed capacity {} exceeds 2x cap",
            scratch.packed.capacity()
        );
        // Uncompressed batches never touch the scratch buffers.
        let mut plain_scratch = CompressScratch::new();
        let plain_header = BatchHeader {
            count: 200,
            base_timestamp: 0,
            max_timestamp: 5,
            ..BatchHeader::default()
        };
        let mut plain_buf = BytesMut::new();
        write_record_batch_scratch(
            &mut plain_buf,
            &plain_header,
            records.iter().map(EncodeRecord::from_record),
            &mut plain_scratch,
        )
        .unwrap();
        assert_eq!(plain_scratch.section.capacity(), 0);
        assert_eq!(plain_scratch.packed.capacity(), 0);
    }

    #[test]
    fn a_compressed_section_is_sized_once() {
        let rec = Record {
            offset: 0,
            timestamp: 5,
            key: Some(Bytes::from_static(b"key-key!")),
            value: Some(Bytes::from_static(
                b"0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
            )),
            headers: vec![],
        };
        let records = vec![rec; 200];
        let header = BatchHeader {
            attributes: Compression::Snappy as i16,
            base_timestamp: 0,
            max_timestamp: 5,
            count: 200,
            ..BatchHeader::default()
        };
        let encoded = records.iter().map(EncodeRecord::from_record);
        let section = uncompressed_section_len(&header, encoded).unwrap();
        assert!(section > 1024);
        let mut scratch = CompressScratch::new();
        scratch.reserve_section(section);
        let capacity = scratch.section.capacity();
        assert!(capacity >= section);
        let _framed = pack_compressed_batch(
            &header,
            records.iter().map(EncodeRecord::from_record),
            &mut scratch,
        )
        .unwrap();
        assert_eq!(scratch.section.capacity(), capacity);
        scratch.reserve_section(section);
        assert_eq!(scratch.section.capacity(), capacity);
        let _again = pack_compressed_batch(
            &header,
            records.iter().map(EncodeRecord::from_record),
            &mut scratch,
        )
        .unwrap();
        assert_eq!(scratch.section.capacity(), capacity);
    }

    #[test]
    fn header_wire_widths_stay_on_the_scratch_across_batches() {
        let rec = Record {
            offset: 0,
            timestamp: 1,
            key: None,
            value: Some(Bytes::from_static(b"v")),
            headers: vec![Header::new("h", Bytes::from_static(b"x"))],
        };
        let header = BatchHeader {
            count: 1,
            base_timestamp: 1,
            max_timestamp: 1,
            ..BatchHeader::default()
        };
        let mut scratch = CompressScratch::new();
        for _ in 0..2 {
            let mut buf = BytesMut::new();
            write_record_batch_scratch(
                &mut buf,
                &header,
                std::iter::once(EncodeRecord::from_record(&rec)),
                &mut scratch,
            )
            .unwrap();
        }
        assert!(scratch.header_wires.capacity() >= 1);
        let kept = scratch.header_wires.capacity();
        let mut buf = BytesMut::new();
        write_record_batch_scratch(
            &mut buf,
            &header,
            std::iter::once(EncodeRecord::from_record(&rec)),
            &mut scratch,
        )
        .unwrap();
        assert!(scratch.header_wires.capacity() >= kept);
        let headers: Vec<_> = (0..8)
            .map(|index| Header::new(format!("h{index}"), Bytes::from_static(b"x")))
            .collect();
        let wide = Record {
            offset: 0,
            timestamp: 1,
            key: None,
            value: Some(Bytes::from_static(b"v")),
            headers,
        };
        let mut wide_scratch = CompressScratch::new();
        let mut wide_buf = BytesMut::new();
        write_record_batch_scratch(
            &mut wide_buf,
            &header,
            std::iter::once(EncodeRecord::from_record(&wide)),
            &mut wide_scratch,
        )
        .unwrap();
        assert_eq!(
            wide_scratch.header_wires.capacity(),
            Vec::<HeaderWire>::with_capacity(8).capacity()
        );
        let wide_kept = wide_scratch.header_wires.capacity();
        wide_buf.clear();
        write_record_batch_scratch(
            &mut wide_buf,
            &header,
            std::iter::once(EncodeRecord::from_record(&wide)),
            &mut wide_scratch,
        )
        .unwrap();
        assert_eq!(wide_scratch.header_wires.capacity(), wide_kept);
    }

    #[test]
    fn record_and_batch_size_in_bytes_match_java() {
        let rec = Record {
            offset: 0,
            timestamp: 10,
            key: Some(Bytes::from_static(b"k")),
            value: Some(Bytes::from_static(b"val")),
            headers: vec![Header::new("h", Bytes::from_static(b"v"))],
        };
        let offset_delta = 3;
        let timestamp_delta = 5;
        let body = rec
            .size_of_body_in_bytes(offset_delta, timestamp_delta)
            .unwrap();
        let size = rec.size_in_bytes(offset_delta, timestamp_delta).unwrap();
        assert_eq!(size, body + buf::size_of_varint(body));
        let mut encoded = BytesMut::new();
        let mut wires = Vec::new();
        encode_record(
            &mut encoded,
            &EncodeRecord::from_record(&rec),
            offset_delta,
            timestamp_delta,
            &mut wires,
        )
        .unwrap();
        assert_eq!(size, buf::i32_from_usize(encoded.len()).unwrap());
        let wire_capacity = wires.capacity();
        encode_record(
            &mut BytesMut::new(),
            &EncodeRecord::from_record(&rec),
            offset_delta,
            timestamp_delta,
            &mut wires,
        )
        .unwrap();
        assert!(wires.capacity() >= wire_capacity);
        assert!(wire_capacity >= 1);

        let rec_a = Record {
            offset: 0,
            timestamp: 100,
            key: None,
            value: Some(Bytes::from_static(b"a")),
            headers: vec![],
        };
        let rec_b = Record {
            offset: 1,
            timestamp: 110,
            key: None,
            value: Some(Bytes::from_static(b"bb")),
            headers: vec![],
        };
        let batch = RecordBatch::from_records(vec![rec_a.clone(), rec_b.clone()]);
        let mut buf = BytesMut::new();
        encode_record_batch(&mut buf, &batch).unwrap();
        let encoded_len = buf::i32_from_usize(buf.len()).unwrap();
        assert_eq!(batch.size_in_bytes().unwrap(), encoded_len);
        assert_eq!(
            RecordBatch::size_in_bytes_of(&batch.records).unwrap(),
            encoded_len
        );

        assert_eq!(RecordBatch::size_in_bytes_of(&[]).unwrap(), 0);
        let empty_batch = RecordBatch::from_records(vec![]);
        assert_eq!(
            empty_batch.size_in_bytes().unwrap(),
            RecordBatch::RECORD_BATCH_OVERHEAD
        );

        let aligned_a = Record {
            offset: 10,
            timestamp: 5,
            key: None,
            value: Some(Bytes::from_static(b"a")),
            headers: vec![],
        };
        let aligned_b = Record {
            offset: 11,
            timestamp: 7,
            key: None,
            value: Some(Bytes::from_static(b"a")),
            headers: vec![],
        };
        assert_eq!(
            RecordBatch::size_in_bytes_from(10, &[aligned_a.clone(), aligned_b.clone()]).unwrap(),
            RecordBatch::size_in_bytes_of(&[aligned_a.clone(), aligned_b]).unwrap()
        );
        let far_b = Record {
            offset: 74,
            timestamp: 5,
            key: None,
            value: Some(Bytes::from_static(b"a")),
            headers: vec![],
        };
        assert_ne!(
            RecordBatch::size_in_bytes_from(10, &[aligned_a.clone(), far_b.clone()]).unwrap(),
            RecordBatch::size_in_bytes_of(&[aligned_a, far_b]).unwrap()
        );

        let crc = batch.checksum().unwrap();
        let off = buf::usize_from_i32(RecordBatch::CRC_OFFSET).unwrap();
        let crc_bytes = buf.get(off..off + 4).unwrap();
        assert_eq!(crc, u32::from_be_bytes(crc_bytes.try_into().unwrap()));
        assert_eq!(
            batch.to_string(),
            format!(
                "RecordBatch(magic=2, offsets=[0, 1], sequence=[-1, -1], isTransactional=false, isControlBatch=false, compression=none, timestampType=CreateTime, crc={crc})"
            )
        );

        let gz = batch.clone().with_compression(Compression::Gzip);
        let mut gz_buf = BytesMut::new();
        encode_record_batch(&mut gz_buf, &gz).unwrap();
        assert_eq!(
            gz.size_in_bytes().unwrap(),
            buf::i32_from_usize(gz_buf.len()).unwrap()
        );
        let gz_crc = gz.checksum().unwrap();
        assert_eq!(
            gz.to_string(),
            format!(
                "RecordBatch(magic=2, offsets=[0, 1], sequence=[-1, -1], isTransactional=false, isControlBatch=false, compression=gzip, timestampType=CreateTime, crc={gz_crc})"
            )
        );
        let lat = batch.with_timestamp_type(TimestampType::LogAppendTime);
        assert!(lat.to_string().contains("timestampType=LogAppendTime"));
    }

    #[test]
    fn record_size_upper_bound_matches_java() {
        let rec = Record {
            offset: 0,
            timestamp: 0,
            key: None,
            value: Some(Bytes::from_static(b"abcd")),
            headers: vec![],
        };
        let size_of = buf::i32_from_usize(
            size_of_key_value_headers(rec.key(), rec.value(), rec.headers()).unwrap(),
        )
        .unwrap();
        let upper = rec.record_size_upper_bound().unwrap();
        assert_eq!(upper, Record::MAX_RECORD_OVERHEAD + size_of);
        assert!(upper >= rec.size_in_bytes(0, 0).unwrap());
        let batch_upper =
            RecordBatch::estimate_batch_size_upper_bound(rec.key(), rec.value(), rec.headers())
                .unwrap();
        assert_eq!(batch_upper, RecordBatch::RECORD_BATCH_OVERHEAD + upper);
        assert_eq!(
            Records::estimate_size_in_bytes_upper_bound(rec.key(), rec.value(), rec.headers())
                .unwrap(),
            batch_upper
        );
        assert_eq!(batch_upper, 89);
    }

    #[test]
    fn estimate_size_in_bytes_matches_java() {
        assert_eq!(
            Records::record_batch_header_size_in_bytes(),
            RecordBatch::RECORD_BATCH_OVERHEAD
        );
        assert_eq!(
            Records::estimate_size_in_bytes(Compression::None, &[]).unwrap(),
            0
        );
        assert_eq!(
            Records::estimate_size_in_bytes(Compression::Gzip, &[]).unwrap(),
            1024
        );
        let rec = Record {
            offset: 10,
            timestamp: 5,
            key: None,
            value: Some(Bytes::from_static(b"a")),
            headers: vec![],
        };
        let uncompressed = RecordBatch::size_in_bytes_of(std::slice::from_ref(&rec)).unwrap();
        assert_eq!(
            Records::estimate_size_in_bytes(Compression::None, std::slice::from_ref(&rec)).unwrap(),
            uncompressed
        );
        assert_eq!(
            Records::estimate_size_in_bytes_from(10, Compression::None, std::slice::from_ref(&rec))
                .unwrap(),
            uncompressed
        );
        let gzip =
            Records::estimate_size_in_bytes(Compression::Gzip, std::slice::from_ref(&rec)).unwrap();
        assert_eq!(gzip, (uncompressed / 2).clamp(1024, 65_536));
        let huge = vec![Record {
            offset: 0,
            timestamp: 0,
            key: None,
            value: Some(Bytes::from(vec![0u8; 200_000])),
            headers: vec![],
        }];
        assert_eq!(
            Records::estimate_size_in_bytes(Compression::Snappy, &huge).unwrap(),
            65_536
        );
    }

    #[test]
    fn has_matching_magic_matches_java_abstract_records() {
        assert!(Records::has_matching_magic(
            &[],
            RecordBatch::CURRENT_MAGIC_VALUE
        ));
        assert!(Records::has_matching_magic(&[], 0));
        assert!(Records::first_batch(&[]).is_none());
        assert!(Records::last_batch(&[]).is_none());

        let first = RecordBatch::from_records(vec![Record {
            offset: 0,
            timestamp: 1,
            key: None,
            value: Some(Bytes::from_static(b"a")),
            headers: vec![],
        }]);
        let mut second = RecordBatch::from_records(vec![Record {
            offset: 0,
            timestamp: 2,
            key: None,
            value: Some(Bytes::from_static(b"b")),
            headers: vec![],
        }]);
        second.base_offset = 10;
        let batches = [first, second];
        assert!(Records::has_matching_magic(
            &batches,
            RecordBatch::CURRENT_MAGIC_VALUE
        ));
        assert!(!Records::has_matching_magic(&batches, 0));
        assert_eq!(
            Records::first_batch(&batches).map(RecordBatch::base_offset),
            Some(0)
        );
        assert_eq!(
            Records::last_batch(&batches).map(RecordBatch::base_offset),
            Some(10)
        );
        assert_eq!(
            Records::first_batch(std::slice::from_ref(&batches[0])).map(RecordBatch::base_offset),
            Some(0)
        );
        assert_eq!(
            Records::last_batch(std::slice::from_ref(&batches[0])).map(RecordBatch::base_offset),
            Some(0)
        );
    }

    #[test]
    fn first_batch_size_matches_java_memory_records() {
        assert_eq!(Records::first_batch_size(&[]).unwrap(), None);
        assert_eq!(Records::first_batch_size(&[0; 16]).unwrap(), None);
        let mut almost = [0u8; 16];
        put_batch_length(&mut almost, 1i32);
        assert_eq!(Records::first_batch_size(&almost).unwrap(), None);

        let mut buf = [0u8; 17];
        put_batch_length(&mut buf, 14i32);
        put_magic(&mut buf, 2);
        assert_eq!(Records::first_batch_size(&buf).unwrap(), Some(26));
        put_magic(&mut buf, 0);
        assert_eq!(Records::first_batch_size(&buf).unwrap(), Some(26));

        let mut small = [0u8; 17];
        put_batch_length(&mut small, 13i32);
        put_magic(&mut small, 2);
        let err = Records::first_batch_size(&small).unwrap_err().to_string();
        assert!(
            err.contains("Record size 13 is less than the minimum record overhead (14)"),
            "{err}"
        );

        let mut neg = [0u8; 17];
        put_batch_length(&mut neg, -1i32);
        let err = Records::first_batch_size(&neg).unwrap_err().to_string();
        assert!(
            err.contains("Record size -1 is less than the minimum record overhead (14)"),
            "{err}"
        );

        let mut min = [0u8; 17];
        put_batch_length(&mut min, i32::MIN);
        let err = Records::first_batch_size(&min).unwrap_err().to_string();
        assert!(
            err.contains("Record size -2147483648 is less than the minimum record overhead (14)"),
            "{err}"
        );

        let mut bad_magic = [0u8; 17];
        put_batch_length(&mut bad_magic, 14i32);
        put_magic(&mut bad_magic, 3);
        let err = Records::first_batch_size(&bad_magic)
            .unwrap_err()
            .to_string();
        assert!(err.contains("Invalid magic found in record: 3"), "{err}");

        let mut signed_magic = [0u8; 17];
        put_batch_length(&mut signed_magic, 14i32);
        put_magic(&mut signed_magic, 0xff);
        let err = Records::first_batch_size(&signed_magic)
            .unwrap_err()
            .to_string();
        assert!(err.contains("Invalid magic found in record: -1"), "{err}");

        let batch = RecordBatch::from_records(vec![Record {
            offset: 0,
            timestamp: 1,
            key: None,
            value: Some(Bytes::from_static(b"a")),
            headers: vec![],
        }]);
        let mut encoded = BytesMut::new();
        encode_record_batch(&mut encoded, &batch).unwrap();
        let encoded_len = i32::try_from(encoded.len()).unwrap();
        assert_eq!(
            Records::first_batch_size(&encoded).unwrap(),
            Some(encoded_len)
        );
        assert_eq!(encoded_len, batch.size_in_bytes().unwrap());
        assert_eq!(Records::valid_bytes(&encoded).unwrap(), encoded_len);
    }

    #[test]
    fn valid_bytes_matches_java_memory_records() {
        assert_eq!(Records::valid_bytes(&[]).unwrap(), 0);
        assert_eq!(Records::valid_bytes(&[0; 11]).unwrap(), 0);

        let err = Records::valid_bytes(&[0; 16]).unwrap_err().to_string();
        assert!(
            err.contains("Record size 0 is less than the minimum record overhead (14)"),
            "{err}"
        );

        let mut almost = [0u8; 16];
        put_batch_length(&mut almost, 1i32);
        let err = Records::valid_bytes(&almost).unwrap_err().to_string();
        assert!(
            err.contains("Record size 1 is less than the minimum record overhead (14)"),
            "{err}"
        );
        assert!(Records::first_batch_size(&almost).unwrap().is_none());

        let batch = RecordBatch::from_records(vec![Record {
            offset: 0,
            timestamp: 1,
            key: None,
            value: Some(Bytes::from_static(b"a")),
            headers: vec![],
        }]);
        let mut encoded = BytesMut::new();
        encode_record_batch(&mut encoded, &batch).unwrap();
        let encoded_len = i32::try_from(encoded.len()).unwrap();

        let mut truncated = encoded.to_vec();
        truncated.extend_from_slice(&[0u8; 11]);
        assert_eq!(Records::valid_bytes(&truncated).unwrap(), encoded_len);

        let mut two = encoded.clone();
        two.extend_from_slice(&encoded);
        assert_eq!(
            Records::valid_bytes(&two).unwrap(),
            encoded_len.wrapping_mul(2)
        );

        let mut tail_corrupt = encoded.to_vec();
        let mut almost = [0u8; 16];
        put_batch_length(&mut almost, 1i32);
        tail_corrupt.extend_from_slice(&almost);
        let err = Records::valid_bytes(&tail_corrupt).unwrap_err().to_string();
        assert!(
            err.contains("Record size 1 is less than the minimum record overhead (14)"),
            "{err}"
        );

        let err = next_batch_size(&[0u8; 17], 10).unwrap_err().to_string();
        assert!(
            err.contains("Record size 0 is less than the minimum record overhead (14)"),
            "{err}"
        );
        let mut over = [0u8; 17];
        put_batch_length(&mut over, 20i32);
        put_magic(&mut over, 2);
        let err = next_batch_size(&over, 19).unwrap_err().to_string();
        assert!(
            err.contains("Record size 20 exceeds the largest allowable message size (19)."),
            "{err}"
        );
        assert_eq!(next_batch_size(&over, 20).unwrap(), Some(32));
        let mut header_only = [0u8; 12];
        put_batch_length(&mut header_only, 14i32);
        assert_eq!(next_batch_size(&header_only, 20).unwrap(), None);
        let err = next_batch_size(&[0; 12], 20).unwrap_err().to_string();
        assert!(
            err.contains("Record size 0 is less than the minimum record overhead (14)"),
            "{err}"
        );
    }

    #[test]
    fn gzip_bounded_decompression_and_bomb() {
        let payload = vec![0x42u8; 2048];
        let compressed = Compression::Gzip.codec_compress(&payload).unwrap();

        // Exactly at limit succeeds
        let decomp = gzip_decompress(&compressed, 2048).unwrap();
        assert_eq!(decomp, payload);

        // One-over limit fails
        let err = gzip_decompress(&compressed, 2047).unwrap_err().to_string();
        assert!(
            err.contains("Decompressed batch exceeds maximum allowable size"),
            "{err}"
        );

        // Gzip bomb (500 KB zeroes compressed) with a 10 KB limit
        let bomb_payload = vec![0u8; 500 * 1024];
        let bomb_compressed = Compression::Gzip.codec_compress(&bomb_payload).unwrap();
        let bomb_err = gzip_decompress(&bomb_compressed, 10 * 1024)
            .unwrap_err()
            .to_string();
        assert!(
            bomb_err.contains("Decompressed batch exceeds maximum allowable size"),
            "{bomb_err}"
        );

        // Truncated gzip stream fails with corruption/EOF error, not expansion limit error
        let truncated = &compressed[..compressed.len() / 2];
        let trunc_err = gzip_decompress(truncated, 2048).unwrap_err().to_string();
        assert!(
            !trunc_err.contains("Decompressed batch exceeds maximum allowable size"),
            "{trunc_err}"
        );
    }

    #[test]
    fn snappy_raw_and_framed_bounded_decompression_and_bomb() {
        let payload = vec![0x37u8; 2048];

        // 1. Raw snappy
        let raw_compressed = snap::raw::Encoder::new().compress_vec(&payload).unwrap();

        // Raw: exactly at limit succeeds
        let raw_decomp = snappy_decompress(&raw_compressed, 2048).unwrap();
        assert_eq!(raw_decomp, payload);

        // Raw: one-over limit fails
        let err = snappy_decompress(&raw_compressed, 2047)
            .unwrap_err()
            .to_string();
        assert!(
            err.contains("Decompressed batch exceeds maximum allowable size"),
            "{err}"
        );

        // Raw: bomb claiming 100 MB uncompressed via varint header with 10 KB limit
        // 100_000_000 = 0x05F5E100 -> varint: [0x80, 0xC2, 0xD7, 0x2F]
        let raw_bomb = [0x80, 0xC2, 0xD7, 0x2F, 0x00, 0x00];
        let raw_bomb_err = snappy_decompress(&raw_bomb, 10 * 1024)
            .unwrap_err()
            .to_string();
        assert!(
            raw_bomb_err.contains("Decompressed batch exceeds maximum allowable size"),
            "{raw_bomb_err}"
        );

        // 2. Framed snappy (snappy-java format)
        let framed = Compression::Snappy.codec_compress(&payload).unwrap();

        // Framed: exactly at limit succeeds
        let framed_decomp = snappy_decompress(&framed, 2048).unwrap();
        assert_eq!(framed_decomp, payload);

        // Framed: one-over limit fails
        let err = snappy_decompress(&framed, 2047).unwrap_err().to_string();
        assert!(
            err.contains("Decompressed batch exceeds maximum allowable size"),
            "{err}"
        );

        // Framed: bomb chunk claiming 100 MB
        let mut framed_bomb = Vec::new();
        framed_bomb.extend_from_slice(SNAPPY_JAVA_MAGIC);
        framed_bomb.extend_from_slice(&1u32.to_be_bytes());
        framed_bomb.extend_from_slice(&1u32.to_be_bytes());
        let chunk_block = [0x80, 0xC2, 0xD7, 0x2F, 0x00, 0x00];
        let clen = buf::u32_from_usize(chunk_block.len()).unwrap();
        framed_bomb.extend_from_slice(&clen.to_be_bytes());
        framed_bomb.extend_from_slice(&chunk_block);
        let framed_bomb_err = snappy_decompress(&framed_bomb, 10 * 1024)
            .unwrap_err()
            .to_string();
        assert!(
            framed_bomb_err.contains("Decompressed batch exceeds maximum allowable size"),
            "{framed_bomb_err}"
        );

        // Framed: truncated chunk fails with short chunk error, not expansion error
        let truncated_framed = &framed[..framed.len() - 5];
        let trunc_err = snappy_decompress(truncated_framed, 2048)
            .unwrap_err()
            .to_string();
        assert!(
            !trunc_err.contains("Decompressed batch exceeds maximum allowable size"),
            "{trunc_err}"
        );
    }

    #[test]
    fn lz4_bounded_decompression_and_bomb() {
        let payload = vec![0x5au8; 2048];
        let compressed = Compression::Lz4.codec_compress(&payload).unwrap();

        // Exactly at limit succeeds
        let decomp = lz4_decompress(&compressed, 2048).unwrap();
        assert_eq!(decomp, payload);

        // One-over limit fails
        let err = lz4_decompress(&compressed, 2047).unwrap_err().to_string();
        assert!(
            err.contains("Decompressed batch exceeds maximum allowable size"),
            "{err}"
        );

        // LZ4 frame declaring 100 MB content_size with 10 KB limit
        use lz4_flex::frame::{BlockMode, BlockSize, FrameEncoder, FrameInfo};
        let bomb_info = FrameInfo::new()
            .block_mode(BlockMode::Independent)
            .block_size(BlockSize::Max64KB)
            .content_size(Some(13));
        let mut enc = FrameEncoder::with_frame_info(bomb_info, Vec::new());
        enc.write_all(b"short-payload").unwrap();
        let mut bomb_framed = enc.finish().unwrap();
        // Tamper content_size in frame header (bytes 6..14) to claim 100 MB
        bomb_framed[6..14].copy_from_slice(&(100u64 * 1024 * 1024).to_le_bytes());
        let bomb_err = lz4_decompress(&bomb_framed, 10 * 1024)
            .unwrap_err()
            .to_string();
        assert!(
            bomb_err.contains("Decompressed batch exceeds maximum allowable size"),
            "{bomb_err}"
        );

        // LZ4 frame without content_size expanding past limit
        let no_size_info = FrameInfo::new()
            .block_mode(BlockMode::Independent)
            .block_size(BlockSize::Max64KB)
            .content_size(None);
        let mut enc_large = FrameEncoder::with_frame_info(no_size_info, Vec::new());
        enc_large.write_all(&vec![0u8; 100 * 1024]).unwrap();
        let large_framed = enc_large.finish().unwrap();
        let large_err = lz4_decompress(&large_framed, 10 * 1024)
            .unwrap_err()
            .to_string();
        assert!(
            large_err.contains("Decompressed batch exceeds maximum allowable size"),
            "{large_err}"
        );

        // Truncated LZ4 stream fails with truncation error, not expansion error
        let truncated = &compressed[..compressed.len() / 2];
        let trunc_err = lz4_decompress(truncated, 2048).unwrap_err().to_string();
        assert!(
            !trunc_err.contains("Decompressed batch exceeds maximum allowable size"),
            "{trunc_err}"
        );
    }

    #[test]
    fn record_batch_decode_with_limit_and_crc() {
        for compression in [
            Compression::None,
            Compression::Gzip,
            Compression::Snappy,
            Compression::Lz4,
        ] {
            let rec = Record {
                offset: 0,
                timestamp: 10,
                key: Some(Bytes::from_static(b"test-key")),
                value: Some(Bytes::from(vec![0x42u8; 512])),
                headers: vec![],
            };
            let batch = RecordBatch::from_records(vec![rec]).with_compression(compression);
            let mut buf = BytesMut::new();
            encode_record_batch(&mut buf, &batch).unwrap();

            // Decode with default limit succeeds
            let decoded_default = decode_record_batches(&mut &buf[..]).unwrap();
            assert_eq!(decoded_default.len(), 1);
            assert_eq!(
                decoded_default[0].records[0].value.as_deref(),
                Some(&vec![0x42u8; 512][..])
            );

            // Decode with large explicit limit succeeds
            let decoded_explicit =
                decode_record_batch_with_limit(&mut &buf[..], 64 * 1024 * 1024).unwrap();
            assert_eq!(
                decoded_explicit.records[0].value.as_deref(),
                Some(&vec![0x42u8; 512][..])
            );

            // Decode with tiny limit fails if compressed
            if compression != Compression::None {
                let err = decode_record_batch_with_limit(&mut &buf[..], 10)
                    .unwrap_err()
                    .to_string();
                assert!(
                    err.contains("Decompressed batch exceeds maximum allowable size"),
                    "compression {compression}: {err}"
                );
            }

            // CRC corruption fails with CRC error, NOT expansion error
            let mut corrupted = buf.clone();
            let attr = RecordBatch::CRC_OFFSET as usize + 4;
            corrupted[attr] ^= 0xff;
            let crc_err = decode_record_batch_with_limit(&mut &corrupted[..], 10)
                .unwrap_err()
                .to_string();
            assert!(
                crc_err.contains("Record is corrupt (stored crc ="),
                "expected CRC error for {compression}, got: {crc_err}"
            );
        }
    }
}
