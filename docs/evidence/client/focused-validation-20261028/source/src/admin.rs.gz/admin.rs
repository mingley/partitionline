//! Kafka admin client: topics, configs, ACLs, groups, and cluster operations.
//!
//! [`Admin::connect`] / [`Admin::new`] negotiate ApiVersions. Methods that
//! must land on the controller retry on `NOT_CONTROLLER`. Group and
//! transaction methods retry on coordinator errors.

use std::cmp::Ordering;
use std::collections::{HashMap, HashSet, VecDeque};
use std::fmt;
use std::future::Future;
use std::pin::Pin;
use std::sync::Arc;
use std::time::{Duration, Instant};

mod offsets;
use offsets::AdminOffsetConn;
mod streams;
pub use streams::{DescribeStreamsGroupsOptions, StreamsGroupDescription};

use bytes::{Bytes, BytesMut};

use crate::cluster::{Cluster, LeaderList};
use crate::error::{self, Error, Result};
use crate::net::{BrokerConn, TlsConfig};
use crate::protocol::acl::{
    decode_create_acls_response_cooperative, decode_delete_acls_filter_results_cooperative,
    decode_describe_acls_response_cooperative, encode_create_acls_request_cooperative,
    encode_delete_acls_request_cooperative, encode_describe_acls_request,
};
use crate::protocol::admin::{
    decode_allocate_producer_ids_response, decode_alter_client_quotas_response_cooperative,
    decode_alter_configs_resource_results_cooperative,
    decode_alter_partition_reassignments_response_data,
    decode_alter_replica_log_dirs_response_cooperative,
    decode_alter_share_group_offsets_response_cooperative,
    decode_alter_user_scram_credentials_response_cooperative,
    decode_assign_replicas_to_dirs_response, decode_consumer_group_describe_response_cooperative,
    decode_create_delegation_token_response, decode_create_partitions_response_cooperative,
    decode_create_topics_response_cooperative, decode_delete_groups_response_cooperative,
    decode_delete_records_topics_response_cooperative,
    decode_delete_share_group_offsets_response_cooperative,
    decode_delete_topics_response_cooperative, decode_describe_client_quotas_response_cooperative,
    decode_describe_cluster_response_cooperative, decode_describe_configs_response_cooperative,
    decode_describe_delegation_token_response_cooperative,
    decode_describe_groups_response_cooperative, decode_describe_log_dirs_response_cooperative,
    decode_describe_producers_response_cooperative,
    decode_describe_share_group_offsets_response_versioned_cooperative,
    decode_describe_topic_partitions_response_cooperative,
    decode_describe_transactions_response_cooperative,
    decode_describe_user_scram_credentials_response_cooperative,
    decode_expire_delegation_token_response,
    decode_get_telemetry_subscriptions_response_cooperative,
    decode_incremental_alter_configs_resource_results_cooperative,
    decode_list_config_resources_response_cooperative, decode_list_groups_response_cooperative,
    decode_list_partition_reassignments_response_cooperative, decode_list_transactions_response,
    decode_push_telemetry_response, decode_renew_delegation_token_response,
    decode_share_group_describe_response_cooperative, decode_unregister_broker_response,
    decode_update_features_response_cooperative, encode_allocate_producer_ids_request,
    encode_alter_client_quotas_request_cooperative, encode_alter_configs_named_cooperative,
    encode_alter_partition_reassignments_named, encode_alter_replica_log_dirs_named_cooperative,
    encode_alter_replica_log_dirs_request_cooperative,
    encode_alter_share_group_offsets_request_cooperative,
    encode_alter_user_scram_credentials_named_cooperative, encode_assign_replicas_to_dirs_request,
    encode_consumer_group_describe_ids_cooperative,
    encode_create_delegation_token_request_cooperative, encode_create_partitions_named_cooperative,
    encode_create_topics_named_cooperative, encode_delete_groups_ids_cooperative,
    encode_delete_records_named_topics_cooperative, encode_delete_records_owned_topics_cooperative,
    encode_delete_share_group_offsets_request_cooperative, encode_delete_topic_list_cooperative,
    encode_describe_client_quotas_request_cooperative, encode_describe_cluster_request,
    encode_describe_configs_named_cooperative,
    encode_describe_delegation_token_request_cooperative, encode_describe_groups_ids_cooperative,
    encode_describe_log_dirs_named, encode_describe_log_dirs_named_cooperative,
    encode_describe_log_dirs_request, encode_describe_producers_named_topics_cooperative,
    encode_describe_share_group_offsets_request_refs_cooperative,
    encode_describe_topic_partitions_names_cooperative,
    encode_describe_transactions_ids_cooperative,
    encode_describe_user_scram_credentials_ids_cooperative, encode_expire_delegation_token_hmac,
    encode_expire_delegation_token_request, encode_get_telemetry_subscriptions_request,
    encode_incremental_alter_configs_named_cooperative, encode_list_config_resources_request,
    encode_list_groups_filters_cooperative, encode_list_partition_reassignments_named_cooperative,
    encode_list_transactions_states, encode_push_telemetry_metrics,
    encode_renew_delegation_token_hmac, encode_renew_delegation_token_request,
    encode_share_group_describe_ids_cooperative, encode_unregister_broker_request,
    encode_update_features_named_cooperative, AlterConfigsResource, BorrowedAlterConfig,
    BorrowedAlterConfigsResource, BorrowedAlterReplicaLogDir, BorrowedAlterReplicaLogDirTopic,
    BorrowedAlterableResource, BorrowedCreatableTopic, BorrowedCreatePartitionsTopic,
    BorrowedDeleteTopic, BorrowedDescribeConfigsResource, BorrowedFeatureUpdate,
    BorrowedReassignmentPartition, BorrowedReplicaAssignment, BorrowedScramDeletion,
    BorrowedScramUpsertion, BorrowedTopicConfig, CreateTopicsRequest, DeleteRecordsPartition,
    DeleteTopicView, DescribeConfigsResult, TopicResult, RESOURCE_BROKER, RESOURCE_BROKER_LOGGER,
    RESOURCE_CLIENT_METRICS, RESOURCE_GROUP, RESOURCE_TOPIC,
};
use crate::protocol::api::{
    decode_api_versions_response, decode_metadata_response,
    decode_metadata_response_into_cooperative, encode_api_versions_request,
    encode_metadata_request_named_cooperative, encode_metadata_request_ref_cooperative,
    encode_metadata_request_topics, encode_metadata_request_topics_cooperative, ApiVersion,
    ApiVersionsResponse, MetadataRequestTopic, MetadataResponse,
};
use crate::protocol::api_keys::{
    pick_version, ALLOCATE_PRODUCER_IDS, ALTER_CLIENT_QUOTAS, ALTER_CONFIGS,
    ALTER_PARTITION_REASSIGNMENTS, ALTER_REPLICA_LOG_DIRS, ALTER_SHARE_GROUP_OFFSETS,
    ALTER_USER_SCRAM_CREDENTIALS, API_VERSIONS, ASSIGN_REPLICAS_TO_DIRS, CONSUMER_GROUP_DESCRIBE,
    CREATE_ACLS, CREATE_DELEGATION_TOKEN, CREATE_PARTITIONS, CREATE_TOPICS, DELETE_ACLS,
    DELETE_GROUPS, DELETE_RECORDS, DELETE_SHARE_GROUP_OFFSETS, DELETE_TOPICS, DESCRIBE_ACLS,
    DESCRIBE_CLIENT_QUOTAS, DESCRIBE_CLUSTER, DESCRIBE_CONFIGS, DESCRIBE_DELEGATION_TOKEN,
    DESCRIBE_GROUPS, DESCRIBE_LOG_DIRS, DESCRIBE_PRODUCERS, DESCRIBE_SHARE_GROUP_OFFSETS,
    DESCRIBE_TOPIC_PARTITIONS, DESCRIBE_TRANSACTIONS, DESCRIBE_USER_SCRAM_CREDENTIALS,
    EXPIRE_DELEGATION_TOKEN, FIND_COORDINATOR, GET_TELEMETRY_SUBSCRIPTIONS,
    INCREMENTAL_ALTER_CONFIGS, INIT_PRODUCER_ID, LEAVE_GROUP, LIST_CONFIG_RESOURCES, LIST_GROUPS,
    LIST_OFFSETS, LIST_PARTITION_REASSIGNMENTS, LIST_TRANSACTIONS, METADATA, OFFSET_COMMIT,
    OFFSET_DELETE, OFFSET_FETCH, PUSH_TELEMETRY, RENEW_DELEGATION_TOKEN, SHARE_GROUP_DESCRIBE,
    UNREGISTER_BROKER, UPDATE_FEATURES, WRITE_TXN_MARKERS,
};
use crate::protocol::group::{
    decode_find_coordinator_response, decode_find_coordinator_response_coordinators_cooperative,
    decode_leave_group_response_version_cooperative, decode_offset_commit_response_cooperative,
    decode_offset_delete_response_cooperative, decode_offset_fetch_groups_response_cooperative,
    decode_offset_fetch_response_cooperative, encode_find_coordinator_request_keys_cooperative,
    encode_find_coordinator_request_typed, encode_leave_group_request_members_cooperative,
    encode_offset_commit_named_cooperative, encode_offset_delete_named_topics_cooperative,
    encode_offset_fetch_groups_named, encode_offset_fetch_groups_named_cooperative,
    encode_offset_fetch_named_cooperative, BorrowedOffsetFetchRequestGroup, LeaveGroupMember,
    COORDINATOR_GROUP, COORDINATOR_TRANSACTION, DEFAULT_RETENTION_TIME,
};
use crate::protocol::idem::{decode_init_producer_id_response, encode_init_producer_id_request};
use crate::protocol::offsets::{
    decode_list_offsets_topics_response_cooperative, encode_list_offsets_named_topics_cooperative,
    ListOffsetsPartitionRequest, ListOffsetsResponsePartition, ListOffsetsTopicRequest,
};
use crate::protocol::sasl;
use crate::protocol::txn::{
    decode_write_txn_markers_response_cooperative, encode_write_txn_markers_named,
    BorrowedTxnMarker, BorrowedTxnMarkerTopic, TransactionResult,
};
use crate::TopicPartition;

pub use crate::protocol::acl::{
    AccessControlEntry, AccessControlEntryFilter, AclBinding, AclBindingFilter, AclCreationResult,
    AclOperation, AclPatternType, AclPermission, AclResourceType, DeleteAclsMatchingAcl,
    DeletedAclsFilterResult, ResourcePattern, ResourcePatternFilter,
};
pub use crate::protocol::admin::{
    ActiveProducer, AlterConfig, AlterConfigOp, AlterConfigOpType, AlterConfigsResourceResult,
    AlterReplicaLogDirsDirectory, AlterReplicaLogDirsRequest, AlterReplicaLogDirsResponse,
    AlterReplicaLogDirsResponsePartition, AlterReplicaLogDirsResponseTopic,
    AlterReplicaLogDirsTopic, AlterShareGroupOffsetsPartition, AlterShareGroupOffsetsTopic,
    AlteredShareGroupOffsets, AlteredShareGroupOffsetsPartition, AlteredShareGroupOffsetsTopic,
    AssignReplicasToDirsDirectory, AssignReplicasToDirsPartition, AssignReplicasToDirsRequest,
    AssignReplicasToDirsResponse, AssignReplicasToDirsResponseDirectory,
    AssignReplicasToDirsResponsePartition, AssignReplicasToDirsResponseTopic,
    AssignReplicasToDirsTopic, ClientQuotaAlteration, ClientQuotaAlterationResult,
    ClientQuotaEntity, ClientQuotaEntry, ClientQuotaFilter, ClientQuotaFilterComponent,
    ClientQuotaOp, ClientQuotaValue, ClusterDescription, ClusterResource, Config, ConfigEntry,
    ConfigSource, ConfigSynonym, ConfigType, ConsumerGroupAssignment, ConsumerGroupMember,
    ConsumerGroupTopicPartitions, CreatableRenewer, CreateDelegationTokenRequest,
    CreateDelegationTokenResponse, DeletableGroupResult, DeleteShareGroupOffsetsTopic,
    DeletedShareGroupOffsets, DeletedShareGroupOffsetsTopic, DescribableLogDirTopic,
    DescribeClusterBroker, DescribeDelegationTokenOwner, DescribeDelegationTokenRequest,
    DescribeDelegationTokenResponse, DescribeLogDirsPartition, DescribeLogDirsRequest,
    DescribeLogDirsResponse, DescribeLogDirsResult, DescribeLogDirsTopic,
    DescribeProducersPartition, DescribeProducersTopic, DescribeShareGroupOffsetsGroup,
    DescribeShareGroupOffsetsTopic, DescribeTopicPartitionsResponse,
    DescribeUserScramCredentialsResult, DescribedConsumerGroup, DescribedDelegationToken,
    DescribedDelegationTokenRenewer, DescribedGroup, DescribedGroupMember, DescribedShareGroup,
    DescribedShareGroupOffsets, DescribedShareGroupOffsetsPartition,
    DescribedShareGroupOffsetsPartitionWithLag, DescribedShareGroupOffsetsTopic,
    DescribedShareGroupOffsetsTopicWithLag, DescribedShareGroupOffsetsWithLag,
    DescribedTopicPartition, DescribedTopicPartitions, ElectLeadersPartitionResult,
    ElectLeadersResponse, ElectLeadersResult, ElectLeadersTopic, EndpointType,
    ExpireDelegationTokenRequest, ExpireDelegationTokenResponse, GetTelemetrySubscriptionsResponse,
    GroupState, GroupType, ListedConfigResource, ListedGroup, Node, PushTelemetryRequest,
    PushTelemetryResponse, RenewDelegationTokenRequest, RenewDelegationTokenResponse,
    ScramCredentialInfo, ScramMechanism, ShareGroupAssignment, ShareGroupMember,
    ShareGroupTopicPartitions, TopicPartitionCursor, TopicPartitionInfo, TransactionListing,
    TransactionState, TransactionTopic, UnregisterBrokerResponse, UpgradeType, ALTER_CONFIG_APPEND,
    ALTER_CONFIG_DELETE, ALTER_CONFIG_SET, ALTER_CONFIG_SUBTRACT, AUTHORIZED_OPERATIONS_OMITTED,
    CONFIG_SOURCE_DEFAULT, CONFIG_SOURCE_DYNAMIC_BROKER, CONFIG_SOURCE_DYNAMIC_BROKER_LOGGER,
    CONFIG_SOURCE_DYNAMIC_CLIENT_METRICS, CONFIG_SOURCE_DYNAMIC_DEFAULT_BROKER,
    CONFIG_SOURCE_DYNAMIC_GROUP, CONFIG_SOURCE_DYNAMIC_TOPIC, CONFIG_SOURCE_STATIC_BROKER,
    CONFIG_SOURCE_UNKNOWN, CONFIG_TYPE_BOOLEAN, CONFIG_TYPE_CLASS, CONFIG_TYPE_DOUBLE,
    CONFIG_TYPE_INT, CONFIG_TYPE_LIST, CONFIG_TYPE_LONG, CONFIG_TYPE_PASSWORD, CONFIG_TYPE_SHORT,
    CONFIG_TYPE_STRING, CONFIG_TYPE_UNKNOWN, ENDPOINT_TYPE_BROKERS, ENDPOINT_TYPE_CONTROLLERS,
    INVALID_OFFSET_LAG, QUOTA_MATCH_ANY, QUOTA_MATCH_DEFAULT, QUOTA_MATCH_EXACT,
    RESOURCE_BROKER as CONFIG_RESOURCE_BROKER,
    RESOURCE_BROKER_LOGGER as CONFIG_RESOURCE_BROKER_LOGGER,
    RESOURCE_CLIENT_METRICS as CONFIG_RESOURCE_CLIENT_METRICS,
    RESOURCE_GROUP as CONFIG_RESOURCE_GROUP, RESOURCE_TOPIC as CONFIG_RESOURCE_TOPIC,
    SCRAM_SHA_256, SCRAM_SHA_512, SCRAM_UNKNOWN, UNKNOWN_VOLUME_BYTES, UPGRADE_TYPE_SAFE_DOWNGRADE,
    UPGRADE_TYPE_UNSAFE_DOWNGRADE, UPGRADE_TYPE_UPGRADE,
};
pub use crate::protocol::admin::{
    AddRaftVoterResponse, RaftVoterAcknowledgement, RaftVoterEndpoint, RemoveRaftVoterResponse,
};
pub use crate::protocol::admin::{
    DescribeQuorumListener, DescribeQuorumNode, DescribeQuorumReplicaState,
};
pub use crate::protocol::group::OffsetDeleteResult;

/// Metadata quorum state returned by [`Admin::describe_quorum`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct QuorumInfo {
    /// Current leader id, or -1 when unknown.
    pub leader_id: i32,
    /// Current leader epoch.
    pub leader_epoch: i32,
    /// Committed metadata high watermark.
    pub high_watermark: i64,
    /// Voting replicas; unknown timestamps are -1, absent directory IDs zero.
    pub voters: Vec<DescribeQuorumReplicaState>,
    /// Observers, using the same unknown sentinels as voters.
    pub observers: Vec<DescribeQuorumReplicaState>,
    /// Controller node listeners (v2+); empty on older peers.
    pub nodes: Vec<DescribeQuorumNode>,
}

/// Leader-election policy (Apache `ElectionType`, KIP-460).
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum ElectionType {
    /// Elect the preferred replica; supported by ElectLeaders v0 and later.
    #[default]
    Preferred,
    /// Elect a live replica even when it is outside the ISR. This can lose data.
    /// Requires ElectLeaders v1 or later.
    Unclean,
}

impl ElectionType {
    fn wire(self) -> i8 {
        match self {
            Self::Preferred => crate::protocol::admin::ELECTION_PREFERRED,
            Self::Unclean => crate::protocol::admin::ELECTION_UNCLEAN,
        }
    }
}

/// Selection, policy and total deadline for [`Admin::elect_leaders`].
#[derive(Debug, Clone, Default)]
pub struct ElectLeadersOptions {
    /// Preferred or unclean election. Defaults to preferred.
    pub election_type: ElectionType,
    /// `None` selects all partitions; `Some(vec![])` selects no partitions.
    pub partitions: Option<Vec<TopicPartition>>,
    /// Total operation deadline, including discovery, connects and retries.
    /// `None` uses [`AdminConfig::request_timeout`].
    pub timeout: Option<Duration>,
}

/// Expected cluster, acknowledgement policy, and total deadline for
/// [`Admin::add_raft_voter`].
///
/// [`Default`] sets `ack_when_committed` to true. That matches the Apache
/// schema default and is the only mode Java's public `AddRaftVoterOptions`
/// exposes (cluster id only). `false` is a Rust extension.
#[derive(Debug, Clone)]
pub struct AddRaftVoterOptions {
    /// Optional expected cluster identity, checked by the controller.
    pub cluster_id: Option<String>,
    /// Total deadline including discovery, authentication and retries.
    /// `None` uses [`AdminConfig::request_timeout`].
    pub timeout: Option<Duration>,
    /// When true, ask the controller to respond after the new voter set is
    /// committed. When false, require AddRaftVoter v1 and treat success as a
    /// local append, not a committed or voting membership.
    pub ack_when_committed: bool,
}

impl Default for AddRaftVoterOptions {
    fn default() -> Self {
        Self {
            cluster_id: None,
            timeout: None,
            ack_when_committed: true,
        }
    }
}

/// Expected cluster and local total deadline for [`Admin::remove_raft_voter`].
#[derive(Debug, Clone, Default)]
pub struct RemoveRaftVoterOptions {
    /// Optional expected cluster identity, checked by the controller.
    pub cluster_id: Option<String>,
    /// Local total deadline, including discovery, authentication and retries.
    /// `None` uses [`AdminConfig::request_timeout`]. No TimeoutMs is sent.
    pub timeout: Option<Duration>,
}

/// Bootstrap, identity, SASL, and TLS for [`Admin`].
#[derive(Clone)]
pub struct AdminConfig {
    /// Bootstrap brokers, `host:port`.
    pub bootstrap: Vec<String>,
    /// Kafka `client.id`.
    pub client_id: String,
    /// Per-request timeout.
    pub request_timeout: Duration,
    /// TCP connect timeout.
    pub connect_timeout: Duration,
    /// Kafka `reconnect.backoff.ms`. Wait after a failed TCP/TLS/SASL
    /// connect to a broker before the next attempt. Default 50ms (Java).
    /// Zero retries immediately. Grows as `base * 2^n` up to
    /// [`Self::reconnect_backoff_max`].
    pub reconnect_backoff: Duration,
    /// Kafka `reconnect.backoff.max.ms`. Cap on [`Self::reconnect_backoff`]
    /// exponential growth. Default 1s (Java).
    pub reconnect_backoff_max: Duration,
    /// Kafka `connections.max.idle.ms`. Close a broker TCP connection that
    /// has been unused for this long and reconnect on the next RPC. Default
    /// 9 minutes (Java). Zero never closes for idle.
    pub connections_max_idle: Duration,
    /// Kafka `retry.backoff.ms`. Wait after a retriable admin error
    /// (`NOT_CONTROLLER`, coordinator moves, IO) before the next attempt.
    /// Default 100ms (Java / librdkafka). Zero retries immediately.
    /// Grows as `base * 2^n` up to [`Self::retry_backoff_max`]. Distinct
    /// from [`Self::reconnect_backoff`] (TCP/handshake failures).
    pub retry_backoff: Duration,
    /// Kafka `retry.backoff.max.ms`. Cap on [`Self::retry_backoff`]
    /// exponential growth. Default 1s.
    pub retry_backoff_max: Duration,
    /// SASL PLAIN `(username, password)`.
    pub sasl_plain: Option<(String, String)>,
    /// SASL SCRAM-SHA-256 `(username, password)`.
    pub sasl_scram: Option<(String, String)>,
    /// SASL SCRAM-SHA-512 `(username, password)`.
    pub sasl_scram_sha512: Option<(String, String)>,
    /// Unsecured OAUTHBEARER token.
    pub sasl_oauthbearer: Option<String>,
    /// OIDC client-credentials token endpoint.
    pub sasl_oauthbearer_oidc: Option<crate::OidcConfig>,
    /// rustls. No OpenSSL.
    pub tls: Option<TlsConfig>,
}

impl fmt::Debug for AdminConfig {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("AdminConfig")
            .field("bootstrap", &self.bootstrap)
            .field("client_id", &self.client_id)
            .field("request_timeout", &self.request_timeout)
            .field("connect_timeout", &self.connect_timeout)
            .field("reconnect_backoff", &self.reconnect_backoff)
            .field("reconnect_backoff_max", &self.reconnect_backoff_max)
            .field("connections_max_idle", &self.connections_max_idle)
            .field("retry_backoff", &self.retry_backoff)
            .field("retry_backoff_max", &self.retry_backoff_max)
            .field(
                "sasl_plain",
                &crate::config::RedactedUserPass(&self.sasl_plain),
            )
            .field(
                "sasl_scram",
                &crate::config::RedactedUserPass(&self.sasl_scram),
            )
            .field(
                "sasl_scram_sha512",
                &crate::config::RedactedUserPass(&self.sasl_scram_sha512),
            )
            .field("sasl_oauthbearer", &self.sasl_oauthbearer)
            .field("sasl_oauthbearer_oidc", &self.sasl_oauthbearer_oidc)
            .field("tls", &self.tls)
            .finish()
    }
}

impl Default for AdminConfig {
    fn default() -> Self {
        Self {
            bootstrap: vec!["127.0.0.1:9092".into()],
            client_id: "partitionline".into(),
            request_timeout: Duration::from_secs(30),
            connect_timeout: Duration::from_secs(10),
            reconnect_backoff: crate::config::DEFAULT_RECONNECT_BACKOFF,
            reconnect_backoff_max: crate::config::DEFAULT_RECONNECT_BACKOFF_MAX,
            connections_max_idle: crate::config::DEFAULT_CONNECTIONS_MAX_IDLE,
            retry_backoff: crate::config::DEFAULT_RETRY_BACKOFF,
            retry_backoff_max: crate::config::DEFAULT_RETRY_BACKOFF_MAX,
            sasl_plain: None,
            sasl_scram: None,
            sasl_scram_sha512: None,
            sasl_oauthbearer: None,
            sasl_oauthbearer_oidc: None,
            tls: None,
        }
    }
}

impl AdminConfig {
    /// Bootstrap brokers, for example `["127.0.0.1:9092"]`.
    pub fn bootstrap<S: Into<String>>(servers: impl IntoIterator<Item = S>) -> Self {
        Self {
            bootstrap: servers.into_iter().map(Into::into).collect(),
            ..Self::default()
        }
    }

    /// Kafka `client.id`.
    #[must_use]
    pub fn client_id(mut self, id: impl Into<String>) -> Self {
        self.client_id = id.into();
        self
    }

    /// SASL. Replaces any previously set mechanism.
    #[must_use]
    pub fn sasl(mut self, sasl: crate::Sasl) -> Self {
        sasl.apply_to(
            &mut self.sasl_plain,
            &mut self.sasl_scram,
            &mut self.sasl_scram_sha512,
            &mut self.sasl_oauthbearer,
            &mut self.sasl_oauthbearer_oidc,
        );
        self
    }

    /// rustls. No OpenSSL.
    #[must_use]
    pub fn tls(mut self, tls: TlsConfig) -> Self {
        crate::config::apply_tls(&mut self.tls, tls);
        self
    }

    /// Per-request timeout.
    #[must_use]
    pub fn request_timeout(mut self, timeout: Duration) -> Self {
        self.request_timeout = timeout;
        self
    }

    /// TCP connect timeout.
    #[must_use]
    pub fn connect_timeout(mut self, timeout: Duration) -> Self {
        self.connect_timeout = timeout;
        self
    }

    /// Kafka `reconnect.backoff.ms`. Wait after a failed broker connect.
    ///
    /// Default 50ms (Java). Zero retries immediately. Combined with
    /// [`Self::reconnect_backoff_max`] this is exponential (`base * 2^n`),
    /// no jitter.
    #[must_use]
    pub fn reconnect_backoff(mut self, backoff: Duration) -> Self {
        self.reconnect_backoff = backoff;
        self
    }

    /// Kafka `reconnect.backoff.max.ms`. Cap on exponential reconnect waits.
    ///
    /// Default 1s (Java). Raised to [`Self::reconnect_backoff`] when set lower.
    #[must_use]
    pub fn reconnect_backoff_max(mut self, backoff: Duration) -> Self {
        self.reconnect_backoff_max = backoff;
        self
    }

    /// Kafka `connections.max.idle.ms`. Close unused broker TCP connections.
    ///
    /// Default 9 minutes (Java). Zero never closes for idle. The next admin
    /// RPC reconnects.
    #[must_use]
    pub fn connections_max_idle(mut self, idle: Duration) -> Self {
        self.connections_max_idle = idle;
        self
    }

    /// Kafka `retry.backoff.ms`. Wait after a retriable admin error.
    ///
    /// Default 100ms. Zero retries immediately. Combined with
    /// [`Self::retry_backoff_max`] this is exponential (`base * 2^n`),
    /// no jitter. Failed TCP/handshake still uses [`Self::reconnect_backoff`].
    #[must_use]
    pub fn retry_backoff(mut self, backoff: Duration) -> Self {
        self.retry_backoff = backoff;
        self
    }

    /// Kafka `retry.backoff.max.ms`. Cap on exponential admin retry waits.
    ///
    /// Default 1s. Raised to [`Self::retry_backoff`] when set lower.
    #[must_use]
    pub fn retry_backoff_max(mut self, backoff: Duration) -> Self {
        self.retry_backoff_max = backoff;
        self
    }
}

/// Topic to create (`CreateTopics`). Java `NewTopic`.
///
/// [`std::fmt::Display`] is Java `NewTopic.toString`. Negative partition count or
/// replication factor prints `default`. Empty assignments and configs
/// print `null`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NewTopic {
    /// Topic name.
    pub name: String,
    /// Partition count, or `-1` for broker `num.partitions` (KIP-464) or
    /// when `assignments` is set (Java `NewTopic(String, Map)`).
    pub num_partitions: i32,
    /// Replication factor, or `-1` for broker `default.replication.factor`
    /// (KIP-464) or when `assignments` is set (Java `NewTopic(String, Map)`).
    pub replication_factor: i16,
    /// Manual replica assignments `(partition_index, broker_ids)`.
    ///
    /// Empty is Java `NewTopic(String, int, short)` (broker assigns).
    /// Non-empty is Java `NewTopic(String, Map<Integer, List<Integer>>)`.
    pub assignments: Vec<(i32, Vec<i32>)>,
    /// Optional topic configs `(name, value)`.
    pub configs: Vec<(String, Option<String>)>,
}

impl NewTopic {
    /// `name` with partition count and replication factor.
    ///
    /// Assignments are empty; the broker places replicas. `-1` on either
    /// count is Java `Optional.empty()` (KIP-464 broker default).
    pub fn new(name: impl Into<String>, num_partitions: i32, replication_factor: i16) -> Self {
        Self {
            name: name.into(),
            num_partitions,
            replication_factor,
            assignments: Vec::new(),
            configs: Vec::new(),
        }
    }

    /// Java `NewTopic(String, Optional.empty(), Optional.empty())` (KIP-464).
    ///
    /// Sends NumPartitions `-1` and ReplicationFactor `-1` with an empty
    /// Assignments array so the broker uses `num.partitions` /
    /// `default.replication.factor`.
    #[must_use]
    pub fn broker_defaults(name: impl Into<String>) -> Self {
        Self::new(
            name,
            CreateTopicsRequest::NO_NUM_PARTITIONS,
            CreateTopicsRequest::NO_REPLICATION_FACTOR,
        )
    }

    /// Java `NewTopic(String, Map<Integer, List<Integer>>)`.
    ///
    /// `num_partitions` and `replication_factor` are `-1`. Each pair is
    /// partition index → replica broker ids.
    #[must_use]
    pub fn with_assignments<A, B>(name: impl Into<String>, assignments: A) -> Self
    where
        A: IntoIterator<Item = (i32, B)>,
        B: IntoIterator<Item = i32>,
    {
        Self {
            name: name.into(),
            num_partitions: CreateTopicsRequest::NO_NUM_PARTITIONS,
            replication_factor: CreateTopicsRequest::NO_REPLICATION_FACTOR,
            assignments: assignments
                .into_iter()
                .map(|(partition, brokers)| (partition, brokers.into_iter().collect()))
                .collect(),
            configs: Vec::new(),
        }
    }

    /// Topic config `(name, value)`.
    #[must_use]
    pub fn config(mut self, name: impl Into<String>, value: impl Into<String>) -> Self {
        self.configs.push((name.into(), Some(value.into())));
        self
    }

    /// Java `NewTopic.configs(Map)`.
    ///
    /// Replaces any configs set by [`Self::config`]. Each pair is
    /// `(name, value)`.
    #[must_use]
    pub fn configs<I, K, V>(mut self, configs: I) -> Self
    where
        I: IntoIterator<Item = (K, V)>,
        K: Into<String>,
        V: Into<String>,
    {
        self.configs = configs
            .into_iter()
            .map(|(k, v)| (k.into(), Some(v.into())))
            .collect();
        self
    }

    /// Java `NewTopic.name`.
    #[must_use]
    pub fn name(&self) -> &str {
        self.name.as_str()
    }

    /// Java `NewTopic.numPartitions` (`-1` is broker default / assignments).
    #[must_use]
    pub fn num_partitions(&self) -> i32 {
        self.num_partitions
    }

    /// Java `NewTopic.replicationFactor` (`-1` is broker default / assignments).
    #[must_use]
    pub fn replication_factor(&self) -> i16 {
        self.replication_factor
    }

    /// Java `NewTopic.replicasAssignments` (`None` is Java `null`).
    #[must_use]
    pub fn replicas_assignments(&self) -> Option<&[(i32, Vec<i32>)]> {
        if self.assignments.is_empty() {
            None
        } else {
            Some(self.assignments.as_slice())
        }
    }
}

impl fmt::Display for NewTopic {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(name={}, numPartitions=", self.name)?;
        if self.num_partitions < 0 {
            f.write_str("default")?;
        } else {
            write!(f, "{}", self.num_partitions)?;
        }
        f.write_str(", replicationFactor=")?;
        if self.replication_factor < 0 {
            f.write_str("default")?;
        } else {
            write!(f, "{}", self.replication_factor)?;
        }
        f.write_str(", replicasAssignments=")?;
        if self.assignments.is_empty() {
            f.write_str("null")?;
        } else {
            f.write_str("{")?;
            for (i, (partition, brokers)) in self.assignments.iter().enumerate() {
                if i > 0 {
                    f.write_str(", ")?;
                }
                write!(f, "{partition}=")?;
                write_java_int_list(f, brokers)?;
            }
            f.write_str("}")?;
        }
        f.write_str(", configs=")?;
        if self.configs.is_empty() {
            f.write_str("null")?;
        } else {
            f.write_str("{")?;
            for (i, (name, value)) in self.configs.iter().enumerate() {
                if i > 0 {
                    f.write_str(", ")?;
                }
                write!(f, "{name}=")?;
                match value {
                    Some(v) => f.write_str(v)?,
                    None => f.write_str("null")?,
                }
            }
            f.write_str("}")?;
        }
        f.write_str(")")
    }
}

/// Java `RecordsToDelete` for [`Admin::delete_records`].
///
/// Converts to the DeleteRecords Offset INT64: records strictly before
/// this offset are deleted; records at or after it are kept.
/// [`crate::protocol::admin::DeleteRecordsRequest::HIGH_WATERMARK`] is Java
/// `DeleteRecordsRequest.HIGH_WATERMARK` (truncate to the high watermark).
/// [`std::fmt::Display`] is Java `RecordsToDelete.toString`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RecordsToDelete {
    offset: i64,
}

impl RecordsToDelete {
    /// Java `RecordsToDelete.beforeOffset(long)`.
    #[must_use]
    pub const fn before_offset(offset: i64) -> Self {
        Self { offset }
    }

    /// DeleteRecords Offset INT64 (Java `RecordsToDelete.beforeOffset()`).
    #[must_use]
    pub const fn offset(self) -> i64 {
        self.offset
    }
}

impl fmt::Display for RecordsToDelete {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(beforeOffset = {})", self.offset)
    }
}

impl From<RecordsToDelete> for i64 {
    fn from(records: RecordsToDelete) -> Self {
        records.offset
    }
}

/// Java `DeletedRecords` for [`Admin::delete_records`].
///
/// `low_watermark` is Java `lowWatermark()`. `error_code` is the
/// per-partition DeleteRecords ErrorCode (Java surfaces non-zero via
/// the future). [`Self::INVALID_LOW_WATERMARK`] is Java
/// `DeleteRecordsResponse.INVALID_LOW_WATERMARK`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DeletedRecords {
    /// New log start offset after the delete.
    pub low_watermark: i64,
    /// Per-partition ErrorCode (`0` is success).
    pub error_code: i16,
}

impl DeletedRecords {
    /// Java `DeleteRecordsResponse.INVALID_LOW_WATERMARK`.
    pub const INVALID_LOW_WATERMARK: i64 = -1;

    /// Java `DeletedRecords(long)` (`error_code` 0).
    #[must_use]
    pub const fn new(low_watermark: i64) -> Self {
        Self {
            low_watermark,
            error_code: 0,
        }
    }

    /// Low watermark plus per-partition ErrorCode.
    #[must_use]
    pub const fn with_error_code(low_watermark: i64, error_code: i16) -> Self {
        Self {
            low_watermark,
            error_code,
        }
    }

    /// Java `DeletedRecords.lowWatermark`.
    #[must_use]
    pub const fn low_watermark(self) -> i64 {
        self.low_watermark
    }

    /// Per-partition DeleteRecords ErrorCode.
    #[must_use]
    pub const fn error_code(self) -> i16 {
        self.error_code
    }
}

impl From<(i64, i16)> for DeletedRecords {
    fn from((low_watermark, error_code): (i64, i16)) -> Self {
        Self {
            low_watermark,
            error_code,
        }
    }
}

impl From<DeletedRecords> for (i64, i16) {
    fn from(deleted: DeletedRecords) -> Self {
        (deleted.low_watermark, deleted.error_code)
    }
}

/// Kafka `org.apache.kafka.common.Uuid` (16 bytes; `toString` is base64url).
///
/// Wire TopicId / ClientInstanceId stay `[u8; 16]`. [`Self::from_string`] /
/// [`std::fmt::Display`] match Java `fromString` / `toString` (`URL_SAFE` without
/// padding). [`Self::random_uuid`] is Java `randomUuid`. Kafka 4.1 Raft
/// voter APIs are not spoken.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Uuid([u8; 16]);

impl Uuid {
    /// Java `Uuid.ZERO_UUID` (`0, 0`).
    pub const ZERO: Self = Self([0; 16]);

    /// Java `Uuid.ZERO_UUID` ([`Self::ZERO`]).
    pub const ZERO_UUID: Self = Self::ZERO;

    /// Java `Uuid.ONE_UUID` (`0, 1`). Also [`Self::METADATA_TOPIC_ID`].
    pub const ONE: Self = Self([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]);

    /// Java `Uuid.ONE_UUID` ([`Self::ONE`]).
    pub const ONE_UUID: Self = Self::ONE;

    /// Java `Uuid.METADATA_TOPIC_ID` (KRaft metadata topic).
    pub const METADATA_TOPIC_ID: Self = Self::ONE;

    /// Java `Uuid.RESERVED` (`ZERO_UUID`, `ONE_UUID` / `METADATA_TOPIC_ID`).
    ///
    /// [`Self::random_uuid`] never returns these.
    pub const RESERVED: [Self; 2] = [Self::ZERO, Self::ONE];

    /// Wrap a 16-byte Kafka UUID (big-endian most then least).
    #[must_use]
    pub const fn from_bytes(bytes: [u8; 16]) -> Self {
        Self(bytes)
    }

    /// 16-byte Kafka UUID.
    #[must_use]
    pub const fn to_bytes(self) -> [u8; 16] {
        self.0
    }

    /// 16-byte Kafka UUID.
    #[must_use]
    pub const fn as_bytes(&self) -> &[u8; 16] {
        &self.0
    }

    /// Java `Uuid(long, long)` (`mostSignificantBits`, `leastSignificantBits`).
    #[must_use]
    pub fn from_parts(most: i64, least: i64) -> Self {
        let mut bytes = [0u8; 16];
        if let Some(hi) = bytes.first_chunk_mut::<8>() {
            *hi = most.to_be_bytes();
        }
        if let Some(lo) = bytes.last_chunk_mut::<8>() {
            *lo = least.to_be_bytes();
        }
        Self(bytes)
    }

    /// Java `getMostSignificantBits`.
    #[must_use]
    pub fn most_significant_bits(self) -> i64 {
        match self.0.first_chunk::<8>() {
            Some(hi) => i64::from_be_bytes(*hi),
            None => 0,
        }
    }

    /// Java `getLeastSignificantBits`.
    #[must_use]
    pub fn least_significant_bits(self) -> i64 {
        match self.0.last_chunk::<8>() {
            Some(lo) => i64::from_be_bytes(*lo),
            None => 0,
        }
    }

    /// Java `Uuid.fromString` (base64url; optional padding).
    pub fn from_string(s: &str) -> Result<Self> {
        if s.len() > 24 {
            let prefix = s.get(..24).unwrap_or(s);
            return Err(Error::protocol(format!(
                "Input string with prefix `{prefix}` is too long to be decoded as a base64 UUID"
            )));
        }
        let decoded =
            match base64::Engine::decode(&base64::engine::general_purpose::URL_SAFE_NO_PAD, s) {
                Ok(b) => b,
                Err(_) => base64::Engine::decode(&base64::engine::general_purpose::URL_SAFE, s)
                    .map_err(|_| {
                        Error::protocol(format!("Uuid string `{s}` is not a base64url UUID"))
                    })?,
            };
        let n = decoded.len();
        let bytes = <[u8; 16]>::try_from(decoded).map_err(|_| {
            Error::protocol(format!(
                "Input string `{s}` decoded as {n} bytes, which is not equal to the expected 16 bytes of a base64-encoded UUID"
            ))
        })?;
        Ok(Self(bytes))
    }

    /// Java `Uuid.randomUuid` (RFC 4122 variant 2 version 4).
    ///
    /// Never returns [`Self::ZERO`], [`Self::ONE`] /
    /// [`Self::METADATA_TOPIC_ID`], or a UUID whose [`std::fmt::Display`]
    /// (base64url) starts with `-`.
    #[must_use]
    pub fn random_uuid() -> Self {
        loop {
            let uuid = Self::new_type4_uuid();
            if Self::RESERVED.contains(&uuid) || uuid.to_string().starts_with('-') {
                continue;
            }
            return uuid;
        }
    }

    fn new_type4_uuid() -> Self {
        let mut bytes = [0u8; 16];
        loop {
            if getrandom::fill(&mut bytes).is_ok() {
                break;
            }
        }
        if let Some(b6) = bytes.get_mut(6) {
            *b6 = (*b6 & 0x0f) | 0x40;
        }
        if let Some(b8) = bytes.get_mut(8) {
            *b8 = (*b8 & 0x3f) | 0x80;
        }
        Self(bytes)
    }
}

impl fmt::Display for Uuid {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&base64::Engine::encode(
            &base64::engine::general_purpose::URL_SAFE_NO_PAD,
            self.0.as_slice(),
        ))
    }
}

impl From<[u8; 16]> for Uuid {
    fn from(bytes: [u8; 16]) -> Self {
        Self(bytes)
    }
}

impl From<Uuid> for [u8; 16] {
    fn from(id: Uuid) -> Self {
        id.0
    }
}

impl std::str::FromStr for Uuid {
    type Err = Error;

    fn from_str(s: &str) -> Result<Self> {
        Self::from_string(s)
    }
}

impl PartialOrd for Uuid {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for Uuid {
    fn cmp(&self, other: &Self) -> Ordering {
        // Java `Uuid.compareTo` compares the two longs as signed values.
        self.most_significant_bits()
            .cmp(&other.most_significant_bits())
            .then(
                self.least_significant_bits()
                    .cmp(&other.least_significant_bits()),
            )
    }
}

/// Java `org.apache.kafka.common.TopicCollection` (`ofTopicNames` /
/// `ofTopicIds`).
///
/// [`Admin::describe_topics_for`] / [`Admin::delete_topics_for`] dispatch
/// names to DescribeTopicPartitions (Metadata fallback) and ids to
/// Metadata v12+ / DeleteTopics v6. Existing
/// [`Admin::describe_topics_by_id`] / [`Admin::delete_topics_by_id`] keep
/// `&[[u8; 16]]` so `describe_topics_by_id(&[])` still infers.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TopicCollection {
    /// Java `TopicCollection.TopicNameCollection`.
    Names(Vec<String>),
    /// Java `TopicCollection.TopicIdCollection`.
    Ids(Vec<Uuid>),
}

impl TopicCollection {
    /// Java `TopicCollection.ofTopicNames`.
    #[must_use]
    pub fn of_topic_names(names: impl IntoIterator<Item = impl Into<String>>) -> Self {
        Self::Names(names.into_iter().map(Into::into).collect())
    }

    /// Java `TopicCollection.ofTopicIds`.
    ///
    /// `ids` items are [`Uuid`] or `[u8; 16]` ([`From`]). Empty `&[]`
    /// does not infer; use [`Self::Ids`] with `Vec::new` or
    /// `Vec::<Uuid>::new()`.
    #[must_use]
    pub fn of_topic_ids<I, Id>(ids: I) -> Self
    where
        I: IntoIterator<Item = Id>,
        Id: Into<Uuid>,
    {
        Self::Ids(ids.into_iter().map(Into::into).collect())
    }

    /// Java `TopicNameCollection.topicNames` (`None` when this is ids).
    #[must_use]
    pub fn topic_names(&self) -> Option<&[String]> {
        match self {
            Self::Names(names) => Some(names.as_slice()),
            Self::Ids(_) => None,
        }
    }

    /// Java `TopicIdCollection.topicIds` (`None` when this is names).
    #[must_use]
    pub fn topic_ids(&self) -> Option<&[Uuid]> {
        match self {
            Self::Ids(ids) => Some(ids.as_slice()),
            Self::Names(_) => None,
        }
    }
}

/// One topic from [`Admin::list_topics`] (Java `TopicListing`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TopicListing {
    /// Topic name.
    pub name: String,
    /// Topic id (Metadata v10+), or zeros.
    pub topic_id: [u8; 16],
    /// Internal topic (for example `__consumer_offsets`).
    pub is_internal: bool,
}

impl TopicListing {
    /// Topic `name` with optional id and internal flag.
    #[must_use]
    pub fn new(name: impl Into<String>, topic_id: impl Into<[u8; 16]>, is_internal: bool) -> Self {
        Self {
            name: name.into(),
            topic_id: topic_id.into(),
            is_internal,
        }
    }

    /// Java `TopicListing.name`.
    #[must_use]
    pub fn name(&self) -> &str {
        self.name.as_str()
    }

    /// Java `TopicListing.topicId`.
    #[must_use]
    pub fn topic_id(&self) -> Uuid {
        Uuid::from_bytes(self.topic_id)
    }

    /// Java `TopicListing.isInternal`.
    #[must_use]
    pub fn is_internal(&self) -> bool {
        self.is_internal
    }
}

impl fmt::Display for TopicListing {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "(name={}, topicId={}, internal={})",
            self.name,
            Uuid::from_bytes(self.topic_id),
            self.is_internal
        )
    }
}

/// One group from [`Admin::describe_consumer_groups`] (Java
/// `ConsumerGroupDescription`).
///
/// Kafka 4.0 `DescribeConsumerGroupsHandler` sends ConsumerGroupDescribe
/// (api 69) first. Per-group [`crate::error::UNSUPPORTED_VERSION`] (35) or
/// [`crate::error::GROUP_ID_NOT_FOUND`] (69), a broker that does not
/// advertise api 69, or an RPC-level [`Error::Unsupported`], fall back to
/// DescribeGroups (api 15).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ConsumerGroupDescription {
    /// New consumer protocol (KIP-848) via ConsumerGroupDescribe.
    Consumer(DescribedConsumerGroup),
    /// Classic protocol via DescribeGroups.
    Classic(DescribedGroup),
}

impl ConsumerGroupDescription {
    /// Kafka `group.id`.
    #[must_use]
    pub fn group_id(&self) -> &str {
        match self {
            Self::Consumer(g) => g.group_id.as_str(),
            Self::Classic(g) => g.group_id.as_str(),
        }
    }

    /// Kafka error code (`0` is success).
    #[must_use]
    pub fn error_code(&self) -> i16 {
        match self {
            Self::Consumer(g) => g.error_code,
            Self::Classic(g) => g.error_code,
        }
    }

    /// Group state name from the broker.
    #[must_use]
    pub fn group_state(&self) -> &str {
        match self {
            Self::Consumer(g) => g.group_state.as_str(),
            Self::Classic(g) => g.group_state.as_str(),
        }
    }

    /// Bitfield of authorized operations, or [`AUTHORIZED_OPERATIONS_OMITTED`].
    #[must_use]
    pub fn authorized_operations(&self) -> i32 {
        match self {
            Self::Consumer(g) => g.authorized_operations,
            Self::Classic(g) => g.authorized_operations,
        }
    }

    /// `true` when this came from ConsumerGroupDescribe (api 69).
    #[must_use]
    pub fn is_consumer_protocol(&self) -> bool {
        matches!(self, Self::Consumer(_))
    }

    /// Java `ConsumerGroupDescription.isSimpleConsumerGroup`.
    ///
    /// [`DescribeConsumerGroupsHandler`](https://github.com/apache/kafka/blob/4.0.0/clients/src/main/java/org/apache/kafka/clients/admin/internals/DescribeConsumerGroupsHandler.java)
    /// is `false` for api 69 and empty classic `ProtocolType` for api 15.
    #[must_use]
    pub fn is_simple_consumer_group(&self) -> bool {
        match self {
            Self::Consumer(_) => false,
            Self::Classic(g) => g.is_simple_consumer_group(),
        }
    }

    /// Java `ConsumerGroupDescription.partitionAssignor`.
    #[must_use]
    pub fn partition_assignor(&self) -> &str {
        match self {
            Self::Consumer(g) => g.assignor_name(),
            Self::Classic(g) => g.protocol_data(),
        }
    }

    /// Java `ConsumerGroupDescription.type`.
    #[must_use]
    pub fn group_type(&self) -> GroupType {
        match self {
            Self::Consumer(_) => GroupType::Consumer,
            Self::Classic(_) => GroupType::Classic,
        }
    }

    /// Java `ConsumerGroupDescription.groupEpoch` (empty for CLASSIC groups).
    #[must_use]
    pub fn group_epoch(&self) -> Option<i32> {
        match self {
            Self::Consumer(g) => Some(g.group_epoch()),
            Self::Classic(_) => None,
        }
    }

    /// Java `ConsumerGroupDescription.targetAssignmentEpoch` (empty for CLASSIC groups).
    #[must_use]
    pub fn target_assignment_epoch(&self) -> Option<i32> {
        match self {
            Self::Consumer(g) => Some(g.assignment_epoch()),
            Self::Classic(_) => None,
        }
    }
}

/// One topic from [`Admin::describe_topics`] (Java `TopicDescription`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TopicDescription {
    /// Topic name (empty when a TopicId describe returns no name).
    pub name: String,
    /// Topic id (Metadata v10+), or zeros.
    pub topic_id: [u8; 16],
    /// Internal topic.
    pub is_internal: bool,
    /// Per-topic Metadata error (`0` is success).
    pub error_code: i16,
    /// Partitions (empty when [`Self::error_code`] is not `0`).
    pub partitions: Vec<crate::PartitionInfo>,
    /// Topic authorized operations (Metadata v8+), or
    /// [`AUTHORIZED_OPERATIONS_OMITTED`] when not requested.
    pub authorized_operations: i32,
}

impl TopicDescription {
    /// Topic `name` with id, internal flag, error, and partitions.
    #[must_use]
    pub fn new(
        name: impl Into<String>,
        topic_id: impl Into<[u8; 16]>,
        is_internal: bool,
        error_code: i16,
        partitions: Vec<crate::PartitionInfo>,
    ) -> Self {
        Self {
            name: name.into(),
            topic_id: topic_id.into(),
            is_internal,
            error_code,
            partitions,
            authorized_operations: AUTHORIZED_OPERATIONS_OMITTED,
        }
    }

    /// Java `TopicDescription.name`.
    #[must_use]
    pub fn name(&self) -> &str {
        self.name.as_str()
    }

    /// Java `TopicDescription.topicId`.
    #[must_use]
    pub fn topic_id(&self) -> Uuid {
        Uuid::from_bytes(self.topic_id)
    }

    /// Java `TopicDescription.isInternal`.
    #[must_use]
    pub fn is_internal(&self) -> bool {
        self.is_internal
    }

    /// Per-topic Metadata error (`0` is success). Java `TopicDescription`
    /// throws instead of storing this.
    #[must_use]
    pub fn error_code(&self) -> i16 {
        self.error_code
    }

    /// Java `TopicDescription.partitions`.
    #[must_use]
    pub fn partitions(&self) -> &[crate::PartitionInfo] {
        &self.partitions
    }

    /// Java `TopicDescription.authorizedOperations` as the Metadata
    /// bitfield, or [`AUTHORIZED_OPERATIONS_OMITTED`].
    #[must_use]
    pub fn authorized_operations(&self) -> i32 {
        self.authorized_operations
    }
}

impl TopicResult {
    /// Java `CreateTopicsResult.topicId` (KIP-516). Zero when the broker
    /// omitted TopicId (CreateTopics below v7 / DeleteTopics below v6, or
    /// an error).
    #[must_use]
    pub fn topic_id(&self) -> Uuid {
        Uuid::from_bytes(self.topic_id)
    }
}

impl GetTelemetrySubscriptionsResponse {
    /// Java `clientInstanceId` (KIP-714). Wire field stays `[u8; 16]`.
    #[must_use]
    pub fn client_instance_id(&self) -> Uuid {
        Uuid::from_bytes(self.client_instance_id)
    }
}

impl PushTelemetryRequest {
    /// Java `clientInstanceId` (KIP-714). Wire field stays `[u8; 16]`.
    #[must_use]
    pub fn client_instance_id(&self) -> Uuid {
        Uuid::from_bytes(self.client_instance_id)
    }
}

impl AssignReplicasToDirsTopic {
    /// Topic id (KIP-858). Wire field stays `[u8; 16]`.
    #[must_use]
    pub fn topic_id(&self) -> Uuid {
        Uuid::from_bytes(self.topic_id)
    }
}

impl AssignReplicasToDirsDirectory {
    /// Directory id (KIP-858). Wire field stays `[u8; 16]`.
    #[must_use]
    pub fn id(&self) -> Uuid {
        Uuid::from_bytes(self.id)
    }
}

impl AssignReplicasToDirsResponseTopic {
    /// Topic id (KIP-858). Wire field stays `[u8; 16]`.
    #[must_use]
    pub fn topic_id(&self) -> Uuid {
        Uuid::from_bytes(self.topic_id)
    }
}

impl AssignReplicasToDirsResponseDirectory {
    /// Directory id (KIP-858). Wire field stays `[u8; 16]`.
    #[must_use]
    pub fn id(&self) -> Uuid {
        Uuid::from_bytes(self.id)
    }
}

/// One replica: topic, partition, and broker id (Java `TopicPartitionReplica`).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct TopicPartitionReplica {
    /// Topic name.
    pub topic: String,
    /// Partition index.
    pub partition: i32,
    /// Broker that hosts this replica.
    pub broker_id: i32,
}

impl TopicPartitionReplica {
    /// Topic `topic`, partition `partition`, on `broker_id`.
    #[must_use]
    pub fn new(topic: impl Into<String>, partition: i32, broker_id: i32) -> Self {
        Self {
            topic: topic.into(),
            partition,
            broker_id,
        }
    }

    /// Java `TopicPartitionReplica.topic`.
    #[must_use]
    pub fn topic(&self) -> &str {
        self.topic.as_str()
    }

    /// Java `TopicPartitionReplica.partition`.
    #[must_use]
    pub fn partition(&self) -> i32 {
        self.partition
    }

    /// Java `TopicPartitionReplica.brokerId`.
    #[must_use]
    pub fn broker_id(&self) -> i32 {
        self.broker_id
    }
}

impl fmt::Display for TopicPartitionReplica {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}-{}-{}", self.topic, self.partition, self.broker_id)
    }
}

/// Log directory for one replica (Java `ReplicaLogDirInfo`).
///
/// Missing current or future dirs are [`None`]. Unknown lag is `-1`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReplicaLogDirInfo {
    /// Current log directory, when the replica is online there.
    pub current_log_dir: Option<String>,
    /// Offset lag in [`Self::current_log_dir`] (`-1` when unknown).
    pub current_offset_lag: i64,
    /// Future log directory (AlterReplicaLogDirs in progress).
    pub future_log_dir: Option<String>,
    /// Offset lag in [`Self::future_log_dir`] (`-1` when unknown).
    pub future_offset_lag: i64,
}

impl ReplicaLogDirInfo {
    /// Current and future log dirs with their offset lags.
    #[must_use]
    pub fn new(
        current_log_dir: Option<String>,
        current_offset_lag: i64,
        future_log_dir: Option<String>,
        future_offset_lag: i64,
    ) -> Self {
        Self {
            current_log_dir,
            current_offset_lag,
            future_log_dir,
            future_offset_lag,
        }
    }

    /// No dirs known (Java `ReplicaLogDirInfo()`). Lags are `-1`.
    #[must_use]
    pub fn unknown() -> Self {
        Self::new(None, -1, None, -1)
    }

    /// Java `ReplicaLogDirInfo.currentLogDir`.
    #[must_use]
    pub fn current_log_dir(&self) -> Option<&str> {
        self.current_log_dir.as_deref()
    }

    /// Java `ReplicaLogDirInfo.currentOffsetLag`.
    #[must_use]
    pub fn current_offset_lag(&self) -> i64 {
        self.current_offset_lag
    }

    /// Java `ReplicaLogDirInfo.futureLogDir`.
    #[must_use]
    pub fn future_log_dir(&self) -> Option<&str> {
        self.future_log_dir.as_deref()
    }

    /// Java `ReplicaLogDirInfo.futureOffsetLag`.
    #[must_use]
    pub fn future_offset_lag(&self) -> i64 {
        self.future_offset_lag
    }
}

impl fmt::Display for ReplicaLogDirInfo {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.future_log_dir.as_deref() {
            Some(future) => {
                f.write_str("(currentReplicaLogDir=")?;
                write_java_nullable_str(f, self.current_log_dir.as_deref())?;
                f.write_str(", futureReplicaLogDir=")?;
                f.write_str(future)?;
                write!(f, ", futureReplicaOffsetLag={})", self.future_offset_lag)
            }
            None => {
                f.write_str("ReplicaLogDirInfo(currentReplicaLogDir=")?;
                write_java_nullable_str(f, self.current_log_dir.as_deref())?;
                f.write_str(")")
            }
        }
    }
}

fn write_java_nullable_str(f: &mut fmt::Formatter<'_>, s: Option<&str>) -> fmt::Result {
    match s {
        Some(s) => f.write_str(s),
        None => f.write_str("null"),
    }
}

/// Java `List.toString` id list: `[1, 2]` (comma-space).
fn write_java_int_list(f: &mut fmt::Formatter<'_>, ids: &[i32]) -> fmt::Result {
    f.write_str("[")?;
    for (i, id) in ids.iter().enumerate() {
        if i > 0 {
            f.write_str(", ")?;
        }
        write!(f, "{id}")?;
    }
    f.write_str("]")
}

/// Java `FeatureMetadata.mapToString`: `{(name -> range), ...}`.
fn write_java_feature_map<T, N>(f: &mut fmt::Formatter<'_>, items: &[T], name: N) -> fmt::Result
where
    T: fmt::Display,
    N: Fn(&T) -> &str,
{
    f.write_str("{")?;
    for (i, item) in items.iter().enumerate() {
        if i > 0 {
            f.write_str(", ")?;
        }
        f.write_str("(")?;
        f.write_str(name(item))?;
        f.write_str(" -> ")?;
        write!(f, "{item}")?;
        f.write_str(")")?;
    }
    f.write_str("}")
}

/// Increase a topic's partition count (`CreatePartitions`). Java `NewPartitions`.
///
/// [`std::fmt::Display`] is Java `NewPartitions.toString` (no topic name; `None`
/// assignments print `null`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NewPartitions {
    /// Topic name.
    pub name: String,
    /// Total partition count after the increase (not a delta).
    pub total_count: i32,
    /// Replica assignments for the new partitions (Java
    /// `NewPartitions.increaseTo(int, List<List<Integer>>)`).
    ///
    /// `None` is a null Assignments array: the broker assigns replicas
    /// (Java `increaseTo(int)`).
    pub assignments: Option<Vec<Vec<i32>>>,
}

impl NewPartitions {
    /// Set `name` to `total_count` partitions (Java `NewPartitions.increaseTo`).
    ///
    /// Assignments are null; the broker picks replicas.
    #[must_use]
    pub fn increase_to(name: impl Into<String>, total_count: i32) -> Self {
        Self {
            name: name.into(),
            total_count,
            assignments: None,
        }
    }

    /// Java `NewPartitions.increaseTo(int, List<List<Integer>>)`.
    ///
    /// Each inner list is the replica broker ids for one new partition.
    #[must_use]
    pub fn with_assignments(
        mut self,
        assignments: impl IntoIterator<Item = impl IntoIterator<Item = i32>>,
    ) -> Self {
        self.assignments = Some(
            assignments
                .into_iter()
                .map(|brokers| brokers.into_iter().collect())
                .collect(),
        );
        self
    }

    /// Topic name.
    #[must_use]
    pub fn name(&self) -> &str {
        self.name.as_str()
    }

    /// Java `NewPartitions.totalCount`.
    #[must_use]
    pub fn total_count(&self) -> i32 {
        self.total_count
    }

    /// Java `NewPartitions.assignments` (`None` is Java `null`).
    #[must_use]
    pub fn assignments(&self) -> Option<&[Vec<i32>]> {
        self.assignments.as_deref()
    }
}

impl fmt::Display for NewPartitions {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(totalCount={}, newAssignments=", self.total_count)?;
        match &self.assignments {
            None => f.write_str("null")?,
            Some(asns) => {
                f.write_str("[")?;
                for (i, brokers) in asns.iter().enumerate() {
                    if i > 0 {
                        f.write_str(", ")?;
                    }
                    write_java_int_list(f, brokers)?;
                }
                f.write_str("]")?;
            }
        }
        f.write_str(")")
    }
}

/// Kafka config resource type (`ConfigResource.Type`).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[repr(i8)]
pub enum ConfigResourceType {
    /// Topic.
    Topic = RESOURCE_TOPIC,
    /// Broker (`broker.id` as the name).
    Broker = RESOURCE_BROKER,
    /// Broker logger (KIP-1142).
    BrokerLogger = RESOURCE_BROKER_LOGGER,
    /// Client metrics (KIP-714 / KIP-1142).
    ClientMetrics = RESOURCE_CLIENT_METRICS,
    /// Consumer group.
    Group = RESOURCE_GROUP,
}

impl From<ConfigResourceType> for i8 {
    fn from(ty: ConfigResourceType) -> Self {
        ty as i8
    }
}

impl ConfigResourceType {
    /// Java `ConfigResource.Type.id`.
    #[must_use]
    pub const fn id(self) -> i8 {
        self as i8
    }

    /// Wire id to [`Self`]. Unknown ids are [`None`].
    #[must_use]
    pub const fn from_id(id: i8) -> Option<Self> {
        match id {
            RESOURCE_TOPIC => Some(Self::Topic),
            RESOURCE_BROKER => Some(Self::Broker),
            RESOURCE_BROKER_LOGGER => Some(Self::BrokerLogger),
            RESOURCE_CLIENT_METRICS => Some(Self::ClientMetrics),
            RESOURCE_GROUP => Some(Self::Group),
            _ => None,
        }
    }
}

impl fmt::Display for ConfigResourceType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match *self {
            Self::Topic => "TOPIC",
            Self::Broker => "BROKER",
            Self::BrokerLogger => "BROKER_LOGGER",
            Self::ClientMetrics => "CLIENT_METRICS",
            Self::Group => "GROUP",
        })
    }
}

/// Resource for DescribeConfigs / IncrementalAlterConfigs / AlterConfigs.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct ConfigResource {
    /// Kafka resource type (`CONFIG_RESOURCE_TOPIC`, [`ConfigResourceType::Topic`], …).
    pub resource_type: i8,
    /// Resource name (topic name, or broker id as a string).
    pub name: String,
    /// Config keys to fetch; `None` means all.
    pub keys: Option<Vec<String>>,
}

impl ConfigResource {
    /// Resource of this type. Fetches every config key unless [`Self::keys`] is set.
    #[must_use]
    pub fn of(ty: ConfigResourceType, name: impl Into<String>) -> Self {
        Self {
            resource_type: i8::from(ty),
            name: name.into(),
            keys: None,
        }
    }

    /// Topic resource. Fetches every config key unless [`Self::keys`] is set.
    #[must_use]
    pub fn topic(name: impl Into<String>) -> Self {
        Self::of(ConfigResourceType::Topic, name)
    }

    /// Broker resource (`broker.id` as the name).
    #[must_use]
    pub fn broker(id: i32) -> Self {
        Self::of(ConfigResourceType::Broker, id.to_string())
    }

    /// Consumer-group resource.
    #[must_use]
    pub fn group(name: impl Into<String>) -> Self {
        Self::of(ConfigResourceType::Group, name)
    }

    /// Restrict DescribeConfigs to these keys.
    #[must_use]
    pub fn keys(mut self, keys: impl IntoIterator<Item = impl Into<String>>) -> Self {
        self.keys = Some(keys.into_iter().map(Into::into).collect());
        self
    }

    /// Java `ConfigResource.name`.
    #[must_use]
    pub fn name(&self) -> &str {
        self.name.as_str()
    }

    /// Java `ConfigResource.type`.
    #[must_use]
    pub fn resource_type(&self) -> Option<ConfigResourceType> {
        ConfigResourceType::from_id(self.resource_type)
    }

    /// Java `ConfigResource.isDefault` (empty name).
    #[must_use]
    pub fn is_default(&self) -> bool {
        self.name.is_empty()
    }
}

impl fmt::Display for ConfigResource {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("ConfigResource(type=")?;
        match self.resource_type() {
            Some(ty) => write!(f, "{ty}")?,
            None => f.write_str("UNKNOWN")?,
        }
        write!(f, ", name='{}')", self.name)
    }
}

/// Java `ConfigResource.Type.forId` then `ConfigResource(Type, name)`.
///
/// Unknown type ids become `UNKNOWN` (0).
fn config_resource_from_response(resource_type: i8, name: impl Into<String>) -> ConfigResource {
    ConfigResource {
        resource_type: ConfigResourceType::from_id(resource_type)
            .map(ConfigResourceType::id)
            .unwrap_or(0),
        name: name.into(),
        keys: None,
    }
}

fn alter_config_api_errors(
    results: &[AlterConfigsResourceResult],
) -> HashMap<ConfigResource, crate::error::ApiError> {
    let mut map = HashMap::new();
    for result in results {
        map.extend([(
            config_resource_from_response(result.resource_type, result.name.clone()),
            crate::error::ApiError::from_code(result.error_code, result.error_message.clone()),
        )]);
    }
    map
}

impl crate::protocol::admin::AlterConfigsResponse {
    /// Java `AlterConfigsResponse.errors`.
    ///
    /// Each key is a [`ConfigResource`] (Java `Type.forId`; unknown ids are
    /// `UNKNOWN`). Values are [`crate::error::ApiError`].
    #[must_use]
    pub fn errors(
        results: &[AlterConfigsResourceResult],
    ) -> HashMap<ConfigResource, crate::error::ApiError> {
        alter_config_api_errors(results)
    }
}

impl crate::protocol::admin::AlterConfigsRequest {
    /// Java `AlterConfigsRequest.configs`.
    ///
    /// Each key is a [`ConfigResource`] (Java `Type.forId`; unknown ids are
    /// `UNKNOWN`). Each value is [`Config`] of [`ConfigEntry::new`] for that
    /// resource's name/value pairs. Official Java wraps an inner
    /// `AlterConfigsRequest.Config` whose `ConfigEntry` constructor rejects a
    /// null Value; crate `None` is Java `null`.
    #[must_use]
    pub fn configs(resources: &[AlterConfigsResource]) -> HashMap<ConfigResource, Config> {
        let mut map = HashMap::new();
        for resource in resources {
            map.extend([(
                config_resource_from_response(resource.resource_type, resource.name.clone()),
                Config::new(
                    resource
                        .configs
                        .iter()
                        .map(|c| ConfigEntry::new(c.name.clone(), c.value.clone())),
                ),
            )]);
        }
        map
    }
}

impl crate::protocol::admin::IncrementalAlterConfigsResponse {
    /// Java `IncrementalAlterConfigsResponse.fromResponseData`.
    ///
    /// Same map as [`crate::protocol::admin::AlterConfigsResponse::errors`].
    #[must_use]
    pub fn from_response_data(
        results: &[AlterConfigsResourceResult],
    ) -> HashMap<ConfigResource, crate::error::ApiError> {
        alter_config_api_errors(results)
    }
}

impl crate::protocol::admin::DescribeConfigsResponse {
    /// Java `DescribeConfigsResponse.resultMap`.
    ///
    /// Each key is a [`ConfigResource`] (Java `Type.forId`; unknown ids are
    /// `UNKNOWN`).
    #[must_use]
    pub fn result_map(
        results: &[DescribeConfigsResult],
    ) -> HashMap<ConfigResource, DescribeConfigsResult> {
        let mut map = HashMap::new();
        for result in results {
            map.extend([(
                config_resource_from_response(result.resource_type, result.name.clone()),
                result.clone(),
            )]);
        }
        map
    }
}

impl crate::protocol::admin::ListConfigResourcesResponse {
    /// Java `ListConfigResourcesResponse.configResources`.
    ///
    /// Each entry is [`ConfigResource`] via `Type.forId` then
    /// `ConfigResource(Type, name)`. Unknown type ids become `UNKNOWN`
    /// (`0`). `keys` stays `None`. Official Java
    /// `ListConfigResourcesResponse.configResources` (4.1.0; 4.0.0 404
    /// as the current name). This crate speaks 0–1. This is not
    /// [`Self::error`] / [`Self::error_counts`] /
    /// [`ListedConfigResource::to_config_resource`] (keeps the wire id).
    #[must_use]
    pub fn config_resources(&self) -> Vec<ConfigResource> {
        self.config_resources
            .iter()
            .map(|r| config_resource_from_response(r.resource_type, r.resource_name.clone()))
            .collect()
    }
}

impl ListedConfigResource {
    /// Java `ConfigResource.name` (`listConfigResources` item).
    #[must_use]
    pub fn name(&self) -> &str {
        self.resource_name.as_str()
    }

    /// Java `ConfigResource.type`. Unknown wire ids are [`None`].
    #[must_use]
    pub fn resource_type(&self) -> Option<ConfigResourceType> {
        ConfigResourceType::from_id(self.resource_type)
    }

    /// This listing as a [`ConfigResource`] with no key filter (Java
    /// `listConfigResources` returns `ConfigResource`).
    #[must_use]
    pub fn to_config_resource(&self) -> ConfigResource {
        ConfigResource {
            resource_type: self.resource_type,
            name: self.resource_name.clone(),
            keys: None,
        }
    }

    /// Java `ConfigResource.isDefault` (empty name).
    #[must_use]
    pub fn is_default(&self) -> bool {
        self.resource_name.is_empty()
    }
}

impl fmt::Display for ListedConfigResource {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.to_config_resource(), f)
    }
}

impl From<ListedConfigResource> for ConfigResource {
    fn from(listed: ListedConfigResource) -> Self {
        Self {
            resource_type: listed.resource_type,
            name: listed.resource_name,
            keys: None,
        }
    }
}

/// One resource plus ops for [`Admin::incremental_alter_configs_for`]
/// (Java `incrementalAlterConfigs(Map)`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ConfigResourceUpdate {
    /// Resource to alter.
    pub resource: ConfigResource,
    /// Incremental ops (`AlterConfig::set` / `delete` / `append` / `subtract`).
    pub configs: Vec<AlterConfig>,
}

impl ConfigResourceUpdate {
    /// `resource` with these ops.
    #[must_use]
    pub fn new(resource: ConfigResource, configs: impl IntoIterator<Item = AlterConfig>) -> Self {
        Self {
            resource,
            configs: configs.into_iter().collect(),
        }
    }
}

/// One resource plus replacement entries for [`Admin::alter_configs_for`]
/// (Java `alterConfigs(Map)`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ConfigReplacement {
    /// Resource to replace configs on.
    pub resource: ConfigResource,
    /// Replacement name/value pairs (value `None` clears the key).
    pub configs: Vec<(String, Option<String>)>,
}

impl ConfigReplacement {
    /// `resource` with these entries.
    #[must_use]
    pub fn new(
        resource: ConfigResource,
        configs: impl IntoIterator<Item = (String, Option<String>)>,
    ) -> Self {
        Self {
            resource,
            configs: configs.into_iter().collect(),
        }
    }

    /// Java `alterConfigs(Map)` value: this resource plus [`Config::entries`].
    #[must_use]
    pub fn from_config(resource: ConfigResource, config: &Config) -> Self {
        Self {
            resource,
            configs: config
                .entries()
                .iter()
                .map(|e| (e.name.clone(), e.value.clone()))
                .collect(),
        }
    }
}

/// Java `NewPartitionReassignment` for
/// [`Admin::alter_partition_reassignments_for`].
///
/// [`Self::new`] rejects an empty replica list (Java throws
/// `IllegalArgumentException`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NewPartitionReassignment {
    /// Target replica broker ids (Java `targetReplicas`).
    pub target_replicas: Vec<i32>,
}

impl NewPartitionReassignment {
    /// Java `NewPartitionReassignment(List)`. Empty replicas is an error.
    pub fn new(target_replicas: impl IntoIterator<Item = i32>) -> Result<Self> {
        let target_replicas: Vec<i32> = target_replicas.into_iter().collect();
        if target_replicas.is_empty() {
            return Err(Error::protocol(
                "Cannot create a new partition reassignment without any replicas",
            ));
        }
        Ok(Self { target_replicas })
    }

    /// Java `NewPartitionReassignment.targetReplicas`.
    #[must_use]
    pub fn target_replicas(&self) -> &[i32] {
        &self.target_replicas
    }
}

/// Options for [`Admin::alter_partition_reassignments_with_options`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct AlterPartitionReassignmentsOptions {
    /// Permit changes to replication factor. Default `true`, matching Java.
    /// Explicit `false` requires a controller supporting API45 version1.
    pub allow_replication_factor_change: bool,
    /// One deadline for discovery, connection, negotiation and all retries.
    /// `None` uses [`AdminConfig::request_timeout`].
    pub timeout: Option<Duration>,
}

impl Default for AlterPartitionReassignmentsOptions {
    fn default() -> Self {
        Self {
            allow_replication_factor_change: true,
            timeout: None,
        }
    }
}

impl AlterPartitionReassignmentsOptions {
    /// Select whether target replica lists may change replication factor.
    #[must_use]
    pub fn allow_replication_factor_change(mut self, allow: bool) -> Self {
        self.allow_replication_factor_change = allow;
        self
    }

    /// Set the overall timeout, also used for the broker-side request timeout.
    #[must_use]
    pub fn timeout(mut self, timeout: Duration) -> Self {
        self.timeout = Some(timeout);
        self
    }
}

/// One partition in `Admin::alter_partition_reassignments`.
///
/// `replicas = None` cancels a pending reassignment (KIP-455).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PartitionReassignment {
    /// Topic name.
    pub topic: String,
    /// Partition index.
    pub partition: i32,
    /// Target replica broker ids, or `None` to cancel a pending move.
    pub replicas: Option<Vec<i32>>,
}

impl PartitionReassignment {
    /// Move `partition` onto `replicas`.
    #[must_use]
    pub fn assign(
        partition: impl Into<crate::TopicPartition>,
        replicas: impl IntoIterator<Item = i32>,
    ) -> Self {
        let tp = partition.into();
        Self {
            topic: tp.topic,
            partition: tp.partition,
            replicas: Some(replicas.into_iter().collect()),
        }
    }

    /// Cancel a pending reassignment for this partition.
    #[must_use]
    pub fn cancel(partition: impl Into<crate::TopicPartition>) -> Self {
        let tp = partition.into();
        Self {
            topic: tp.topic,
            partition: tp.partition,
            replicas: None,
        }
    }

    /// Java `alterPartitionReassignments(Map)` value: `Some` assigns,
    /// `None` cancels (Java `Optional.empty()`).
    #[must_use]
    pub fn from_new(
        partition: impl Into<crate::TopicPartition>,
        assignment: Option<NewPartitionReassignment>,
    ) -> Self {
        match assignment {
            Some(n) => Self::assign(partition, n.target_replicas),
            None => Self::cancel(partition),
        }
    }

    /// Topic name.
    #[must_use]
    pub fn topic(&self) -> &str {
        self.topic.as_str()
    }

    /// Partition index.
    #[must_use]
    pub fn partition(&self) -> i32 {
        self.partition
    }

    /// Target replicas, or `None` to cancel.
    #[must_use]
    pub fn replicas(&self) -> Option<&[i32]> {
        self.replicas.as_deref()
    }
}

/// Flattened per-partition result of AlterPartitionReassignments.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReassignmentResult {
    /// Topic name.
    pub topic: String,
    /// Partition index.
    pub partition: i32,
    /// Per-partition error code (`0` is success).
    pub error_code: i16,
    /// Broker error message, when present.
    pub error_message: Option<String>,
}

impl ReassignmentResult {
    /// Topic name.
    #[must_use]
    pub fn topic(&self) -> &str {
        self.topic.as_str()
    }

    /// Partition index.
    #[must_use]
    pub fn partition(&self) -> i32 {
        self.partition
    }

    /// Per-partition error code (`0` is success).
    #[must_use]
    pub fn error_code(&self) -> i16 {
        self.error_code
    }

    /// Broker error message, when present.
    #[must_use]
    pub fn error_message(&self) -> Option<&str> {
        self.error_message.as_deref()
    }
}

/// Flattened ongoing reassignment from ListPartitionReassignments
/// (Java `PartitionReassignment`).
///
/// [`std::fmt::Display`] is Java `PartitionReassignment.toString` (no topic or
/// partition; those are the `listPartitionReassignments` map keys).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OngoingReassignment {
    /// Topic name.
    pub topic: String,
    /// Partition index.
    pub partition: i32,
    /// Replica set after the move completes.
    pub replicas: Vec<i32>,
    /// Brokers being added.
    pub adding_replicas: Vec<i32>,
    /// Brokers being removed.
    pub removing_replicas: Vec<i32>,
}

impl OngoingReassignment {
    /// Topic name.
    #[must_use]
    pub fn topic(&self) -> &str {
        self.topic.as_str()
    }

    /// Partition index.
    #[must_use]
    pub fn partition(&self) -> i32 {
        self.partition
    }

    /// Java `PartitionReassignment.replicas`.
    #[must_use]
    pub fn replicas(&self) -> &[i32] {
        &self.replicas
    }

    /// Java `PartitionReassignment.addingReplicas`.
    #[must_use]
    pub fn adding_replicas(&self) -> &[i32] {
        &self.adding_replicas
    }

    /// Java `PartitionReassignment.removingReplicas`.
    #[must_use]
    pub fn removing_replicas(&self) -> &[i32] {
        &self.removing_replicas
    }
}

impl fmt::Display for OngoingReassignment {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("PartitionReassignment(replicas=")?;
        write_java_int_list(f, &self.replicas)?;
        f.write_str(", addingReplicas=")?;
        write_java_int_list(f, &self.adding_replicas)?;
        f.write_str(", removingReplicas=")?;
        write_java_int_list(f, &self.removing_replicas)?;
        f.write_str(")")
    }
}

/// One finalized-feature update for `Admin::update_features`.
///
/// [`std::fmt::Display`] is Java `FeatureUpdate.toString` (no feature name; that is
/// the `updateFeatures` map key). Unknown upgrade-type codes print
/// `UNKNOWN`. Java `FeatureUpdate` constructor rejects maxVersionLevel 0
/// with [`UPGRADE_TYPE_UPGRADE`] and a negative maxVersionLevel; this crate
/// checks those rules when encoding UpdateFeatures.
/// [`Self::is_delete_request`] is Java
/// `UpdateFeaturesRequest.FeatureUpdateItem.isDeleteRequest`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FeatureUpdate {
    /// Feature name (for example `metadata.version`).
    pub name: String,
    /// Target finalized version.
    pub max_version_level: i16,
    /// When true, allow a downgrade (v0 `AllowDowngrade`; Java maps this
    /// to safe downgrade).
    pub allow_downgrade: bool,
    /// Upgrade type (v1+). [`UPGRADE_TYPE_UPGRADE`] / safe / unsafe.
    pub upgrade_type: i8,
}

impl FeatureUpdate {
    /// Feature `name` at `max_version_level` (upgrade only).
    #[must_use]
    pub fn new(name: impl Into<String>, max_version_level: i16) -> Self {
        Self {
            name: name.into(),
            max_version_level,
            allow_downgrade: false,
            upgrade_type: UPGRADE_TYPE_UPGRADE,
        }
    }

    /// Allow a downgrade of this feature (Java `FeatureUpdate(short, true)`
    /// → safe downgrade). v0 sends `AllowDowngrade`. v1+ sends
    /// [`UPGRADE_TYPE_SAFE_DOWNGRADE`].
    #[must_use]
    pub fn allow_downgrade(mut self, allow: bool) -> Self {
        self.allow_downgrade = allow;
        self.upgrade_type = if allow {
            UPGRADE_TYPE_SAFE_DOWNGRADE
        } else {
            UPGRADE_TYPE_UPGRADE
        };
        self
    }

    /// Set v1+ [`UpgradeType`] (`1` upgrade, `2` safe, `3` unsafe).
    /// v0 sends `AllowDowngrade` when the type is not upgrade-only.
    #[must_use]
    pub fn upgrade_type(mut self, upgrade_type: impl Into<i8>) -> Self {
        let upgrade_type = upgrade_type.into();
        self.upgrade_type = upgrade_type;
        self.allow_downgrade = upgrade_type != UPGRADE_TYPE_UPGRADE;
        self
    }

    /// Feature name (Java map key for `updateFeatures`).
    #[must_use]
    pub fn name(&self) -> &str {
        self.name.as_str()
    }

    /// Java `FeatureUpdate.maxVersionLevel`.
    #[must_use]
    pub fn max_version_level(&self) -> i16 {
        self.max_version_level
    }

    /// Java `UpdateFeaturesRequest.FeatureUpdateItem.isDeleteRequest`.
    ///
    /// True when `maxVersionLevel` is below 1 and the upgrade type is not
    /// [`UPGRADE_TYPE_UPGRADE`]. Encode still rejects level 0 with
    /// `UpgradeType.UPGRADE` and a negative level.
    #[must_use]
    pub fn is_delete_request(&self) -> bool {
        self.max_version_level < 1 && self.upgrade_type != UPGRADE_TYPE_UPGRADE
    }
}

impl fmt::Display for FeatureUpdate {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("FeatureUpdate{maxVersionLevel:")?;
        write!(f, "{}", self.max_version_level)?;
        f.write_str(", upgradeType:")?;
        f.write_str(match self.upgrade_type {
            UPGRADE_TYPE_UPGRADE => "UPGRADE",
            UPGRADE_TYPE_SAFE_DOWNGRADE => "SAFE_DOWNGRADE",
            UPGRADE_TYPE_UNSAFE_DOWNGRADE => "UNSAFE_DOWNGRADE",
            _ => "UNKNOWN",
        })?;
        f.write_str("}")
    }
}

/// Per-feature result of UpdateFeatures.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FeatureUpdateResult {
    /// Feature name.
    pub name: String,
    /// Per-feature error code (`0` is success).
    pub error_code: i16,
    /// Broker error message, when present.
    pub error_message: Option<String>,
}

impl FeatureUpdateResult {
    /// Feature name.
    #[must_use]
    pub fn name(&self) -> &str {
        self.name.as_str()
    }

    /// Per-feature error code (`0` is success).
    #[must_use]
    pub fn error_code(&self) -> i16 {
        self.error_code
    }

    /// Broker error message, when present.
    #[must_use]
    pub fn error_message(&self) -> Option<&str> {
        self.error_message.as_deref()
    }
}

/// Supported version range from [`Admin::describe_features`] (Java `SupportedVersionRange`).
///
/// [`std::fmt::Display`] is Java `SupportedVersionRange.toString` (no feature name;
/// that is the `supportedFeatures` map key). Java constructor requires a
/// non-negative min through max; [`Self::new`] checks that.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SupportedVersionRange {
    /// Feature name (for example `metadata.version`).
    pub name: String,
    /// Lowest version the broker supports.
    pub min_version: i16,
    /// Highest version the broker supports.
    pub max_version: i16,
}

impl SupportedVersionRange {
    /// Feature `name` supported from `min_version` through `max_version`.
    ///
    /// Java `SupportedVersionRange(short, short)` rejects a negative min
    /// or max, or max below min.
    pub fn new(name: impl Into<String>, min_version: i16, max_version: i16) -> Result<Self> {
        if min_version < 0 || max_version < 0 || max_version < min_version {
            return Err(Error::protocol(format!(
                "Expected 0 <= minVersion <= maxVersion but received minVersion:{min_version}, maxVersion:{max_version}."
            )));
        }
        Ok(Self {
            name: name.into(),
            min_version,
            max_version,
        })
    }

    /// Feature name.
    #[must_use]
    pub fn name(&self) -> &str {
        self.name.as_str()
    }

    /// Java `SupportedVersionRange.min`.
    #[must_use]
    pub fn min_version(&self) -> i16 {
        self.min_version
    }

    /// Java `SupportedVersionRange.max`.
    #[must_use]
    pub fn max_version(&self) -> i16 {
        self.max_version
    }
}

impl fmt::Display for SupportedVersionRange {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("SupportedVersionRange[min_version:")?;
        write!(f, "{}", self.min_version())?;
        f.write_str(", max_version:")?;
        write!(f, "{}", self.max_version())?;
        f.write_str("]")
    }
}

/// Finalized version range from [`Admin::describe_features`] (Java `FinalizedVersionRange`).
///
/// [`std::fmt::Display`] is Java `FinalizedVersionRange.toString` (no feature name;
/// that is the `finalizedFeatures` map key). Java constructor requires
/// non-negative min/max and max at least min; [`Self::new`] checks that.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FinalizedVersionRange {
    /// Feature name (for example `metadata.version`).
    pub name: String,
    /// Lowest finalized version.
    pub min_version_level: i16,
    /// Highest finalized version.
    pub max_version_level: i16,
}

impl FinalizedVersionRange {
    /// Feature `name` finalized from `min_version_level` through `max_version_level`.
    ///
    /// Java `FinalizedVersionRange(short, short)` rejects a negative min
    /// or max, or max below min.
    pub fn new(
        name: impl Into<String>,
        min_version_level: i16,
        max_version_level: i16,
    ) -> Result<Self> {
        if min_version_level < 0 || max_version_level < 0 || max_version_level < min_version_level {
            return Err(Error::protocol(format!(
                "Expected minVersionLevel >= 0, maxVersionLevel >= 0 and maxVersionLevel >= minVersionLevel, but received minVersionLevel: {min_version_level}, maxVersionLevel: {max_version_level}"
            )));
        }
        Ok(Self {
            name: name.into(),
            min_version_level,
            max_version_level,
        })
    }

    /// Feature name.
    #[must_use]
    pub fn name(&self) -> &str {
        self.name.as_str()
    }

    /// Java `FinalizedVersionRange.minVersionLevel`.
    #[must_use]
    pub fn min_version_level(&self) -> i16 {
        self.min_version_level
    }

    /// Java `FinalizedVersionRange.maxVersionLevel`.
    #[must_use]
    pub fn max_version_level(&self) -> i16 {
        self.max_version_level
    }
}

impl fmt::Display for FinalizedVersionRange {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("FinalizedVersionRange[min_version_level:")?;
        write!(f, "{}", self.min_version_level())?;
        f.write_str(", max_version_level:")?;
        write!(f, "{}", self.max_version_level())?;
        f.write_str("]")
    }
}

/// Cluster feature metadata from [`Admin::describe_features`] (Java `FeatureMetadata`).
///
/// There is no DescribeFeatures api key. Java and this client re-issue
/// ApiVersions v3–v4 and read KIP-482 tagged fields.
///
/// [`std::fmt::Display`] is Java `FeatureMetadata.toString` (crate vec order;
/// empty epoch prints a space; omits `zk_migration_ready`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FeatureMetadata {
    /// Features the broker supports (`supportedFeatures`).
    pub supported_features: Vec<SupportedVersionRange>,
    /// Finalized features (`finalizedFeatures`).
    pub finalized_features: Vec<FinalizedVersionRange>,
    /// Monotonic finalized-features epoch. `None` when the broker sends `-1`.
    pub finalized_features_epoch: Option<i64>,
    /// ApiVersions tagged field 3 (`zkMigrationReady`, KIP-866).
    pub zk_migration_ready: bool,
}

impl FeatureMetadata {
    /// Java `FeatureMetadata.supportedFeatures`.
    #[must_use]
    pub fn supported_features(&self) -> &[SupportedVersionRange] {
        &self.supported_features
    }

    /// Java `FeatureMetadata.finalizedFeatures`.
    #[must_use]
    pub fn finalized_features(&self) -> &[FinalizedVersionRange] {
        &self.finalized_features
    }

    /// Java `FeatureMetadata.finalizedFeaturesEpoch`.
    #[must_use]
    pub fn finalized_features_epoch(&self) -> Option<i64> {
        self.finalized_features_epoch
    }

    /// ApiVersions tagged field 3 (`zkMigrationReady`).
    #[must_use]
    pub fn zk_migration_ready(&self) -> bool {
        self.zk_migration_ready
    }
}

impl fmt::Display for FeatureMetadata {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("FeatureMetadata{finalizedFeatures:")?;
        write_java_feature_map(f, self.finalized_features(), FinalizedVersionRange::name)?;
        f.write_str(", finalizedFeaturesEpoch:")?;
        match self.finalized_features_epoch() {
            Some(epoch) => write!(f, "{epoch}")?,
            None => f.write_str(" ")?,
        }
        f.write_str(", supportedFeatures:")?;
        write_java_feature_map(f, self.supported_features(), SupportedVersionRange::name)?;
        f.write_str("}")
    }
}

/// One SCRAM credential to remove for `Admin::alter_user_scram_credentials`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct UserScramCredentialDeletion {
    /// User name.
    pub name: String,
    /// `SCRAM_SHA_256` / [`crate::ScramMechanism::Sha256`], or SHA-512.
    pub mechanism: i8,
}

impl UserScramCredentialDeletion {
    /// Delete this user's credential for `mechanism`.
    #[must_use]
    pub fn new(name: impl Into<String>, mechanism: impl Into<i8>) -> Self {
        Self {
            name: name.into(),
            mechanism: mechanism.into(),
        }
    }

    /// Java `UserScramCredentialAlteration.user`.
    #[must_use]
    pub fn user(&self) -> &str {
        self.name.as_str()
    }

    /// Java `UserScramCredentialDeletion.mechanism`.
    #[must_use]
    pub fn mechanism(&self) -> ScramMechanism {
        ScramMechanism::from_id(self.mechanism)
    }
}

/// One SCRAM credential to insert or replace.
///
/// Callers supply dummy `salt` / `salted_password` bytes. This crate does
/// not hash a password or keep a credential store. `Debug` redacts those
/// fields.
#[derive(Clone, PartialEq, Eq)]
pub struct UserScramCredentialUpsertion {
    /// User name.
    pub name: String,
    /// `SCRAM_SHA_256` / [`crate::ScramMechanism::Sha256`], or SHA-512.
    pub mechanism: i8,
    /// PBKDF2 iteration count.
    pub iterations: i32,
    /// Salt bytes. Redacted in `Debug`.
    pub salt: Vec<u8>,
    /// Salted password bytes. Redacted in `Debug`.
    pub salted_password: Vec<u8>,
}

impl UserScramCredentialUpsertion {
    /// Insert or replace this user's SCRAM credential.
    #[must_use]
    pub fn new(
        name: impl Into<String>,
        mechanism: impl Into<i8>,
        iterations: i32,
        salt: impl Into<Vec<u8>>,
        salted_password: impl Into<Vec<u8>>,
    ) -> Self {
        Self {
            name: name.into(),
            mechanism: mechanism.into(),
            iterations,
            salt: salt.into(),
            salted_password: salted_password.into(),
        }
    }

    /// Java `UserScramCredentialAlteration.user`.
    #[must_use]
    pub fn user(&self) -> &str {
        self.name.as_str()
    }

    /// Java `UserScramCredentialUpsertion.credentialInfo`.
    #[must_use]
    pub fn credential_info(&self) -> ScramCredentialInfo {
        ScramCredentialInfo::new(self.mechanism, self.iterations)
    }

    /// Java `UserScramCredentialUpsertion.salt`.
    #[must_use]
    pub fn salt(&self) -> &[u8] {
        &self.salt
    }
}

impl std::fmt::Debug for UserScramCredentialUpsertion {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("UserScramCredentialUpsertion")
            .field("name", &self.name)
            .field("mechanism", &self.mechanism)
            .field("iterations", &self.iterations)
            .field("salt", &"<redacted>")
            .field("salted_password", &"<redacted>")
            .finish()
    }
}

/// Java `UserScramCredentialAlteration` for
/// [`Admin::alter_user_scram_credentials_with`].
///
/// Java `alterUserScramCredentials(List)` is a mixed list of
/// [`UserScramCredentialDeletion`] and [`UserScramCredentialUpsertion`].
/// The wire request still splits Deletions then Upsertions.
#[derive(Clone, PartialEq, Eq, Debug)]
pub enum UserScramCredentialAlteration {
    /// Java `UserScramCredentialDeletion`.
    Deletion(UserScramCredentialDeletion),
    /// Java `UserScramCredentialUpsertion`.
    Upsertion(UserScramCredentialUpsertion),
}

impl UserScramCredentialAlteration {
    /// Java `UserScramCredentialAlteration.user()`.
    #[must_use]
    pub fn user(&self) -> &str {
        match self {
            Self::Deletion(d) => d.name.as_str(),
            Self::Upsertion(u) => u.name.as_str(),
        }
    }
}

impl From<UserScramCredentialDeletion> for UserScramCredentialAlteration {
    fn from(deletion: UserScramCredentialDeletion) -> Self {
        Self::Deletion(deletion)
    }
}

impl From<UserScramCredentialUpsertion> for UserScramCredentialAlteration {
    fn from(upsertion: UserScramCredentialUpsertion) -> Self {
        Self::Upsertion(upsertion)
    }
}

/// Per-user result of AlterUserScramCredentials.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct UserScramCredentialResult {
    /// User name.
    pub user: String,
    /// Per-user error code (`0` is success).
    pub error_code: i16,
    /// Broker error message, when present.
    pub error_message: Option<String>,
}

impl UserScramCredentialResult {
    /// User name.
    #[must_use]
    pub fn user(&self) -> &str {
        self.user.as_str()
    }

    /// Per-user error code (`0` is success).
    #[must_use]
    pub fn error_code(&self) -> i16 {
        self.error_code
    }

    /// Broker error message, when present.
    #[must_use]
    pub fn error_message(&self) -> Option<&str> {
        self.error_message.as_deref()
    }
}

/// PID block from `Admin::allocate_producer_ids` (AllocateProducerIds api 67).
///
/// Fixture broker id/epoch only. This is not a live cluster PID allocator.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProducerIdBlock {
    /// First producer id in the allocated block.
    pub producer_id_start: i64,
    /// Number of ids in the block.
    pub producer_id_len: i32,
}

impl ProducerIdBlock {
    /// First producer id in the allocated block.
    #[must_use]
    pub fn producer_id_start(&self) -> i64 {
        self.producer_id_start
    }

    /// Number of ids in the block.
    #[must_use]
    pub fn producer_id_len(&self) -> i32 {
        self.producer_id_len
    }
}

/// One transactional.id fenced by [`Admin::fence_producers`].
///
/// Java `FenceProducersResult`: [`Self::producer_id`] is `producerId`,
/// [`Self::epoch`] is `epoch`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FencedProducer {
    /// Kafka `transactional.id`.
    pub transactional_id: String,
    /// Producer id after InitProducerId.
    pub producer_id: i64,
    /// Producer epoch after InitProducerId.
    pub epoch: i16,
}

impl FencedProducer {
    /// Kafka `transactional.id`.
    #[must_use]
    pub fn transactional_id(&self) -> &str {
        self.transactional_id.as_str()
    }

    /// Java `FenceProducersResult.producerId`.
    #[must_use]
    pub fn producer_id(&self) -> i64 {
        self.producer_id
    }

    /// Java `FenceProducersResult.epochId`.
    #[must_use]
    pub fn epoch(&self) -> i16 {
        self.epoch
    }
}

/// Spec for [`Admin::abort_transaction`] (Java `AbortTransactionSpec`).
///
/// Sends WriteTxnMarkers (api 27) with
/// [`crate::TransactionResult::Abort`] (`transactionResult` false)
/// to the Metadata partition leader.
///
/// [`std::fmt::Display`] is Java `AbortTransactionSpec.toString`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AbortTransactionSpec {
    /// Topic name.
    pub topic: String,
    /// Partition index.
    pub partition: i32,
    /// Producer id that owns the open transaction.
    pub producer_id: i64,
    /// Producer epoch.
    pub producer_epoch: i16,
    /// Transaction coordinator epoch.
    pub coordinator_epoch: i32,
}

impl AbortTransactionSpec {
    /// Abort the open transaction of `producer_id` on `partition`.
    #[must_use]
    pub fn new(
        partition: impl Into<crate::TopicPartition>,
        producer_id: i64,
        producer_epoch: i16,
        coordinator_epoch: i32,
    ) -> Self {
        let tp = partition.into();
        Self {
            topic: tp.topic,
            partition: tp.partition,
            producer_id,
            producer_epoch,
            coordinator_epoch,
        }
    }

    /// Java `AbortTransactionSpec.topicPartition`.
    #[must_use]
    pub fn topic_partition(&self) -> crate::TopicPartition {
        crate::TopicPartition::new(self.topic.clone(), self.partition)
    }

    /// Java `AbortTransactionSpec.producerId`.
    #[must_use]
    pub fn producer_id(&self) -> i64 {
        self.producer_id
    }

    /// Java `AbortTransactionSpec.producerEpoch`.
    #[must_use]
    pub fn producer_epoch(&self) -> i16 {
        self.producer_epoch
    }

    /// Java `AbortTransactionSpec.coordinatorEpoch`.
    #[must_use]
    pub fn coordinator_epoch(&self) -> i32 {
        self.coordinator_epoch
    }
}

impl fmt::Display for AbortTransactionSpec {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("AbortTransactionSpec(topicPartition=")?;
        write!(f, "{}-{}", self.topic, self.partition)?;
        f.write_str(", producerId=")?;
        write!(f, "{}", self.producer_id())?;
        f.write_str(", producerEpoch=")?;
        write!(f, "{}", self.producer_epoch())?;
        f.write_str(", coordinatorEpoch=")?;
        write!(f, "{}", self.coordinator_epoch())?;
        f.write_str(")")
    }
}

/// Java `KafkaAdminClient.DEFAULT_LEAVE_GROUP_REASON` (KIP-800).
pub const DEFAULT_LEAVE_GROUP_REASON: &str = "member was removed by an admin";

/// LeaveGroup v5 Reason: empty/null → default; otherwise KIP-800 truncate.
fn admin_leave_reason(reason: Option<&str>) -> String {
    match reason {
        None | Some("") => DEFAULT_LEAVE_GROUP_REASON.to_string(),
        Some(r) => crate::group::truncate_group_reason(r),
    }
}

/// One static member for [`Admin::remove_members_from_consumer_group`].
///
/// Java `MemberToRemove`. Identified by Kafka `group.instance.id` (KIP-345).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MemberToRemove {
    /// Kafka `group.instance.id`.
    pub group_instance_id: String,
}

impl MemberToRemove {
    /// Remove the static member with this `group.instance.id`.
    #[must_use]
    pub fn new(group_instance_id: impl Into<String>) -> Self {
        Self {
            group_instance_id: group_instance_id.into(),
        }
    }

    /// Java `MemberToRemove.groupInstanceId`.
    #[must_use]
    pub fn group_instance_id(&self) -> &str {
        self.group_instance_id.as_str()
    }
}

impl From<&str> for MemberToRemove {
    fn from(id: &str) -> Self {
        Self::new(id)
    }
}

impl From<String> for MemberToRemove {
    fn from(id: String) -> Self {
        Self::new(id)
    }
}

/// One group's topic-partition filter (Java `ListConsumerGroupOffsetsSpec`).
///
/// `partitions: None` is every committed partition (OffsetFetch null
/// Topics). Empty `partitions` is a no-op for that group.
///
/// [`std::fmt::Display`] is Java `ListConsumerGroupOffsetsSpec.toString`
/// (`topicPartitions=null` when [`Self::all`]).
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct ListConsumerGroupOffsetsSpec {
    /// Topic-partitions to fetch. `None` is all committed partitions.
    pub partitions: Option<Vec<crate::TopicPartition>>,
}

impl ListConsumerGroupOffsetsSpec {
    /// Every committed partition (Java null `topicPartitions`).
    #[must_use]
    pub fn all() -> Self {
        Self { partitions: None }
    }

    /// Named topic-partitions (Java `ListConsumerGroupOffsetsSpec.topicPartitions`).
    #[must_use]
    pub fn topic_partitions(
        partitions: impl IntoIterator<Item = impl Into<crate::TopicPartition>>,
    ) -> Self {
        Self {
            partitions: Some(partitions.into_iter().map(Into::into).collect()),
        }
    }

    /// Java `ListConsumerGroupOffsetsSpec.topicPartitions` (`None` is all).
    #[must_use]
    pub fn partitions(&self) -> Option<&[crate::TopicPartition]> {
        self.partitions.as_deref()
    }
}

impl fmt::Display for ListConsumerGroupOffsetsSpec {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("ListConsumerGroupOffsetsSpec(topicPartitions=")?;
        match &self.partitions {
            None => f.write_str("null")?,
            Some(tps) => {
                f.write_str("[")?;
                for (i, tp) in tps.iter().enumerate() {
                    if i > 0 {
                        f.write_str(", ")?;
                    }
                    write!(f, "{tp}")?;
                }
                f.write_str("]")?;
            }
        }
        f.write_str(")")
    }
}

/// Per-member result of [`Admin::remove_members_from_consumer_group`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RemovedMember {
    /// Kafka member id from the LeaveGroup response (empty when unknown).
    pub member_id: String,
    /// Kafka `group.instance.id`, when present.
    pub group_instance_id: Option<String>,
    /// Per-member error code (`0` is success).
    pub error_code: i16,
}

impl RemovedMember {
    /// Kafka member id from the LeaveGroup response.
    #[must_use]
    pub fn member_id(&self) -> &str {
        self.member_id.as_str()
    }

    /// Kafka `group.instance.id`, when present.
    #[must_use]
    pub fn group_instance_id(&self) -> Option<&str> {
        self.group_instance_id.as_deref()
    }

    /// Per-member error code (`0` is success).
    #[must_use]
    pub fn error_code(&self) -> i16 {
        self.error_code
    }
}

/// Kafka admin client: topics, configs, ACLs, groups, and cluster operations.
pub struct Admin {
    cfg: AdminConfig,
    conn: BrokerConn,
    versions: HashMap<i16, ApiVersion>,
    create_version: i16,
    delete_version: i16,
    describe_version: Option<i16>,
    partitions_version: Option<i16>,
    alter_version: Option<i16>,
    legacy_alter_version: Option<i16>,
    delete_records_version: Option<i16>,
    describe_producers_version: Option<i16>,
    describe_cluster_version: Option<i16>,
    create_acls_version: Option<i16>,
    describe_acls_version: Option<i16>,
    delete_acls_version: Option<i16>,
    metadata_version: i16,
    /// Last Metadata body. Refilled in place and read only after a successful fetch.
    metadata_image: MetadataResponse,
    find_coord_version: Option<i16>,
    offset_delete_version: Option<i16>,
    list_reassign_version: Option<i16>,
    update_features_version: Option<i16>,
    alter_user_scram_version: Option<i16>,
    describe_user_scram_version: Option<i16>,
    unregister_broker_version: Option<i16>,
    describe_client_quotas_version: Option<i16>,
    alter_client_quotas_version: Option<i16>,
    allocate_producer_ids_version: Option<i16>,
    describe_transactions_version: Option<i16>,
    consumer_group_describe_version: Option<i16>,
    describe_groups_version: Option<i16>,
    list_groups_version: Option<i16>,
    delete_groups_version: Option<i16>,
    share_group_describe_version: Option<i16>,
    describe_share_group_offsets_version: Option<i16>,
    alter_share_group_offsets_version: Option<i16>,
    delete_share_group_offsets_version: Option<i16>,
    describe_topic_partitions_version: Option<i16>,
    list_config_resources_version: Option<i16>,
    get_telemetry_subscriptions_version: Option<i16>,
    /// Cached KIP-714 client instance UUID (`None` until first fetch).
    cached_client_instance_id: Option<[u8; 16]>,
    push_telemetry_version: Option<i16>,
    assign_replicas_to_dirs_version: Option<i16>,
    alter_replica_log_dirs_version: Option<i16>,
    create_delegation_token_version: Option<i16>,
    renew_delegation_token_version: Option<i16>,
    expire_delegation_token_version: Option<i16>,
    describe_delegation_token_version: Option<i16>,
    cluster: Cluster,
    conns: HashMap<i32, AdminOffsetConn>,
    /// ApiVersions learned for a broker address. A later dial skips the handshake.
    peer_versions: HashMap<String, Vec<ApiVersion>>,
    /// Controller broker dropped after `NOT_CONTROLLER`. Dialed again while
    /// the broker directory reloads.
    controller_redial: Option<i32>,
    reconnect_fails: HashMap<i32, u32>,
    group_coord: Option<(String, i32)>,
    group_coords: HashMap<String, i32>,
    /// Group coordinators dropped after a retriable coordinator error.
    /// Dialed again while FindCoordinator reloads those groups.
    group_coord_redial: Vec<i32>,
    txn_coord: Option<(String, i32)>,
    txn_coords: HashMap<String, i32>,
    /// Transaction coordinators dropped after a retriable coordinator error.
    /// Dialed again while FindCoordinator reloads those ids.
    txn_coord_redial: Vec<i32>,
    stats: Arc<crate::metrics::AdminTracker>,
}

/// The result of querying one broker for transactions.
///
/// A successful empty listing is a complete broker response. An error retains
/// that broker's origin; it must not be flattened into a complete cluster result.
#[derive(Debug)]
pub struct BrokerTransactionListings {
    /// Broker ID from the initial Metadata membership snapshot.
    pub broker_id: i32,
    /// Listings in the broker's response order, or that broker's failure.
    pub listings: Result<Vec<TransactionListing>>,
}

/// Bounded transaction-list filters shared by every broker query.
///
/// Defaults select every transaction. Public calls normalize a null or empty
/// pattern to no filter. Nonempty patterns require API66 v2 on each broker;
/// invalid regular expressions remain broker errors. See the raw protocol type
/// for serialization that preserves an explicitly empty pattern.
pub type ListTransactionsOptions = crate::protocol::admin::ListTransactionsRequestData;

struct ListTransactionsQuery<'a, S: AsRef<str>> {
    states: &'a [S],
    producer_ids: &'a [i64],
    duration_ms: i64,
    pattern: Option<&'a str>,
}

#[derive(Default)]
struct ListTransactionsBudget {
    listings: usize,
    response_bytes: usize,
    refreshes: usize,
    exhausted: bool,
}

fn list_transactions_retryable(error: &Error) -> bool {
    // This is an all-brokers query. A coordinator load delay retries the same
    // broker; NOT_COORDINATOR is not a request to look up an empty ID.
    matches!(error, Error::Io(_) | Error::Timeout)
        || error.broker_code() == Some(error::COORDINATOR_LOAD_IN_PROGRESS)
}

fn validate_list_transactions_body(mut bytes: &[u8], remaining_listings: usize) -> Result<()> {
    use crate::protocol::buf;
    let _ = buf::get_i32(&mut bytes)?;
    let _ = buf::get_i16(&mut bytes)?;
    let unknown = buf::get_array_len(&mut bytes, true)?
        .ok_or_else(|| Error::protocol("null ListTransactions unknown-filter array"))?;
    if unknown > 8_192 {
        return Err(Error::protocol(
            "ListTransactions unknown-filter count exceeds local limit",
        ));
    }
    for _ in 0..unknown {
        list_transactions_skip_string(&mut bytes, true, false)?;
    }
    let count = buf::get_array_len(&mut bytes, true)?
        .ok_or_else(|| Error::protocol("null ListTransactions listing array"))?;
    // Every listing includes two compact strings, an i64 and a tag count.
    if count > remaining_listings || count > bytes.len() / 11 {
        return Err(Error::protocol(
            "ListTransactions listing count exceeds local limit or body",
        ));
    }
    for _ in 0..count {
        list_transactions_skip_string(&mut bytes, true, false)?;
        let _ = buf::get_i64(&mut bytes)?;
        list_transactions_skip_string(&mut bytes, true, false)?;
        buf::skip_tagged_fields(&mut bytes)?;
    }
    buf::skip_tagged_fields(&mut bytes)?;
    if !bytes.is_empty() {
        return Err(Error::protocol("trailing ListTransactions response bytes"));
    }
    Ok(())
}

fn list_transactions_skip_string(bytes: &mut &[u8], flexible: bool, nullable: bool) -> Result<()> {
    let count = if flexible {
        let encoded = crate::protocol::buf::get_unsigned_varint(bytes)?;
        if encoded == 0 {
            if nullable {
                return Ok(());
            }
            return Err(Error::protocol("null required ListTransactions string"));
        }
        usize::try_from(encoded - 1)
            .map_err(|_| Error::protocol("ListTransactions string length overflow"))?
    } else {
        let length = crate::protocol::buf::get_i16(bytes)?;
        if length < 0 {
            if nullable && length == -1 {
                return Ok(());
            }
            return Err(Error::protocol(
                "null or invalid ListTransactions Metadata string",
            ));
        }
        usize::try_from(length)
            .map_err(|_| Error::protocol("ListTransactions Metadata string length overflow"))?
    };
    if count > 64 * 1024 || count > bytes.len() {
        return Err(Error::protocol(
            "ListTransactions string exceeds local limit or body",
        ));
    }
    let (text, remaining) = bytes.split_at(count);
    let _ =
        std::str::from_utf8(text).map_err(|_| Error::protocol("invalid ListTransactions UTF-8"))?;
    *bytes = remaining;
    Ok(())
}

fn validate_list_transactions_metadata(mut bytes: &[u8], version: i16) -> Result<()> {
    use crate::protocol::buf;
    let flexible = version >= 9;
    if version >= 3 {
        let _ = buf::get_i32(&mut bytes)?;
    }
    let brokers = buf::get_array_len(&mut bytes, flexible)?
        .ok_or_else(|| Error::protocol("null ListTransactions Metadata broker array"))?;
    if brokers == 0 || brokers > 256 {
        return Err(Error::protocol(
            "ListTransactions Metadata broker count outside 1..=256",
        ));
    }
    for _ in 0..brokers {
        let _ = buf::get_i32(&mut bytes)?;
        list_transactions_skip_string(&mut bytes, flexible, false)?;
        let port = buf::get_i32(&mut bytes)?;
        if !(1..=65_535).contains(&port) {
            return Err(Error::protocol(
                "invalid ListTransactions Metadata broker port",
            ));
        }
        if version >= 1 {
            list_transactions_skip_string(&mut bytes, flexible, true)?;
        }
        if flexible {
            buf::skip_tagged_fields(&mut bytes)?;
        }
    }
    if version >= 2 {
        list_transactions_skip_string(&mut bytes, flexible, true)?;
    }
    if version >= 1 {
        let _ = buf::get_i32(&mut bytes)?;
    }
    // This operation requests an empty topic selection. Reject a nonzero/null
    // topic count before decode_metadata_response allocates any topic vector.
    if buf::get_array_len(&mut bytes, flexible)? != Some(0) {
        return Err(Error::protocol(
            "unexpected ListTransactions Metadata topics",
        ));
    }
    if (8..=10).contains(&version) {
        let _ = buf::get_i32(&mut bytes)?;
    }
    if version >= 13 {
        let _ = buf::get_i16(&mut bytes)?;
    }
    if flexible {
        buf::skip_tagged_fields(&mut bytes)?;
    }
    if !bytes.is_empty() {
        return Err(Error::protocol("trailing ListTransactions Metadata bytes"));
    }
    Ok(())
}

pub(crate) async fn fetch_client_instance_id(
    conn: &mut BrokerConn,
    version: i16,
    timeout: Duration,
    known: [u8; 16],
) -> Result<[u8; 16]> {
    let body = conn
        .roundtrip(
            GET_TELEMETRY_SUBSCRIPTIONS,
            version,
            |buf| encode_get_telemetry_subscriptions_request(buf, &known),
            timeout,
        )
        .await?;
    let resp = decode_get_telemetry_subscriptions_response_cooperative(&mut body.clone()).await?;
    if resp.error_code != 0 {
        return Err(Error::broker(resp.error_code, "GetTelemetrySubscriptions"));
    }
    Ok(resp.client_instance_id)
}

async fn borrowed_offset_fetch_groups<'a>(
    jobs: &'a [(String, ListConsumerGroupOffsetsSpec)],
    idxs: &[usize],
) -> Result<Vec<BorrowedOffsetFetchRequestGroup<'a>>> {
    let mut groups = Vec::new();
    for &i in idxs {
        let job = jobs
            .get(i)
            .ok_or_else(|| Error::protocol("missing group spec"))?;
        let topics = match job.1.partitions.as_deref() {
            Some(parts) => {
                Some(crate::group::group_borrowed_offset_fetch_topics_cooperative(parts).await)
            }
            None => None,
        };
        groups.push(BorrowedOffsetFetchRequestGroup {
            group_id: job.0.as_str(),
            member_id: None,
            member_epoch: -1,
            topics,
        });
    }
    Ok(groups)
}

async fn listed_group_offsets(
    spec: &ListConsumerGroupOffsetsSpec,
    fetched: &[crate::protocol::group::FetchedOffsetTopic],
) -> Result<Vec<(crate::TopicPartition, crate::OffsetAndMetadata)>> {
    match &spec.partitions {
        None => {
            let map = crate::group::committed_offset_map_cooperative(fetched).await?;
            Ok(crate::group::committed_offset_pairs_cooperative(map).await)
        }
        Some(ps) => {
            crate::group::check_fetched_offsets(fetched)?;
            let index = crate::group::index_fetched_offsets_cooperative(fetched).await;
            let mut listed = Vec::with_capacity(ps.len());
            let mut walked = 0usize;
            for tp in ps {
                let md = index
                    .get(&(tp.topic.as_str(), tp.partition))
                    .copied()
                    .map(crate::group::offset_and_metadata_from)
                    .unwrap_or_else(|| crate::OffsetAndMetadata::new(-1));
                listed.push((tp.clone(), md));
                walked = walked.saturating_add(1);
                if walked == 8 * 1024 {
                    walked = 0;
                    tokio::task::yield_now().await;
                }
            }
            Ok(listed)
        }
    }
}

#[cfg(test)]
fn unique_names<'a, I>(names: I) -> Vec<&'a str>
where
    I: IntoIterator<Item = &'a str>,
{
    let mut seen: HashSet<&str> = HashSet::new();
    let mut topics = Vec::new();
    for name in names {
        if seen.insert(name) {
            topics.push(name);
        }
    }
    topics
}

fn pending_leader_chunk() -> usize {
    8 * 1024
}

/// Group each pending partition under its cached leader.
///
/// The walk pauses every 8,192 partitions. Without that pause, grouping
/// 4,000,000 partitions held the caller for 1.77 seconds.
///
/// The first time a leader is seen, it stays first. A missing leader stops
/// the walk and returns an error.
async fn group_pending_by_leader<'a>(
    cluster: &Cluster,
    parts: impl IntoIterator<Item = (usize, &'a str, i32)>,
) -> Result<(Vec<i32>, HashMap<i32, Vec<usize>>)> {
    let mut by_node: HashMap<i32, Vec<usize>> = HashMap::new();
    let mut nodes = Vec::new();
    let mut leaders = LeaderList::new();
    let mut walked = 0usize;
    for (index, topic, partition) in parts {
        walked = walked.saturating_add(1);
        let node = leaders.node(cluster, topic, partition)?;
        match by_node.entry(node) {
            std::collections::hash_map::Entry::Vacant(slot) => {
                nodes.push(node);
                let _stored = slot.insert(vec![index]);
            }
            std::collections::hash_map::Entry::Occupied(mut slot) => {
                slot.get_mut().push(index);
            }
        }
        if walked == pending_leader_chunk() {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    Ok((nodes, by_node))
}

fn missing_leader_chunk() -> usize {
    8 * 1024
}

/// List topics that do not have a cached leader.
///
/// The walk pauses every 8,192 partitions. Without that pause, listing
/// 4,000,000 partitions held the caller for 881 milliseconds.
///
/// A topic is kept once, the first time it is missing. A topic that already
/// has a leader is skipped.
async fn topics_missing_leaders<'a>(
    cluster: &Cluster,
    parts: impl IntoIterator<Item = (&'a str, i32)>,
) -> Vec<&'a str> {
    let mut need = Vec::new();
    let mut seen = HashSet::new();
    let mut leaders = LeaderList::new();
    let mut walked = 0usize;
    for (topic, partition) in parts {
        walked = walked.saturating_add(1);
        if leaders.node(cluster, topic, partition).is_err() && seen.insert(topic) {
            need.push(topic);
        }
        if walked == missing_leader_chunk() {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    need
}

fn unique_name_chunk() -> usize {
    8 * 1024
}

/// Keep the first copy of each topic name.
///
/// The walk pauses every 8,192 names. Without that pause, collecting
/// 2,000,000 names held the caller for 1.55 seconds.
///
/// Later copies of the same name are dropped. Order follows the first copy.
async fn unique_names_cooperative<'a, I>(names: I) -> Vec<&'a str>
where
    I: IntoIterator<Item = &'a str>,
{
    let mut seen: HashSet<&str> = HashSet::new();
    let mut topics = Vec::new();
    let mut walked = 0usize;
    for name in names {
        walked = walked.saturating_add(1);
        if seen.insert(name) {
            topics.push(name);
        }
        if walked == unique_name_chunk() {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    topics
}

async fn delete_records_topics<'a>(
    records: &'a [(crate::TopicPartition, i64)],
    idxs: &[usize],
) -> Vec<(&'a str, Vec<DeleteRecordsPartition>)> {
    let mut groups: Vec<(&str, Vec<DeleteRecordsPartition>)> = Vec::new();
    let mut slots: HashMap<&str, usize> = HashMap::new();
    let mut walked = 0usize;
    for &i in idxs {
        if let Some((tp, offset)) = records.get(i) {
            let part = DeleteRecordsPartition {
                partition: tp.partition,
                offset: *offset,
            };
            let topic = tp.topic.as_str();
            if let Some(&slot) = slots.get(topic) {
                if let Some((_, parts)) = groups.get_mut(slot) {
                    parts.push(part);
                }
            } else {
                let slot = groups.len();
                let _ = slots.insert(topic, slot);
                groups.push((topic, vec![part]));
            }
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    groups
}

async fn describe_producers_topics<'a>(
    partitions: &'a [crate::TopicPartition],
    idxs: &[usize],
) -> Vec<(&'a str, Vec<i32>)> {
    let mut groups: Vec<(&str, Vec<i32>)> = Vec::new();
    let mut slots: HashMap<&str, usize> = HashMap::new();
    let mut walked = 0usize;
    for &i in idxs {
        if let Some(tp) = partitions.get(i) {
            let topic = tp.topic.as_str();
            if let Some(&slot) = slots.get(topic) {
                if let Some((_, parts)) = groups.get_mut(slot) {
                    parts.push(tp.partition);
                }
            } else {
                let slot = groups.len();
                let _ = slots.insert(topic, slot);
                groups.push((topic, vec![tp.partition]));
            }
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    groups
}

type DescribeProducersNodeOutcome = (Vec<(usize, DescribeProducersPartition)>, Vec<usize>);

type LeaderEncode = Pin<Box<dyn Future<Output = Result<Bytes>> + Send>>;

struct LeaderFrame {
    api_key: i16,
    version: i16,
    body: Bytes,
    /// Encoded on the leader task so a large body can yield between partitions.
    deferred: Option<LeaderEncode>,
}

impl LeaderFrame {
    fn ready(api_key: i16, version: i16, body: Bytes) -> Self {
        Self {
            api_key,
            version,
            body,
            deferred: None,
        }
    }

    fn deferred(api_key: i16, version: i16, encode: LeaderEncode) -> Self {
        Self {
            api_key,
            version,
            body: Bytes::new(),
            deferred: Some(encode),
        }
    }
}

type LeaderExchange = HashMap<i32, (i16, Result<Bytes>)>;

fn borrowed_scram_deletions(
    deletions: &[UserScramCredentialDeletion],
) -> Vec<BorrowedScramDeletion<'_>> {
    deletions
        .iter()
        .map(|deletion| BorrowedScramDeletion {
            name: deletion.name.as_str(),
            mechanism: deletion.mechanism,
        })
        .collect()
}

fn borrowed_scram_upsertions(
    upsertions: &[UserScramCredentialUpsertion],
) -> Vec<BorrowedScramUpsertion<'_>> {
    upsertions
        .iter()
        .map(|upsertion| BorrowedScramUpsertion {
            name: upsertion.name.as_str(),
            mechanism: upsertion.mechanism,
            iterations: upsertion.iterations,
            salt: upsertion.salt.as_slice(),
            salted_password: upsertion.salted_password.as_slice(),
        })
        .collect()
}

fn borrowed_feature_updates(updates: &[FeatureUpdate]) -> Vec<BorrowedFeatureUpdate<'_>> {
    updates
        .iter()
        .map(|update| BorrowedFeatureUpdate {
            name: update.name.as_str(),
            max_version_level: update.max_version_level,
            allow_downgrade: update.allow_downgrade,
            upgrade_type: update.upgrade_type,
        })
        .collect()
}

fn borrowed_describe_configs_resources(
    resources: &[ConfigResource],
) -> Vec<BorrowedDescribeConfigsResource<'_>> {
    resources
        .iter()
        .map(|resource| BorrowedDescribeConfigsResource {
            resource_type: resource.resource_type,
            name: resource.name.as_str(),
            keys: resource.keys.as_deref(),
        })
        .collect()
}

fn borrowed_alter_configs_resources(
    updates: &[ConfigReplacement],
) -> Vec<BorrowedAlterConfigsResource<'_>> {
    updates
        .iter()
        .map(|update| BorrowedAlterConfigsResource {
            resource_type: update.resource.resource_type,
            name: update.resource.name.as_str(),
            configs: update
                .configs
                .iter()
                .map(|(name, value)| BorrowedTopicConfig {
                    name: name.as_str(),
                    value: value.as_deref(),
                })
                .collect(),
        })
        .collect()
}

fn borrowed_alterable_resources(
    updates: &[ConfigResourceUpdate],
) -> Vec<BorrowedAlterableResource<'_>> {
    updates
        .iter()
        .map(|update| BorrowedAlterableResource {
            resource_type: update.resource.resource_type,
            name: update.resource.name.as_str(),
            configs: update
                .configs
                .iter()
                .map(|config| BorrowedAlterConfig {
                    name: config.name.as_str(),
                    op: config.op,
                    value: config.value.as_deref(),
                })
                .collect(),
        })
        .collect()
}

fn creatable_from_new<'a>(
    topics: impl IntoIterator<Item = &'a NewTopic>,
) -> Vec<BorrowedCreatableTopic<'a>> {
    topics
        .into_iter()
        .map(|t| BorrowedCreatableTopic {
            name: t.name.as_str(),
            num_partitions: t.num_partitions,
            replication_factor: t.replication_factor,
            assignments: t
                .assignments
                .iter()
                .map(|(partition_index, broker_ids)| BorrowedReplicaAssignment {
                    partition_index: *partition_index,
                    broker_ids: broker_ids.as_slice(),
                })
                .collect(),
            configs: t
                .configs
                .iter()
                .map(|(name, value)| BorrowedTopicConfig {
                    name: name.as_str(),
                    value: value.as_deref(),
                })
                .collect(),
        })
        .collect()
}

fn borrowed_ids<'a, T: AsRef<str>>(ids: &'a [T], idxs: &[usize]) -> Vec<&'a str> {
    idxs.iter()
        .filter_map(|&i| ids.get(i).map(AsRef::as_ref))
        .collect()
}

type CoordinatorSlot = (i16, i32, String, i32);

async fn take_coordinator_slots(
    by_key: &mut HashMap<String, CoordinatorSlot>,
    keys: &[&str],
) -> Result<Vec<CoordinatorSlot>> {
    let mut out = Vec::with_capacity(keys.len());
    let mut walked = 0usize;
    for key in keys {
        out.push(
            by_key
                .remove(*key)
                .ok_or_else(|| Error::protocol(format!("FindCoordinator missing {key}")))?,
        );
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    Ok(out)
}

async fn index_coordinators(
    coords: Vec<crate::protocol::group::CoordinatorResult>,
) -> HashMap<String, CoordinatorSlot> {
    let mut by_key = HashMap::new();
    let mut walked = 0usize;
    for coordinator in coords {
        let _previous = by_key.insert(
            coordinator.key,
            (
                coordinator.error_code,
                coordinator.node_id,
                coordinator.host,
                coordinator.port,
            ),
        );
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    by_key
}

async fn group_named<T>(
    items: impl IntoIterator<Item = T>,
    name: impl Fn(&T) -> &str,
) -> HashMap<String, VecDeque<T>> {
    let mut grouped: HashMap<String, VecDeque<T>> = HashMap::new();
    let mut walked = 0usize;
    for item in items {
        let key = name(&item);
        if let Some(queue) = grouped.get_mut(key) {
            queue.push_back(item);
        } else {
            let owned = key.to_owned();
            let mut queue = VecDeque::new();
            queue.push_back(item);
            let _ = grouped.insert(owned, queue);
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    grouped
}

async fn first_name_index<'a, I>(names: I) -> HashMap<&'a str, usize>
where
    I: IntoIterator<Item = &'a str>,
    I::IntoIter: Send,
{
    let mut slots = HashMap::new();
    let mut walked = 0usize;
    for (index, name) in names.into_iter().enumerate() {
        if let std::collections::hash_map::Entry::Vacant(slot) = slots.entry(name) {
            let _ = slot.insert(index);
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    slots
}

struct DeletePendingIndex<'a> {
    by_name: HashMap<&'a str, usize>,
    by_id: HashMap<[u8; 16], usize>,
}

fn index_delete_selection<'a, T: DeleteTopicView>(
    topics: &'a [T],
    selected: &[usize],
) -> DeletePendingIndex<'a> {
    let mut by_name = HashMap::new();
    let mut by_id = HashMap::new();
    for &index in selected {
        let Some(topic) = topics.get(index) else {
            continue;
        };
        match topic.delete_topic_name() {
            Some(name) => {
                if let std::collections::hash_map::Entry::Vacant(slot) = by_name.entry(name) {
                    let _ = slot.insert(index);
                }
            }
            None if topic.delete_topic_id() != [0; 16] => {
                if let std::collections::hash_map::Entry::Vacant(slot) =
                    by_id.entry(topic.delete_topic_id())
                {
                    let _ = slot.insert(index);
                }
            }
            None => {}
        }
    }
    DeletePendingIndex { by_name, by_id }
}

#[cfg(test)]
use crate::protocol::admin::DeleteTopicState;

#[cfg(test)]
fn index_delete_pending(pending: &[DeleteTopicState]) -> DeletePendingIndex<'_> {
    let mut by_name = HashMap::new();
    let mut by_id = HashMap::new();
    for (index, topic) in pending.iter().enumerate() {
        match topic.name.as_deref() {
            Some(name) => {
                if let std::collections::hash_map::Entry::Vacant(slot) = by_name.entry(name) {
                    let _ = slot.insert(index);
                }
            }
            None if topic.topic_id != [0; 16] => {
                if let std::collections::hash_map::Entry::Vacant(slot) = by_id.entry(topic.topic_id)
                {
                    let _ = slot.insert(index);
                }
            }
            None => {}
        }
    }
    DeletePendingIndex { by_name, by_id }
}

fn delete_pending_slot(index: &DeletePendingIndex<'_>, result: &TopicResult) -> Option<usize> {
    let by_name = index.by_name.get(result.name.as_str()).copied();
    let by_id = (result.topic_id != [0; 16])
        .then(|| index.by_id.get(&result.topic_id).copied())
        .flatten();
    match (by_name, by_id) {
        (Some(name), Some(id)) => Some(name.min(id)),
        (Some(name), None) => Some(name),
        (None, Some(id)) => Some(id),
        (None, None) => None,
    }
}

fn delete_state_matches(topic: &impl DeleteTopicView, result: &TopicResult) -> bool {
    match topic.delete_topic_name() {
        Some(name) => name == result.name,
        None => topic.delete_topic_id() != [0; 16] && topic.delete_topic_id() == result.topic_id,
    }
}

fn partitions_from_new<'a>(
    topics: impl IntoIterator<Item = &'a NewPartitions>,
) -> Vec<BorrowedCreatePartitionsTopic<'a>> {
    topics
        .into_iter()
        .map(|t| BorrowedCreatePartitionsTopic {
            name: t.name.as_str(),
            count: t.total_count,
            assignments: t.assignments.as_deref(),
        })
        .collect()
}

fn startup_remaining(deadline: Instant) -> Result<Duration> {
    let remaining = deadline.saturating_duration_since(Instant::now());
    if remaining.is_zero() {
        Err(Error::Timeout)
    } else {
        Ok(remaining)
    }
}

async fn dial_admin_socket(
    addr: &str,
    cfg: &AdminConfig,
    stats: &Arc<crate::metrics::AdminTracker>,
    deadline: Instant,
) -> Result<AdminOffsetConn> {
    let opened = async {
        let rest = deadline.saturating_duration_since(Instant::now());
        if rest.is_zero() {
            return Err(Error::Timeout);
        }
        let mut conn = BrokerConn::connect_tls(
            addr,
            &cfg.client_id,
            cfg.connect_timeout.min(rest),
            cfg.tls.as_ref(),
        )
        .await?;
        conn.set_stats(Arc::clone(stats));
        let rest = deadline.saturating_duration_since(Instant::now());
        if rest.is_zero() {
            return Err(Error::Timeout);
        }
        let versions_resp = crate::protocol::api::negotiate_api_versions(&mut conn, rest).await?;
        sasl::apply_api_keys(&mut conn, &versions_resp.api_keys);
        let rest = deadline.saturating_duration_since(Instant::now());
        if rest.is_zero() {
            return Err(Error::Timeout);
        }
        sasl::authenticate(
            &mut conn,
            cfg.sasl_plain.as_ref(),
            cfg.sasl_scram.as_ref(),
            cfg.sasl_scram_sha512.as_ref(),
            cfg.sasl_oauthbearer.as_deref(),
            cfg.sasl_oauthbearer_oidc.as_ref(),
            rest,
        )
        .await?;
        Ok(AdminOffsetConn::new(conn, &versions_resp))
    }
    .await;
    // A failed handshake drops its socket in this call. Yield so the broker
    // observes that close before the error returns. A successful dial keeps
    // the socket and does not wait.
    if opened.is_err() {
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }
    }
    opened
}

async fn dial_known_admin_socket(
    addr: &str,
    cfg: &AdminConfig,
    stats: &Arc<crate::metrics::AdminTracker>,
    keys: &[ApiVersion],
    deadline: Instant,
) -> Result<AdminOffsetConn> {
    let opened = async {
        let rest = deadline.saturating_duration_since(Instant::now());
        if rest.is_zero() {
            return Err(Error::Timeout);
        }
        let mut conn = BrokerConn::connect_tls(
            addr,
            &cfg.client_id,
            cfg.connect_timeout.min(rest),
            cfg.tls.as_ref(),
        )
        .await?;
        conn.set_stats(Arc::clone(stats));
        let versions_resp = ApiVersionsResponse {
            error_code: 0,
            api_keys: keys.to_vec(),
            throttle_time_ms: 0,
            supported_features: Vec::new(),
            finalized_features_epoch: None,
            finalized_features: Vec::new(),
            zk_migration_ready: false,
        };
        sasl::apply_api_keys(&mut conn, &versions_resp.api_keys);
        let rest = deadline.saturating_duration_since(Instant::now());
        if rest.is_zero() {
            return Err(Error::Timeout);
        }
        sasl::authenticate(
            &mut conn,
            cfg.sasl_plain.as_ref(),
            cfg.sasl_scram.as_ref(),
            cfg.sasl_scram_sha512.as_ref(),
            cfg.sasl_oauthbearer.as_deref(),
            cfg.sasl_oauthbearer_oidc.as_ref(),
            rest,
        )
        .await?;
        Ok(AdminOffsetConn::new(conn, &versions_resp))
    }
    .await;
    if opened.is_err() {
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }
    }
    opened
}

async fn dial_admin_peer(
    addr: &str,
    cfg: &AdminConfig,
    stats: &Arc<crate::metrics::AdminTracker>,
    keys: &[ApiVersion],
    deadline: Instant,
) -> Result<AdminOffsetConn> {
    if keys.is_empty() {
        dial_admin_socket(addr, cfg, stats, deadline).await
    } else {
        dial_known_admin_socket(addr, cfg, stats, keys, deadline).await
    }
}

impl Admin {
    /// Add a metadata-quorum voter (KIP-853), using AddRaftVoter v0 or v1.
    ///
    /// Broker-bootstrap clients send through a broker, which forwards to the
    /// active controller, matching pinned Java 4.1. Controller bootstrap is not
    /// supported. Requires a nonnegative voter ID, a nonreserved directory UUID
    /// and at least one valid endpoint with unique listener names. These checks
    /// run before I/O. The controller determines membership and feature support.
    ///
    /// The default [`AddRaftVoterOptions::ack_when_committed`] is true: negotiate
    /// the highest of v0 and v1, and a successful response is
    /// [`RaftVoterAcknowledgement::Committed`]. v0 has no other mode. Kafka 4.1
    /// advertises only v0, so that fallback is the schema default, not a
    /// separately measured 4.1 Raft commit. Explicit `false` is not a Java
    /// public option. It requires v1 and is rejected with
    /// [`Error::Unsupported`] before any AddRaftVoter frame when the broker's
    /// maximum is below 1. A successful false result is
    /// [`RaftVoterAcknowledgement::LocalAppend`]: the leader wrote the change
    /// locally. That is not a committed or voting membership.
    ///
    /// Only NOT_CONTROLLER and transport failures are retried within one total
    /// deadline. Other broker errors preserve their code/message, including
    /// duplicate voter and server-side timeout, and are not returned as a
    /// successful acknowledgement. A lost response can leave the membership
    /// outcome ambiguous; inspect the quorum before another change. Success
    /// retains the broker's throttle time in the typed response.
    pub async fn add_raft_voter(
        &mut self,
        voter_id: i32,
        voter_directory_id: Uuid,
        endpoints: Vec<RaftVoterEndpoint>,
        options: AddRaftVoterOptions,
    ) -> Result<AddRaftVoterResponse> {
        if voter_id < 0 || Uuid::RESERVED.contains(&voter_directory_id) {
            return Err(Error::protocol(
                "voter ID must be nonnegative and directory UUID nonreserved",
            ));
        }
        if endpoints.is_empty() {
            return Err(Error::protocol("at least one voter endpoint is required"));
        }
        let mut names = std::collections::HashSet::with_capacity(endpoints.len());
        for endpoint in &endpoints {
            endpoint.validate()?;
            if !names.insert(&endpoint.listener) {
                return Err(Error::protocol("duplicate voter listener name"));
            }
        }
        if options.cluster_id.as_ref().is_some_and(String::is_empty) {
            return Err(Error::protocol("expected cluster ID must not be empty"));
        }
        let timeout = options.timeout.unwrap_or(self.cfg.request_timeout);
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let deadline = Instant::now()
            .checked_add(timeout)
            .ok_or_else(|| Error::protocol("quorum timeout exceeds clock range"))?;
        let request = crate::protocol::admin::AddRaftVoterRequest {
            cluster_id: options.cluster_id,
            timeout_ms: 0,
            voter_id,
            voter_directory_id: voter_directory_id.to_bytes(),
            listeners: endpoints,
            ack_when_committed: options.ack_when_committed,
        };
        self.add_raft_voter_until(request, deadline).await
    }

    async fn add_raft_voter_until(
        &mut self,
        mut request: crate::protocol::admin::AddRaftVoterRequest,
        deadline: Instant,
    ) -> Result<AddRaftVoterResponse> {
        let mut attempt = 0;
        let mut reconnect = false;
        let mut refresh = false;
        loop {
            let result = async {
                if reconnect {
                    let addr = self.conn.addr().to_owned();
                    let opened = self.open_node_conn_until(&addr, deadline).await?;
                    self.adopt_bootstrap(opened).await?;
                    reconnect = false;
                }
                self.ensure_bootstrap(deadline).await?;
                let (want_min, want_max) = if request.ack_when_committed {
                    (0, 1)
                } else {
                    (1, 1)
                };
                let version = self
                    .negotiated(
                        crate::protocol::api_keys::ADD_RAFT_VOTER,
                        want_min,
                        want_max,
                    )
                    .ok_or_else(|| {
                        if request.ack_when_committed {
                            Error::Unsupported(
                                "broker does not support AddRaftVoter v0 or v1".into(),
                            )
                        } else {
                            Error::Unsupported(
                                "AddRaftVoter local-append acknowledgement requires v1".into(),
                            )
                        }
                    })?;
                if refresh {
                    self.refresh_broker_directory(deadline).await?;
                    refresh = false;
                }
                let remaining = deadline.saturating_duration_since(Instant::now());
                if remaining.is_zero() {
                    return Err(Error::Timeout);
                }
                request.timeout_ms = i32::try_from(remaining.as_millis())
                    .unwrap_or(i32::MAX)
                    .max(1);
                let mut body = self
                    .conn
                    .roundtrip(
                        crate::protocol::api_keys::ADD_RAFT_VOTER,
                        version,
                        |buf| {
                            crate::protocol::admin::encode_add_raft_voter_request(
                                buf, version, &request,
                            )
                        },
                        remaining,
                    )
                    .await?;
                let mut response =
                    crate::protocol::admin::decode_add_raft_voter_response(&mut body, version)?;
                if !body.is_empty() {
                    return Err(Error::protocol("trailing AddRaftVoter response bytes"));
                }
                if response.error_code != 0 {
                    return Err(Error::broker(
                        response.error_code,
                        response
                            .error_message
                            .unwrap_or_else(|| "AddRaftVoter".into()),
                    ));
                }
                if !request.ack_when_committed {
                    response.acknowledgement =
                        crate::protocol::admin::RaftVoterAcknowledgement::LocalAppend;
                }
                Ok(response)
            }
            .await;
            match result {
                Err(err)
                    if err.broker_code() == Some(error::NOT_CONTROLLER)
                        || matches!(err, Error::Io(_) | Error::Closed | Error::Timeout) =>
                {
                    if err.broker_code() == Some(error::NOT_CONTROLLER) {
                        self.forget_controller();
                        refresh = true;
                    } else {
                        reconnect = true;
                    }
                    self.wait_retry(&mut attempt, deadline).await?;
                }
                result => return result,
            }
        }
    }

    /// Remove one metadata-quorum voter by replica and directory identity.
    ///
    /// Matches pinned Java 4.1 RemoveRaftVoter v0 for broker-bootstrap clients:
    /// the broker forwards to the active controller. Direct controller bootstrap
    /// is not supported. Rejects negative voter IDs, reserved directory UUIDs
    /// and empty expected cluster IDs before I/O. There is no server TimeoutMs
    /// field; the total local deadline bounds discovery, authentication,
    /// capability negotiation, metadata refresh, RPC and retry waits.
    ///
    /// Only NOT_CONTROLLER and transport failures retry. Other broker errors
    /// preserve code/message, including authorization and VOTER_NOT_FOUND. A
    /// lost response may leave the membership outcome ambiguous; not-found after
    /// retry is an error, not confirmed success. Inspect the quorum before a
    /// subsequent membership change. Success retains broker throttle time.
    pub async fn remove_raft_voter(
        &mut self,
        voter_id: i32,
        voter_directory_id: Uuid,
        options: RemoveRaftVoterOptions,
    ) -> Result<RemoveRaftVoterResponse> {
        if voter_id < 0 || Uuid::RESERVED.contains(&voter_directory_id) {
            return Err(Error::protocol(
                "voter ID must be nonnegative and directory UUID nonreserved",
            ));
        }
        if options.cluster_id.as_ref().is_some_and(String::is_empty) {
            return Err(Error::protocol("expected cluster ID must not be empty"));
        }
        let timeout = options.timeout.unwrap_or(self.cfg.request_timeout);
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let deadline = Instant::now()
            .checked_add(timeout)
            .ok_or_else(|| Error::protocol("quorum timeout exceeds clock range"))?;
        let request = crate::protocol::admin::RemoveRaftVoterRequest {
            cluster_id: options.cluster_id,
            voter_id,
            voter_directory_id: voter_directory_id.to_bytes(),
        };
        self.remove_raft_voter_until(request, deadline).await
    }

    async fn remove_raft_voter_until(
        &mut self,
        request: crate::protocol::admin::RemoveRaftVoterRequest,
        deadline: Instant,
    ) -> Result<RemoveRaftVoterResponse> {
        let mut attempt = 0;
        let mut reconnect = false;
        let mut refresh = false;
        loop {
            let result = async {
                if reconnect {
                    let addr = self.conn.addr().to_owned();
                    let opened = self.open_node_conn_until(&addr, deadline).await?;
                    self.adopt_bootstrap(opened).await?;
                    reconnect = false;
                }
                self.ensure_bootstrap(deadline).await?;
                let version = self
                    .negotiated(crate::protocol::api_keys::REMOVE_RAFT_VOTER, 0, 0)
                    .ok_or_else(|| {
                        Error::Unsupported("broker does not support RemoveRaftVoter v0".into())
                    })?;
                if refresh {
                    self.refresh_broker_directory(deadline).await?;
                    refresh = false;
                }
                let remaining = deadline.saturating_duration_since(Instant::now());
                if remaining.is_zero() {
                    return Err(Error::Timeout);
                }
                let mut body = self
                    .conn
                    .roundtrip(
                        crate::protocol::api_keys::REMOVE_RAFT_VOTER,
                        version,
                        |buf| {
                            crate::protocol::admin::encode_remove_raft_voter_request(
                                buf, version, &request,
                            )
                        },
                        remaining,
                    )
                    .await?;
                let response =
                    crate::protocol::admin::decode_remove_raft_voter_response(&mut body, version)?;
                if !body.is_empty() {
                    return Err(Error::protocol("trailing RemoveRaftVoter response bytes"));
                }
                if response.error_code != 0 {
                    return Err(Error::broker(
                        response.error_code,
                        response
                            .error_message
                            .unwrap_or_else(|| "RemoveRaftVoter".into()),
                    ));
                }
                Ok(response)
            }
            .await;
            match result {
                Err(err)
                    if err.broker_code() == Some(error::NOT_CONTROLLER)
                        || matches!(err, Error::Io(_) | Error::Closed | Error::Timeout) =>
                {
                    if err.broker_code() == Some(error::NOT_CONTROLLER) {
                        self.forget_controller();
                        refresh = true;
                    } else {
                        reconnect = true;
                    }
                    self.wait_retry(&mut attempt, deadline).await?;
                }
                result => return result,
            }
        }
    }

    /// Inspect the metadata quorum (`__cluster_metadata`, partition 0).
    ///
    /// Matches Java `describeMetadataQuorum` for broker-bootstrap clients:
    /// the connected broker forwards to the active controller. Negotiates
    /// DescribeQuorum v0–v2 on the connected peer, including after reconnect.
    /// v0 has no fetch timestamps; v1 has no directory IDs or node endpoints.
    /// Their documented unknown sentinels are retained in the typed result.
    /// Top-level and partition errors retain the broker's code and message.
    /// NOT_CONTROLLER refreshes metadata; retriable broker/transport errors
    /// share one deadline and at most eight attempts. Exhaustion returns the
    /// last error. No quorum membership is changed.
    pub async fn describe_quorum(&mut self) -> Result<QuorumInfo> {
        self.describe_quorum_timeout(self.cfg.request_timeout).await
    }

    /// [`Self::describe_quorum`] with a total operation deadline, including
    /// reconnect, authentication, capability negotiation and retries.
    pub async fn describe_quorum_timeout(&mut self, timeout: Duration) -> Result<QuorumInfo> {
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let deadline = Instant::now()
            .checked_add(timeout)
            .ok_or_else(|| Error::protocol("quorum timeout exceeds clock range"))?;
        self.describe_quorum_until(deadline).await
    }

    async fn describe_quorum_until(&mut self, deadline: Instant) -> Result<QuorumInfo> {
        let mut attempt = 0;
        let mut reconnect = false;
        let mut refresh = false;
        loop {
            let result = async {
                if reconnect {
                    let addr = self.conn.addr().to_owned();
                    let opened = self.open_node_conn_until(&addr, deadline).await?;
                    self.adopt_bootstrap(opened).await?;
                    reconnect = false;
                }
                self.ensure_bootstrap(deadline).await?;
                let version = self
                    .negotiated(crate::protocol::api_keys::DESCRIBE_QUORUM, 0, 2)
                    .ok_or_else(|| {
                        Error::Unsupported("broker does not support DescribeQuorum v0-2".into())
                    })?;
                if refresh {
                    self.refresh_broker_directory(deadline).await?;
                    refresh = false;
                }
                let remaining = deadline.saturating_duration_since(Instant::now());
                if remaining.is_zero() {
                    return Err(Error::Timeout);
                }
                let partitions = [0];
                let topics = [("__cluster_metadata", partitions.as_slice())];
                let mut body = self
                    .conn
                    .roundtrip(
                        crate::protocol::api_keys::DESCRIBE_QUORUM,
                        version,
                        |buf| {
                            crate::protocol::admin::encode_describe_quorum_topics(
                                buf, version, &topics,
                            )
                        },
                        remaining,
                    )
                    .await?;
                let response =
                    crate::protocol::admin::decode_describe_quorum_response(&mut body, version)?;
                if !body.is_empty() {
                    return Err(Error::protocol("trailing DescribeQuorum response bytes"));
                }
                if response.error_code != 0 {
                    return Err(Error::broker(
                        response.error_code,
                        response
                            .error_message
                            .unwrap_or_else(|| "DescribeQuorum".into()),
                    ));
                }
                let mut topics = response.topics.into_iter();
                let topic = match (topics.next(), topics.next()) {
                    (Some(topic), None) if topic.topic == "__cluster_metadata" => topic,
                    _ => {
                        return Err(Error::protocol(
                            "DescribeQuorum must return only __cluster_metadata",
                        ))
                    }
                };
                let mut partitions = topic.partitions.into_iter();
                let partition = match (partitions.next(), partitions.next()) {
                    (Some(partition), None) if partition.partition_index == 0 => partition,
                    _ => {
                        return Err(Error::protocol(
                            "DescribeQuorum must return only metadata partition 0",
                        ))
                    }
                };
                if partition.error_code != 0 {
                    return Err(Error::broker(
                        partition.error_code,
                        partition
                            .error_message
                            .unwrap_or_else(|| "DescribeQuorum partition 0".into()),
                    ));
                }
                Ok(QuorumInfo {
                    leader_id: partition.leader_id,
                    leader_epoch: partition.leader_epoch,
                    high_watermark: partition.high_watermark,
                    voters: partition.current_voters,
                    observers: partition.observers,
                    nodes: response.nodes,
                })
            }
            .await;
            match result {
                Err(err) if err.is_retriable() || matches!(err, Error::Closed) => {
                    if attempt >= 7 {
                        return Err(err);
                    }
                    if err.broker_code() == Some(error::NOT_CONTROLLER) {
                        self.forget_controller();
                        refresh = true;
                    }
                    if matches!(err, Error::Io(_) | Error::Closed | Error::Timeout) {
                        reconnect = true;
                    }
                    self.wait_retry(&mut attempt, deadline).await?;
                }
                result => return result,
            }
        }
    }

    /// Elect leaders with typed policy and partition selection (KIP-460).
    ///
    /// Routes to the Metadata controller and negotiates v0–v2 on that node,
    /// including after a controller change. v0 supports preferred elections
    /// only; an unclean request never silently downgrades to preferred.
    /// Successful and terminal partition results survive retries of other
    /// partitions. Only NOT_CONTROLLER and retriable transport failures retry.
    ///
    /// The response retains individual broker codes/messages. A top-level
    /// error on a known selection becomes each outstanding partition's error;
    /// when selecting all partitions and the broker cannot enumerate them,
    /// that error is returned as [`Error::Broker`]. A deadline failure can be
    /// ambiguous: an election may have happened before the response was lost.
    /// Unclean election can lose data; use it only with explicit operator intent.
    pub async fn elect_leaders(
        &mut self,
        options: ElectLeadersOptions,
    ) -> Result<ElectLeadersResponse> {
        if let Some(partitions) = &options.partitions {
            if partitions.iter().any(|tp| tp.partition < 0) {
                return Err(Error::protocol("election partition must be nonnegative"));
            }
        }
        let timeout = options.timeout.unwrap_or(self.cfg.request_timeout);
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let deadline = Instant::now()
            .checked_add(timeout)
            .ok_or_else(|| Error::protocol("election timeout exceeds clock range"))?;
        self.elect_leaders_until(options, deadline).await
    }

    async fn elect_leaders_until(
        &mut self,
        options: ElectLeadersOptions,
        deadline: Instant,
    ) -> Result<ElectLeadersResponse> {
        let mut selection = ElectionSelection::default();
        let (mut order, mut pending) = if let Some(partitions) = options.partitions {
            let (order, kept) = record_election_partitions(&mut selection, partitions).await;
            (order, Some(kept))
        } else {
            (Vec::new(), None)
        };
        let mut finished: HashMap<String, HashMap<i32, ElectLeadersPartitionResult>> =
            HashMap::new();
        let mut throttle_time_ms = 0;
        let mut attempt = 0;
        loop {
            if self.cluster.controller().is_err() {
                self.refresh_broker_directory(deadline).await?;
            }
            let node = self.cluster.controller()?;
            self.prepare_node_until(node, deadline).await?;
            // The controller socket's own handshake selects the schema.
            // The bootstrap handshake is that socket when the controller is the bootstrap broker.
            let version = self
                .negotiated_on(node, crate::protocol::api_keys::ELECT_LEADERS, 0, 2)
                .ok_or_else(|| {
                    Error::Unsupported("controller does not support ElectLeaders v0-2".into())
                })?;
            if version == 0 && options.election_type == ElectionType::Unclean {
                return Err(Error::Unsupported(
                    "unclean election requires ElectLeaders v1+".into(),
                ));
            }
            let topics = pending
                .as_ref()
                .map(|partitions| election_request_topics(&selection.names, partitions));
            let remaining = deadline.saturating_duration_since(Instant::now());
            if remaining.is_zero() {
                return Err(Error::Timeout);
            }
            let election_type = options.election_type.wire();
            let timeout_ms = crate::consumer::duration_millis_i32(remaining);
            let mut payload = BytesMut::new();
            crate::protocol::admin::encode_elect_leaders_named_cooperative(
                &mut payload,
                version,
                election_type,
                topics.as_deref(),
                timeout_ms,
            )
            .await?;
            let body = self
                .roundtrip_known_node(
                    node,
                    deadline,
                    crate::protocol::api_keys::ELECT_LEADERS,
                    version,
                    |buf| {
                        buf.extend_from_slice(&payload);
                        Ok(())
                    },
                    remaining,
                )
                .await;
            let body = match body {
                Ok(body) => body,
                Err(err) if err.is_retriable() || matches!(err, Error::Closed) => {
                    self.drop_node_conn(node).await;
                    self.forget_controller();
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(err) => return Err(err),
            };
            let mut response = crate::protocol::admin::decode_elect_leaders_response_cooperative(
                &mut body.clone(),
                version,
            )
            .await?;
            throttle_time_ms = throttle_time_ms.max(response.throttle_time_ms);
            if response.error_code == error::NOT_CONTROLLER {
                self.drop_node_conn(node).await;
                self.forget_controller();
                self.wait_retry(&mut attempt, deadline).await?;
                continue;
            }
            if response.error_code != 0 {
                let Some(partitions) = &pending else {
                    return Err(Error::broker(response.error_code, "ElectLeaders"));
                };
                // Keep earlier results when a retry receives a terminal global error.
                let mut results: Vec<ElectLeadersResult> = Vec::new();
                let mut slots: Vec<Option<usize>> = Vec::new();
                for &(index, partition) in partitions {
                    let part = ElectLeadersPartitionResult {
                        partition_id: partition,
                        error_code: response.error_code,
                        error_message: None,
                    };
                    if let Some(Some(slot)) = slots.get(index).copied() {
                        if let Some(topic) = results.get_mut(slot) {
                            topic.partitions.push(part);
                            continue;
                        }
                    }
                    let Some(name) = selection.names.get(index) else {
                        return Err(Error::protocol("missing ElectLeaders topic"));
                    };
                    let slot = results.len();
                    if slots.len() <= index {
                        slots.resize_with(index.saturating_add(1), || None);
                    }
                    if let Some(entry) = slots.get_mut(index) {
                        *entry = Some(slot);
                    }
                    results.push(ElectLeadersResult {
                        topic: name.clone(),
                        partitions: vec![part],
                    });
                }
                response.results = results;
            }
            let mut returned: Vec<HashSet<i32>> = Vec::new();
            let mut retry = Vec::new();
            for topic in response.results {
                let mut added = Vec::new();
                for partition in topic.partitions {
                    let index = selection.name_index(&topic.topic);
                    let duplicate = !mark_returned(&mut returned, index, partition.partition_id);
                    let unexpected =
                        pending.is_some() && !selection.contains(index, partition.partition_id);
                    if duplicate || unexpected {
                        return Err(Error::protocol(
                            "unexpected or duplicate ElectLeaders partition result",
                        ));
                    }
                    if !selection.contains(index, partition.partition_id) {
                        if let Some(parts) = selection.parts.get_mut(index) {
                            let _ = parts.insert(partition.partition_id);
                        }
                        order.push((index, partition.partition_id));
                    }
                    if partition.error_code == error::NOT_CONTROLLER {
                        retry.push((index, partition.partition_id));
                    } else {
                        added.push(partition);
                    }
                }
                if added.is_empty() {
                    continue;
                }
                if let Some(parts) = finished.get_mut(topic.topic.as_str()) {
                    for partition in added {
                        let _ = parts.insert(partition.partition_id, partition);
                    }
                } else {
                    let mut parts = HashMap::new();
                    for partition in added {
                        let _ = parts.insert(partition.partition_id, partition);
                    }
                    let _ = finished.insert(topic.topic, parts);
                }
            }
            if pending.as_ref().is_some_and(|ps| {
                ps.iter().any(|&(index, partition)| {
                    returned
                        .get(index)
                        .is_none_or(|parts| !parts.contains(&partition))
                })
            }) {
                return Err(Error::protocol("missing ElectLeaders partition result"));
            }
            if !retry.is_empty() {
                pending = Some(retry);
                self.discard_node_conn(node).await;
                self.forget_controller();
                self.wait_retry(&mut attempt, deadline).await?;
                continue;
            }
            let grouped = {
                let mut grouped: Vec<(usize, Vec<ElectLeadersPartitionResult>)> = Vec::new();
                let mut slots: Vec<Option<usize>> = Vec::new();
                for &(name_index, partition_id) in &order {
                    let name = selection
                        .names
                        .get(name_index)
                        .map(String::as_str)
                        .ok_or_else(|| Error::protocol("missing final ElectLeaders result"))?;
                    let partition = finished
                        .get_mut(name)
                        .and_then(|parts| parts.remove(&partition_id))
                        .ok_or_else(|| Error::protocol("missing final ElectLeaders result"))?;
                    if let Some(Some(slot)) = slots.get(name_index).copied() {
                        if let Some((_, parts)) = grouped.get_mut(slot) {
                            parts.push(partition);
                            continue;
                        }
                    }
                    let slot = grouped.len();
                    if slots.len() <= name_index {
                        slots.resize_with(name_index.saturating_add(1), || None);
                    }
                    if let Some(entry) = slots.get_mut(name_index) {
                        *entry = Some(slot);
                    }
                    grouped.push((name_index, vec![partition]));
                }
                grouped
            };
            let mut results = Vec::with_capacity(grouped.len());
            for (index, partitions) in grouped {
                let topic = selection
                    .names
                    .get_mut(index)
                    .map(std::mem::take)
                    .ok_or_else(|| Error::protocol("missing final ElectLeaders result"))?;
                results.push(ElectLeadersResult { topic, partitions });
            }
            return Ok(ElectLeadersResponse::new(throttle_time_ms, 0, results));
        }
    }

    /// Connect with default config to one bootstrap server.
    pub async fn connect(bootstrap: impl Into<String>) -> Result<Self> {
        Self::new(AdminConfig::bootstrap([bootstrap.into()])).await
    }

    /// Connect using `cfg`. Negotiates ApiVersions and optional SASL/TLS.
    ///
    /// Several bootstraps race that handshake. The first one to finish is
    /// kept, so a peer that accepts TCP and then stalls cannot hold a
    /// reachable broker for the whole connect timeout.
    ///
    /// CreateTopics, DeleteTopics, and Metadata are required at connect.
    /// Configuration, partition expansion, record deletion, ACL, coordinator,
    /// and group APIs are optional; missing APIs fail on the method with
    /// [`Error::Unsupported`] before discovery or dispatch.
    ///
    /// DescribeTopicPartitions, ConsumerGroupDescribe, ShareGroupDescribe,
    /// the share-offset RPCs, AllocateProducerIds, ListConfigResources,
    /// GetTelemetrySubscriptions, PushTelemetry, AssignReplicasToDirs,
    /// UnregisterBroker, DescribeProducers, DescribeCluster,
    /// UpdateFeatures, DescribeClientQuotas, AlterClientQuotas,
    /// AlterUserScramCredentials, DescribeUserScramCredentials,
    /// AlterReplicaLogDirs, DescribeLogDirs, the delegation-token APIs,
    /// DescribeTransactions, ListTransactions, AlterPartitionReassignments,
    /// ListPartitionReassignments, OffsetDelete, and IncrementalAlterConfigs
    /// are optional at connect. Missing APIs fail on the method with
    /// [`Error::Unsupported`].
    pub async fn new(cfg: AdminConfig) -> Result<Self> {
        let deadline = Instant::now()
            .checked_add(cfg.request_timeout)
            .ok_or(Error::Timeout)?;
        crate::net::Deadline::from_std(deadline)
            .run(Self::new_until(cfg, deadline))
            .await
    }

    /// TCP, ApiVersions, and SASL on one bootstrap, bounded by `deadline`.
    async fn open_one_bootstrap(
        cfg: &AdminConfig,
        addr: &str,
        stats: &Arc<crate::metrics::AdminTracker>,
        deadline: Instant,
    ) -> Result<(BrokerConn, crate::protocol::api::ApiVersionsResponse)> {
        let opened = async {
            let mut conn = BrokerConn::connect_tls(
                addr,
                &cfg.client_id,
                cfg.connect_timeout.min(startup_remaining(deadline)?),
                cfg.tls.as_ref(),
            )
            .await?;
            conn.set_stats(Arc::clone(stats));
            let resp = crate::protocol::api::negotiate_api_versions(
                &mut conn,
                startup_remaining(deadline)?,
            )
            .await?;
            sasl::apply_api_keys(&mut conn, &resp.api_keys);
            sasl::authenticate(
                &mut conn,
                cfg.sasl_plain.as_ref(),
                cfg.sasl_scram.as_ref(),
                cfg.sasl_scram_sha512.as_ref(),
                cfg.sasl_oauthbearer.as_deref(),
                cfg.sasl_oauthbearer_oidc.as_ref(),
                startup_remaining(deadline)?,
            )
            .await?;
            Ok((conn, resp))
        }
        .await;
        // A failed handshake drops its socket in this call. Yield so the broker
        // observes that close before the error returns. A successful dial keeps
        // the socket and does not wait.
        if opened.is_err() {
            for _ in 0..8 {
                tokio::task::yield_now().await;
            }
        }
        opened
    }

    /// Race bootstrap handshakes and return as soon as the losers have stopped.
    ///
    /// [`Self::new`] continues with cluster metadata after this race, and those
    /// later awaits hide a handshake that was only aborted.
    #[doc(hidden)]
    pub async fn test_race_bootstrap(cfg: AdminConfig) -> Result<()> {
        let deadline = Instant::now()
            .checked_add(cfg.request_timeout)
            .ok_or(Error::Timeout)?;
        let stats = Arc::new(crate::metrics::AdminTracker::default());
        let _opened = Self::open_bootstrap(&cfg, &stats, deadline).await?;
        Ok(())
    }

    /// Cancel handshakes that lost the bootstrap race and wait until they stop.
    ///
    /// Abort only schedules cancellation. On a current-thread runtime a read
    /// stays inside the broker until this caller yields.
    async fn finish_aborted_handshakes(
        mut set: tokio::task::JoinSet<
            Result<(BrokerConn, crate::protocol::api::ApiVersionsResponse)>,
        >,
    ) {
        set.abort_all();
        let mut extra = 0u32;
        while !set.is_empty() {
            tokio::select! {
                biased;
                joined = set.join_next() => {
                    let Some(joined) = joined else {
                        break;
                    };
                    if let Ok(Ok((mut conn, _))) = joined {
                        Self::retire_admin_socket(&mut conn).await;
                    }
                }
                () = tokio::task::yield_now() => {
                    extra = extra.saturating_add(1);
                    if extra >= 8 {
                        break;
                    }
                }
            }
        }
        // A cancelled admin handshake drops its socket when the task is polled.
        // The idle watch then has to run before that broker sees the close.
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }
    }

    pub(crate) async fn finish_aborted_indexed_handshakes(
        mut set: tokio::task::JoinSet<(
            usize,
            Result<(BrokerConn, crate::protocol::api::ApiVersionsResponse)>,
        )>,
    ) {
        set.abort_all();
        let mut extra = 0u32;
        while !set.is_empty() {
            tokio::select! {
                biased;
                joined = set.join_next() => {
                    let Some(joined) = joined else {
                        break;
                    };
                    if let Ok((_, Ok((mut conn, _)))) = joined {
                        Self::retire_admin_socket(&mut conn).await;
                    }
                }
                () = tokio::task::yield_now() => {
                    extra = extra.saturating_add(1);
                    if extra >= 8 {
                        break;
                    }
                }
            }
        }
        // A cancelled indexed handshake drops its socket when the task is polled.
        // The idle watch then has to run before that broker sees the close.
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }
    }

    /// Handshake every bootstrap together and keep the first full success.
    ///
    /// Handshakes that finish with the first one are returned as learned
    /// versions. A later dial to one of those brokers skips ApiVersions.
    async fn open_bootstrap(
        cfg: &AdminConfig,
        stats: &Arc<crate::metrics::AdminTracker>,
        deadline: Instant,
    ) -> Result<(
        BrokerConn,
        crate::protocol::api::ApiVersionsResponse,
        Vec<(String, Vec<ApiVersion>)>,
    )> {
        if cfg.bootstrap.len() <= 1 {
            let addr = cfg
                .bootstrap
                .first()
                .ok_or_else(|| Error::protocol("all bootstrap servers failed"))?;
            let (conn, resp) = Self::open_one_bootstrap(cfg, addr, stats, deadline).await?;
            return Ok((conn, resp, Vec::new()));
        }
        let mut inflight = tokio::task::JoinSet::new();
        for addr in &cfg.bootstrap {
            let cfg = cfg.clone();
            let addr = addr.clone();
            let stats = Arc::clone(stats);
            let _ = inflight.spawn(async move {
                Admin::open_one_bootstrap(&cfg, &addr, &stats, deadline).await
            });
        }
        let mut last = Error::protocol("all bootstrap servers failed");
        let mut finished = Vec::new();
        while !inflight.is_empty() {
            let Some(joined) = inflight.join_next().await else {
                break;
            };
            match joined {
                Ok(Ok(opened)) => {
                    finished.push(opened);
                    let gather = deadline
                        .saturating_duration_since(Instant::now())
                        .min(Duration::from_millis(5));
                    let gather_done = tokio::time::sleep(gather);
                    tokio::pin!(gather_done);
                    loop {
                        tokio::select! {
                            biased;
                            joined = inflight.join_next(), if !inflight.is_empty() => {
                                match joined {
                                    Some(Ok(Ok(opened))) => finished.push(opened),
                                    Some(Ok(Err(error))) => last = error,
                                    _ => {}
                                }
                            }
                            () = &mut gather_done => break,
                        }
                    }
                    break;
                }
                Ok(Err(error)) => last = error,
                Err(error) => last = Error::protocol(format!("bootstrap handshake: {error}")),
            }
        }
        Self::finish_aborted_handshakes(inflight).await;
        let mut rest = finished.into_iter();
        let Some((conn, resp)) = rest.next() else {
            return Err(last);
        };
        let mut learned = Vec::new();
        for (mut spare, versions) in rest {
            if !versions.api_keys.is_empty() {
                learned.push((spare.addr().to_string(), versions.api_keys));
            }
            Self::retire_admin_socket(&mut spare).await;
        }
        Ok((conn, resp, learned))
    }

    async fn new_until(cfg: AdminConfig, deadline: Instant) -> Result<Self> {
        if cfg.bootstrap.len() > 16 || cfg.client_id.len() > i16::MAX as usize {
            return Err(Error::protocol(
                "bootstrap/client ID exceeds discovery limit",
            ));
        }
        let mut cfg = cfg;
        cfg.bootstrap = crate::net::parse_and_validate_addresses(&cfg.bootstrap)?;
        let stats = Arc::new(crate::metrics::AdminTracker::default());
        let (conn, resp, siblings) = Self::open_bootstrap(&cfg, &stats, deadline).await?;
        let mut versions = HashMap::new();
        for api in resp.api_keys {
            let _prev = versions.insert(api.api_key, api);
        }
        let create_version = versions
            .get(&CREATE_TOPICS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 7))
            .ok_or_else(|| {
                Error::Unsupported("broker does not support CreateTopics v0-7".into())
            })?;
        let delete_version = versions
            .get(&DELETE_TOPICS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 6))
            .ok_or_else(|| {
                Error::Unsupported("broker does not support DeleteTopics v0-6".into())
            })?;
        let describe_version = versions
            .get(&DESCRIBE_CONFIGS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 4));
        let partitions_version = versions
            .get(&CREATE_PARTITIONS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 3));
        let alter_version = versions
            .get(&INCREMENTAL_ALTER_CONFIGS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 1));
        let legacy_alter_version = versions
            .get(&ALTER_CONFIGS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 2));
        let delete_records_version = versions
            .get(&DELETE_RECORDS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 2));
        let describe_producers_version = versions
            .get(&DESCRIBE_PRODUCERS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 0));
        let describe_cluster_version = versions
            .get(&DESCRIBE_CLUSTER)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 2));
        let create_acls_version = versions
            .get(&CREATE_ACLS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 3));
        let describe_acls_version = versions
            .get(&DESCRIBE_ACLS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 3));
        let delete_acls_version = versions
            .get(&DELETE_ACLS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 3));
        let metadata_version = versions
            .get(&METADATA)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 13))
            .ok_or_else(|| Error::Unsupported("broker does not support Metadata".into()))?;
        let find_coord_version = versions
            .get(&FIND_COORDINATOR)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 6));
        let offset_delete_version = versions
            .get(&OFFSET_DELETE)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 0));
        let list_reassign_version = versions
            .get(&LIST_PARTITION_REASSIGNMENTS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 0));
        let update_features_version = versions
            .get(&UPDATE_FEATURES)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 2));
        let alter_user_scram_version = versions
            .get(&ALTER_USER_SCRAM_CREDENTIALS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 0));
        let describe_user_scram_version = versions
            .get(&DESCRIBE_USER_SCRAM_CREDENTIALS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 0));
        let unregister_broker_version = versions
            .get(&UNREGISTER_BROKER)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 0));
        let describe_client_quotas_version = versions
            .get(&DESCRIBE_CLIENT_QUOTAS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 1));
        let alter_client_quotas_version = versions
            .get(&ALTER_CLIENT_QUOTAS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 1));
        let allocate_producer_ids_version = versions
            .get(&ALLOCATE_PRODUCER_IDS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 0));
        let describe_transactions_version = versions
            .get(&DESCRIBE_TRANSACTIONS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 0));
        let consumer_group_describe_version = versions
            .get(&CONSUMER_GROUP_DESCRIBE)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 1));
        let describe_groups_version = versions
            .get(&DESCRIBE_GROUPS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 6));
        let list_groups_version = versions
            .get(&LIST_GROUPS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 5));
        let delete_groups_version = versions
            .get(&DELETE_GROUPS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 2));
        let share_group_describe_version = versions
            .get(&SHARE_GROUP_DESCRIBE)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 1));
        let describe_share_group_offsets_version = versions
            .get(&DESCRIBE_SHARE_GROUP_OFFSETS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 1));
        let alter_share_group_offsets_version = versions
            .get(&ALTER_SHARE_GROUP_OFFSETS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 0));
        let delete_share_group_offsets_version = versions
            .get(&DELETE_SHARE_GROUP_OFFSETS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 0));
        let describe_topic_partitions_version = versions
            .get(&DESCRIBE_TOPIC_PARTITIONS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 0));
        let list_config_resources_version = versions
            .get(&LIST_CONFIG_RESOURCES)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 1));
        let get_telemetry_subscriptions_version = versions
            .get(&GET_TELEMETRY_SUBSCRIPTIONS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 0));
        let push_telemetry_version = versions
            .get(&PUSH_TELEMETRY)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 0));
        let assign_replicas_to_dirs_version = versions
            .get(&ASSIGN_REPLICAS_TO_DIRS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 0));
        let alter_replica_log_dirs_version = versions
            .get(&ALTER_REPLICA_LOG_DIRS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 1, 2));
        let create_delegation_token_version = versions
            .get(&CREATE_DELEGATION_TOKEN)
            .and_then(|v| pick_version(v.min_version, v.max_version, 1, 3));
        let renew_delegation_token_version = versions
            .get(&RENEW_DELEGATION_TOKEN)
            .and_then(|v| pick_version(v.min_version, v.max_version, 1, 2));
        let expire_delegation_token_version = versions
            .get(&EXPIRE_DELEGATION_TOKEN)
            .and_then(|v| pick_version(v.min_version, v.max_version, 1, 2));
        let describe_delegation_token_version = versions
            .get(&DESCRIBE_DELEGATION_TOKEN)
            .and_then(|v| pick_version(v.min_version, v.max_version, 1, 3));
        let mut peer_versions = HashMap::new();
        for (addr, keys) in siblings {
            if !keys.is_empty() && addr != conn.addr() {
                let _stored = peer_versions.insert(addr, keys);
            }
        }
        Ok(Self {
            cfg,
            conn,
            versions,
            create_version,
            delete_version,
            describe_version,
            partitions_version,
            alter_version,
            legacy_alter_version,
            delete_records_version,
            describe_producers_version,
            describe_cluster_version,
            create_acls_version,
            describe_acls_version,
            delete_acls_version,
            metadata_version,
            metadata_image: MetadataResponse::blank(),
            find_coord_version,
            offset_delete_version,
            list_reassign_version,
            update_features_version,
            alter_user_scram_version,
            describe_user_scram_version,
            unregister_broker_version,
            describe_client_quotas_version,
            alter_client_quotas_version,
            allocate_producer_ids_version,
            describe_transactions_version,
            consumer_group_describe_version,
            describe_groups_version,
            list_groups_version,
            delete_groups_version,
            share_group_describe_version,
            describe_share_group_offsets_version,
            alter_share_group_offsets_version,
            delete_share_group_offsets_version,
            describe_topic_partitions_version,
            list_config_resources_version,
            get_telemetry_subscriptions_version,
            cached_client_instance_id: None,
            push_telemetry_version,
            assign_replicas_to_dirs_version,
            alter_replica_log_dirs_version,
            create_delegation_token_version,
            renew_delegation_token_version,
            expire_delegation_token_version,
            describe_delegation_token_version,
            cluster: Cluster::default(),
            conns: HashMap::new(),
            peer_versions,
            controller_redial: None,
            reconnect_fails: HashMap::new(),
            group_coord: None,
            group_coords: HashMap::new(),
            group_coord_redial: Vec::new(),
            txn_coord: None,
            txn_coords: HashMap::new(),
            txn_coord_redial: Vec::new(),
            stats,
        })
    }

    /// Negotiated ApiVersions for this connection.
    #[must_use]
    pub fn versions(&self) -> &HashMap<i16, ApiVersion> {
        &self.versions
    }

    /// Pick a version from the bootstrap handshake.
    fn negotiated(&self, api_key: i16, min: i16, max: i16) -> Option<i16> {
        self.versions
            .get(&api_key)
            .and_then(|api| pick_version(api.min_version, api.max_version, min, max))
    }

    /// Install a replacement bootstrap socket and the ApiVersions it learned.
    async fn adopt_bootstrap(&mut self, opened: AdminOffsetConn) -> Result<()> {
        self.metadata_version = opened
            .metadata
            .ok_or_else(|| Error::Unsupported("broker does not support Metadata".into()))?;
        self.find_coord_version = opened.find;
        self.versions.clear();
        for api in opened.apis {
            let _prev = self.versions.insert(api.api_key, api);
        }
        Self::retire_admin_socket(&mut self.conn).await;
        self.conn = opened.inner;
        Ok(())
    }

    /// Shut the admin bootstrap socket down before another connection replaces it.
    ///
    /// Assignment drops the previous connection. The idle watch is aborted with
    /// that drop, so the broker stays in its read until the watch is scheduled.
    async fn retire_admin_socket(conn: &mut BrokerConn) {
        conn.close();
        conn.release_if_closed().await;
    }

    /// Admin RPC counters and round-trip latency since connect.
    ///
    /// Java `Admin.metrics()` is Kafka's live metric map. This snapshot
    /// counts every Admin [`BrokerConn::roundtrip`]. `errors` is I/O,
    /// timeout, and protocol failure — not a decoded broker `error_code`
    /// on a valid body. `connections` is the bootstrap socket plus
    /// per-node sockets.
    #[must_use]
    pub fn metrics(&self) -> crate::AdminMetrics {
        self.stats.snapshot(1 + self.conns.len() as u64)
    }

    /// Drop the admin connection.
    ///
    /// Sockets are dropped before this returns. On a current-thread runtime
    /// the broker stays in its read until this caller yields.
    pub async fn close(self) -> Result<()> {
        drop(self);
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }
        Ok(())
    }

    /// [`Self::close`] with a timeout (Java `close(Duration)`).
    ///
    /// Admin has no LeaveGroup; the duration is unused, same as
    /// [`crate::Consumer::close_timeout`].
    pub async fn close_timeout(self, _timeout: Duration) -> Result<()> {
        self.close().await
    }

    /// Java `clientInstanceId` (KIP-714 GetTelemetrySubscriptions).
    ///
    /// Returns [`Uuid`] (Java `Uuid`). The first call sends a zero UUID;
    /// the broker assigns one. Later calls return the cached id without
    /// another round-trip. Waits up to [`AdminConfig::request_timeout`].
    /// For a one-shot timeout, use [`Self::client_instance_id_timeout`].
    pub async fn client_instance_id(&mut self) -> Result<Uuid> {
        let timeout = self.cfg.request_timeout;
        self.client_instance_id_timeout(timeout).await
    }

    /// [`Self::client_instance_id`] with a one-shot timeout (Java
    /// `clientInstanceId(Duration)`).
    ///
    /// `timeout` is the GetTelemetrySubscriptions RPC deadline. Cached after
    /// the first successful call; later calls ignore `timeout`.
    pub async fn client_instance_id_timeout(&mut self, timeout: Duration) -> Result<Uuid> {
        if let Some(id) = self.cached_client_instance_id {
            return Ok(Uuid::from_bytes(id));
        }
        let deadline = Instant::now().checked_add(timeout).ok_or(Error::Timeout)?;
        self.ensure_bootstrap(deadline).await?;
        let version = self.get_telemetry_subscriptions_version.ok_or_else(|| {
            Error::Unsupported("broker does not support GetTelemetrySubscriptions".into())
        })?;
        let id = fetch_client_instance_id(
            &mut self.conn,
            version,
            startup_remaining(deadline)?,
            [0; 16],
        )
        .await?;
        self.cached_client_instance_id = Some(id);
        Ok(Uuid::from_bytes(id))
    }

    /// Create topics (`CreateTopics`).
    ///
    /// Negotiates v0–v7 (v5+ flexible; v5 returns NumPartitions /
    /// ReplicationFactor / Configs, KIP-525; v7 TopicId, KIP-516).
    /// Kafka 4.0 `validVersions` is `2-7`. v8+ is not spoken.
    /// `timeout_ms` is CreateTopics TimeoutMs. The RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot timeout that
    /// drives both the RPC deadline and TimeoutMs, use
    /// [`Self::create_topics_timeout`].
    /// Java `CreateTopicsOptions.retryOnQuotaViolation` defaults to
    /// `true` (KIP-599); use [`Self::create_topics_with_quota_retry`]
    /// to disable.
    pub async fn create_topics(
        &mut self,
        topics: &[NewTopic],
        timeout_ms: i32,
        validate_only: bool,
    ) -> Result<Vec<TopicResult>> {
        let timeout = self.cfg.request_timeout;
        self.create_topics_with(topics, timeout_ms, validate_only, timeout, true)
            .await
    }

    /// [`Self::create_topics`] with a one-shot timeout (Java
    /// `CreateTopicsOptions.timeoutMs`).
    ///
    /// `timeout` is the RPC deadline and CreateTopics TimeoutMs.
    pub async fn create_topics_timeout(
        &mut self,
        topics: &[NewTopic],
        timeout: Duration,
        validate_only: bool,
    ) -> Result<Vec<TopicResult>> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.create_topics_with(topics, timeout_ms, validate_only, timeout, true)
            .await
    }

    /// [`Self::create_topics`] with Java `CreateTopicsOptions.retryOnQuotaViolation`.
    ///
    /// [`Self::create_topics`] defaults this to `true` (KIP-599). When
    /// true, topics that return `THROTTLING_QUOTA_EXCEEDED` (89) are
    /// retried alone until the RPC deadline.
    pub async fn create_topics_with_quota_retry(
        &mut self,
        topics: &[NewTopic],
        timeout_ms: i32,
        validate_only: bool,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        let timeout = self.cfg.request_timeout;
        self.create_topics_with(
            topics,
            timeout_ms,
            validate_only,
            timeout,
            retry_on_quota_violation,
        )
        .await
    }

    /// [`Self::create_topics_with_quota_retry`] with a one-shot timeout
    /// (Java `CreateTopicsOptions.timeoutMs` + `retryOnQuotaViolation`).
    ///
    /// `timeout` is the RPC deadline and CreateTopics TimeoutMs.
    pub async fn create_topics_timeout_with_quota_retry(
        &mut self,
        topics: &[NewTopic],
        timeout: Duration,
        validate_only: bool,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.create_topics_with(
            topics,
            timeout_ms,
            validate_only,
            timeout,
            retry_on_quota_violation,
        )
        .await
    }

    async fn create_topics_with(
        &mut self,
        topics: &[NewTopic],
        timeout_ms: i32,
        validate_only: bool,
        timeout: Duration,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        let mut pending: Vec<usize> = (0..topics.len()).collect();
        let original = first_name_index(topics.iter().map(|topic| topic.name.as_str())).await;
        let mut finished: Vec<Option<TopicResult>> = Vec::new();
        finished.resize_with(topics.len(), || None);
        let version = self.create_version;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        loop {
            let encoded = creatable_from_new(pending.iter().filter_map(|&index| topics.get(index)));
            let mut payload = BytesMut::new();
            encode_create_topics_named_cooperative(
                &mut payload,
                version,
                &encoded,
                timeout_ms,
                validate_only,
            )
            .await?;
            if self.cluster.controller().is_err() {
                self.refresh_broker_directory(deadline).await?;
            }
            let node = self.cluster.controller()?;
            let body = self
                .roundtrip_known_node(
                    node,
                    deadline,
                    CREATE_TOPICS,
                    version,
                    |buf| {
                        buf.extend_from_slice(&payload);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await;
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.forget_controller();
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let (results, ..) =
                decode_create_topics_response_cooperative(&mut body.clone(), version).await?;
            if results
                .iter()
                .any(|r| r.error_code == error::NOT_CONTROLLER)
            {
                // NOT_CONTROLLER (41): Metadata, then the new controller.
                self.forget_controller();
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                self.refresh_broker_directory(deadline).await?;
                continue;
            }
            let slots = first_name_index(
                pending
                    .iter()
                    .filter_map(|&index| topics.get(index).map(|topic| topic.name.as_str())),
            )
            .await;
            let mut next_pending = Vec::new();
            for r in results {
                if retry_on_quota_violation && r.error_code == error::THROTTLING_QUOTA_EXCEEDED {
                    if let Some(&index) = slots
                        .get(r.name.as_str())
                        .and_then(|pending_at| pending.get(*pending_at))
                    {
                        next_pending.push(index);
                    }
                } else if let Some(&index) = original.get(r.name.as_str()) {
                    if let Some(slot) = finished.get_mut(index) {
                        *slot = Some(r);
                    }
                }
            }
            if next_pending.is_empty() {
                let mut out = Vec::with_capacity(topics.len());
                for (index, t) in topics.iter().enumerate() {
                    let r = finished
                        .get_mut(index)
                        .and_then(Option::take)
                        .ok_or_else(|| {
                            Error::protocol(format!("missing create_topics result for {}", t.name))
                        })?;
                    out.push(r);
                }
                return Ok(out);
            }
            pending = next_pending;
            self.wait_retry(&mut attempt, deadline).await?;
        }
    }

    /// Delete topics (`DeleteTopics`).
    ///
    /// Negotiates v0–v6 (v4+ flexible; v5 ErrorMessage, KIP-599; v6
    /// Topics of Name + TopicId, KIP-516). Name-based deletes send a
    /// zero UUID at v6 (Java `deleteTopics(Collection<String>)`).
    /// For TopicId deletes (Java `TopicCollection.ofTopicIds`), use
    /// [`Self::delete_topics_by_id`].
    /// Kafka 4.0 `validVersions` is `1-6`. v7+ is not spoken.
    ///
    /// Lands on the Metadata controller. `NOT_CONTROLLER` (41) refreshes
    /// Metadata and retries on the new controller.
    /// `timeout_ms` is DeleteTopics TimeoutMs. The RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot timeout that
    /// drives both the RPC deadline and TimeoutMs, use
    /// [`Self::delete_topics_timeout`].
    /// Java `DeleteTopicsOptions.retryOnQuotaViolation` defaults to
    /// `true` (KIP-599); use [`Self::delete_topics_with_quota_retry`]
    /// to disable.
    pub async fn delete_topics(
        &mut self,
        names: &[impl AsRef<str>],
        timeout_ms: i32,
    ) -> Result<Vec<TopicResult>> {
        let timeout = self.cfg.request_timeout;
        self.delete_topics_with(names, timeout_ms, timeout, true)
            .await
    }

    /// [`Self::delete_topics`] with a one-shot timeout (Java
    /// `DeleteTopicsOptions.timeoutMs`).
    ///
    /// `timeout` is the RPC deadline and DeleteTopics TimeoutMs.
    pub async fn delete_topics_timeout(
        &mut self,
        names: &[impl AsRef<str>],
        timeout: Duration,
    ) -> Result<Vec<TopicResult>> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.delete_topics_with(names, timeout_ms, timeout, true)
            .await
    }

    /// [`Self::delete_topics`] with Java `DeleteTopicsOptions.retryOnQuotaViolation`.
    ///
    /// [`Self::delete_topics`] defaults this to `true` (KIP-599). When
    /// true, topics that return `THROTTLING_QUOTA_EXCEEDED` (89) are
    /// retried alone until the RPC deadline.
    pub async fn delete_topics_with_quota_retry(
        &mut self,
        names: &[impl AsRef<str>],
        timeout_ms: i32,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        let timeout = self.cfg.request_timeout;
        self.delete_topics_with(names, timeout_ms, timeout, retry_on_quota_violation)
            .await
    }

    /// [`Self::delete_topics_with_quota_retry`] with a one-shot timeout
    /// (Java `DeleteTopicsOptions.timeoutMs` + `retryOnQuotaViolation`).
    ///
    /// `timeout` is the RPC deadline and DeleteTopics TimeoutMs.
    pub async fn delete_topics_timeout_with_quota_retry(
        &mut self,
        names: &[impl AsRef<str>],
        timeout: Duration,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.delete_topics_with(names, timeout_ms, timeout, retry_on_quota_violation)
            .await
    }

    /// Delete topics by TopicId (Java `deleteTopics(TopicCollection.ofTopicIds)`).
    ///
    /// DeleteTopics v6 sends Topics of null Name + TopicId. Brokers that
    /// only speak v0–v5 return [`Error::Unsupported`]. Empty `ids` is a
    /// no-op. Unknown ids return `UNKNOWN_TOPIC_ID` (100) per topic.
    /// `timeout_ms` is DeleteTopics TimeoutMs. The RPC deadline is
    /// [`AdminConfig::request_timeout`]. See
    /// [`Self::delete_topics_by_id_timeout`].
    /// Java `DeleteTopicsOptions.retryOnQuotaViolation` defaults to
    /// `true` (KIP-599); use [`Self::delete_topics_by_id_with_quota_retry`]
    /// to disable.
    pub async fn delete_topics_by_id(
        &mut self,
        ids: &[[u8; 16]],
        timeout_ms: i32,
    ) -> Result<Vec<TopicResult>> {
        let timeout = self.cfg.request_timeout;
        self.delete_topics_by_id_with(ids, timeout_ms, timeout, true)
            .await
    }

    /// [`Self::delete_topics_by_id`] with a one-shot timeout (Java
    /// `DeleteTopicsOptions.timeoutMs`).
    pub async fn delete_topics_by_id_timeout(
        &mut self,
        ids: &[[u8; 16]],
        timeout: Duration,
    ) -> Result<Vec<TopicResult>> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.delete_topics_by_id_with(ids, timeout_ms, timeout, true)
            .await
    }

    /// [`Self::delete_topics_by_id`] with Java
    /// `DeleteTopicsOptions.retryOnQuotaViolation`.
    ///
    /// [`Self::delete_topics_by_id`] defaults this to `true` (KIP-599).
    /// When true, topics that return `THROTTLING_QUOTA_EXCEEDED` (89)
    /// are retried alone until the RPC deadline.
    pub async fn delete_topics_by_id_with_quota_retry(
        &mut self,
        ids: &[[u8; 16]],
        timeout_ms: i32,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        let timeout = self.cfg.request_timeout;
        self.delete_topics_by_id_with(ids, timeout_ms, timeout, retry_on_quota_violation)
            .await
    }

    /// [`Self::delete_topics_by_id_with_quota_retry`] with a one-shot
    /// timeout (Java `DeleteTopicsOptions.timeoutMs` +
    /// `retryOnQuotaViolation`).
    ///
    /// `timeout` is the RPC deadline and DeleteTopics TimeoutMs.
    pub async fn delete_topics_by_id_timeout_with_quota_retry(
        &mut self,
        ids: &[[u8; 16]],
        timeout: Duration,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.delete_topics_by_id_with(ids, timeout_ms, timeout, retry_on_quota_violation)
            .await
    }

    /// Java `deleteTopics(TopicCollection)`.
    ///
    /// [`TopicCollection::Names`] is [`Self::delete_topics`].
    /// [`TopicCollection::Ids`] is [`Self::delete_topics_by_id`].
    /// Empty collections are a no-op. `timeout_ms` is DeleteTopics
    /// TimeoutMs. The RPC deadline is [`AdminConfig::request_timeout`].
    /// Java `DeleteTopicsOptions.retryOnQuotaViolation` defaults to
    /// `true` (KIP-599); use [`Self::delete_topics_for_with_quota_retry`]
    /// to disable.
    pub async fn delete_topics_for(
        &mut self,
        topics: &TopicCollection,
        timeout_ms: i32,
    ) -> Result<Vec<TopicResult>> {
        let timeout = self.cfg.request_timeout;
        self.delete_topics_for_inner(topics, timeout_ms, timeout, true)
            .await
    }

    /// [`Self::delete_topics_for`] with a one-shot timeout (Java
    /// `DeleteTopicsOptions.timeoutMs`).
    ///
    /// `timeout` is the RPC deadline and DeleteTopics TimeoutMs.
    pub async fn delete_topics_for_timeout(
        &mut self,
        topics: &TopicCollection,
        timeout: Duration,
    ) -> Result<Vec<TopicResult>> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.delete_topics_for_inner(topics, timeout_ms, timeout, true)
            .await
    }

    /// [`Self::delete_topics_for`] with Java
    /// `DeleteTopicsOptions.retryOnQuotaViolation`.
    pub async fn delete_topics_for_with_quota_retry(
        &mut self,
        topics: &TopicCollection,
        timeout_ms: i32,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        let timeout = self.cfg.request_timeout;
        self.delete_topics_for_inner(topics, timeout_ms, timeout, retry_on_quota_violation)
            .await
    }

    /// [`Self::delete_topics_for_with_quota_retry`] with a one-shot
    /// timeout (Java `DeleteTopicsOptions.timeoutMs` +
    /// `retryOnQuotaViolation`).
    pub async fn delete_topics_for_timeout_with_quota_retry(
        &mut self,
        topics: &TopicCollection,
        timeout: Duration,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.delete_topics_for_inner(topics, timeout_ms, timeout, retry_on_quota_violation)
            .await
    }

    async fn delete_topics_for_inner(
        &mut self,
        topics: &TopicCollection,
        timeout_ms: i32,
        timeout: Duration,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        match topics {
            TopicCollection::Names(names) => {
                self.delete_topics_with(names, timeout_ms, timeout, retry_on_quota_violation)
                    .await
            }
            TopicCollection::Ids(ids) => {
                let ids: Vec<[u8; 16]> = ids.iter().copied().map(Uuid::to_bytes).collect();
                self.delete_topics_by_id_with(&ids, timeout_ms, timeout, retry_on_quota_violation)
                    .await
            }
        }
    }

    async fn delete_topics_by_id_with(
        &mut self,
        ids: &[[u8; 16]],
        timeout_ms: i32,
        timeout: Duration,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        if ids.is_empty() {
            return Ok(Vec::new());
        }
        if self.delete_version < 6 {
            return Err(Error::Unsupported(
                "broker does not support DeleteTopics v6 topic IDs".into(),
            ));
        }
        let topics: Vec<BorrowedDeleteTopic<'_>> = ids
            .iter()
            .copied()
            .map(|topic_id| BorrowedDeleteTopic {
                name: None,
                topic_id,
            })
            .collect();
        self.delete_topics_states_with(&topics, timeout_ms, timeout, retry_on_quota_violation)
            .await
    }

    async fn delete_topics_with<T: AsRef<str>>(
        &mut self,
        names: &[T],
        timeout_ms: i32,
        timeout: Duration,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        let topics: Vec<BorrowedDeleteTopic<'_>> = names
            .iter()
            .map(|name| BorrowedDeleteTopic {
                name: Some(name.as_ref()),
                topic_id: [0; 16],
            })
            .collect();
        self.delete_topics_states_with(&topics, timeout_ms, timeout, retry_on_quota_violation)
            .await
    }

    async fn delete_topics_states_with<T: DeleteTopicView + Sync>(
        &mut self,
        topics: &[T],
        timeout_ms: i32,
        timeout: Duration,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        let original = topics;
        let mut pending: Vec<usize> = (0..original.len()).collect();
        let mut finished: Vec<Option<TopicResult>> = Vec::new();
        finished.resize_with(original.len(), || None);
        let version = self.delete_version;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        loop {
            if self.cluster.controller().is_err() {
                self.refresh_broker_directory(deadline).await?;
            }
            let node = self.cluster.controller()?;
            let requested: Vec<&T> = pending
                .iter()
                .filter_map(|&index| original.get(index))
                .collect();
            let mut payload = BytesMut::new();
            encode_delete_topic_list_cooperative(&mut payload, version, &requested, timeout_ms)
                .await?;
            let body = self
                .roundtrip_known_node(
                    node,
                    deadline,
                    DELETE_TOPICS,
                    version,
                    |buf| {
                        buf.extend_from_slice(&payload);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await;
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.forget_controller();
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let (results, ..) =
                decode_delete_topics_response_cooperative(&mut body.clone(), version).await?;
            if results
                .iter()
                .any(|r| r.error_code == error::NOT_CONTROLLER)
            {
                // NOT_CONTROLLER (41): Metadata, then the new controller.
                self.forget_controller();
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                self.refresh_broker_directory(deadline).await?;
                continue;
            }
            let slots = index_delete_selection(original, &pending);
            let mut next_pending = Vec::new();
            for r in results {
                let Some(index) = delete_pending_slot(&slots, &r) else {
                    continue;
                };
                let Some(topic) = original.get(index) else {
                    continue;
                };
                if !delete_state_matches(topic, &r) {
                    continue;
                }
                if retry_on_quota_violation && r.error_code == error::THROTTLING_QUOTA_EXCEEDED {
                    next_pending.push(index);
                } else if let Some(slot) = finished.get_mut(index) {
                    *slot = Some(r);
                }
            }
            if next_pending.is_empty() {
                let mut out = Vec::with_capacity(original.len());
                for (index, t) in original.iter().enumerate() {
                    let r = finished
                        .get_mut(index)
                        .and_then(Option::take)
                        .ok_or_else(|| {
                            Error::protocol(format!(
                                "missing delete_topics result for {}",
                                t.delete_topic_name().unwrap_or("topic id")
                            ))
                        })?;
                    out.push(r);
                }
                return Ok(out);
            }
            pending = next_pending;
            self.wait_retry(&mut attempt, deadline).await?;
        }
    }

    /// Cluster topics (Java `Admin.listTopics`).
    ///
    /// Sends Metadata with a null topic array (all topics) on the
    /// bootstrap connection. Includes internal topics;
    /// [`TopicListing::is_internal`] is Metadata `IsInternal`.
    /// Metadata has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For Java
    /// `ListTopicsOptions.listInternal`, use [`Self::list_topics_with`].
    /// For a one-shot RPC deadline, use [`Self::list_topics_timeout`].
    pub async fn list_topics(&mut self) -> Result<Vec<TopicListing>> {
        let timeout = self.cfg.request_timeout;
        self.list_topics_with_timeout(true, timeout).await
    }

    /// [`Self::list_topics`] filtered by Java `ListTopicsOptions.listInternal`.
    ///
    /// Metadata still returns every topic; this crate drops rows with
    /// `IsInternal` when `list_internal` is false. [`Self::list_topics`]
    /// keeps internals (Java's default `listInternal` is false).
    pub async fn list_topics_with(&mut self, list_internal: bool) -> Result<Vec<TopicListing>> {
        let timeout = self.cfg.request_timeout;
        self.list_topics_with_timeout(list_internal, timeout).await
    }

    /// [`Self::list_topics`] with a one-shot RPC deadline (Java
    /// `ListTopicsOptions.timeoutMs`).
    ///
    /// Metadata has no TimeoutMs. Includes internal topics, matching
    /// [`Self::list_topics`].
    pub async fn list_topics_timeout(&mut self, timeout: Duration) -> Result<Vec<TopicListing>> {
        self.list_topics_with_timeout(true, timeout).await
    }

    /// [`Self::list_topics`] with Java `ListTopicsOptions.listInternal` and
    /// `timeoutMs`.
    ///
    /// Metadata has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn list_topics_with_timeout(
        &mut self,
        list_internal: bool,
        timeout: Duration,
    ) -> Result<Vec<TopicListing>> {
        self.fetch_metadata_request_with(None, false, timeout)
            .await?;
        Ok(topic_listings_from(&self.metadata_image, list_internal))
    }

    /// Topic partition layouts (Java `Admin.describeTopics`).
    ///
    /// Sends DescribeTopicPartitions (api 75, KIP-966) when the broker
    /// advertises it (Java `TopicCollection.ofTopicNames`). Otherwise
    /// Metadata for the named topics (Java fallback before KIP-966).
    /// `ResponsePartitionLimit` is 2000; a `NextCursor` is followed until
    /// the broker is done. Empty input is a no-op (no RPC). Per-topic
    /// errors live on [`TopicDescription::error_code`];
    /// [`TopicDescription::partitions`] is filled only when that code is `0`.
    /// DescribeTopicPartitions has no IncludeTopicAuthorizedOperations
    /// request flag; [`TopicDescription::authorized_operations`] is
    /// [`AUTHORIZED_OPERATIONS_OMITTED`] unless
    /// [`Self::describe_topics_with`] is used. For TopicId describes
    /// (Java `TopicCollection.ofTopicIds`), use [`Self::describe_topics_by_id`].
    /// DescribeTopicPartitions and Metadata have no TimeoutMs; the RPC
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// deadline, use [`Self::describe_topics_timeout`].
    pub async fn describe_topics<'a, S>(
        &mut self,
        topics: impl IntoIterator<Item = &'a S>,
    ) -> Result<Vec<TopicDescription>>
    where
        S: AsRef<str> + ?Sized + 'a,
    {
        self.describe_topics_with(topics, false).await
    }

    /// [`Self::describe_topics`] with a one-shot RPC deadline (Java
    /// `DescribeTopicsOptions.timeoutMs`).
    pub async fn describe_topics_timeout<'a, S>(
        &mut self,
        topics: impl IntoIterator<Item = &'a S>,
        timeout: Duration,
    ) -> Result<Vec<TopicDescription>>
    where
        S: AsRef<str> + ?Sized + 'a,
    {
        self.describe_topics_with_timeout(topics, false, timeout)
            .await
    }

    /// [`Self::describe_topics`] with Java
    /// `DescribeTopicsOptions.includeAuthorizedOperations`.
    ///
    /// DescribeTopicPartitions always returns TopicAuthorizedOperations.
    /// When `include_authorized_operations` is false, this crate stores
    /// [`AUTHORIZED_OPERATIONS_OMITTED`] (Java Metadata path omits the
    /// request flag; DTP has no equivalent field). The Metadata fallback
    /// sends IncludeTopicAuthorizedOperations when the flag is true.
    pub async fn describe_topics_with<'a, S>(
        &mut self,
        topics: impl IntoIterator<Item = &'a S>,
        include_authorized_operations: bool,
    ) -> Result<Vec<TopicDescription>>
    where
        S: AsRef<str> + ?Sized + 'a,
    {
        let timeout = self.cfg.request_timeout;
        self.describe_topics_with_timeout(topics, include_authorized_operations, timeout)
            .await
    }

    /// [`Self::describe_topics_with`] with Java
    /// `DescribeTopicsOptions.timeoutMs`.
    ///
    /// DescribeTopicPartitions and Metadata have no TimeoutMs; `timeout`
    /// is the RPC deadline (and the DTP NextCursor loop budget).
    /// `ResponsePartitionLimit` is 2000 (Java
    /// `DescribeTopicsOptions.partitionSizeLimitPerResponse` default).
    /// For a custom limit, use
    /// [`Self::describe_topics_with_partition_limit_timeout`].
    pub async fn describe_topics_with_timeout<'a, S>(
        &mut self,
        topics: impl IntoIterator<Item = &'a S>,
        include_authorized_operations: bool,
        timeout: Duration,
    ) -> Result<Vec<TopicDescription>>
    where
        S: AsRef<str> + ?Sized + 'a,
    {
        self.describe_topics_with_partition_limit_timeout(
            topics,
            include_authorized_operations,
            DESCRIBE_TOPIC_PARTITIONS_LIMIT,
            timeout,
        )
        .await
    }

    /// [`Self::describe_topics_with`] with Java
    /// `DescribeTopicsOptions.partitionSizeLimitPerResponse`.
    ///
    /// `partition_size_limit` is DescribeTopicPartitions
    /// `ResponsePartitionLimit` (Java default 2000). The broker may cap
    /// it at `max.request.partition.size.limit`. Ignored on the Metadata
    /// fallback when api 75 is not advertised. Topic-id describes
    /// ([`Self::describe_topics_by_id`]) stay on Metadata (KAFKA-19628).
    pub async fn describe_topics_with_partition_limit<'a, S>(
        &mut self,
        topics: impl IntoIterator<Item = &'a S>,
        include_authorized_operations: bool,
        partition_size_limit: i32,
    ) -> Result<Vec<TopicDescription>>
    where
        S: AsRef<str> + ?Sized + 'a,
    {
        let timeout = self.cfg.request_timeout;
        self.describe_topics_with_partition_limit_timeout(
            topics,
            include_authorized_operations,
            partition_size_limit,
            timeout,
        )
        .await
    }

    /// [`Self::describe_topics_with_partition_limit`] with Java
    /// `DescribeTopicsOptions.timeoutMs`.
    ///
    /// DescribeTopicPartitions and Metadata have no TimeoutMs; `timeout`
    /// is the RPC deadline (and the DTP NextCursor loop budget).
    pub async fn describe_topics_with_partition_limit_timeout<'a, S>(
        &mut self,
        topics: impl IntoIterator<Item = &'a S>,
        include_authorized_operations: bool,
        partition_size_limit: i32,
        timeout: Duration,
    ) -> Result<Vec<TopicDescription>>
    where
        S: AsRef<str> + ?Sized + 'a,
    {
        let names: Vec<&str> = topics.into_iter().map(AsRef::as_ref).collect();
        if names.is_empty() {
            return Ok(Vec::new());
        }
        if self.describe_topic_partitions_version.is_some() {
            self.describe_topics_dtp(
                &names,
                include_authorized_operations,
                partition_size_limit,
                timeout,
            )
            .await
        } else {
            self.describe_topics_metadata(&names, include_authorized_operations, timeout)
                .await
        }
    }

    /// Describe topics by TopicId (Java `describeTopics(TopicCollection.ofTopicIds)`).
    ///
    /// Metadata v12+ sends Topics of null Name + TopicId (Java
    /// `MetadataRequest.Builder`; v10 and v11 must not send TopicId).
    /// `AllowAutoTopicCreation` is false. Brokers that only speak v1–v11
    /// return [`Error::Unsupported`]. Empty `ids` is a no-op. Unknown
    /// ids return `UNKNOWN_TOPIC_ID` (100) per topic with an empty name.
    /// See [`Self::describe_topics_by_id_with`]. Metadata has no TimeoutMs;
    /// the RPC deadline is [`AdminConfig::request_timeout`]. For a
    /// one-shot deadline, use [`Self::describe_topics_by_id_timeout`].
    pub async fn describe_topics_by_id(
        &mut self,
        ids: &[[u8; 16]],
    ) -> Result<Vec<TopicDescription>> {
        self.describe_topics_by_id_with(ids, false).await
    }

    /// [`Self::describe_topics_by_id`] with Java
    /// `DescribeTopicsOptions.includeAuthorizedOperations`.
    ///
    /// Metadata v12+ sends IncludeTopicAuthorizedOperations (the flag
    /// exists from v8; TopicId on the request requires v12). Metadata has no TimeoutMs;
    /// the RPC deadline is [`AdminConfig::request_timeout`]. For a
    /// one-shot deadline, use [`Self::describe_topics_by_id_with_timeout`].
    pub async fn describe_topics_by_id_with(
        &mut self,
        ids: &[[u8; 16]],
        include_authorized_operations: bool,
    ) -> Result<Vec<TopicDescription>> {
        let timeout = self.cfg.request_timeout;
        self.describe_topics_by_id_with_timeout(ids, include_authorized_operations, timeout)
            .await
    }

    /// [`Self::describe_topics_by_id`] with a one-shot RPC deadline (Java
    /// `DescribeTopicsOptions.timeoutMs`).
    pub async fn describe_topics_by_id_timeout(
        &mut self,
        ids: &[[u8; 16]],
        timeout: Duration,
    ) -> Result<Vec<TopicDescription>> {
        self.describe_topics_by_id_with_timeout(ids, false, timeout)
            .await
    }

    /// [`Self::describe_topics_by_id_with`] with Java
    /// `DescribeTopicsOptions.timeoutMs`.
    ///
    /// Metadata has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn describe_topics_by_id_with_timeout(
        &mut self,
        ids: &[[u8; 16]],
        include_authorized_operations: bool,
        timeout: Duration,
    ) -> Result<Vec<TopicDescription>> {
        if ids.is_empty() {
            return Ok(Vec::new());
        }
        if self.metadata_version < 12 {
            return Err(Error::Unsupported(
                "broker does not support Metadata v12 topic IDs".into(),
            ));
        }
        let topics = MetadataRequestTopic::convert_from_ids(ids.iter().copied());
        self.fetch_metadata_request_with(Some(&topics), include_authorized_operations, timeout)
            .await?;
        Ok(topic_descriptions_including_unnamed(&self.metadata_image).await)
    }

    /// Java `describeTopics(TopicCollection)`.
    ///
    /// [`TopicCollection::Names`] is [`Self::describe_topics`]
    /// (DescribeTopicPartitions, Metadata fallback).
    /// [`TopicCollection::Ids`] is [`Self::describe_topics_by_id`]
    /// (Metadata v12+). Empty collections are a no-op.
    /// DescribeTopicPartitions and Metadata have no TimeoutMs; the RPC
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// deadline, use [`Self::describe_topics_for_timeout`].
    pub async fn describe_topics_for(
        &mut self,
        topics: &TopicCollection,
    ) -> Result<Vec<TopicDescription>> {
        self.describe_topics_for_with(topics, false).await
    }

    /// [`Self::describe_topics_for`] with a one-shot RPC deadline (Java
    /// `DescribeTopicsOptions.timeoutMs`).
    pub async fn describe_topics_for_timeout(
        &mut self,
        topics: &TopicCollection,
        timeout: Duration,
    ) -> Result<Vec<TopicDescription>> {
        self.describe_topics_for_with_timeout(topics, false, timeout)
            .await
    }

    /// [`Self::describe_topics_for`] with Java
    /// `DescribeTopicsOptions.includeAuthorizedOperations`.
    pub async fn describe_topics_for_with(
        &mut self,
        topics: &TopicCollection,
        include_authorized_operations: bool,
    ) -> Result<Vec<TopicDescription>> {
        let timeout = self.cfg.request_timeout;
        self.describe_topics_for_with_timeout(topics, include_authorized_operations, timeout)
            .await
    }

    /// [`Self::describe_topics_for_with`] with Java
    /// `DescribeTopicsOptions.timeoutMs`.
    ///
    /// DescribeTopicPartitions and Metadata have no TimeoutMs; `timeout`
    /// is the RPC deadline (and the DTP NextCursor loop budget).
    pub async fn describe_topics_for_with_timeout(
        &mut self,
        topics: &TopicCollection,
        include_authorized_operations: bool,
        timeout: Duration,
    ) -> Result<Vec<TopicDescription>> {
        match topics {
            TopicCollection::Names(names) => {
                self.describe_topics_with_timeout(names, include_authorized_operations, timeout)
                    .await
            }
            TopicCollection::Ids(ids) => {
                let ids: Vec<[u8; 16]> = ids.iter().copied().map(Uuid::to_bytes).collect();
                self.describe_topics_by_id_with_timeout(
                    &ids,
                    include_authorized_operations,
                    timeout,
                )
                .await
            }
        }
    }

    /// Describe broker or topic configs (`DescribeConfigs`).
    ///
    /// Negotiates v0–v4 (v1 IncludeSynonyms / ConfigSource / Synonyms;
    /// v3 IncludeDocumentation / ConfigType, KIP-226; v4 flexible).
    /// Kafka 4.0 `validVersions` is `1-4`. v5+ is not spoken.
    /// Documentation is omitted (`false`); see
    /// [`Self::describe_configs_with_documentation`]. DescribeConfigs has
    /// no TimeoutMs; the RPC deadline is [`AdminConfig::request_timeout`].
    /// For a one-shot deadline, use [`Self::describe_configs_timeout`].
    pub async fn describe_configs(
        &mut self,
        resources: &[ConfigResource],
        include_synonyms: bool,
    ) -> Result<Vec<DescribeConfigsResult>> {
        self.describe_configs_with_documentation(resources, include_synonyms, false)
            .await
    }

    /// [`Self::describe_configs`] with a one-shot RPC deadline (Java
    /// `DescribeConfigsOptions.timeoutMs`).
    ///
    /// DescribeConfigs has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn describe_configs_timeout(
        &mut self,
        resources: &[ConfigResource],
        include_synonyms: bool,
        timeout: Duration,
    ) -> Result<Vec<DescribeConfigsResult>> {
        self.describe_configs_with_documentation_timeout(
            resources,
            include_synonyms,
            false,
            timeout,
        )
        .await
    }

    /// DescribeConfigs with documentation (Java `describeConfigs` plus
    /// `DescribeConfigsOptions.includeDocumentation`).
    ///
    /// v3+ sends IncludeDocumentation. v0–v2 omit the field even when
    /// `include_documentation` is set. DescribeConfigs has no TimeoutMs;
    /// the RPC deadline is [`AdminConfig::request_timeout`]. For a
    /// one-shot deadline, use
    /// [`Self::describe_configs_with_documentation_timeout`].
    pub async fn describe_configs_with_documentation(
        &mut self,
        resources: &[ConfigResource],
        include_synonyms: bool,
        include_documentation: bool,
    ) -> Result<Vec<DescribeConfigsResult>> {
        let timeout = self.cfg.request_timeout;
        self.describe_configs_with_documentation_timeout(
            resources,
            include_synonyms,
            include_documentation,
            timeout,
        )
        .await
    }

    /// [`Self::describe_configs_with_documentation`] with Java
    /// `DescribeConfigsOptions.timeoutMs`.
    ///
    /// DescribeConfigs has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn describe_configs_with_documentation_timeout(
        &mut self,
        resources: &[ConfigResource],
        include_synonyms: bool,
        include_documentation: bool,
        timeout: Duration,
    ) -> Result<Vec<DescribeConfigsResult>> {
        let req = borrowed_describe_configs_resources(resources);
        let version = self.describe_version.ok_or_else(|| {
            Error::Unsupported("broker does not support DescribeConfigs v0-4".into())
        })?;
        let mut payload = BytesMut::new();
        encode_describe_configs_named_cooperative(
            &mut payload,
            version,
            &req,
            include_synonyms,
            include_documentation,
        )
        .await?;
        let body = self
            .roundtrip_bootstrap(
                DESCRIBE_CONFIGS,
                version,
                |buf| {
                    buf.extend_from_slice(&payload);
                    Ok(())
                },
                timeout,
            )
            .await?;
        let (results, ..) =
            decode_describe_configs_response_cooperative(&mut body.clone(), version).await?;
        Ok(results)
    }

    /// Increase partition count (`CreatePartitions`).
    ///
    /// Negotiates v0–v3 (v0–v1 classic; v2+ flexible; v3 KIP-599
    /// THROTTLING_QUOTA_EXCEEDED). Kafka 4.0 `validVersions` is `0-3`.
    /// v4+ is not spoken. [`NewPartitions::total_count`] is the new
    /// total, not a delta. Lands on the Metadata controller.
    /// `NOT_CONTROLLER` (41) refreshes Metadata and retries.
    /// `timeout_ms` is CreatePartitions TimeoutMs. The RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot timeout that
    /// drives both the RPC deadline and TimeoutMs, use
    /// [`Self::create_partitions_timeout`].
    /// Java `CreatePartitionsOptions.retryOnQuotaViolation` defaults to
    /// `true` (KIP-599); use [`Self::create_partitions_with_quota_retry`]
    /// to disable.
    pub async fn create_partitions(
        &mut self,
        topics: &[NewPartitions],
        timeout_ms: i32,
        validate_only: bool,
    ) -> Result<Vec<TopicResult>> {
        let timeout = self.cfg.request_timeout;
        self.create_partitions_with(topics, timeout_ms, validate_only, timeout, true)
            .await
    }

    /// [`Self::create_partitions`] with a one-shot timeout (Java
    /// `CreatePartitionsOptions.timeoutMs`).
    ///
    /// `timeout` is the RPC deadline and CreatePartitions TimeoutMs.
    pub async fn create_partitions_timeout(
        &mut self,
        topics: &[NewPartitions],
        timeout: Duration,
        validate_only: bool,
    ) -> Result<Vec<TopicResult>> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.create_partitions_with(topics, timeout_ms, validate_only, timeout, true)
            .await
    }

    /// [`Self::create_partitions`] with Java `CreatePartitionsOptions.retryOnQuotaViolation`.
    ///
    /// [`Self::create_partitions`] defaults this to `true` (KIP-599). When
    /// true, topics that return `THROTTLING_QUOTA_EXCEEDED` (89) are
    /// retried alone until the RPC deadline.
    pub async fn create_partitions_with_quota_retry(
        &mut self,
        topics: &[NewPartitions],
        timeout_ms: i32,
        validate_only: bool,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        let timeout = self.cfg.request_timeout;
        self.create_partitions_with(
            topics,
            timeout_ms,
            validate_only,
            timeout,
            retry_on_quota_violation,
        )
        .await
    }

    /// [`Self::create_partitions_with_quota_retry`] with a one-shot timeout
    /// (Java `CreatePartitionsOptions.timeoutMs` + `retryOnQuotaViolation`).
    ///
    /// `timeout` is the RPC deadline and CreatePartitions TimeoutMs.
    pub async fn create_partitions_timeout_with_quota_retry(
        &mut self,
        topics: &[NewPartitions],
        timeout: Duration,
        validate_only: bool,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.create_partitions_with(
            topics,
            timeout_ms,
            validate_only,
            timeout,
            retry_on_quota_violation,
        )
        .await
    }

    async fn create_partitions_with(
        &mut self,
        topics: &[NewPartitions],
        timeout_ms: i32,
        validate_only: bool,
        timeout: Duration,
        retry_on_quota_violation: bool,
    ) -> Result<Vec<TopicResult>> {
        let mut pending: Vec<usize> = (0..topics.len()).collect();
        let original = first_name_index(topics.iter().map(|topic| topic.name.as_str())).await;
        let mut finished: Vec<Option<TopicResult>> = Vec::new();
        finished.resize_with(topics.len(), || None);
        let version = self.partitions_version.ok_or_else(|| {
            Error::Unsupported("broker does not support CreatePartitions v0-3".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        loop {
            let encoded =
                partitions_from_new(pending.iter().filter_map(|&index| topics.get(index)));
            let mut payload = BytesMut::new();
            encode_create_partitions_named_cooperative(
                &mut payload,
                version,
                &encoded,
                timeout_ms,
                validate_only,
            )
            .await?;
            if self.cluster.controller().is_err() {
                self.refresh_broker_directory(deadline).await?;
            }
            let node = self.cluster.controller()?;
            let body = self
                .roundtrip_known_node(
                    node,
                    deadline,
                    CREATE_PARTITIONS,
                    version,
                    |buf| {
                        buf.extend_from_slice(&payload);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await;
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.forget_controller();
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let (results, ..) =
                decode_create_partitions_response_cooperative(&mut body.clone(), version).await?;
            if results
                .iter()
                .any(|r| r.error_code == error::NOT_CONTROLLER)
            {
                // NOT_CONTROLLER (41): Metadata, then the new controller.
                self.forget_controller();
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                self.refresh_broker_directory(deadline).await?;
                continue;
            }
            let slots = first_name_index(
                pending
                    .iter()
                    .filter_map(|&index| topics.get(index).map(|topic| topic.name.as_str())),
            )
            .await;
            let mut next_pending = Vec::new();
            for r in results {
                if retry_on_quota_violation && r.error_code == error::THROTTLING_QUOTA_EXCEEDED {
                    if let Some(&index) = slots
                        .get(r.name.as_str())
                        .and_then(|pending_at| pending.get(*pending_at))
                    {
                        next_pending.push(index);
                    }
                } else if let Some(&index) = original.get(r.name.as_str()) {
                    if let Some(slot) = finished.get_mut(index) {
                        *slot = Some(r);
                    }
                }
            }
            if next_pending.is_empty() {
                let mut out = Vec::with_capacity(topics.len());
                for (index, t) in topics.iter().enumerate() {
                    let r = finished
                        .get_mut(index)
                        .and_then(Option::take)
                        .ok_or_else(|| {
                            Error::protocol(format!(
                                "missing create_partitions result for {}",
                                t.name
                            ))
                        })?;
                    out.push(r);
                }
                return Ok(out);
            }
            pending = next_pending;
            self.wait_retry(&mut attempt, deadline).await?;
        }
    }

    /// Alter configs incrementally (`IncrementalAlterConfigs`).
    ///
    /// Negotiates v0–v1 (v0 classic; v1 flexible). Kafka 4.0
    /// `validVersions` is `0-1`. v2+ is not spoken.
    /// Lands on the Metadata controller. `NOT_CONTROLLER` (41) refreshes
    /// Metadata and retries on the new controller.
    /// Returns the first resource's error code. For several resources in
    /// one RPC (Java `incrementalAlterConfigs(Map)`), use
    /// [`Self::incremental_alter_configs_for`]. IncrementalAlterConfigs
    /// has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::incremental_alter_configs_timeout`]. Optional at
    /// [`Self::new`] (Kafka 2.3+ / KIP-339); a broker that omits api 44
    /// returns [`Error::Unsupported`].
    pub async fn incremental_alter_configs(
        &mut self,
        resource: &ConfigResource,
        configs: &[AlterConfig],
        validate_only: bool,
    ) -> Result<i16> {
        let results = self
            .incremental_alter_configs_for(
                &[ConfigResourceUpdate::new(
                    resource.clone(),
                    configs.iter().cloned(),
                )],
                validate_only,
            )
            .await?;
        Ok(results.first().map(|r| r.error_code).unwrap_or(0))
    }

    /// [`Self::incremental_alter_configs`] with a one-shot RPC deadline
    /// (Java `AlterConfigsOptions.timeoutMs`).
    ///
    /// IncrementalAlterConfigs has no TimeoutMs; `timeout` is the RPC
    /// deadline and the `NOT_CONTROLLER` retry budget.
    pub async fn incremental_alter_configs_timeout(
        &mut self,
        resource: &ConfigResource,
        configs: &[AlterConfig],
        timeout: Duration,
        validate_only: bool,
    ) -> Result<i16> {
        let results = self
            .incremental_alter_configs_for_timeout(
                &[ConfigResourceUpdate::new(
                    resource.clone(),
                    configs.iter().cloned(),
                )],
                timeout,
                validate_only,
            )
            .await?;
        Ok(results.first().map(|r| r.error_code).unwrap_or(0))
    }

    /// [`Self::incremental_alter_configs`] for several resources (Java
    /// `incrementalAlterConfigs(Map)`; IncrementalAlterConfigs Resources of N).
    ///
    /// Empty `updates` is a no-op.
    pub async fn incremental_alter_configs_for(
        &mut self,
        updates: &[ConfigResourceUpdate],
        validate_only: bool,
    ) -> Result<Vec<AlterConfigsResourceResult>> {
        let timeout = self.cfg.request_timeout;
        self.incremental_alter_configs_for_timeout(updates, timeout, validate_only)
            .await
    }

    /// [`Self::incremental_alter_configs_for`] with Java
    /// `AlterConfigsOptions.timeoutMs`.
    ///
    /// Empty `updates` is a no-op. IncrementalAlterConfigs has no
    /// TimeoutMs; `timeout` is the RPC deadline and the `NOT_CONTROLLER`
    /// retry budget.
    pub async fn incremental_alter_configs_for_timeout(
        &mut self,
        updates: &[ConfigResourceUpdate],
        timeout: Duration,
        validate_only: bool,
    ) -> Result<Vec<AlterConfigsResourceResult>> {
        if updates.is_empty() {
            return Ok(Vec::new());
        }
        let version = self.alter_version.ok_or_else(|| {
            Error::Unsupported("broker does not support IncrementalAlterConfigs v0-1".into())
        })?;
        let resources = borrowed_alterable_resources(updates);
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut encoded = BytesMut::new();
        encode_incremental_alter_configs_named_cooperative(
            &mut encoded,
            version,
            &resources,
            validate_only,
        )
        .await?;
        loop {
            if self.cluster.controller().is_err() {
                self.refresh_broker_directory(deadline).await?;
            }
            let node = self.cluster.controller()?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    INCREMENTAL_ALTER_CONFIGS,
                    version,
                    |buf| {
                        buf.extend_from_slice(&encoded);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.forget_controller();
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let (results, ..) = decode_incremental_alter_configs_resource_results_cooperative(
                &mut body.clone(),
                version,
            )
            .await?;
            if results
                .iter()
                .any(|r| r.error_code == error::NOT_CONTROLLER)
            {
                self.forget_controller();
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                self.refresh_broker_directory(deadline).await?;
                continue;
            }
            return Ok(results);
        }
    }

    /// Create ACL bindings (`CreateAcls`).
    ///
    /// Negotiates v0–v3 (v0–v1 classic; v2+ flexible). v1 adds
    /// ResourcePatternType (LITERAL unless [`AclBinding::pattern_type`]
    /// is set). v3 is the same layout (user resource type). Kafka 4.0
    /// `validVersions` is `1-3`. v4+ is not spoken. Java `ResourcePattern`
    /// / `AccessControlEntry` constructors reject ANY resource type,
    /// ANY/MATCH pattern type, and ANY operation / permission.
    /// Lands on the Metadata controller. `NOT_CONTROLLER` (41) refreshes
    /// Metadata and retries on the new controller. CreateAcls has no
    /// TimeoutMs; the RPC deadline is [`AdminConfig::request_timeout`].
    /// For a one-shot deadline, use [`Self::create_acls_timeout`].
    /// Returns one [`AclCreationResult`] per request binding (Java
    /// `CreateAclsResult`; request bindings are not copied into the
    /// result).
    pub async fn create_acls(&mut self, acls: &[AclBinding]) -> Result<Vec<AclCreationResult>> {
        let timeout = self.cfg.request_timeout;
        self.create_acls_timeout(acls, timeout).await
    }

    /// [`Self::create_acls`] with a one-shot RPC deadline (Java
    /// `CreateAclsOptions.timeoutMs`).
    ///
    /// CreateAcls has no TimeoutMs; `timeout` is the RPC deadline and
    /// the `NOT_CONTROLLER` retry budget.
    pub async fn create_acls_timeout(
        &mut self,
        acls: &[AclBinding],
        timeout: Duration,
    ) -> Result<Vec<AclCreationResult>> {
        let version = self
            .create_acls_version
            .ok_or_else(|| Error::Unsupported("broker does not support CreateAcls v0-3".into()))?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut encoded = BytesMut::new();
        encode_create_acls_request_cooperative(&mut encoded, version, acls).await?;
        loop {
            if self.cluster.controller().is_err() {
                self.refresh_broker_directory(deadline).await?;
            }
            let node = self.cluster.controller()?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    CREATE_ACLS,
                    version,
                    |buf| {
                        buf.extend_from_slice(&encoded);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.forget_controller();
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let (results, ..) =
                decode_create_acls_response_cooperative(&mut body.clone(), version).await?;
            if results
                .iter()
                .any(|r| r.error_code == error::NOT_CONTROLLER)
            {
                // NOT_CONTROLLER (41): Metadata, then the new controller.
                self.forget_controller();
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                self.refresh_broker_directory(deadline).await?;
                continue;
            }
            return Ok(results);
        }
    }

    /// Alter partition replicas (AlterPartitionReassignments api 45).
    ///
    /// Lands on the Metadata controller. `NOT_CONTROLLER` (41) refreshes
    /// Metadata and retries on the new controller.
    /// `timeout_ms` is AlterPartitionReassignments TimeoutMs. The RPC
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// timeout that drives both the RPC deadline and TimeoutMs, use
    /// [`Self::alter_partition_reassignments_timeout`]. Optional at
    /// [`Self::new`] (Kafka 2.4+ / KIP-455); a broker that omits api 45
    /// returns [`Error::Unsupported`].
    pub async fn alter_partition_reassignments(
        &mut self,
        assignments: &[PartitionReassignment],
        timeout_ms: i32,
    ) -> Result<Vec<ReassignmentResult>> {
        let timeout = self.cfg.request_timeout;
        self.alter_partition_reassignments_with(assignments, timeout_ms, timeout, true)
            .await
    }

    /// [`Self::alter_partition_reassignments`] with a one-shot timeout
    /// (Java `AlterPartitionReassignmentsOptions.timeoutMs`).
    ///
    /// `timeout` is the RPC deadline and AlterPartitionReassignments
    /// TimeoutMs.
    pub async fn alter_partition_reassignments_timeout(
        &mut self,
        assignments: &[PartitionReassignment],
        timeout: Duration,
    ) -> Result<Vec<ReassignmentResult>> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.alter_partition_reassignments_with(assignments, timeout_ms, timeout, true)
            .await
    }

    /// Java `alterPartitionReassignments(Map)` ([`NewPartitionReassignment`];
    /// `None` cancels).
    ///
    /// `timeout_ms` is AlterPartitionReassignments TimeoutMs. The RPC
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// timeout that drives both, use
    /// [`Self::alter_partition_reassignments_for_timeout`].
    pub async fn alter_partition_reassignments_for<I, Tp>(
        &mut self,
        assignments: I,
        timeout_ms: i32,
    ) -> Result<Vec<ReassignmentResult>>
    where
        I: IntoIterator<Item = (Tp, Option<NewPartitionReassignment>)>,
        Tp: Into<crate::TopicPartition>,
    {
        let collected: Vec<PartitionReassignment> = assignments
            .into_iter()
            .take(crate::protocol::admin::MAX_REASSIGNMENT_PARTITIONS + 1)
            .map(|(tp, assignment)| PartitionReassignment::from_new(tp, assignment))
            .collect();
        self.alter_partition_reassignments(&collected, timeout_ms)
            .await
    }

    /// [`Self::alter_partition_reassignments_for`] with a one-shot timeout
    /// (Java `AlterPartitionReassignmentsOptions.timeoutMs`).
    ///
    /// `timeout` is the RPC deadline and AlterPartitionReassignments
    /// TimeoutMs.
    pub async fn alter_partition_reassignments_for_timeout<I, Tp>(
        &mut self,
        assignments: I,
        timeout: Duration,
    ) -> Result<Vec<ReassignmentResult>>
    where
        I: IntoIterator<Item = (Tp, Option<NewPartitionReassignment>)>,
        Tp: Into<crate::TopicPartition>,
    {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        let collected: Vec<PartitionReassignment> = assignments
            .into_iter()
            .take(crate::protocol::admin::MAX_REASSIGNMENT_PARTITIONS + 1)
            .map(|(tp, assignment)| PartitionReassignment::from_new(tp, assignment))
            .collect();
        self.alter_partition_reassignments_with(&collected, timeout_ms, timeout, true)
            .await
    }

    /// Alter assignments with an explicit replication-factor policy.
    ///
    /// The controller connection negotiates API45 version0–1 on each attempt.
    /// Version0 permits only the default `true`; explicit `false` fails before
    /// any reassignment frame. Null replica lists cancel a pending move.
    /// Per-partition errors remain in the returned result tree.
    ///
    /// Requests contain at most10,000 partitions and100,000 total replica IDs;
    /// responses contain at most10,000 partition results and16MiB of wire data.
    /// Discovery, reconnects, negotiation and retries share one timeout. A lost
    /// acknowledgement may retry the same intended assignment and policy.
    pub async fn alter_partition_reassignments_with_options(
        &mut self,
        assignments: &[PartitionReassignment],
        options: AlterPartitionReassignmentsOptions,
    ) -> Result<Vec<ReassignmentResult>> {
        let timeout = options.timeout.unwrap_or(self.cfg.request_timeout);
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.alter_partition_reassignments_with(
            assignments,
            timeout_ms,
            timeout,
            options.allow_replication_factor_change,
        )
        .await
    }

    async fn alter_partition_reassignments_with(
        &mut self,
        assignments: &[PartitionReassignment],
        timeout_ms: i32,
        timeout: Duration,
        allow: bool,
    ) -> Result<Vec<ReassignmentResult>> {
        let deadline = Instant::now() + timeout;
        validate_reassignments(assignments)?;
        let topics = group_reassignments(assignments);
        self.alter_partition_reassignments_until(&topics, timeout_ms, allow, deadline)
            .await
    }

    async fn alter_partition_reassignments_until(
        &mut self,
        topics: &[(&str, Vec<BorrowedReassignmentPartition<'_>>)],
        original_timeout_ms: i32,
        allow: bool,
        deadline: Instant,
    ) -> Result<Vec<ReassignmentResult>> {
        let mut attempt = 0;
        loop {
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            let result = async {
                if self.cluster.controller().is_err() {
                    if self.conn.is_closed() {
                        let addr = self.conn.addr().to_owned();
                        let opened = self.open_node_conn_until(&addr, deadline).await?;
                    self.adopt_bootstrap(opened).await?;
                    }
                    self.refresh_broker_directory(deadline).await?;
                }
                let node = self.cluster.controller()?;
                if self.conns.get(&node).is_some_and(|conn| conn.is_closed()) {
                    self.discard_node_conn(node).await;
                }
                self.prepare_node_until(node, deadline).await?;
                let version = self
                    .negotiated_on(node, ALTER_PARTITION_REASSIGNMENTS, 0, 1)
                    .ok_or_else(|| {
                        Error::Unsupported(
                            "controller does not support AlterPartitionReassignments v0-1".into(),
                        )
                    })?;
                if version == 0 && !allow {
                    return Err(Error::Unsupported("AllowReplicationFactorChange=false requires AlterPartitionReassignments v1".into()));
                }
                let remaining = deadline.saturating_duration_since(Instant::now());
                if remaining.is_zero() {
                    return Err(Error::Timeout);
                }
                let timeout_ms =
                    original_timeout_ms.min(crate::consumer::duration_millis_i32(remaining));
                let body = self.roundtrip_known_node(
                    node,
                    deadline,
                    ALTER_PARTITION_REASSIGNMENTS,
                    version,
                    |buf| {
                        encode_alter_partition_reassignments_named(
                            buf, version, timeout_ms, allow, topics,
                        )
                    },
                    remaining,
                ).await?;
                let response = decode_alter_partition_reassignments_response_data(&mut body.as_ref(), version)?.response;
                if response.error_code == error::NOT_CONTROLLER
                    || response.results.iter().any(|topic| topic.partitions.iter().any(|partition| partition.error_code == error::NOT_CONTROLLER)) {
                    return Err(Error::broker(error::NOT_CONTROLLER, "AlterPartitionReassignments"));
                }
                if response.error_code != 0 {
                    return Err(Error::broker(response.error_code, "AlterPartitionReassignments"));
                }
                Ok(flatten_reassignment_results(&response.results).await)
            }.await;
            match result {
                Err(error)
                    if error.is_retriable()
                        || error.broker_code() == Some(error::NOT_CONTROLLER) =>
                {
                    if let Ok(node) = self.cluster.controller() {
                        self.drop_node_conn(node).await;
                    }
                    self.forget_controller();
                    if attempt >= 8 {
                        return Err(Error::Timeout);
                    }
                    self.wait_retry(&mut attempt, deadline).await?;
                }
                other => return other,
            }
        }
    }

    /// List ongoing replica moves (ListPartitionReassignments api 46).
    ///
    /// `partitions = None` lists every ongoing reassignment. Lands on the
    /// Metadata controller. `NOT_CONTROLLER` (41) refreshes Metadata and
    /// retries on the new controller.
    /// `timeout_ms` is ListPartitionReassignments TimeoutMs. The RPC
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// timeout that drives both the RPC deadline and TimeoutMs, use
    /// [`Self::list_partition_reassignments_timeout`]. Optional at
    /// [`Self::new`] (Kafka 2.4+ / KIP-455); a broker that omits api 46
    /// returns [`Error::Unsupported`].
    pub async fn list_partition_reassignments(
        &mut self,
        partitions: Option<&[crate::TopicPartition]>,
        timeout_ms: i32,
    ) -> Result<Vec<OngoingReassignment>> {
        let timeout = self.cfg.request_timeout;
        self.list_partition_reassignments_with(partitions, timeout_ms, timeout)
            .await
    }

    /// [`Self::list_partition_reassignments`] with a one-shot timeout
    /// (Java `ListPartitionReassignmentsOptions.timeoutMs`).
    ///
    /// `timeout` is the RPC deadline and ListPartitionReassignments
    /// TimeoutMs.
    pub async fn list_partition_reassignments_timeout(
        &mut self,
        partitions: Option<&[crate::TopicPartition]>,
        timeout: Duration,
    ) -> Result<Vec<OngoingReassignment>> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.list_partition_reassignments_with(partitions, timeout_ms, timeout)
            .await
    }

    /// List every ongoing replica move (Java
    /// `Admin.listPartitionReassignments()`).
    ///
    /// Same wire as [`Self::list_partition_reassignments`] with `topics`
    /// null. TimeoutMs is [`AdminConfig::request_timeout`].
    pub async fn list_partition_reassignments_all(&mut self) -> Result<Vec<OngoingReassignment>> {
        let timeout = self.cfg.request_timeout;
        self.list_partition_reassignments_all_timeout(timeout).await
    }

    /// [`Self::list_partition_reassignments_all`] with a one-shot timeout
    /// (Java `ListPartitionReassignmentsOptions.timeoutMs`).
    ///
    /// `timeout` is the RPC deadline and ListPartitionReassignments
    /// TimeoutMs.
    pub async fn list_partition_reassignments_all_timeout(
        &mut self,
        timeout: Duration,
    ) -> Result<Vec<OngoingReassignment>> {
        self.list_partition_reassignments_timeout(None, timeout)
            .await
    }

    /// List ongoing replica moves for `partitions` (Java
    /// `Admin.listPartitionReassignments(Set)`).
    ///
    /// TimeoutMs is [`AdminConfig::request_timeout`]. For a one-shot
    /// timeout, use [`Self::list_partition_reassignments_timeout`].
    pub async fn list_partition_reassignments_for(
        &mut self,
        partitions: &[crate::TopicPartition],
    ) -> Result<Vec<OngoingReassignment>> {
        let timeout = self.cfg.request_timeout;
        self.list_partition_reassignments_timeout(Some(partitions), timeout)
            .await
    }

    async fn list_partition_reassignments_with(
        &mut self,
        partitions: Option<&[crate::TopicPartition]>,
        timeout_ms: i32,
        timeout: Duration,
    ) -> Result<Vec<OngoingReassignment>> {
        let topics = match partitions {
            Some(partitions) => Some(group_list_reassignments(partitions).await),
            None => None,
        };
        let version = self.list_reassign_version.ok_or_else(|| {
            Error::Unsupported("broker does not support ListPartitionReassignments".into())
        })?;
        let mut payload = BytesMut::new();
        encode_list_partition_reassignments_named_cooperative(
            &mut payload,
            timeout_ms,
            topics.as_deref(),
        )
        .await?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        loop {
            if self.cluster.controller().is_err() {
                self.refresh_broker_directory(deadline).await?;
            }
            let node = self.cluster.controller()?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    LIST_PARTITION_REASSIGNMENTS,
                    version,
                    |buf| {
                        buf.extend_from_slice(&payload);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.forget_controller();
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let resp =
                decode_list_partition_reassignments_response_cooperative(&mut body.clone()).await?;
            if resp.error_code == error::NOT_CONTROLLER {
                // NOT_CONTROLLER (41): Metadata, then the new controller.
                self.forget_controller();
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                self.refresh_broker_directory(deadline).await?;
                continue;
            }
            if resp.error_code != 0 {
                return Err(Error::broker(resp.error_code, "ListPartitionReassignments"));
            }
            return Ok(flatten_list_reassignments(&resp.topics).await);
        }
    }

    /// Update finalized feature versions using UpdateFeatures v0–v2.
    ///
    /// Requests go to the metadata controller. A top-level `NOT_CONTROLLER`
    /// refreshes metadata and retries; per-feature errors remain in the returned
    /// results. Successful responses without result rows produce one success
    /// result for each requested feature.
    ///
    /// `timeout_ms` sets the broker timeout, capped by the remaining operation
    /// budget. [`AdminConfig::request_timeout`] bounds discovery, connections,
    /// requests, and retries together. [`Self::update_features_timeout`] sets
    /// both budgets for one call. [`Self::update_features_with`] adds validation.
    ///
    /// An empty update list or a blank feature name returns [`Error::Protocol`].
    /// A broker without UpdateFeatures returns [`Error::Unsupported`].
    pub async fn update_features(
        &mut self,
        updates: &[FeatureUpdate],
        timeout_ms: i32,
    ) -> Result<Vec<FeatureUpdateResult>> {
        let timeout = self.cfg.request_timeout;
        self.update_features_inner(updates, timeout_ms, false, timeout)
            .await
    }

    /// [`Self::update_features`] with a one-shot timeout (Java
    /// `UpdateFeaturesOptions.timeoutMs`).
    ///
    /// `timeout` bounds the whole operation, including controller discovery and retries.
    /// Each request sends the smaller of the requested TimeoutMs and remaining budget.
    pub async fn update_features_timeout(
        &mut self,
        updates: &[FeatureUpdate],
        timeout: Duration,
    ) -> Result<Vec<FeatureUpdateResult>> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.update_features_inner(updates, timeout_ms, false, timeout)
            .await
    }

    /// UpdateFeatures with validate-only (Java `updateFeatures` plus
    /// `UpdateFeaturesOptions.validateOnly`).
    ///
    /// v1+ sends `ValidateOnly`. v0 rejects validation-only requests before encoding.
    /// `timeout_ms` is UpdateFeatures TimeoutMs. The RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot timeout that
    /// drives both, use [`Self::update_features_with_timeout`].
    pub async fn update_features_with(
        &mut self,
        updates: &[FeatureUpdate],
        timeout_ms: i32,
        validate_only: bool,
    ) -> Result<Vec<FeatureUpdateResult>> {
        let timeout = self.cfg.request_timeout;
        self.update_features_inner(updates, timeout_ms, validate_only, timeout)
            .await
    }

    /// [`Self::update_features_with`] with a one-shot timeout (Java
    /// `UpdateFeaturesOptions.timeoutMs` plus `validateOnly`).
    ///
    /// `timeout` bounds the whole operation, including controller discovery and retries.
    /// Each request sends the smaller of the requested TimeoutMs and remaining budget.
    pub async fn update_features_with_timeout(
        &mut self,
        updates: &[FeatureUpdate],
        timeout: Duration,
        validate_only: bool,
    ) -> Result<Vec<FeatureUpdateResult>> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.update_features_inner(updates, timeout_ms, validate_only, timeout)
            .await
    }

    /// Java `KafkaAdminClient.updateFeatures` argument checks.
    fn reject_java_feature_updates(updates: &[FeatureUpdate]) -> Result<()> {
        if updates.is_empty() {
            return Err(Error::protocol("Feature updates can not be null or empty."));
        }
        for u in updates {
            if u.name
                .trim_matches(|character| character <= '\u{0020}')
                .is_empty()
            {
                return Err(Error::protocol("Provided feature can not be empty."));
            }
        }
        Ok(())
    }

    async fn update_features_inner(
        &mut self,
        updates: &[FeatureUpdate],
        timeout_ms: i32,
        validate_only: bool,
        timeout: Duration,
    ) -> Result<Vec<FeatureUpdateResult>> {
        Self::reject_java_feature_updates(updates)?;
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let deadline = Instant::now()
            .checked_add(timeout)
            .ok_or_else(|| Error::protocol("UpdateFeatures deadline overflow"))?;
        let keys = borrowed_feature_updates(updates);
        let version = self.update_features_version.ok_or_else(|| {
            Error::Unsupported("broker does not support UpdateFeatures v0-2".into())
        })?;
        let mut attempt = 0u32;
        loop {
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            if self.cluster.controller().is_err() {
                self.refresh_broker_directory(deadline).await?;
            }
            let node = self.cluster.controller()?;
            let remaining = deadline.saturating_duration_since(Instant::now());
            if remaining.is_zero() {
                return Err(Error::Timeout);
            }
            let wire_timeout_ms = timeout_ms.min(
                i32::try_from(remaining.as_millis())
                    .unwrap_or(i32::MAX)
                    .max(1),
            );
            let mut payload = BytesMut::new();
            encode_update_features_named_cooperative(
                &mut payload,
                version,
                wire_timeout_ms,
                &keys,
                validate_only,
            )
            .await?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    UPDATE_FEATURES,
                    version,
                    |buf| {
                        buf.extend_from_slice(&payload);
                        Ok(())
                    },
                    remaining,
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.forget_controller();
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let resp =
                decode_update_features_response_cooperative(&mut body.clone(), version).await?;
            if resp.error_code == error::NOT_CONTROLLER {
                // NOT_CONTROLLER (41): Metadata, then the new controller.
                self.forget_controller();
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                self.refresh_broker_directory(deadline).await?;
                continue;
            }
            if resp.error_code != 0 {
                return Err(Error::broker(resp.error_code, "UpdateFeatures"));
            }
            if version >= 2 || resp.results.is_empty() {
                return Ok(updates
                    .iter()
                    .map(|update| FeatureUpdateResult {
                        name: update.name.clone(),
                        error_code: 0,
                        error_message: None,
                    })
                    .collect());
            }
            return Ok(resp
                .results
                .into_iter()
                .map(|r| FeatureUpdateResult {
                    name: r.name,
                    error_code: r.error_code,
                    error_message: r.error_message,
                })
                .collect());
        }
    }

    /// Supported and finalized features (Java `describeFeatures`).
    ///
    /// There is no DescribeFeatures api key. This re-issues ApiVersions v3–v4
    /// on the bootstrap connection and reads KIP-482 tagged fields
    /// (`supportedFeatures`, `finalizedFeaturesEpoch`, `finalizedFeatures`,
    /// `zkMigrationReady`). v4 includes SupportedFeatures with MinVersion 0
    /// (KAFKA-17011). Java `SupportedVersionRange` / `FinalizedVersionRange`
    /// constructors reject a negative min or max, or max below min.
    /// ApiVersions has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::describe_features_timeout`].
    pub async fn describe_features(&mut self) -> Result<FeatureMetadata> {
        let timeout = self.cfg.request_timeout;
        self.describe_features_timeout(timeout).await
    }

    /// [`Self::describe_features`] with a one-shot RPC deadline (Java
    /// `DescribeFeaturesOptions.timeoutMs`).
    ///
    /// There is no DescribeFeatures api key; this re-issues ApiVersions
    /// v3–v4. ApiVersions has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn describe_features_timeout(
        &mut self,
        timeout: Duration,
    ) -> Result<FeatureMetadata> {
        let version = self
            .versions
            .get(&API_VERSIONS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 3, 4))
            .unwrap_or(3);
        let body = self
            .roundtrip_bootstrap(
                API_VERSIONS,
                version,
                |buf| encode_api_versions_request(buf, version, "partitionline", "0.1.0"),
                timeout,
            )
            .await?;
        let resp = decode_api_versions_response(&mut body.clone(), version)?;
        if resp.error_code != 0 {
            return Err(Error::broker(resp.error_code, "ApiVersions"));
        }
        Ok(FeatureMetadata {
            supported_features: resp
                .supported_features
                .into_iter()
                .map(|f| SupportedVersionRange::new(f.name, f.min_version, f.max_version))
                .collect::<Result<Vec<_>>>()?,
            finalized_features: resp
                .finalized_features
                .into_iter()
                .map(|f| {
                    FinalizedVersionRange::new(f.name, f.min_version_level, f.max_version_level)
                })
                .collect::<Result<Vec<_>>>()?,
            finalized_features_epoch: resp.finalized_features_epoch,
            zk_migration_ready: resp.zk_migration_ready,
        })
    }

    /// Upsert or delete user SCRAM credentials (AlterUserScramCredentials
    /// api 51).
    ///
    /// Lands on the Metadata controller. `NOT_CONTROLLER` (41) refreshes
    /// Metadata and retries on the new controller. AlterUserScramCredentials
    /// has no TimeoutMs; the RPC deadline is [`AdminConfig::request_timeout`].
    /// For a one-shot deadline, use
    /// [`Self::alter_user_scram_credentials_timeout`]. Optional at
    /// [`Self::new`] (Kafka 2.7+ / KIP-554); a broker that omits api 51
    /// returns [`Error::Unsupported`]. Java
    /// `alterUserScramCredentials(List)` is
    /// [`Self::alter_user_scram_credentials_with`].
    pub async fn alter_user_scram_credentials(
        &mut self,
        deletions: &[UserScramCredentialDeletion],
        upsertions: &[UserScramCredentialUpsertion],
    ) -> Result<Vec<UserScramCredentialResult>> {
        let timeout = self.cfg.request_timeout;
        self.alter_user_scram_credentials_timeout(deletions, upsertions, timeout)
            .await
    }

    /// Java `alterUserScramCredentials(List)` of [`UserScramCredentialAlteration`].
    ///
    /// The wire request still splits Deletions then Upsertions. AlterUserScramCredentials
    /// has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::alter_user_scram_credentials_with_timeout`].
    pub async fn alter_user_scram_credentials_with<A>(
        &mut self,
        alterations: impl IntoIterator<Item = A>,
    ) -> Result<Vec<UserScramCredentialResult>>
    where
        A: Into<UserScramCredentialAlteration>,
    {
        let timeout = self.cfg.request_timeout;
        self.alter_user_scram_credentials_with_timeout(alterations, timeout)
            .await
    }

    /// [`Self::alter_user_scram_credentials_with`] with a one-shot RPC
    /// deadline (Java `AlterUserScramCredentialsOptions.timeoutMs`).
    ///
    /// AlterUserScramCredentials has no TimeoutMs; `timeout` is the RPC
    /// deadline and the `NOT_CONTROLLER` retry budget.
    pub async fn alter_user_scram_credentials_with_timeout<A>(
        &mut self,
        alterations: impl IntoIterator<Item = A>,
        timeout: Duration,
    ) -> Result<Vec<UserScramCredentialResult>>
    where
        A: Into<UserScramCredentialAlteration>,
    {
        let mut deletions = Vec::new();
        let mut upsertions = Vec::new();
        for item in alterations {
            match item.into() {
                UserScramCredentialAlteration::Deletion(d) => deletions.push(d),
                UserScramCredentialAlteration::Upsertion(u) => upsertions.push(u),
            }
        }
        self.alter_user_scram_credentials_timeout(&deletions, &upsertions, timeout)
            .await
    }

    /// [`Self::alter_user_scram_credentials`] with a one-shot RPC deadline
    /// (Java `AlterUserScramCredentialsOptions.timeoutMs`).
    ///
    /// AlterUserScramCredentials has no TimeoutMs; `timeout` is the RPC
    /// deadline and the `NOT_CONTROLLER` retry budget.
    pub async fn alter_user_scram_credentials_timeout(
        &mut self,
        deletions: &[UserScramCredentialDeletion],
        upsertions: &[UserScramCredentialUpsertion],
        timeout: Duration,
    ) -> Result<Vec<UserScramCredentialResult>> {
        let deletions = borrowed_scram_deletions(deletions);
        let upsertions = borrowed_scram_upsertions(upsertions);
        let version = self.alter_user_scram_version.ok_or_else(|| {
            Error::Unsupported("broker does not support AlterUserScramCredentials".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut encoded = BytesMut::new();
        encode_alter_user_scram_credentials_named_cooperative(
            &mut encoded,
            &deletions,
            &upsertions,
        )
        .await?;
        loop {
            if self.cluster.controller().is_err() {
                self.refresh_broker_directory(deadline).await?;
            }
            let node = self.cluster.controller()?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    ALTER_USER_SCRAM_CREDENTIALS,
                    version,
                    |buf| {
                        buf.extend_from_slice(&encoded);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.forget_controller();
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let (results, ..) =
                decode_alter_user_scram_credentials_response_cooperative(&mut body.clone()).await?;
            if results
                .iter()
                .any(|r| r.error_code == error::NOT_CONTROLLER)
            {
                // NOT_CONTROLLER (41): Metadata, then the new controller.
                self.forget_controller();
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                self.refresh_broker_directory(deadline).await?;
                continue;
            }
            return Ok(results
                .into_iter()
                .map(|r| UserScramCredentialResult {
                    user: r.user,
                    error_code: r.error_code,
                    error_message: r.error_message,
                })
                .collect());
        }
    }

    /// Describe user SCRAM credentials (DescribeUserScramCredentials
    /// api 50).
    ///
    /// Lands on the Metadata controller. `NOT_CONTROLLER` (41) refreshes
    /// Metadata and retries on the new controller. Top-level `error_code`
    /// (bytes 4–5), not a first-result field. Empty `users` sends a null
    /// Users array (Java `describeUserScramCredentials()` / empty list)
    /// and describes every user. DescribeUserScramCredentials has no
    /// TimeoutMs; the RPC deadline is [`AdminConfig::request_timeout`].
    /// For a one-shot deadline, use
    /// [`Self::describe_user_scram_credentials_timeout`]. Optional at
    /// [`Self::new`] (Kafka 2.7+ / KIP-554); a broker that omits api 50
    /// returns [`Error::Unsupported`].
    pub async fn describe_user_scram_credentials(
        &mut self,
        users: &[&str],
    ) -> Result<Vec<DescribeUserScramCredentialsResult>> {
        let timeout = self.cfg.request_timeout;
        self.describe_user_scram_credentials_timeout(users, timeout)
            .await
    }

    /// [`Self::describe_user_scram_credentials`] with a one-shot RPC
    /// deadline (Java `DescribeUserScramCredentialsOptions.timeoutMs`).
    ///
    /// DescribeUserScramCredentials has no TimeoutMs; `timeout` is the
    /// RPC deadline and the `NOT_CONTROLLER` retry budget.
    pub async fn describe_user_scram_credentials_timeout(
        &mut self,
        users: &[&str],
        timeout: Duration,
    ) -> Result<Vec<DescribeUserScramCredentialsResult>> {
        let users_wire = if users.is_empty() { None } else { Some(users) };
        let version = self.describe_user_scram_version.ok_or_else(|| {
            Error::Unsupported("broker does not support DescribeUserScramCredentials".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut encoded = BytesMut::new();
        encode_describe_user_scram_credentials_ids_cooperative(&mut encoded, users_wire).await?;
        loop {
            if self.cluster.controller().is_err() {
                self.refresh_broker_directory(deadline).await?;
            }
            let node = self.cluster.controller()?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    DESCRIBE_USER_SCRAM_CREDENTIALS,
                    version,
                    |buf| {
                        buf.extend_from_slice(&encoded);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.forget_controller();
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let resp =
                decode_describe_user_scram_credentials_response_cooperative(&mut body.clone())
                    .await?;
            if resp.error_code == error::NOT_CONTROLLER {
                // NOT_CONTROLLER (41): Metadata, then the new controller.
                self.forget_controller();
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                self.refresh_broker_directory(deadline).await?;
                continue;
            }
            if resp.error_code != 0 {
                return Err(Error::broker(
                    resp.error_code,
                    "DescribeUserScramCredentials",
                ));
            }
            return Ok(resp.results);
        }
    }

    /// Describe every user's SCRAM credentials (Java
    /// `Admin.describeUserScramCredentials()`).
    ///
    /// Same wire as [`Self::describe_user_scram_credentials`] with an
    /// empty user list (Users null).
    pub async fn describe_user_scram_credentials_all(
        &mut self,
    ) -> Result<Vec<DescribeUserScramCredentialsResult>> {
        let timeout = self.cfg.request_timeout;
        self.describe_user_scram_credentials_all_timeout(timeout)
            .await
    }

    /// [`Self::describe_user_scram_credentials_all`] with a one-shot RPC
    /// deadline (Java `DescribeUserScramCredentialsOptions.timeoutMs`).
    pub async fn describe_user_scram_credentials_all_timeout(
        &mut self,
        timeout: Duration,
    ) -> Result<Vec<DescribeUserScramCredentialsResult>> {
        self.describe_user_scram_credentials_timeout(&[], timeout)
            .await
    }

    /// Unregister a broker (UnregisterBroker api 64, KIP-500).
    ///
    /// Lands on the Metadata controller. `NOT_CONTROLLER` (41) refreshes
    /// Metadata and retries on the new controller. Top-level `error_code`
    /// (bytes 4–5), after throttle. Fixture broker id only; this is not
    /// a live KRaft unregistration. Optional at [`Self::new`] (Java
    /// `@InterfaceStability.Unstable`); a broker that omits api 64
    /// returns [`Error::Unsupported`]. UnregisterBroker has no TimeoutMs;
    /// the RPC deadline is [`AdminConfig::request_timeout`]. For a
    /// one-shot deadline, use [`Self::unregister_broker_timeout`].
    pub async fn unregister_broker(&mut self, broker_id: i32) -> Result<()> {
        let timeout = self.cfg.request_timeout;
        self.unregister_broker_timeout(broker_id, timeout).await
    }

    /// [`Self::unregister_broker`] with a one-shot RPC deadline (Java
    /// `UnregisterBrokerOptions.timeoutMs`).
    ///
    /// UnregisterBroker has no TimeoutMs; `timeout` is the RPC deadline
    /// and the `NOT_CONTROLLER` retry budget.
    pub async fn unregister_broker_timeout(
        &mut self,
        broker_id: i32,
        timeout: Duration,
    ) -> Result<()> {
        let version = self
            .unregister_broker_version
            .ok_or_else(|| Error::Unsupported("broker does not support UnregisterBroker".into()))?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        loop {
            if self.cluster.controller().is_err() {
                self.refresh_broker_directory(deadline).await?;
            }
            let node = self.cluster.controller()?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    UNREGISTER_BROKER,
                    version,
                    |buf| encode_unregister_broker_request(buf, broker_id),
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.forget_controller();
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let resp = decode_unregister_broker_response(&mut body.clone())?;
            if resp.error_code == error::NOT_CONTROLLER {
                // NOT_CONTROLLER (41): Metadata, then the new controller.
                self.forget_controller();
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                self.refresh_broker_directory(deadline).await?;
                continue;
            }
            if resp.error_code != 0 {
                return Err(Error::broker(resp.error_code, "UnregisterBroker"));
            }
            return Ok(());
        }
    }

    /// Describe client quotas (DescribeClientQuotas api 48, KIP-219).
    ///
    /// Lands on the connected broker (bootstrap is fine). Negotiates
    /// DescribeClientQuotas v0–v1 (Kafka 4.0 `validVersions` `0-1`;
    /// v0 classic, v1 flexible). Official Apache
    /// JSON listeners are `broker` only. This is not a controller hop:
    /// there is no Metadata `controller_id` lookup and no
    /// `NOT_CONTROLLER` (41) retry. Top-level `error_code` is the INT16
    /// at bytes 4–5, after throttle. DescribeClientQuotas has no TimeoutMs;
    /// the RPC deadline is [`AdminConfig::request_timeout`]. For a
    /// one-shot deadline, use [`Self::describe_client_quotas_timeout`].
    /// Optional at [`Self::new`] (Kafka 2.6+ / KIP-219); a broker that
    /// omits api 48 returns [`Error::Unsupported`]. See
    /// [`Self::describe_client_quotas_all`] for Java
    /// `ClientQuotaFilter.all()`, or [`Self::describe_client_quotas_with`]
    /// for [`ClientQuotaFilter::contains`] / [`ClientQuotaFilter::contains_only`].
    pub async fn describe_client_quotas(
        &mut self,
        components: &[ClientQuotaFilterComponent],
        strict: bool,
    ) -> Result<Vec<ClientQuotaEntry>> {
        let timeout = self.cfg.request_timeout;
        self.describe_client_quotas_timeout(components, strict, timeout)
            .await
    }

    /// [`Self::describe_client_quotas`] with a one-shot RPC deadline (Java
    /// `DescribeClientQuotasOptions.timeoutMs`).
    ///
    /// DescribeClientQuotas has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn describe_client_quotas_timeout(
        &mut self,
        components: &[ClientQuotaFilterComponent],
        strict: bool,
        timeout: Duration,
    ) -> Result<Vec<ClientQuotaEntry>> {
        let version = self.describe_client_quotas_version.ok_or_else(|| {
            Error::Unsupported("broker does not support DescribeClientQuotas v0-1".into())
        })?;
        let mut payload = BytesMut::new();
        encode_describe_client_quotas_request_cooperative(
            &mut payload,
            version,
            components,
            strict,
        )
        .await?;
        let body = self
            .roundtrip_bootstrap(
                DESCRIBE_CLIENT_QUOTAS,
                version,
                |buf| {
                    buf.extend_from_slice(&payload);
                    Ok(())
                },
                timeout,
            )
            .await?;
        let resp =
            decode_describe_client_quotas_response_cooperative(&mut body.clone(), version).await?;
        if resp.error_code != 0 {
            return Err(Error::broker(resp.error_code, "DescribeClientQuotas"));
        }
        Ok(resp.entries.unwrap_or_default())
    }

    /// [`Self::describe_client_quotas`] with a Java `ClientQuotaFilter`.
    ///
    /// DescribeClientQuotas has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::describe_client_quotas_with_timeout`].
    pub async fn describe_client_quotas_with(
        &mut self,
        filter: &ClientQuotaFilter,
    ) -> Result<Vec<ClientQuotaEntry>> {
        self.describe_client_quotas(filter.components(), filter.strict())
            .await
    }

    /// [`Self::describe_client_quotas_with`] with a one-shot RPC deadline
    /// (Java `DescribeClientQuotasOptions.timeoutMs`).
    ///
    /// DescribeClientQuotas has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn describe_client_quotas_with_timeout(
        &mut self,
        filter: &ClientQuotaFilter,
        timeout: Duration,
    ) -> Result<Vec<ClientQuotaEntry>> {
        self.describe_client_quotas_timeout(filter.components(), filter.strict(), timeout)
            .await
    }

    /// Describe every client quota (Java `ClientQuotaFilter.all()`).
    ///
    /// Same wire as [`Self::describe_client_quotas_with`] with
    /// [`ClientQuotaFilter::all`].
    pub async fn describe_client_quotas_all(&mut self) -> Result<Vec<ClientQuotaEntry>> {
        self.describe_client_quotas_with(&ClientQuotaFilter::all())
            .await
    }

    /// [`Self::describe_client_quotas_all`] with a one-shot RPC deadline
    /// (Java `DescribeClientQuotasOptions.timeoutMs`).
    pub async fn describe_client_quotas_all_timeout(
        &mut self,
        timeout: Duration,
    ) -> Result<Vec<ClientQuotaEntry>> {
        self.describe_client_quotas_with_timeout(&ClientQuotaFilter::all(), timeout)
            .await
    }

    /// Upsert or delete client quotas (AlterClientQuotas api 49).
    ///
    /// Lands on the Metadata controller. Negotiates AlterClientQuotas
    /// v0–v1 (Kafka 4.0 `validVersions` `0-1`; v0 classic, v1 flexible).
    /// `NOT_CONTROLLER` (41) refreshes Metadata and retries on the new
    /// controller. AlterClientQuotas has no TimeoutMs; the RPC deadline
    /// is [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::alter_client_quotas_timeout`]. Optional at [`Self::new`]
    /// (Kafka 2.6+ / KIP-219); a broker that omits api 49 returns
    /// [`Error::Unsupported`].
    pub async fn alter_client_quotas(
        &mut self,
        entries: &[ClientQuotaAlteration],
        validate_only: bool,
    ) -> Result<Vec<ClientQuotaAlterationResult>> {
        let timeout = self.cfg.request_timeout;
        self.alter_client_quotas_timeout(entries, timeout, validate_only)
            .await
    }

    /// [`Self::alter_client_quotas`] with a one-shot RPC deadline (Java
    /// `AlterClientQuotasOptions.timeoutMs`).
    ///
    /// AlterClientQuotas has no TimeoutMs; `timeout` is the RPC deadline
    /// and the `NOT_CONTROLLER` retry budget.
    pub async fn alter_client_quotas_timeout(
        &mut self,
        entries: &[ClientQuotaAlteration],
        timeout: Duration,
        validate_only: bool,
    ) -> Result<Vec<ClientQuotaAlterationResult>> {
        let version = self.alter_client_quotas_version.ok_or_else(|| {
            Error::Unsupported("broker does not support AlterClientQuotas v0-1".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut encoded = BytesMut::new();
        encode_alter_client_quotas_request_cooperative(
            &mut encoded,
            version,
            entries,
            validate_only,
        )
        .await?;
        loop {
            if self.cluster.controller().is_err() {
                self.refresh_broker_directory(deadline).await?;
            }
            let node = self.cluster.controller()?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    ALTER_CLIENT_QUOTAS,
                    version,
                    |buf| {
                        buf.extend_from_slice(&encoded);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.forget_controller();
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let (results, ..) =
                decode_alter_client_quotas_response_cooperative(&mut body.clone(), version).await?;
            if results
                .iter()
                .any(|r| r.error_code == error::NOT_CONTROLLER)
            {
                // NOT_CONTROLLER (41): Metadata, then the new controller.
                self.forget_controller();
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                self.refresh_broker_directory(deadline).await?;
                continue;
            }
            return Ok(results);
        }
    }

    /// Allocate a producer-id block (AllocateProducerIds api 67).
    ///
    /// Lands on the Metadata controller. `NOT_CONTROLLER` (41) refreshes
    /// Metadata and retries on the new controller. `broker_id` /
    /// `broker_epoch` are the requesting broker's fixture identity.
    /// AllocateProducerIds has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::allocate_producer_ids_timeout`].
    pub async fn allocate_producer_ids(
        &mut self,
        broker_id: i32,
        broker_epoch: i64,
    ) -> Result<ProducerIdBlock> {
        let timeout = self.cfg.request_timeout;
        self.allocate_producer_ids_timeout(broker_id, broker_epoch, timeout)
            .await
    }

    /// [`Self::allocate_producer_ids`] with a one-shot RPC deadline.
    ///
    /// AllocateProducerIds has no TimeoutMs; `timeout` is the RPC
    /// deadline and the `NOT_CONTROLLER` retry budget. Java `Admin`
    /// has no `allocateProducerIds`; this overload is crate-first.
    pub async fn allocate_producer_ids_timeout(
        &mut self,
        broker_id: i32,
        broker_epoch: i64,
        timeout: Duration,
    ) -> Result<ProducerIdBlock> {
        let version = self.allocate_producer_ids_version.ok_or_else(|| {
            Error::Unsupported("broker does not support AllocateProducerIds".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        loop {
            if self.cluster.controller().is_err() {
                self.refresh_broker_directory(deadline).await?;
            }
            let node = self.cluster.controller()?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    ALLOCATE_PRODUCER_IDS,
                    version,
                    |buf| encode_allocate_producer_ids_request(buf, broker_id, broker_epoch),
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.forget_controller();
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let resp = decode_allocate_producer_ids_response(&mut body.clone())?;
            if resp.error_code == error::NOT_CONTROLLER {
                // NOT_CONTROLLER (41): Metadata, then the new controller.
                self.forget_controller();
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                self.refresh_broker_directory(deadline).await?;
                continue;
            }
            if resp.error_code != 0 {
                return Err(Error::broker(resp.error_code, "AllocateProducerIds"));
            }
            return Ok(ProducerIdBlock {
                producer_id_start: resp.producer_id_start,
                producer_id_len: resp.producer_id_len,
            });
        }
    }

    /// Fence transactional producers (Java `Admin.fenceProducers`).
    ///
    /// InitProducerId v0–v5 on each `transactional.id`'s transaction
    /// coordinator (`FindCoordinator` `key_type=1`). Empty
    /// `transactional_ids` returns an empty list. Coordinator load /
    /// move errors refresh and retry. [`AdminConfig::request_timeout`]
    /// is the RPC deadline and is sent as `transaction.timeout.ms`. For
    /// a one-shot timeout, use [`Self::fence_producers_timeout`]. Java
    /// `forceTerminateTransaction` is [`Self::force_terminate_transaction`].
    pub async fn fence_producers(
        &mut self,
        transactional_ids: impl IntoIterator<Item = impl Into<String>>,
    ) -> Result<Vec<FencedProducer>> {
        let timeout = self.cfg.request_timeout;
        self.fence_producers_timeout(transactional_ids, timeout)
            .await
    }

    /// [`Self::fence_producers`] with a one-shot timeout (Java
    /// `fenceProducers` plus `FenceProducersOptions.timeoutMs`).
    ///
    /// `timeout` is the shared deadline and InitProducerId
    /// `transaction.timeout.ms`. Distinct coordinators are fenced together.
    ///
    /// Ids are copied in slices of 8,192, so the timeout can still fire while
    /// a long list is prepared. Each id is still copied.
    pub async fn fence_producers_timeout(
        &mut self,
        transactional_ids: impl IntoIterator<Item = impl Into<String>>,
        timeout: Duration,
    ) -> Result<Vec<FencedProducer>> {
        let ids = collect_strings(transactional_ids).await;
        if ids.len() <= 1 {
            let mut out = Vec::new();
            for id in &ids {
                let (producer_id, epoch) = self.fence_one(id, timeout).await?;
                out.push(FencedProducer {
                    transactional_id: id.clone(),
                    producer_id,
                    epoch,
                });
            }
            return Ok(out);
        }
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let deadline = Instant::now()
            .checked_add(timeout)
            .ok_or_else(|| Error::protocol("fenceProducers deadline overflow"))?;
        let version = self
            .versions
            .get(&INIT_PRODUCER_ID)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 5))
            .ok_or_else(|| Error::Unsupported("broker does not support InitProducerId".into()))?;
        let txn_timeout_ms = crate::consumer::duration_millis_i32(timeout);
        let refs: Vec<&str> = ids.iter().map(String::as_str).collect();
        let mut out: Vec<Option<(i64, i16)>> = open_result_slots(ids.len()).await;
        let mut pending = pending_indexes(ids.len()).await;
        let mut attempt = 0u32;
        while !pending.is_empty() {
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            let by_node = self.txn_coord_nodes(&refs, &pending, deadline).await?;
            let mut nodes: Vec<i32> = by_node.keys().copied().collect();
            nodes.sort_unstable();
            let mut wave: Vec<(i32, usize)> = Vec::new();
            let mut later = Vec::new();
            for node in &nodes {
                let Some(idxs) = by_node.get(node) else {
                    continue;
                };
                let mut first = true;
                for &index in idxs {
                    if first {
                        wave.push((*node, index));
                        first = false;
                    } else {
                        later.push(index);
                    }
                }
            }
            if wave.len() <= 1 {
                let Some((_, index)) = wave.pop() else {
                    break;
                };
                let id = refs
                    .get(index)
                    .copied()
                    .ok_or_else(|| Error::protocol("missing transactional id"))?;
                let (producer_id, epoch) =
                    self.fence_one_until(id, txn_timeout_ms, deadline).await?;
                if let Some(slot) = out.get_mut(index) {
                    *slot = Some((producer_id, epoch));
                }
                pending = later;
                continue;
            }
            let mut node_index: HashMap<i32, usize> = HashMap::new();
            for (node, index) in &wave {
                let _ = node_index.insert(*node, *index);
            }
            let wave_nodes: Vec<i32> = wave.iter().map(|(node, _)| *node).collect();
            let mut finished = self
                .exchange_leaders(&wave_nodes, deadline, |_admin, node, _conn, _timeout| {
                    let index = node_index
                        .get(&node)
                        .copied()
                        .ok_or_else(|| Error::protocol("missing transactional id"))?;
                    let id = refs
                        .get(index)
                        .copied()
                        .ok_or_else(|| Error::protocol("missing transactional id"))?;
                    let mut payload = BytesMut::new();
                    encode_init_producer_id_request(
                        &mut payload,
                        version,
                        Some(id),
                        txn_timeout_ms,
                        crate::RecordBatch::NO_PRODUCER_ID,
                        crate::RecordBatch::NO_PRODUCER_EPOCH,
                    )?;
                    Ok(LeaderFrame::ready(
                        INIT_PRODUCER_ID,
                        version,
                        payload.freeze(),
                    ))
                })
                .await;
            let mut again = Vec::new();
            for (node, index) in wave {
                if refs.get(index).is_none() {
                    return Err(Error::protocol("missing transactional id"));
                }
                let Some((spoken, body)) = finished.remove(&node) else {
                    self.invalidate_txn_coord_idxs(&refs, &[index], node).await;
                    again.push(index);
                    continue;
                };
                match body {
                    Err(error) if matches!(error, Error::Timeout) => return Err(error),
                    Err(error) if error.is_retriable() => {
                        self.invalidate_txn_coord_idxs(&refs, &[index], node).await;
                        again.push(index);
                    }
                    Err(error) => return Err(error),
                    Ok(body) => {
                        let (err, producer_id, epoch, ..) =
                            decode_init_producer_id_response(&mut body.clone(), spoken)?;
                        if err == 0 {
                            if let Some(slot) = out.get_mut(index) {
                                *slot = Some((producer_id, epoch));
                            }
                        } else if error::coordinator_retriable(err) {
                            self.invalidate_txn_coord_idxs(&refs, &[index], node).await;
                            again.push(index);
                        } else {
                            return Err(Error::broker(err, "InitProducerId"));
                        }
                    }
                }
            }
            let retry = !again.is_empty();
            pending = later;
            pending.extend(again);
            if retry {
                self.wait_retry(&mut attempt, deadline).await?;
            }
        }
        out.into_iter()
            .zip(ids)
            .map(|(fenced, transactional_id)| {
                let (producer_id, epoch) = fenced.ok_or_else(|| {
                    Error::protocol(format!("InitProducerId missing {transactional_id}"))
                })?;
                Ok(FencedProducer {
                    transactional_id,
                    producer_id,
                    epoch,
                })
            })
            .collect()
    }

    /// Force-terminate a transactional id (Java
    /// `Admin.forceTerminateTransaction`).
    ///
    /// Same wire as [`Self::fence_producers`] for one id: InitProducerId
    /// on the transaction coordinator (`FindCoordinator` `key_type=1`).
    /// Java's `forceTerminateTransaction` calls `fenceProducers` with a
    /// singleton set. Waits up to [`AdminConfig::request_timeout`]. For
    /// a one-shot timeout, use [`Self::force_terminate_transaction_timeout`].
    pub async fn force_terminate_transaction(
        &mut self,
        transactional_id: impl Into<String>,
    ) -> Result<FencedProducer> {
        let timeout = self.cfg.request_timeout;
        self.force_terminate_transaction_timeout(transactional_id, timeout)
            .await
    }

    /// [`Self::force_terminate_transaction`] with a one-shot timeout
    /// (Java `forceTerminateTransaction` plus
    /// `FenceProducersOptions.timeoutMs`).
    pub async fn force_terminate_transaction_timeout(
        &mut self,
        transactional_id: impl Into<String>,
        timeout: Duration,
    ) -> Result<FencedProducer> {
        let transactional_id = transactional_id.into();
        let (producer_id, epoch) = self.fence_one(&transactional_id, timeout).await?;
        Ok(FencedProducer {
            transactional_id,
            producer_id,
            epoch,
        })
    }

    async fn fence_one(&mut self, transactional_id: &str, timeout: Duration) -> Result<(i64, i16)> {
        let txn_timeout_ms = crate::consumer::duration_millis_i32(timeout);
        let deadline = Instant::now() + timeout;
        self.fence_one_until(transactional_id, txn_timeout_ms, deadline)
            .await
    }

    async fn fence_one_until(
        &mut self,
        transactional_id: &str,
        txn_timeout_ms: i32,
        deadline: Instant,
    ) -> Result<(i64, i16)> {
        let version = self
            .versions
            .get(&INIT_PRODUCER_ID)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 5))
            .ok_or_else(|| Error::Unsupported("broker does not support InitProducerId".into()))?;
        let mut attempt = 0u32;
        loop {
            let stale = self
                .txn_coord
                .as_ref()
                .is_none_or(|(k, _)| k != transactional_id);
            if stale {
                let node = self.discover_txn_coord(transactional_id, deadline).await?;
                self.txn_coord = Some((transactional_id.to_string(), node));
            }
            let node = self
                .txn_coord
                .as_ref()
                .map(|(_, n)| *n)
                .ok_or_else(|| Error::protocol("missing transaction coordinator"))?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    INIT_PRODUCER_ID,
                    version,
                    |buf| {
                        encode_init_producer_id_request(
                            buf,
                            version,
                            Some(transactional_id),
                            txn_timeout_ms,
                            crate::RecordBatch::NO_PRODUCER_ID,
                            crate::RecordBatch::NO_PRODUCER_EPOCH,
                        )
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.txn_coord = None;
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let (err, producer_id, epoch, ..) =
                decode_init_producer_id_response(&mut body.clone(), version)?;
            if err == 0 {
                return Ok((producer_id, epoch));
            }
            if error::coordinator_retriable(err) {
                self.txn_coord = None;
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                continue;
            }
            return Err(Error::broker(err, "InitProducerId"));
        }
    }

    /// Force-abort an open transaction on a partition (Java `abortTransaction`).
    ///
    /// Sends WriteTxnMarkers (api27) v0 classic or v1/v2 flexible with `transactionResult=false` to the
    /// Metadata partition leader. `NOT_LEADER_OR_FOLLOWER` and
    /// fenced/unknown leader epochs refresh Metadata and retry. This is
    /// not a controller hop and not a transaction-coordinator hop.
    /// Version2 sends default TransactionVersion0 like Java force-abort. WriteTxnMarkers
    /// has no TimeoutMs; the RPC deadline is [`AdminConfig::request_timeout`].
    /// For a one-shot deadline, use [`Self::abort_transaction_timeout`].
    pub async fn abort_transaction(&mut self, spec: AbortTransactionSpec) -> Result<()> {
        let timeout = self.cfg.request_timeout;
        self.abort_transaction_timeout(spec, timeout).await
    }

    /// [`Self::abort_transaction`] with a one-shot RPC deadline (Java
    /// `AbortTransactionOptions.timeoutMs`).
    ///
    /// WriteTxnMarkers has no TimeoutMs; `timeout` is the RPC deadline
    /// and the `NOT_LEADER_OR_FOLLOWER` retry budget.
    pub async fn abort_transaction_timeout(
        &mut self,
        spec: AbortTransactionSpec,
        timeout: Duration,
    ) -> Result<()> {
        let version = self
            .versions
            .get(&WRITE_TXN_MARKERS)
            .and_then(|v| pick_version(v.min_version, v.max_version, 0, 2))
            .ok_or_else(|| Error::Unsupported("broker does not support WriteTxnMarkers".into()))?;
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let deadline = Instant::now()
            .checked_add(timeout)
            .ok_or_else(|| Error::protocol("WriteTxnMarkers deadline overflow"))?;
        let mut attempt = 0u32;
        let partitions = [spec.partition];
        let topics = [BorrowedTxnMarkerTopic {
            name: spec.topic.as_str(),
            partitions: &partitions,
        }];
        let marker = [BorrowedTxnMarker {
            producer_id: spec.producer_id,
            producer_epoch: spec.producer_epoch,
            transaction_result: TransactionResult::Abort.id(),
            topics: &topics,
            coordinator_epoch: spec.coordinator_epoch,
        }];
        loop {
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            if self.cluster.leader_id(&spec.topic, spec.partition).is_err() {
                let topics = [spec.topic.as_str()];
                self.refresh_metadata_ref(Some(&topics), deadline).await?;
            }
            let node = self.cluster.leader_id(&spec.topic, spec.partition)?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    WRITE_TXN_MARKERS,
                    version,
                    |buf| encode_write_txn_markers_named(buf, version, &marker),
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let mut cursor = body.clone();
            let resp = decode_write_txn_markers_response_cooperative(&mut cursor, version).await?;
            if !cursor.is_empty() {
                return Err(Error::protocol("WriteTxnMarkers trailing response bytes"));
            }
            // Official AbortTransactionHandler requires exactly one matching
            // marker/topic/partition before consulting its error. A generic
            // batched codec permits many entries; this public operation sent
            // exactly one marker and must not infer success from absence.
            let [marker_result] = resp.as_slice() else {
                return Err(Error::protocol("WriteTxnMarkers unexpected marker count"));
            };
            if marker_result.producer_id != spec.producer_id {
                return Err(Error::protocol(
                    "WriteTxnMarkers unexpected producer identity",
                ));
            }
            let [topic_result] = marker_result.topics.as_slice() else {
                return Err(Error::protocol("WriteTxnMarkers unexpected topic count"));
            };
            if topic_result.name != spec.topic {
                return Err(Error::protocol("WriteTxnMarkers unexpected topic identity"));
            }
            let [partition_result] = topic_result.partitions.as_slice() else {
                return Err(Error::protocol(
                    "WriteTxnMarkers unexpected partition count",
                ));
            };
            if partition_result.partition_index != spec.partition {
                return Err(Error::protocol(
                    "WriteTxnMarkers unexpected partition identity",
                ));
            }
            let error_code = partition_result.error_code;
            if error_code == 0 {
                return Ok(());
            }
            let e = Error::broker(error_code, "WriteTxnMarkers");
            if matches!(
                error_code,
                error::FENCED_LEADER_EPOCH
                    | error::UNKNOWN_LEADER_EPOCH
                    | error::BROKER_NOT_AVAILABLE
                    | error::REPLICA_NOT_AVAILABLE
            ) || e.is_retriable()
            {
                let known = [node];
                self.cluster.invalidate_topic(&spec.topic);
                self.discard_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                let topics = [spec.topic.as_str()];
                self.refresh_topics_while_dialing(&topics, &known, deadline)
                    .await?;
                continue;
            }
            return Err(e);
        }
    }

    /// Describe transactional.id state (DescribeTransactions api 65).
    ///
    /// Lands on the transaction coordinator (`FindCoordinator`
    /// `key_type=1`). `COORDINATOR_LOAD_IN_PROGRESS` /
    /// `COORDINATOR_NOT_AVAILABLE` / `NOT_COORDINATOR` (16) refresh the
    /// coordinator and retry. This is not `NOT_CONTROLLER` (41).
    /// FindCoordinator v4+ CoordinatorKeys array of N (KIP-699): one
    /// FindCoordinator per retry for uncached transactional ids.
    /// DescribeTransactions is one RPC per coordinator, and those RPCs run
    /// together. Brokers that
    /// only speak FindCoordinator v1–v3 get one FindCoordinator per
    /// uncached id. Empty input is a no-op. Optional at [`Self::new`]
    /// (Kafka 2.5+ / KIP-573); a broker that omits api 65 returns
    /// [`Error::Unsupported`]. DescribeTransactions has no TimeoutMs;
    /// the RPC deadline is [`AdminConfig::request_timeout`]. For a
    /// one-shot deadline, use [`Self::describe_transactions_timeout`].
    pub async fn describe_transactions(
        &mut self,
        transactional_ids: &[&str],
    ) -> Result<Vec<TransactionState>> {
        let timeout = self.cfg.request_timeout;
        self.describe_transactions_timeout(transactional_ids, timeout)
            .await
    }

    /// [`Self::describe_transactions`] with a one-shot RPC deadline (Java
    /// `DescribeTransactionsOptions.timeoutMs`).
    ///
    /// DescribeTransactions has no TimeoutMs; `timeout` is the RPC
    /// deadline and the coordinator retry budget.
    pub async fn describe_transactions_timeout(
        &mut self,
        transactional_ids: &[&str],
        timeout: Duration,
    ) -> Result<Vec<TransactionState>> {
        let ids = transactional_ids;
        if ids.is_empty() {
            return Ok(Vec::new());
        }
        let version = self.describe_transactions_version.ok_or_else(|| {
            Error::Unsupported("broker does not support DescribeTransactions".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut out: Vec<Option<TransactionState>> = open_result_slots(ids.len()).await;
        let mut pending = pending_indexes(ids.len()).await;
        loop {
            let by_node = self.txn_coord_nodes(ids, &pending, deadline).await?;
            let mut nodes: Vec<i32> = by_node.keys().copied().collect();
            nodes.sort_unstable();
            let mut still = Vec::new();
            if nodes.len() > 1 {
                let mut prepared = HashMap::new();
                for node in &nodes {
                    let idxs = by_node.get(node).map(Vec::as_slice).unwrap_or(&[]);
                    let subset = borrowed_ids(ids, idxs);
                    let mut payload = BytesMut::new();
                    encode_describe_transactions_ids_cooperative(&mut payload, &subset).await?;
                    let _previous = prepared.insert(*node, payload.freeze());
                }
                let mut finished = self
                    .exchange_leaders(&nodes, deadline, |_admin, node, _conn, _timeout| {
                        let payload = prepared.get(&node).cloned().ok_or_else(|| {
                            Error::protocol("missing describe transactions request")
                        })?;
                        Ok(LeaderFrame::ready(DESCRIBE_TRANSACTIONS, version, payload))
                    })
                    .await;
                for node in &nodes {
                    let idxs = by_node.get(node).cloned().unwrap_or_default();
                    let Some((_spoken, body)) = finished.remove(node) else {
                        self.invalidate_txn_coord_idxs(ids, &idxs, *node).await;
                        still.extend(idxs);
                        continue;
                    };
                    match body {
                        Err(error) if error.is_retriable() => {
                            self.invalidate_txn_coord_idxs(ids, &idxs, *node).await;
                            still.extend(idxs);
                        }
                        Err(error) => return Err(error),
                        Ok(body) => {
                            let done =
                                Self::apply_describe_transactions_body(ids, &idxs, body).await?;
                            for (i, t) in done {
                                if error::coordinator_retriable(t.error_code) {
                                    self.invalidate_txn_coord_idxs(ids, &[i], *node).await;
                                    still.push(i);
                                } else if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(t);
                                }
                            }
                        }
                    }
                }
            } else {
                for node in nodes {
                    let idxs = by_node.get(&node).cloned().unwrap_or_default();
                    match self
                        .describe_transactions_on_node(node, ids, &idxs, version, deadline)
                        .await
                    {
                        Ok(done) => {
                            for (i, t) in done {
                                if error::coordinator_retriable(t.error_code) {
                                    self.invalidate_txn_coord_idxs(ids, &[i], node).await;
                                    still.push(i);
                                } else if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(t);
                                }
                            }
                        }
                        Err(e) if e.is_retriable() => {
                            self.invalidate_txn_coord_idxs(ids, &idxs, node).await;
                            still.extend(idxs);
                        }
                        Err(e) => return Err(e),
                    }
                }
            }
            pending = still;
            if pending.is_empty() {
                break;
            }
            self.wait_retry(&mut attempt, deadline).await?;
        }
        out.into_iter()
            .zip(ids)
            .map(|(t, id)| {
                t.ok_or_else(|| Error::protocol(format!("DescribeTransactions missing {id}")))
            })
            .collect()
    }

    /// List transactional.id state from every broker (ListTransactions api 66).
    ///
    /// Queries every broker from Metadata and negotiates each connection.
    /// Complete results require every broker to succeed; load delays retry the
    /// affected broker under one caller deadline.
    /// Duration is unfiltered (`-1`). See
    /// [`Self::list_transactions_with_duration`] for Java
    /// `ListTransactionsOptions.filterOnDuration`. Optional at
    /// [`Self::new`] (Kafka 2.5+ / KIP-573); a broker that omits api 66
    /// returns [`Error::Unsupported`]. ListTransactions has no TimeoutMs;
    /// the RPC deadline is [`AdminConfig::request_timeout`]. For a
    /// one-shot deadline, use [`Self::list_transactions_timeout`].
    pub async fn list_transactions(
        &mut self,
        state_filters: &[&str],
        producer_id_filters: &[i64],
    ) -> Result<Vec<TransactionListing>> {
        let timeout = self.cfg.request_timeout;
        self.list_transactions_timeout(state_filters, producer_id_filters, timeout)
            .await
    }

    /// [`Self::list_transactions`] with a one-shot RPC deadline (Java
    /// `ListTransactionsOptions.timeoutMs`).
    ///
    /// ListTransactions has no TimeoutMs; `timeout` is the RPC deadline
    /// and the total all-broker retry budget. DurationFilter stays `-1`
    /// (unfiltered). See [`Self::list_transactions_with_duration_timeout`]
    /// for `filterOnDuration` plus deadline.
    pub async fn list_transactions_timeout(
        &mut self,
        state_filters: &[&str],
        producer_id_filters: &[i64],
        timeout: Duration,
    ) -> Result<Vec<TransactionListing>> {
        self.list_transactions_with_duration_timeout(
            state_filters,
            producer_id_filters,
            -1,
            timeout,
        )
        .await
    }

    /// List every transaction (Java `Admin.listTransactions()`).
    ///
    /// Same wire as [`Self::list_transactions`] with empty state and
    /// producer-id filters and DurationFilter `-1` (Java
    /// `ListTransactionsOptions` default).
    pub async fn list_transactions_all(&mut self) -> Result<Vec<TransactionListing>> {
        self.list_transactions(&[], &[]).await
    }

    /// [`Self::list_transactions_all`] with a one-shot RPC deadline (Java
    /// `ListTransactionsOptions.timeoutMs`).
    pub async fn list_transactions_all_timeout(
        &mut self,
        timeout: Duration,
    ) -> Result<Vec<TransactionListing>> {
        self.list_transactions_timeout(&[], &[], timeout).await
    }

    /// ListTransactions with a duration filter (Java `listTransactions`
    /// plus `ListTransactionsOptions.filterOnDuration`).
    ///
    /// Negative `duration_ms` means no duration filter (Java default `-1`).
    /// v1 sends `DurationFilter` INT64 (KIP-994). Java
    /// `ListTransactionsRequest.Builder.build` rejects a non-negative
    /// DurationFilter on v0 ([`Error::Unsupported`]). Kafka 4.0
    /// `validVersions` is `0-1`. This crate speaks 0–1. v2
    /// Pattern filters use [`Self::list_transactions_with_options`]. ListTransactions has no
    /// TimeoutMs; the RPC deadline is [`AdminConfig::request_timeout`].
    /// For a one-shot deadline, use
    /// [`Self::list_transactions_with_duration_timeout`].
    pub async fn list_transactions_with_duration(
        &mut self,
        state_filters: &[&str],
        producer_id_filters: &[i64],
        duration_ms: i64,
    ) -> Result<Vec<TransactionListing>> {
        let timeout = self.cfg.request_timeout;
        self.list_transactions_with_duration_timeout(
            state_filters,
            producer_id_filters,
            duration_ms,
            timeout,
        )
        .await
    }

    /// List transactions with complete results from every discovered broker.
    ///
    /// Discovery, authentication, negotiation and retries share one absolute
    /// deadline. Brokers are queried sequentially in ascending ID order; their
    /// listings are concatenated without deduplicating transactional IDs.
    /// Use [`Self::list_transactions_by_broker_timeout`] to inspect partial
    /// successes and the error from each broker.
    pub async fn list_transactions_with_duration_timeout(
        &mut self,
        state_filters: &[&str],
        producer_id_filters: &[i64],
        duration_ms: i64,
        timeout: Duration,
    ) -> Result<Vec<TransactionListing>> {
        let results = self
            .list_transactions_by_broker_timeout(
                state_filters,
                producer_id_filters,
                duration_ms,
                timeout,
            )
            .await?;
        let mut all = Vec::new();
        for broker in results {
            all.extend(broker.listings?);
        }
        Ok(all)
    }

    /// List transactions with broker IDs and individual success/error results.
    ///
    /// This queries the broker membership returned by one Metadata discovery,
    /// including brokers which own no matching transactions. Results retain
    /// duplicate IDs and contradictory states from different brokers. A
    /// discovery failure is returned directly; after discovery each broker has
    /// a result, including brokers not reached before the deadline.
    ///
    /// The local limits are 256 brokers, 100,000 listings, 16 MiB of cumulative
    /// API66 response bodies, eight attempts per broker and three Metadata
    /// refreshes. Only one broker request is active. Discovery and refresh
    /// bodies are limited to 1 MiB. The transport's existing 100 MiB frame cap
    /// applies before this operation can inspect a received body. Filter arrays
    /// are limited to 8,192 elements each and state-filter text to 256 KiB.
    /// Exceeding a limit returns an error rather than a partial-only success.
    ///
    /// Duration filters require API66 v1 on every broker. This operation speaks
    /// versions 0–2 and negotiates separately on each selected connection.
    /// All work is awaited by this future; dropping it cancels its active wait.
    pub async fn list_transactions_by_broker(
        &mut self,
        state_filters: &[&str],
        producer_id_filters: &[i64],
        duration_ms: i64,
    ) -> Result<Vec<BrokerTransactionListings>> {
        let timeout = self.cfg.request_timeout;
        self.list_transactions_by_broker_timeout(
            state_filters,
            producer_id_filters,
            duration_ms,
            timeout,
        )
        .await
    }

    /// [`Self::list_transactions_by_broker`] with one total caller deadline.
    ///
    /// A timeout preserves completed broker results and records [`Error::Timeout`]
    /// for each remaining broker. The complete-only Vec-returning methods fail
    /// when any broker fails. Membership is the initial discovery snapshot;
    /// bounded refreshes resolve address changes for those broker IDs.
    pub async fn list_transactions_by_broker_timeout(
        &mut self,
        state_filters: &[&str],
        producer_id_filters: &[i64],
        duration_ms: i64,
        timeout: Duration,
    ) -> Result<Vec<BrokerTransactionListings>> {
        self.list_transactions_by_broker_inner(
            state_filters,
            producer_id_filters,
            duration_ms,
            None,
            timeout,
        )
        .await
    }

    /// Query every broker with typed state, producer, duration and pattern options.
    pub async fn list_transactions_with_options(
        &mut self,
        options: &ListTransactionsOptions,
    ) -> Result<Vec<TransactionListing>> {
        self.list_transactions_with_options_timeout(options, self.cfg.request_timeout)
            .await
    }

    /// Typed complete-only query under one original caller deadline.
    pub async fn list_transactions_with_options_timeout(
        &mut self,
        options: &ListTransactionsOptions,
        timeout: Duration,
    ) -> Result<Vec<TransactionListing>> {
        let brokers = self
            .list_transactions_by_broker_with_options_timeout(options, timeout)
            .await?;
        let mut all = Vec::new();
        for broker in brokers {
            all.extend(broker.listings?);
        }
        Ok(all)
    }

    /// Typed query preserving broker origins and partial errors.
    pub async fn list_transactions_by_broker_with_options(
        &mut self,
        options: &ListTransactionsOptions,
    ) -> Result<Vec<BrokerTransactionListings>> {
        self.list_transactions_by_broker_with_options_timeout(options, self.cfg.request_timeout)
            .await
    }

    /// Typed per-broker query with shared deadline and the ordinary listing bounds.
    ///
    /// Pattern text is limited to256 KiB before discovery or request writes.
    /// Nonempty patterns require v2; unsupported brokers remain explicit errors.
    pub async fn list_transactions_by_broker_with_options_timeout(
        &mut self,
        options: &ListTransactionsOptions,
        timeout: Duration,
    ) -> Result<Vec<BrokerTransactionListings>> {
        let pattern = options
            .transactional_id_pattern
            .as_deref()
            .filter(|p| !p.is_empty());
        self.list_transactions_by_broker_inner(
            &options.state_filters,
            &options.producer_id_filters,
            options.duration_ms,
            pattern,
            timeout,
        )
        .await
    }

    async fn list_transactions_by_broker_inner<S: AsRef<str>>(
        &mut self,
        state_filters: &[S],
        producer_id_filters: &[i64],
        duration_ms: i64,
        pattern: Option<&str>,
        timeout: Duration,
    ) -> Result<Vec<BrokerTransactionListings>> {
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let deadline = Instant::now()
            .checked_add(timeout)
            .ok_or_else(|| Error::protocol("ListTransactions deadline overflow"))?;
        if state_filters.len() > 8_192 || producer_id_filters.len() > 8_192 {
            return Err(Error::protocol(
                "ListTransactions filter count exceeds local limit",
            ));
        }
        let text_bytes = state_filters.iter().try_fold(0usize, |total, value| {
            total.checked_add(value.as_ref().len())
        });
        if text_bytes.is_none_or(|bytes| bytes > 256 * 1024)
            || pattern.is_some_and(|p| p.len() > 256 * 1024)
        {
            return Err(Error::protocol(
                "ListTransactions filter text exceeds local limit",
            ));
        }
        let query = ListTransactionsQuery {
            states: state_filters,
            producer_ids: producer_id_filters,
            duration_ms,
            pattern,
        };
        let nodes = self.list_transactions_broker_ids(deadline).await?;
        let mut results = Vec::with_capacity(nodes.len());
        let mut budget = ListTransactionsBudget::default();
        for node in nodes {
            let listings = self
                .list_transactions_on_broker(node, &query, deadline, &mut budget)
                .await;
            results.push(BrokerTransactionListings {
                broker_id: node,
                listings,
            });
        }
        Ok(results)
    }

    async fn list_transactions_broker_ids(&mut self, deadline: Instant) -> Result<Vec<i32>> {
        let version = self.metadata_version;
        let body = self
            .roundtrip_bootstrap(
                METADATA,
                version,
                |buf| encode_metadata_request_topics(buf, version, Some(&[]), version < 4, false),
                deadline.saturating_duration_since(Instant::now()),
            )
            .await?;
        if body.len() > 1024 * 1024 {
            return Err(Error::protocol(
                "ListTransactions Metadata exceeds 1 MiB limit",
            ));
        }
        // Validate every borrowed field and empty topic selection before the
        // ordinary decoder allocates any broker, string or topic vector.
        validate_list_transactions_metadata(&body, version)?;
        let mut cursor = body.as_ref();
        // Empty topic selection would truncate the stored image's topic buffers.
        let metadata = decode_metadata_response(&mut cursor, version)?;
        if !cursor.is_empty() || !metadata.topics.is_empty() {
            return Err(Error::protocol(
                "unexpected ListTransactions Metadata topic or trailing bytes",
            ));
        }
        metadata.check()?;
        let mut nodes: Vec<i32> = metadata
            .brokers
            .iter()
            .map(|broker| broker.node_id)
            .collect();
        nodes.sort_unstable();
        if nodes.iter().any(|id| *id < 0)
            || nodes
                .iter()
                .zip(nodes.iter().skip(1))
                .any(|(left, right)| left == right)
        {
            return Err(Error::protocol(
                "invalid or duplicate ListTransactions broker ID",
            ));
        }
        self.cluster.apply_image(&metadata, version).await;
        Ok(nodes)
    }

    async fn list_transactions_on_broker<S: AsRef<str>>(
        &mut self,
        node: i32,
        query: &ListTransactionsQuery<'_, S>,
        deadline: Instant,
        budget: &mut ListTransactionsBudget,
    ) -> Result<Vec<TransactionListing>> {
        if budget.exhausted {
            return Err(Error::protocol(
                "ListTransactions aggregate response limit exhausted",
            ));
        }
        let mut attempt = 0u32;
        loop {
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            let result = async {
                self.list_transactions_connect(node, deadline).await?;
                let version = self
                    .conns
                    .get(&node)
                    .and_then(|conn| conn.negotiated(LIST_TRANSACTIONS, 0, 2))
                    .ok_or_else(|| {
                        Error::Unsupported(format!(
                            "broker {node} does not support ListTransactions v0-2"
                        ))
                    })?;
                let conn = self
                    .conns
                    .get_mut(&node)
                    .ok_or_else(|| Error::protocol("missing ListTransactions broker connection"))?;
                crate::protocol::admin::ListTransactionsRequest::build_with_pattern(
                    version,
                    query.duration_ms,
                    query.pattern,
                )?;
                let body = conn
                    .roundtrip(
                        LIST_TRANSACTIONS,
                        version,
                        |buf| {
                            encode_list_transactions_states(
                                buf,
                                version,
                                query.states,
                                query.producer_ids,
                                query.duration_ms,
                                query.pattern,
                            )
                        },
                        deadline.saturating_duration_since(Instant::now()),
                    )
                    .await?;
                budget.response_bytes = budget.response_bytes.saturating_add(body.len());
                if budget.response_bytes > 16 * 1024 * 1024 {
                    budget.exhausted = true;
                    return Err(Error::protocol(
                        "ListTransactions response bytes exceed local limit",
                    ));
                }
                validate_list_transactions_body(
                    &body,
                    100_000usize.saturating_sub(budget.listings),
                )?;
                let mut cursor = body.as_ref();
                let response = decode_list_transactions_response(&mut cursor, version)?;
                if !cursor.is_empty() {
                    return Err(Error::protocol("trailing ListTransactions response bytes"));
                }
                if response.error_code != 0 {
                    return Err(Error::broker(
                        response.error_code,
                        format!("ListTransactions broker {node}"),
                    ));
                }
                budget.listings += response.transaction_states.len();
                Ok(response.transaction_states)
            }
            .await;
            match result {
                Err(error) if list_transactions_retryable(&error) && attempt < 7 => {
                    self.discard_node_conn(node).await;
                    if matches!(&error, Error::Io(_)) && budget.refreshes < 3 {
                        budget.refreshes += 1;
                        let _ = self.list_transactions_broker_ids(deadline).await?;
                    }
                    self.wait_retry(&mut attempt, deadline).await?;
                }
                other => return other,
            }
        }
    }

    async fn list_transactions_connect(&mut self, node: i32, deadline: Instant) -> Result<()> {
        if self
            .conns
            .get(&node)
            .is_some_and(|conn| conn.idle_expired(self.cfg.connections_max_idle))
        {
            self.discard_node_conn(node).await;
        }
        if self.conns.contains_key(&node) {
            return Ok(());
        }
        let address =
            self.cluster.brokers.get(&node).cloned().ok_or_else(|| {
                Error::protocol(format!("unknown ListTransactions broker {node}"))
            })?;
        let failures = self.reconnect_fails.get(&node).copied().unwrap_or(0);
        let delay = crate::config::reconnect_backoff_delay(
            self.cfg.reconnect_backoff,
            self.cfg.reconnect_backoff_max,
            failures,
        );
        if !delay.is_zero() {
            let now = Instant::now();
            if now >= deadline {
                return Err(Error::Timeout);
            }
            tokio::time::sleep(delay.min(deadline.saturating_duration_since(now))).await;
        }
        if Instant::now() >= deadline {
            return Err(Error::Timeout);
        }
        match self.open_node_conn_until(&address, deadline).await {
            Ok(connection) => {
                let _ = self.reconnect_fails.remove(&node);
                let _ = self.conns.insert(node, connection);
                Ok(())
            }
            Err(error) => {
                let _ = crate::config::bump_reconnect_fails(&mut self.reconnect_fails, node);
                Err(error)
            }
        }
    }

    /// Describe ACL bindings (`DescribeAcls`) matching `resource_type`.
    ///
    /// Negotiates v0–v3 (v0–v1 classic; v2+ flexible). v1+ sends
    /// PatternTypeFilter ANY. Operation and Permission are ANY (Java
    /// `AccessControlEntryFilter.ANY`). Kafka 4.0 `validVersions` is
    /// `1-3`. v4+ is not spoken.
    ///
    /// `resource_type` is [`crate::AclResourceType`] or a protocol `i8`
    /// (`ACL_RESOURCE_TOPIC`, …). For principal / host / name / operation
    /// filters, use [`Self::describe_acls_with`]. DescribeAcls has no
    /// TimeoutMs; the RPC deadline is [`AdminConfig::request_timeout`].
    /// For a one-shot deadline, use [`Self::describe_acls_timeout`].
    pub async fn describe_acls(&mut self, resource_type: impl Into<i8>) -> Result<Vec<AclBinding>> {
        self.describe_acls_with(&AclBindingFilter::resource_type(resource_type))
            .await
    }

    /// [`Self::describe_acls`] with a one-shot RPC deadline (Java
    /// `DescribeAclsOptions.timeoutMs`).
    pub async fn describe_acls_timeout(
        &mut self,
        resource_type: impl Into<i8>,
        timeout: Duration,
    ) -> Result<Vec<AclBinding>> {
        self.describe_acls_with_timeout(&AclBindingFilter::resource_type(resource_type), timeout)
            .await
    }

    /// [`Self::describe_acls`] with a Java `AclBindingFilter`.
    ///
    /// DescribeAcls has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::describe_acls_with_timeout`].
    pub async fn describe_acls_with(
        &mut self,
        filter: &AclBindingFilter,
    ) -> Result<Vec<AclBinding>> {
        let timeout = self.cfg.request_timeout;
        self.describe_acls_with_timeout(filter, timeout).await
    }

    /// [`Self::describe_acls_with`] with Java `DescribeAclsOptions.timeoutMs`.
    ///
    /// DescribeAcls has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn describe_acls_with_timeout(
        &mut self,
        filter: &AclBindingFilter,
        timeout: Duration,
    ) -> Result<Vec<AclBinding>> {
        let version = self.describe_acls_version.ok_or_else(|| {
            Error::Unsupported("broker does not support DescribeAcls v0-3".into())
        })?;
        let body = self
            .roundtrip_bootstrap(
                DESCRIBE_ACLS,
                version,
                |buf| encode_describe_acls_request(buf, version, filter),
                timeout,
            )
            .await?;
        let (acls, ..) =
            decode_describe_acls_response_cooperative(&mut body.clone(), version).await?;
        Ok(acls)
    }

    /// Describe every ACL (Java `describeAcls(AclBindingFilter.ANY)`).
    ///
    /// Same wire as [`Self::describe_acls_with`] with
    /// [`AclBindingFilter::any`]. DescribeAcls has no TimeoutMs; the RPC
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// deadline, use [`Self::describe_acls_any_timeout`].
    pub async fn describe_acls_any(&mut self) -> Result<Vec<AclBinding>> {
        self.describe_acls_with(&AclBindingFilter::any()).await
    }

    /// [`Self::describe_acls_any`] with a one-shot RPC deadline (Java
    /// `DescribeAclsOptions.timeoutMs`).
    ///
    /// DescribeAcls has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn describe_acls_any_timeout(
        &mut self,
        timeout: Duration,
    ) -> Result<Vec<AclBinding>> {
        self.describe_acls_with_timeout(&AclBindingFilter::any(), timeout)
            .await
    }

    /// Replace configs (`AlterConfigs`, legacy api 33).
    ///
    /// Negotiates v0–v2 (v0–v1 classic; v2 flexible). v1 response adds
    /// ThrottleTimeMs (KIP-219). Kafka 4.0 `validVersions` is `0-2`.
    /// v3+ is not spoken.
    ///
    /// Prefer [`Self::incremental_alter_configs`] on modern brokers.
    /// Returns the first resource's error code. For several resources in
    /// one RPC (Java `alterConfigs(Map)`), use [`Self::alter_configs_for`].
    /// AlterConfigs has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::alter_configs_timeout`].
    pub async fn alter_configs(
        &mut self,
        resource: &ConfigResource,
        configs: &[(String, Option<String>)],
        validate_only: bool,
    ) -> Result<i16> {
        let results = self
            .alter_configs_for(
                &[ConfigReplacement::new(
                    resource.clone(),
                    configs.iter().cloned(),
                )],
                validate_only,
            )
            .await?;
        Ok(results.first().map(|r| r.error_code).unwrap_or(0))
    }

    /// [`Self::alter_configs`] with a one-shot RPC deadline (Java
    /// `AlterConfigsOptions.timeoutMs`).
    ///
    /// AlterConfigs has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn alter_configs_timeout(
        &mut self,
        resource: &ConfigResource,
        configs: &[(String, Option<String>)],
        timeout: Duration,
        validate_only: bool,
    ) -> Result<i16> {
        let results = self
            .alter_configs_for_timeout(
                &[ConfigReplacement::new(
                    resource.clone(),
                    configs.iter().cloned(),
                )],
                timeout,
                validate_only,
            )
            .await?;
        Ok(results.first().map(|r| r.error_code).unwrap_or(0))
    }

    /// [`Self::alter_configs`] with a Java `Config` (`alterConfigs(Map)` one
    /// resource).
    ///
    /// AlterConfigs has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::alter_configs_with_timeout`].
    pub async fn alter_configs_with(
        &mut self,
        resource: &ConfigResource,
        config: &Config,
        validate_only: bool,
    ) -> Result<i16> {
        let results = self
            .alter_configs_for(
                &[ConfigReplacement::from_config(resource.clone(), config)],
                validate_only,
            )
            .await?;
        Ok(results.first().map(|r| r.error_code).unwrap_or(0))
    }

    /// [`Self::alter_configs_with`] with a one-shot RPC deadline (Java
    /// `AlterConfigsOptions.timeoutMs`).
    ///
    /// AlterConfigs has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn alter_configs_with_timeout(
        &mut self,
        resource: &ConfigResource,
        config: &Config,
        timeout: Duration,
        validate_only: bool,
    ) -> Result<i16> {
        let results = self
            .alter_configs_for_timeout(
                &[ConfigReplacement::from_config(resource.clone(), config)],
                timeout,
                validate_only,
            )
            .await?;
        Ok(results.first().map(|r| r.error_code).unwrap_or(0))
    }

    /// [`Self::alter_configs`] for several resources (Java `alterConfigs(Map)`;
    /// AlterConfigs Resources of N).
    ///
    /// Empty `updates` is a no-op.
    pub async fn alter_configs_for(
        &mut self,
        updates: &[ConfigReplacement],
        validate_only: bool,
    ) -> Result<Vec<AlterConfigsResourceResult>> {
        let timeout = self.cfg.request_timeout;
        self.alter_configs_for_timeout(updates, timeout, validate_only)
            .await
    }

    /// [`Self::alter_configs_for`] with Java `AlterConfigsOptions.timeoutMs`.
    ///
    /// Empty `updates` is a no-op. AlterConfigs has no TimeoutMs;
    /// `timeout` is the RPC deadline.
    pub async fn alter_configs_for_timeout(
        &mut self,
        updates: &[ConfigReplacement],
        timeout: Duration,
        validate_only: bool,
    ) -> Result<Vec<AlterConfigsResourceResult>> {
        if updates.is_empty() {
            return Ok(Vec::new());
        }
        let resources = borrowed_alter_configs_resources(updates);
        let version = self.legacy_alter_version.ok_or_else(|| {
            Error::Unsupported("broker does not support AlterConfigs v0-2".into())
        })?;
        let mut encoded = BytesMut::new();
        encode_alter_configs_named_cooperative(&mut encoded, version, &resources, validate_only)
            .await?;
        let body = self
            .roundtrip_bootstrap(
                ALTER_CONFIGS,
                version,
                |buf| {
                    buf.extend_from_slice(&encoded);
                    Ok(())
                },
                timeout,
            )
            .await?;
        let (results, ..) =
            decode_alter_configs_resource_results_cooperative(&mut body.clone(), version).await?;
        Ok(results)
    }

    async fn fetch_metadata_request_with(
        &mut self,
        topics: Option<&[MetadataRequestTopic]>,
        include_topic_authorized_operations: bool,
        timeout: Duration,
    ) -> Result<()> {
        let deadline = Instant::now().checked_add(timeout).ok_or(Error::Timeout)?;
        self.fetch_metadata_request_until(topics, include_topic_authorized_operations, deadline)
            .await
    }

    async fn fetch_metadata_request_until(
        &mut self,
        topics: Option<&[MetadataRequestTopic]>,
        include_topic_authorized_operations: bool,
        deadline: Instant,
    ) -> Result<()> {
        self.ensure_bootstrap(deadline).await?;
        let version = self.metadata_version;
        let mut encoded = BytesMut::new();
        encode_metadata_request_topics_cooperative(
            &mut encoded,
            version,
            topics,
            version < 4 && topics.is_none(),
            include_topic_authorized_operations,
        )
        .await?;
        self.exchange_prepared_metadata(
            topics.is_some(),
            include_topic_authorized_operations,
            deadline,
            version,
            &encoded,
        )
        .await
    }

    /// Brokers and the controller, without downloading the topic list.
    ///
    /// Metadata v1+ empty topic array is that directory. v0 cannot say
    /// "no topics", so it still asks for every topic.
    fn forget_controller(&mut self) {
        if let Ok(node) = self.cluster.controller() {
            self.controller_redial = Some(node);
        }
        self.cluster.invalidate_controller();
    }

    async fn refresh_broker_directory(&mut self, deadline: Instant) -> Result<()> {
        let mut nodes = Vec::new();
        if let Some(node) = self.controller_redial.take() {
            nodes.push(node);
        }
        let dials = self.take_broker_dials(&nodes).await;
        if dials.is_empty() {
            return self.refresh_directory_metadata(deadline).await;
        }
        let opened =
            Self::dial_admin_nodes(self.cfg.clone(), Arc::clone(&self.stats), dials, deadline);
        let refreshed = self.refresh_directory_metadata(deadline);
        let (opened, refreshed) = tokio::join!(opened, refreshed);
        self.store_admin_dials(opened);
        refreshed
    }

    async fn refresh_directory_metadata(&mut self, deadline: Instant) -> Result<()> {
        if self.metadata_version == 0 {
            return self.refresh_metadata_until(None, deadline).await;
        }
        let topics: [&str; 0] = [];
        self.refresh_metadata_ref(Some(topics.as_slice()), deadline)
            .await
    }

    /// Refresh metadata using only the time still left on `deadline`.
    async fn refresh_metadata_until(
        &mut self,
        topics: Option<&[String]>,
        deadline: Instant,
    ) -> Result<()> {
        self.refresh_metadata_ref(topics, deadline).await
    }

    /// Refresh metadata for names the caller already holds.
    async fn refresh_metadata_ref<T: AsRef<str> + Sync>(
        &mut self,
        topics: Option<&[T]>,
        deadline: Instant,
    ) -> Result<()> {
        let timeout = deadline.saturating_duration_since(Instant::now());
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let deadline = Instant::now().checked_add(timeout).ok_or(Error::Timeout)?;
        self.ensure_bootstrap(deadline).await?;
        let version = self.metadata_version;
        let mut encoded = BytesMut::new();
        encode_metadata_request_ref_cooperative(
            &mut encoded,
            version,
            topics,
            version < 4 && topics.is_none(),
        )
        .await?;
        self.exchange_prepared_metadata(topics.is_some(), false, deadline, version, &encoded)
            .await
    }

    async fn exchange_prepared_metadata(
        &mut self,
        topic_selection: bool,
        include_topic_authorized_operations: bool,
        deadline: Instant,
        version: i16,
        encoded: &[u8],
    ) -> Result<()> {
        if version == 0 && (topic_selection || include_topic_authorized_operations) {
            return Err(Error::Unsupported(
                "Metadata v0 cannot represent this Admin request".into(),
            ));
        }
        let mut body = self
            .roundtrip_bootstrap(
                METADATA,
                version,
                |buf| {
                    buf.extend_from_slice(encoded);
                    Ok(())
                },
                startup_remaining(deadline)?,
            )
            .await?;
        decode_metadata_response_into_cooperative(&mut body, version, &mut self.metadata_image)
            .await?;
        self.metadata_image.check()?;
        self.cluster
            .apply_image(&self.metadata_image, version)
            .await;
        Ok(())
    }

    /// Wait [`AdminConfig::retry_backoff`] (exponential) or [`Error::Timeout`].
    async fn wait_retry(&mut self, attempt: &mut u32, deadline: Instant) -> Result<()> {
        if Instant::now() >= deadline {
            return Err(Error::Timeout);
        }
        // A retry that already retired the bootstrap socket must drop that
        // TCP connection before the backoff, not only flip the closed flag.
        self.conn.release_if_closed().await;
        let retired: Vec<i32> = self
            .conns
            .iter()
            .filter(|(_, conn)| conn.is_closed())
            .map(|(node, _)| *node)
            .collect();
        for node in retired {
            if let Some(mut conn) = self.conns.remove(&node) {
                conn.release_if_closed().await;
            }
        }
        let delay = crate::config::retry_backoff_delay(
            self.cfg.retry_backoff,
            self.cfg.retry_backoff_max,
            *attempt,
        );
        if !delay.is_zero() && Instant::now() < deadline {
            let rest = delay.min(deadline.saturating_duration_since(Instant::now()));
            let sleep = tokio::time::sleep(rest);
            tokio::pin!(sleep);
            loop {
                tokio::select! {
                    biased;
                    () = &mut sleep => break,
                    // A queued response must not complete this arm. Polling
                    // it again would spin and never yield, so a later close
                    // could not shut the socket down.
                    _ = self.conn.peer_left(), if !self.conn.is_closed() => {}
                }
            }
        }
        *attempt = attempt.saturating_add(1);
        if Instant::now() >= deadline {
            return Err(Error::Timeout);
        }
        Ok(())
    }

    async fn ensure_bootstrap(&mut self, deadline: Instant) -> Result<()> {
        if !self.conn.is_closed() && !self.conn.idle_expired(self.cfg.connections_max_idle) {
            return Ok(());
        }
        let addr = self.conn.addr().to_string();
        let replacement = if self.conn.is_closed() {
            // A replacement connection may reach a restarted or upgraded
            // broker. Its API ranges must come from its own handshake.
            dial_admin_socket(&addr, &self.cfg, &self.stats, deadline).await?
        } else if self.versions.is_empty() {
            self.open_node_conn_until(&addr, deadline).await?
        } else {
            self.open_known_peer_until(&addr, deadline).await?
        };
        self.adopt_bootstrap(replacement).await
    }

    /// Reconnect the bootstrap socket if it has been idle, then round-trip.
    async fn roundtrip_bootstrap(
        &mut self,
        api_key: i16,
        api_version: i16,
        encode_body: impl FnOnce(&mut BytesMut) -> Result<()>,
        timeout: Duration,
    ) -> Result<Bytes> {
        let deadline = Instant::now().checked_add(timeout).ok_or(Error::Timeout)?;
        self.ensure_bootstrap(deadline).await?;
        self.conn
            .roundtrip(
                api_key,
                api_version,
                encode_body,
                startup_remaining(deadline)?,
            )
            .await
    }

    /// The broker address is the bootstrap socket already negotiated.
    fn targets_bootstrap(&self, node: i32) -> bool {
        self.cluster
            .brokers
            .get(&node)
            .is_some_and(|addr| addr == self.conn.addr())
    }

    /// Send on the bootstrap socket when `node` is that broker.
    ///
    /// A one-broker cluster would otherwise open a second connection and
    /// repeat ApiVersions before the controller RPC.
    async fn roundtrip_known_node(
        &mut self,
        node: i32,
        deadline: Instant,
        api_key: i16,
        version: i16,
        encode: impl FnOnce(&mut bytes::BytesMut) -> Result<()>,
        timeout: Duration,
    ) -> Result<bytes::Bytes> {
        if self.targets_bootstrap(node) {
            self.ensure_bootstrap(deadline).await?;
            let remaining = timeout.min(startup_remaining(deadline)?);
            return self
                .conn
                .roundtrip(api_key, version, encode, remaining)
                .await;
        }
        self.connect_node_until(node, deadline).await?;
        let remaining = timeout.min(startup_remaining(deadline)?);
        let conn = self
            .conns
            .get_mut(&node)
            .ok_or_else(|| Error::protocol("missing broker connection"))?;
        conn.roundtrip(api_key, version, encode, remaining).await
    }

    /// An admin that already holds `conn`, for tests of socket closes.
    #[cfg(test)]
    fn test_holding(conn: BrokerConn) -> Self {
        Self {
            cfg: AdminConfig::default(),
            conn,
            versions: HashMap::new(),
            create_version: 0,
            delete_version: 0,
            describe_version: None,
            partitions_version: None,
            alter_version: None,
            legacy_alter_version: None,
            delete_records_version: None,
            describe_producers_version: None,
            describe_cluster_version: None,
            create_acls_version: None,
            describe_acls_version: None,
            delete_acls_version: None,
            metadata_version: 0,
            metadata_image: MetadataResponse::blank(),
            find_coord_version: None,
            offset_delete_version: None,
            list_reassign_version: None,
            update_features_version: None,
            alter_user_scram_version: None,
            describe_user_scram_version: None,
            unregister_broker_version: None,
            describe_client_quotas_version: None,
            alter_client_quotas_version: None,
            allocate_producer_ids_version: None,
            describe_transactions_version: None,
            consumer_group_describe_version: None,
            describe_groups_version: None,
            list_groups_version: None,
            delete_groups_version: None,
            share_group_describe_version: None,
            describe_share_group_offsets_version: None,
            alter_share_group_offsets_version: None,
            delete_share_group_offsets_version: None,
            describe_topic_partitions_version: None,
            list_config_resources_version: None,
            get_telemetry_subscriptions_version: None,
            cached_client_instance_id: None,
            push_telemetry_version: None,
            assign_replicas_to_dirs_version: None,
            alter_replica_log_dirs_version: None,
            create_delegation_token_version: None,
            renew_delegation_token_version: None,
            expire_delegation_token_version: None,
            describe_delegation_token_version: None,
            cluster: Cluster::default(),
            conns: HashMap::new(),
            peer_versions: HashMap::new(),
            controller_redial: None,
            reconnect_fails: HashMap::new(),
            group_coord: None,
            group_coords: HashMap::new(),
            group_coord_redial: Vec::new(),
            txn_coord: None,
            txn_coords: HashMap::new(),
            txn_coord_redial: Vec::new(),
            stats: Arc::new(crate::metrics::AdminTracker::default()),
        }
    }

    /// Drop a dedicated broker socket that a retry will not reuse.
    ///
    /// Removing it from the map drops the connection. The idle watch is aborted
    /// with that drop, so the broker stays in its read until the watch is scheduled.
    async fn discard_node_conn(&mut self, node: i32) {
        if let Some(mut conn) = self.conns.remove(&node) {
            let _ = self.peer_versions.remove(conn.addr());
            conn.inner.close();
            conn.inner.release_if_closed().await;
        }
    }

    async fn drop_node_conn(&mut self, node: i32) {
        if self.targets_bootstrap(node) {
            self.conn.close();
            self.conn.release_if_closed().await;
        }
        self.discard_node_conn(node).await;
    }

    /// Open the dedicated socket, or the bootstrap socket when `node` is that broker.
    async fn prepare_node_until(&mut self, node: i32, deadline: Instant) -> Result<()> {
        if self.targets_bootstrap(node) {
            self.ensure_bootstrap(deadline).await
        } else {
            self.connect_node_until(node, deadline).await
        }
    }

    /// ApiVersions for `node`: the bootstrap handshake when that broker is `node`.
    fn negotiated_on(&self, node: i32, api_key: i16, min: i16, max: i16) -> Option<i16> {
        if self.targets_bootstrap(node) {
            self.negotiated(api_key, min, max)
        } else {
            self.conns
                .get(&node)
                .and_then(|conn| conn.negotiated(api_key, min, max))
        }
    }

    /// OffsetCommit or OffsetFetch version for `node`.
    fn offset_version_on(&self, node: i32, api: i16, min: i16, max: i16) -> Result<i16> {
        if self.targets_bootstrap(node) {
            return self.negotiated(api, min, max).ok_or_else(|| {
                Error::Unsupported("actual coordinator cannot represent the offset request".into())
            });
        }
        self.conns
            .get(&node)
            .ok_or_else(|| Error::protocol("missing offset coordinator"))?
            .offset_version(api, min, max)
    }

    async fn connect_node_until(&mut self, node: i32, deadline: Instant) -> Result<()> {
        let connected = async {
            if self
                .conns
                .get(&node)
                .is_some_and(|c| c.idle_expired(self.cfg.connections_max_idle))
            {
                self.discard_node_conn(node).await;
            }
            if self.conns.contains_key(&node) {
                return Ok(());
            }
            let addr = self
                .cluster
                .brokers
                .get(&node)
                .cloned()
                .ok_or_else(|| Error::protocol(format!("unknown broker {node}")))?;
            loop {
                let fails = self.reconnect_fails.get(&node).copied().unwrap_or(0);
                let delay = crate::config::reconnect_backoff_delay(
                    self.cfg.reconnect_backoff,
                    self.cfg.reconnect_backoff_max,
                    fails,
                );
                if !delay.is_zero() {
                    let now = Instant::now();
                    if now >= deadline {
                        return Err(Error::Timeout);
                    }
                    tokio::time::sleep(delay.min(deadline.saturating_duration_since(now))).await;
                }
                if Instant::now() >= deadline {
                    return Err(Error::Timeout);
                }
                let opened = self.open_node_conn_until(&addr, deadline).await;
                match opened {
                    Ok(conn) => {
                        let _ = self.reconnect_fails.remove(&node);
                        let _prev = self.conns.insert(node, conn);
                        return Ok(());
                    }
                    Err(e) if e.is_retriable() => {
                        let _fails =
                            crate::config::bump_reconnect_fails(&mut self.reconnect_fails, node);
                        if Instant::now() >= deadline {
                            return Err(Error::Timeout);
                        }
                    }
                    Err(e) => {
                        let _fails =
                            crate::config::bump_reconnect_fails(&mut self.reconnect_fails, node);
                        return Err(e);
                    }
                }
            }
        }
        .await;
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }
        connected
    }

    /// Dial and authenticate inside `deadline`, skipping ApiVersions when this
    /// address was already learned.
    async fn open_node_conn_until(
        &mut self,
        addr: &str,
        deadline: Instant,
    ) -> Result<AdminOffsetConn> {
        if addr == self.conn.addr() {
            if self.conn.is_closed() {
                return dial_admin_socket(addr, &self.cfg, &self.stats, deadline).await;
            }
            if !self.versions.is_empty() {
                return self.open_known_peer_until(addr, deadline).await;
            }
        }
        let known = self.peer_versions.get(addr).cloned().unwrap_or_default();
        let conn = dial_admin_peer(addr, &self.cfg, &self.stats, &known, deadline).await?;
        self.remember_peer(&conn);
        Ok(conn)
    }

    fn remember_peer(&mut self, conn: &AdminOffsetConn) {
        if conn.apis.is_empty() || self.peer_versions.contains_key(conn.addr()) {
            return;
        }
        let _stored = self
            .peer_versions
            .insert(conn.addr().to_string(), conn.apis.clone());
    }

    /// Open a remembered bootstrap socket and return once SASL has stopped.
    ///
    /// The versions were already learned. A peer that accepts and then stalls
    /// in SASL must not stay open after this call returns.
    #[doc(hidden)]
    pub async fn test_open_known_sasl_peer(&mut self, addr: &str) -> Result<()> {
        use crate::protocol::api_keys::{SASL_AUTHENTICATE, SASL_HANDSHAKE};
        self.cfg.sasl_plain = Some(("user".into(), "pass".into()));
        self.cfg.connect_timeout = Duration::from_millis(200);
        let _ = self.versions.insert(
            SASL_HANDSHAKE,
            ApiVersion {
                api_key: SASL_HANDSHAKE,
                min_version: 0,
                max_version: 1,
            },
        );
        let _ = self.versions.insert(
            SASL_AUTHENTICATE,
            ApiVersion {
                api_key: SASL_AUTHENTICATE,
                min_version: 0,
                max_version: 2,
            },
        );
        let _peer = self
            .open_known_peer_until(addr, Instant::now() + Duration::from_millis(200))
            .await?;
        Ok(())
    }

    /// Open another socket to the bootstrap broker without repeating ApiVersions.
    ///
    /// The first socket already learned the broker's versions. A second
    /// handshake to that same address only repeats that round trip.
    async fn open_known_peer_until(
        &self,
        addr: &str,
        deadline: Instant,
    ) -> Result<AdminOffsetConn> {
        let keys: Vec<ApiVersion> = self.versions.values().cloned().collect();
        dial_known_admin_socket(addr, &self.cfg, &self.stats, &keys, deadline).await
    }

    /// Delete records before `offset` (`DeleteRecords`).
    ///
    /// Negotiates v0–v2 (v0–v1 classic; v2 flexible). v1 response adds
    /// ThrottleTimeMs (KIP-219). Kafka 4.0 `validVersions` is `0-2`.
    /// v3+ is not spoken.
    ///
    /// `offset` is [`RecordsToDelete`] or INT64 (Java
    /// `RecordsToDelete.beforeOffset(long)`).
    /// [`crate::protocol::admin::DeleteRecordsRequest::HIGH_WATERMARK`]
    /// truncates to the high watermark. Lands on the Metadata
    /// partition leader. `NOT_LEADER_OR_FOLLOWER` (6) and other
    /// retriable codes refresh Metadata and retry on the new leader.
    /// Returns [`DeletedRecords`] (`lowWatermark` plus per-partition
    /// ErrorCode). `timeout_ms` is
    /// DeleteRecords TimeoutMs. The RPC deadline is
    /// [`AdminConfig::request_timeout`]. For several partitions, use
    /// [`Self::delete_records_for`]. For a one-shot timeout that drives
    /// both the RPC deadline and TimeoutMs, use
    /// [`Self::delete_records_timeout`].
    pub async fn delete_records(
        &mut self,
        partition: impl Into<crate::TopicPartition>,
        offset: impl Into<i64>,
        timeout_ms: i32,
    ) -> Result<DeletedRecords> {
        let timeout = self.cfg.request_timeout;
        self.delete_records_one(partition.into(), offset.into(), timeout_ms, timeout)
            .await
            .map(DeletedRecords::from)
    }

    /// [`Self::delete_records`] with a one-shot timeout (Java
    /// `DeleteRecordsOptions.timeoutMs`).
    ///
    /// `timeout` is the RPC deadline and DeleteRecords TimeoutMs.
    pub async fn delete_records_timeout(
        &mut self,
        partition: impl Into<crate::TopicPartition>,
        offset: impl Into<i64>,
        timeout: Duration,
    ) -> Result<DeletedRecords> {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        self.delete_records_one(partition.into(), offset.into(), timeout_ms, timeout)
            .await
            .map(DeletedRecords::from)
    }

    /// Delete records on several partitions (Java `deleteRecords(Map)`).
    ///
    /// Each item is a topic partition and an offset ([`RecordsToDelete`] or
    /// INT64). Partitions that share a leader are sent together. An empty list
    /// does nothing.
    ///
    /// Topic names are copied in slices of 8,192, so the timeout can still
    /// fire while a long list is prepared. Finished slices are kept.
    ///
    /// TimeoutMs and the RPC deadline are [`AdminConfig::request_timeout`].
    /// For a one-shot timeout, use [`Self::delete_records_for_timeout`].
    /// Each result is [`DeletedRecords`].
    pub async fn delete_records_for<Tp, Off>(
        &mut self,
        records: impl IntoIterator<Item = (Tp, Off)>,
    ) -> Result<Vec<(crate::TopicPartition, DeletedRecords)>>
    where
        Tp: Into<crate::TopicPartition>,
        Off: Into<i64>,
    {
        let timeout = self.cfg.request_timeout;
        self.delete_records_for_timeout(records, timeout).await
    }

    /// [`Self::delete_records_for`] with a one-shot timeout (Java
    /// `deleteRecords` plus `DeleteRecordsOptions.timeoutMs`).
    ///
    /// `timeout` is the RPC deadline and DeleteRecords TimeoutMs.
    pub async fn delete_records_for_timeout<Tp, Off>(
        &mut self,
        records: impl IntoIterator<Item = (Tp, Off)>,
        timeout: Duration,
    ) -> Result<Vec<(crate::TopicPartition, DeletedRecords)>>
    where
        Tp: Into<crate::TopicPartition>,
        Off: Into<i64>,
    {
        let timeout_ms = crate::consumer::duration_millis_i32(timeout);
        let raw = self
            .delete_records_for_with(records, timeout_ms, timeout)
            .await?;
        Ok(raw
            .into_iter()
            .map(|(tp, low, err)| (tp, DeletedRecords::with_error_code(low, err)))
            .collect())
    }

    async fn delete_records_one(
        &mut self,
        tp: crate::TopicPartition,
        offset: i64,
        timeout_ms: i32,
        timeout: Duration,
    ) -> Result<(i64, i16)> {
        let mut out = self
            .delete_records_for_with([(tp, offset)], timeout_ms, timeout)
            .await?;
        match out.pop() {
            Some((_, low, err)) => Ok((low, err)),
            None => Err(Error::protocol("missing DeleteRecords result")),
        }
    }

    async fn delete_records_for_with<Tp, Off>(
        &mut self,
        records: impl IntoIterator<Item = (Tp, Off)>,
        timeout_ms: i32,
        timeout: Duration,
    ) -> Result<Vec<(crate::TopicPartition, i64, i16)>>
    where
        Tp: Into<crate::TopicPartition>,
        Off: Into<i64>,
    {
        let records = collect_topic_pairs(records).await;
        if records.is_empty() {
            return Ok(Vec::new());
        }
        let version = self.delete_records_version.ok_or_else(|| {
            Error::Unsupported("broker does not support DeleteRecords v0-2".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut out: Vec<Option<(i64, i16)>> = open_result_slots(records.len()).await;
        let mut pending = pending_indexes(records.len()).await;
        loop {
            if pending.is_empty() {
                break;
            }
            let need = topics_missing_leaders(
                &self.cluster,
                pending.iter().filter_map(|&i| {
                    records
                        .get(i)
                        .map(|(tp, _)| (tp.topic.as_str(), tp.partition))
                }),
            )
            .await;
            if !need.is_empty() {
                let known_nodes = self
                    .known_leader_nodes(pending.iter().filter_map(|&i| {
                        records
                            .get(i)
                            .map(|(tp, _)| (tp.topic.as_str(), tp.partition))
                    }))
                    .await;
                self.refresh_topics_while_dialing(&need, &known_nodes, deadline)
                    .await?;
            }
            let mut present = 0usize;
            let (nodes, mut by_node) = group_pending_by_leader(
                &self.cluster,
                pending.iter().filter_map(|&i| {
                    let (tp, _) = records.get(i)?;
                    present = present.saturating_add(1);
                    Some((i, tp.topic.as_str(), tp.partition))
                }),
            )
            .await?;
            if present != pending.len() {
                return Err(Error::protocol("missing DeleteRecords query"));
            }
            let mut still = Vec::new();
            if nodes.len() > 1 {
                let mut grouped = HashMap::new();
                for &node in &nodes {
                    let idxs = by_node.get(&node).map(Vec::as_slice).unwrap_or(&[]);
                    let topics = delete_records_topics(&records, idxs)
                        .await
                        .into_iter()
                        .map(|(name, parts)| (name.to_owned(), parts))
                        .collect::<Vec<_>>();
                    let _ = grouped.insert(node, topics);
                }
                let mut finished = self
                    .exchange_leaders(&nodes, deadline, |_admin, node, _conn, _timeout| {
                        let topics = grouped.remove(&node).unwrap_or_default();
                        Ok(LeaderFrame::deferred(
                            DELETE_RECORDS,
                            version,
                            Box::pin(async move {
                                let mut payload = BytesMut::new();
                                encode_delete_records_owned_topics_cooperative(
                                    &mut payload,
                                    version,
                                    &topics,
                                    timeout_ms,
                                )
                                .await?;
                                Ok(payload.freeze())
                            }),
                        ))
                    })
                    .await;
                for node in &nodes {
                    let idxs = by_node.get(node).cloned().unwrap_or_default();
                    let Some((spoken, body)) = finished.remove(node) else {
                        self.discard_node_conn(*node).await;
                        still.extend(idxs);
                        continue;
                    };
                    match body {
                        Err(error) if error.is_retriable() => {
                            self.discard_node_conn(*node).await;
                            still.extend(idxs);
                        }
                        Err(error) => return Err(error),
                        Ok(body) => {
                            let (done, retry) = self
                                .apply_delete_records_body(*node, spoken, &records, &idxs, body)
                                .await?;
                            for (i, low, err) in done {
                                if let Some(slot) = out.get_mut(i) {
                                    *slot = Some((low, err));
                                }
                            }
                            still.extend(retry);
                        }
                    }
                }
            } else {
                for node in nodes {
                    let idxs = by_node.remove(&node).unwrap_or_default();
                    match self
                        .delete_records_on_node(
                            node, version, timeout_ms, &records, &idxs, deadline,
                        )
                        .await
                    {
                        Ok((done, retry)) => {
                            for (i, low, err) in done {
                                if let Some(slot) = out.get_mut(i) {
                                    *slot = Some((low, err));
                                }
                            }
                            still.extend(retry);
                        }
                        Err(e) if e.is_retriable() => {
                            self.drop_node_conn(node).await;
                            still.extend(idxs);
                        }
                        Err(e) => return Err(e),
                    }
                }
            }
            pending = still;
            if pending.is_empty() {
                break;
            }
            self.wait_retry(&mut attempt, deadline).await?;
            let known_nodes = self
                .known_leader_nodes(pending.iter().filter_map(|&i| {
                    records
                        .get(i)
                        .map(|(tp, _)| (tp.topic.as_str(), tp.partition))
                }))
                .await;
            let topics = unique_names_cooperative(
                pending
                    .iter()
                    .filter_map(|&i| records.get(i).map(|(tp, _)| tp.topic.as_str())),
            )
            .await;
            self.cluster
                .invalidate_topics_cooperative(topics.iter().copied())
                .await;
            if !topics.is_empty() {
                self.refresh_topics_while_dialing(&topics, &known_nodes, deadline)
                    .await?;
            }
        }
        out.into_iter()
            .zip(records)
            .map(|(got, (tp, _))| {
                got.map(|(low, err)| (tp, low, err))
                    .ok_or_else(|| Error::protocol("DeleteRecords missing result"))
            })
            .collect()
    }

    async fn delete_records_on_node(
        &mut self,
        node: i32,
        version: i16,
        timeout_ms: i32,
        records: &[(crate::TopicPartition, i64)],
        idxs: &[usize],
        deadline: Instant,
    ) -> Result<(Vec<(usize, i64, i16)>, Vec<usize>)> {
        let topics = delete_records_topics(records, idxs).await;
        let timeout = deadline.saturating_duration_since(Instant::now());
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let mut payload = BytesMut::new();
        encode_delete_records_named_topics_cooperative(&mut payload, version, &topics, timeout_ms)
            .await?;
        let body = self
            .roundtrip_known_node(
                node,
                deadline,
                DELETE_RECORDS,
                version,
                |buf| {
                    buf.extend_from_slice(&payload);
                    Ok(())
                },
                timeout,
            )
            .await?;
        self.apply_delete_records_body(node, version, records, idxs, body)
            .await
    }

    async fn apply_delete_records_body(
        &mut self,
        node: i32,
        version: i16,
        records: &[(crate::TopicPartition, i64)],
        idxs: &[usize],
        body: Bytes,
    ) -> Result<(Vec<(usize, i64, i16)>, Vec<usize>)> {
        let (resp, ..) =
            decode_delete_records_topics_response_cooperative(&mut body.clone(), version).await?;
        let mut by_key = index_deleted_records(resp).await;
        let mut order = Vec::with_capacity(idxs.len());
        let mut walked = 0usize;
        for &i in idxs {
            let (tp, _) = records
                .get(i)
                .ok_or_else(|| Error::protocol("missing DeleteRecords query"))?;
            order.push((i, tp.topic.as_str(), tp.partition));
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
        let popped = pop_deleted_records(&mut by_key, &order).await;
        let mut done = Vec::new();
        let mut retry = Vec::new();
        let mut walked = 0usize;
        for ((i, topic, partition), part) in order.into_iter().zip(popped) {
            let (low, err) = part.ok_or_else(|| {
                Error::protocol(format!("DeleteRecords missing {topic}-{partition}"))
            })?;
            if err == 0 {
                done.push((i, low, err));
            } else {
                let e = Error::broker(err, format!("{topic}-{partition}"));
                if e.is_retriable() {
                    self.discard_node_conn(node).await;
                    retry.push(i);
                } else {
                    done.push((i, low, err));
                }
            }
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
        Ok((done, retry))
    }

    /// ListOffsets for these partitions (Java `Admin.listOffsets`).
    ///
    /// Isolation is read-uncommitted. See
    /// [`Self::list_offsets_with_isolation`] for
    /// `ListOffsetsOptions.isolationLevel`. Each timestamp is
    /// [`crate::OffsetSpec`] or an INT64.
    ///
    /// Topic names are copied in slices of 8,192, so the timeout can still
    /// fire while a long list is prepared. Finished slices are kept.
    ///
    /// The call waits up to [`AdminConfig::request_timeout`]. For a one-shot
    /// timeout, use [`Self::list_offsets_timeout`].
    pub async fn list_offsets<Tp, Ts>(
        &mut self,
        queries: impl IntoIterator<Item = (Tp, Ts)>,
    ) -> Result<Vec<(crate::TopicPartition, crate::OffsetAndTimestamp)>>
    where
        Tp: Into<crate::TopicPartition>,
        Ts: Into<i64>,
    {
        let timeout = self.cfg.request_timeout;
        self.list_offsets_timeout(queries, timeout).await
    }

    /// [`Self::list_offsets`] with a one-shot timeout (Java `listOffsets`
    /// plus `ListOffsetsOptions.timeoutMs`).
    ///
    /// `timeout` bounds metadata/connect/negotiation/RPC/retries; ListOffsets
    /// v10+ `TimeoutMs` carries the remaining budget.
    pub async fn list_offsets_timeout<Tp, Ts>(
        &mut self,
        queries: impl IntoIterator<Item = (Tp, Ts)>,
        timeout: Duration,
    ) -> Result<Vec<(crate::TopicPartition, crate::OffsetAndTimestamp)>>
    where
        Tp: Into<crate::TopicPartition>,
        Ts: Into<i64>,
    {
        self.list_offsets_with_isolation_timeout(
            queries,
            crate::IsolationLevel::ReadUncommitted,
            timeout,
        )
        .await
    }

    /// ListOffsets with isolation (Java `listOffsets` +
    /// `ListOffsetsOptions.isolationLevel`).
    ///
    /// Each item is a [`crate::TopicPartition`] and a timestamp
    /// ([`crate::OffsetSpec`] or INT64): [`crate::OffsetSpec::earliest`]
    /// / [`crate::EARLIEST_TIMESTAMP`] (`-2`), [`crate::OffsetSpec::latest`]
    /// / [`crate::LATEST_TIMESTAMP`] (`-1`), [`crate::OffsetSpec::max_timestamp`]
    /// / [`crate::MAX_TIMESTAMP`] (`-3`),
    /// [`crate::OffsetSpec::earliest_local`] /
    /// [`crate::EARLIEST_LOCAL_TIMESTAMP`] (`-4`),
    /// [`crate::OffsetSpec::latest_tiered`] /
    /// [`crate::LATEST_TIERED_TIMESTAMP`] (`-5`),
    /// [`crate::OffsetSpec::earliest_pending_upload`] /
    /// [`crate::EARLIEST_PENDING_UPLOAD_TIMESTAMP`] (`-6`, requires v11), or milliseconds since
    /// the Unix epoch. One ListOffsets
    /// RPC per Metadata partition leader (duplicate partitions keep
    /// separate timestamps). Distinct leaders are queried together.
    /// `NOT_LEADER_OR_FOLLOWER` refreshes
    /// Metadata and retries.
    /// [`crate::OffsetAndTimestamp::leader_epoch`] is ListOffsets v4+.
    /// v1–v5 are classic; v6–v11 are flexible. The leader socket reuses
    /// the ApiVersions learned when it connected;
    /// unsupported selector/isolation combinations return `Error::Unsupported`.
    /// Metadata, connect, negotiation and retries share the caller budget; v10+
    /// `TimeoutMs` carries its remainder. For a one-shot timeout, use
    /// [`Self::list_offsets_with_isolation_timeout`]. Empty input is a no-op.
    pub async fn list_offsets_with_isolation<Tp, Ts>(
        &mut self,
        queries: impl IntoIterator<Item = (Tp, Ts)>,
        isolation: crate::IsolationLevel,
    ) -> Result<Vec<(crate::TopicPartition, crate::OffsetAndTimestamp)>>
    where
        Tp: Into<crate::TopicPartition>,
        Ts: Into<i64>,
    {
        let timeout = self.cfg.request_timeout;
        self.list_offsets_with_isolation_timeout(queries, isolation, timeout)
            .await
    }

    /// [`Self::list_offsets_with_isolation`] with a one-shot timeout (Java
    /// `listOffsets` plus `ListOffsetsOptions.isolationLevel` and
    /// `timeoutMs`).
    ///
    /// `timeout` bounds metadata/connect/negotiation/RPC/retries; ListOffsets
    /// v10+ `TimeoutMs` carries the remaining budget.
    pub async fn list_offsets_with_isolation_timeout<Tp, Ts>(
        &mut self,
        queries: impl IntoIterator<Item = (Tp, Ts)>,
        isolation: crate::IsolationLevel,
        timeout: Duration,
    ) -> Result<Vec<(crate::TopicPartition, crate::OffsetAndTimestamp)>>
    where
        Tp: Into<crate::TopicPartition>,
        Ts: Into<i64>,
    {
        let queries = collect_topic_pairs(queries).await;
        if queries.is_empty() {
            return Ok(Vec::new());
        }
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let deadline = Instant::now()
            .checked_add(timeout)
            .ok_or_else(|| Error::protocol("ListOffsets deadline overflow"))?;
        let mut attempt = 0u32;
        let isolation = isolation.as_i8();
        let mut out: Vec<Option<crate::OffsetAndTimestamp>> =
            open_result_slots(queries.len()).await;
        let mut pending = pending_indexes(queries.len()).await;
        loop {
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            if pending.is_empty() {
                break;
            }
            let need = topics_missing_leaders(
                &self.cluster,
                pending.iter().filter_map(|&i| {
                    queries
                        .get(i)
                        .map(|(tp, _)| (tp.topic.as_str(), tp.partition))
                }),
            )
            .await;
            if !need.is_empty() {
                let known_nodes = self
                    .known_leader_nodes(pending.iter().filter_map(|&i| {
                        queries
                            .get(i)
                            .map(|(tp, _)| (tp.topic.as_str(), tp.partition))
                    }))
                    .await;
                self.refresh_topics_while_dialing(&need, &known_nodes, deadline)
                    .await?;
                if Instant::now() >= deadline {
                    return Err(Error::Timeout);
                }
            }
            let mut present = 0usize;
            let (nodes, mut by_node) = group_pending_by_leader(
                &self.cluster,
                pending.iter().filter_map(|&i| {
                    let (tp, _) = queries.get(i)?;
                    present = present.saturating_add(1);
                    Some((i, tp.topic.as_str(), tp.partition))
                }),
            )
            .await?;
            if present != pending.len() {
                return Err(Error::protocol("missing ListOffsets query"));
            }
            let mut still = Vec::new();
            if nodes.len() > 1 {
                self.list_offsets_nodes_parallel(
                    &nodes, &by_node, isolation, &queries, deadline, &mut out, &mut still,
                )
                .await?;
            } else {
                for node in nodes {
                    let idxs = by_node.remove(&node).unwrap_or_default();
                    match self
                        .list_offsets_on_node(node, isolation, &queries, &idxs, deadline)
                        .await
                    {
                        Ok((done, retry)) => {
                            for (i, ot) in done {
                                if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(ot);
                                }
                            }
                            still.extend(retry);
                        }
                        Err(e) if e.is_retriable() => {
                            self.drop_node_conn(node).await;
                            still.extend(idxs);
                        }
                        Err(e) => return Err(e),
                    }
                }
            }
            pending = still;
            if pending.is_empty() {
                break;
            }
            self.wait_retry(&mut attempt, deadline).await?;
            let known_nodes = self
                .known_leader_nodes(pending.iter().filter_map(|&i| {
                    queries
                        .get(i)
                        .map(|(tp, _)| (tp.topic.as_str(), tp.partition))
                }))
                .await;
            let topics = unique_names_cooperative(
                pending
                    .iter()
                    .filter_map(|&i| queries.get(i).map(|(tp, _)| tp.topic.as_str())),
            )
            .await;
            self.cluster
                .invalidate_topics_cooperative(topics.iter().copied())
                .await;
            if !topics.is_empty() {
                self.refresh_topics_while_dialing(&topics, &known_nodes, deadline)
                    .await?;
            }
        }
        out.into_iter()
            .zip(queries)
            .map(|(ot, (tp, _))| {
                ot.map(|ot| (tp, ot))
                    .ok_or_else(|| Error::protocol("ListOffsets missing result"))
            })
            .collect()
    }

    fn known_leader_chunk() -> usize {
        8 * 1024
    }

    /// Return each cached leader once.
    ///
    /// The walk pauses every 8,192 partitions. Without that pause, finding
    /// leaders for 4,000,000 partitions held the caller for 246 milliseconds.
    ///
    /// A leader that is already in the result is not added again. A partition
    /// with no cached leader is skipped.
    async fn known_leader_nodes<'a>(
        &self,
        parts: impl IntoIterator<Item = (&'a str, i32)>,
    ) -> Vec<i32> {
        let mut known_nodes = Vec::new();
        let mut seen = HashSet::new();
        let mut known = LeaderList::new();
        let mut walked = 0usize;
        for (topic, partition) in parts {
            walked = walked.saturating_add(1);
            if let Ok(node) = known.node(&self.cluster, topic, partition) {
                if seen.insert(node) {
                    known_nodes.push(node);
                }
            }
            if walked == Self::known_leader_chunk() {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
        known_nodes
    }

    /// Load `need` and redial `known_nodes` together.
    ///
    /// Metadata uses the bootstrap socket. Leader handshakes use the cached
    /// broker addresses, so a topic that still needs a lookup does not hold
    /// the leaders this caller already has.
    async fn refresh_topics_while_dialing(
        &mut self,
        need: &[&str],
        known_nodes: &[i32],
        deadline: Instant,
    ) -> Result<()> {
        let dials = self.take_broker_dials(known_nodes).await;
        if dials.is_empty() {
            return self.refresh_metadata_ref(Some(need), deadline).await;
        }
        let cfg = self.cfg.clone();
        let stats = Arc::clone(&self.stats);
        let dialed = Self::dial_admin_nodes(cfg, stats, dials, deadline);
        let refreshed = self.refresh_metadata_ref(Some(need), deadline);
        let (dialed, refreshed) = tokio::join!(dialed, refreshed);
        self.store_admin_dials(dialed);
        refreshed
    }

    /// Dial every leader together, then run one prepared RPC on each socket.
    /// A slow handshake does not hold the other leaders. Missing entries
    /// did not finish before `deadline`.
    async fn take_broker_dials(&mut self, nodes: &[i32]) -> Vec<(i32, String, Vec<ApiVersion>)> {
        let mut dials = Vec::new();
        for &node in nodes {
            if self
                .conns
                .get(&node)
                .is_some_and(|conn| conn.idle_expired(self.cfg.connections_max_idle))
            {
                self.discard_node_conn(node).await;
            }
            if self.conns.contains_key(&node) {
                continue;
            }
            let Some(addr) = self.cluster.brokers.get(&node).cloned() else {
                continue;
            };
            let keys = self.peer_versions.get(&addr).cloned().unwrap_or_default();
            dials.push((node, addr, keys));
        }
        dials
    }

    async fn dial_admin_nodes(
        cfg: AdminConfig,
        stats: Arc<crate::metrics::AdminTracker>,
        dials: Vec<(i32, String, Vec<ApiVersion>)>,
        deadline: Instant,
    ) -> Vec<(i32, Result<AdminOffsetConn>)> {
        if dials.is_empty() {
            return Vec::new();
        }
        let mut waiting = dials.into_iter();
        let mut inflight = tokio::task::JoinSet::new();
        while inflight.len() < 8 {
            let Some((node, addr, keys)) = waiting.next() else {
                break;
            };
            let cfg = cfg.clone();
            let stats = Arc::clone(&stats);
            let _ = inflight.spawn(async move {
                let result = dial_admin_peer(&addr, &cfg, &stats, &keys, deadline).await;
                (node, result)
            });
        }
        let mut opened = Vec::new();
        while let Some(joined) = inflight.join_next().await {
            if let Ok((node, result)) = joined {
                opened.push((node, result));
            }
            while inflight.len() < 8 {
                let Some((node, addr, keys)) = waiting.next() else {
                    break;
                };
                let cfg = cfg.clone();
                let stats = Arc::clone(&stats);
                let _ = inflight.spawn(async move {
                    let result = dial_admin_peer(&addr, &cfg, &stats, &keys, deadline).await;
                    (node, result)
                });
            }
        }
        // A finished dial drops its socket while this call is still in the
        // same poll. Yield so the broker observes that close before the
        // caller continues.
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }
        opened
    }

    fn store_admin_dials(&mut self, dialed: Vec<(i32, Result<AdminOffsetConn>)>) {
        for (node, result) in dialed {
            match result {
                Ok(conn) => {
                    self.remember_peer(&conn);
                    let _ = self.reconnect_fails.remove(&node);
                    let _prev = self.conns.insert(node, conn);
                }
                Err(_) => {
                    let _fails =
                        crate::config::bump_reconnect_fails(&mut self.reconnect_fails, node);
                }
            }
        }
    }

    /// Keep leader dials and RPCs that already finished before the rest are aborted.
    fn reap_leader_exchange(
        dialing: &mut tokio::task::JoinSet<(i32, Result<AdminOffsetConn>)>,
        rpcing: &mut tokio::task::JoinSet<(i32, i16, AdminOffsetConn, Result<Bytes>)>,
        held: &mut HashMap<i32, AdminOffsetConn>,
        finished: &mut LeaderExchange,
        waiting_rpc: &mut VecDeque<i32>,
        reconnect_fails: &mut HashMap<i32, u32>,
    ) {
        while let Some(joined) = dialing.try_join_next() {
            let Ok((node, result)) = joined else {
                continue;
            };
            match result {
                Ok(conn) => {
                    let _ = reconnect_fails.remove(&node);
                    let _prev = held.insert(node, conn);
                    waiting_rpc.push_back(node);
                }
                Err(error) => {
                    let _fails = crate::config::bump_reconnect_fails(reconnect_fails, node);
                    let _prev = finished.insert(node, (0, Err(error)));
                }
            }
        }
        while let Some(joined) = rpcing.try_join_next() {
            let Ok((node, version, conn, body)) = joined else {
                continue;
            };
            waiting_rpc.retain(|id| *id != node);
            let _prev = held.insert(node, conn);
            let _prev = finished.insert(node, (version, body));
        }
    }

    async fn retire_admin_conn(mut conn: AdminOffsetConn) {
        conn.inner.close();
        conn.inner.release_if_closed().await;
    }

    /// Cancel leader dials and RPCs that did not finish and wait until they stop.
    ///
    /// Abort only schedules cancellation. A dial or RPC that already finished
    /// still owns its socket, so that socket is shut down before this returns.
    async fn stop_leader_exchange(
        mut dialing: tokio::task::JoinSet<(i32, Result<AdminOffsetConn>)>,
        mut rpcing: tokio::task::JoinSet<(i32, i16, AdminOffsetConn, Result<Bytes>)>,
    ) {
        dialing.abort_all();
        rpcing.abort_all();
        let mut extra = 0u32;
        while !dialing.is_empty() || !rpcing.is_empty() {
            tokio::select! {
                biased;
                joined = dialing.join_next(), if !dialing.is_empty() => {
                    if let Some(Ok((_, Ok(conn)))) = joined {
                        Self::retire_admin_conn(conn).await;
                    }
                }
                joined = rpcing.join_next(), if !rpcing.is_empty() => {
                    if let Some(Ok((_, _, conn, _))) = joined {
                        Self::retire_admin_conn(conn).await;
                    }
                }
                () = tokio::task::yield_now() => {
                    extra = extra.saturating_add(1);
                    if extra >= 8 {
                        break;
                    }
                }
            }
        }
        // A cancelled dial or RPC drops its socket when the task is polled.
        // The idle watch then has to run before that broker sees the close.
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }
    }

    /// Dial one stalled leader and return once that handshake has stopped.
    ///
    /// The caller's deadline aborts the dial. Later work must not run while
    /// the broker read is still in flight.
    #[doc(hidden)]
    pub async fn test_exchange_stall(&mut self, addr: String) {
        let _prev = self.cluster.brokers.insert(9, addr);
        let deadline = Instant::now() + Duration::from_millis(200);
        let _finished = self
            .exchange_leaders(&[9], deadline, |_admin, _node, _conn, _timeout| {
                Err(Error::protocol("stall dial should not reach an RPC"))
            })
            .await;
    }

    async fn exchange_leaders<F>(
        &mut self,
        nodes: &[i32],
        deadline: Instant,
        mut prepare: F,
    ) -> LeaderExchange
    where
        F: FnMut(&mut Self, i32, &AdminOffsetConn, Duration) -> Result<LeaderFrame>,
    {
        const PARALLELISM: usize = 8;
        type Dial = (i32, Result<AdminOffsetConn>);
        type Rpc = (i32, i16, AdminOffsetConn, Result<Bytes>);
        let mut waiting_dial = VecDeque::new();
        let mut waiting_rpc = VecDeque::new();
        for &node in nodes {
            if self
                .conns
                .get(&node)
                .is_some_and(|conn| conn.idle_expired(self.cfg.connections_max_idle))
            {
                self.discard_node_conn(node).await;
            }
            if self.conns.contains_key(&node) {
                waiting_rpc.push_back(node);
            } else {
                waiting_dial.push_back(node);
            }
        }
        let mut dialing: tokio::task::JoinSet<Dial> = tokio::task::JoinSet::new();
        let mut rpcing: tokio::task::JoinSet<Rpc> = tokio::task::JoinSet::new();
        let mut held: HashMap<i32, AdminOffsetConn> = HashMap::new();
        let mut finished = LeaderExchange::new();
        loop {
            if Instant::now() >= deadline {
                Self::reap_leader_exchange(
                    &mut dialing,
                    &mut rpcing,
                    &mut held,
                    &mut finished,
                    &mut waiting_rpc,
                    &mut self.reconnect_fails,
                );
                Self::stop_leader_exchange(dialing, rpcing).await;
                break;
            }
            while dialing.len() < PARALLELISM {
                let Some(node) = waiting_dial.pop_front() else {
                    break;
                };
                let Some(addr) = self.cluster.brokers.get(&node).cloned() else {
                    let _prev = finished.insert(
                        node,
                        (0, Err(Error::protocol(format!("unknown broker {node}")))),
                    );
                    continue;
                };
                let cfg = self.cfg.clone();
                let stats = Arc::clone(&self.stats);
                let keys = self.peer_versions.get(&addr).cloned().unwrap_or_default();
                let _ = dialing.spawn(async move {
                    let result = dial_admin_peer(&addr, &cfg, &stats, &keys, deadline).await;
                    (node, result)
                });
            }
            while rpcing.len() < PARALLELISM {
                let Some(node) = waiting_rpc.pop_front() else {
                    break;
                };
                let Some(conn) = held.remove(&node).or_else(|| self.conns.remove(&node)) else {
                    let _prev = finished
                        .insert(node, (0, Err(Error::protocol("missing leader connection"))));
                    continue;
                };
                let timeout = deadline.saturating_duration_since(Instant::now());
                if timeout.is_zero() {
                    let _prev = held.insert(node, conn);
                    let _prev = finished.insert(node, (0, Err(Error::Timeout)));
                    continue;
                }
                let frame = match prepare(self, node, &conn, timeout) {
                    Ok(frame) => frame,
                    Err(error) => {
                        let _prev = held.insert(node, conn);
                        let _prev = finished.insert(node, (0, Err(error)));
                        continue;
                    }
                };
                let LeaderFrame {
                    api_key,
                    version,
                    body: payload,
                    deferred,
                } = frame;
                let _ = rpcing.spawn(async move {
                    let mut conn = conn;
                    let payload = if let Some(deferred) = deferred {
                        match deferred.await {
                            Ok(body) => body,
                            Err(error) => return (node, version, conn, Err(error)),
                        }
                    } else {
                        payload
                    };
                    let body = conn
                        .roundtrip(
                            api_key,
                            version,
                            |buf| {
                                buf.extend_from_slice(&payload);
                                Ok(())
                            },
                            timeout,
                        )
                        .await;
                    (node, version, conn, body)
                });
            }
            if dialing.is_empty() && rpcing.is_empty() {
                break;
            }
            let rest = deadline.saturating_duration_since(Instant::now());
            if rest.is_zero() {
                Self::reap_leader_exchange(
                    &mut dialing,
                    &mut rpcing,
                    &mut held,
                    &mut finished,
                    &mut waiting_rpc,
                    &mut self.reconnect_fails,
                );
                Self::stop_leader_exchange(dialing, rpcing).await;
                break;
            }
            tokio::select! {
                joined = dialing.join_next(), if !dialing.is_empty() => {
                    match joined {
                        Some(Ok((node, Ok(conn)))) => {
                            let _ = self.reconnect_fails.remove(&node);
                            let _prev = held.insert(node, conn);
                            waiting_rpc.push_back(node);
                        }
                        Some(Ok((node, Err(error)))) => {
                            let _fails = crate::config::bump_reconnect_fails(
                                &mut self.reconnect_fails,
                                node,
                            );
                            let _prev = finished.insert(node, (0, Err(error)));
                        }
                        Some(Err(_)) | None => {}
                    }
                }
                joined = rpcing.join_next(), if !rpcing.is_empty() => {
                    if let Some(Ok((node, version, conn, body))) = joined {
                        let _prev = held.insert(node, conn);
                        let _prev = finished.insert(node, (version, body));
                    }
                }
                () = tokio::time::sleep(rest) => {
                    Self::reap_leader_exchange(
                        &mut dialing,
                        &mut rpcing,
                        &mut held,
                        &mut finished,
                        &mut waiting_rpc,
                        &mut self.reconnect_fails,
                    );
                    Self::stop_leader_exchange(dialing, rpcing).await;
                    break;
                }
            }
        }
        for (node, conn) in held {
            self.remember_peer(&conn);
            let _prev = self.conns.insert(node, conn);
        }
        finished
    }

    /// Dial and list offsets on every leader at once. One slow handshake
    /// does not hold the other leaders. Results are applied in leader order.
    #[expect(
        clippy::too_many_arguments,
        reason = "one shared deadline fans a prepared leader set into the caller's result slots"
    )]
    async fn list_offsets_nodes_parallel(
        &mut self,
        nodes: &[i32],
        by_node: &HashMap<i32, Vec<usize>>,
        isolation: i8,
        queries: &[(crate::TopicPartition, i64)],
        deadline: Instant,
        out: &mut [Option<crate::OffsetAndTimestamp>],
        still: &mut Vec<usize>,
    ) -> Result<()> {
        let mut grouped = HashMap::new();
        for &node in nodes {
            let idxs = by_node.get(&node).map(Vec::as_slice).unwrap_or(&[]);
            let borrowed = list_offset_topic_requests(queries, idxs, &self.cluster).await;
            let topics = own_list_offset_topics(borrowed).await;
            let _ = grouped.insert(node, topics);
        }
        let mut finished = self.exchange_leaders(nodes, deadline, |_admin, node, conn, timeout| {
            let idxs = by_node.get(&node).map(Vec::as_slice).unwrap_or(&[]);
            let mut minimum = 1;
            for &index in idxs {
                let Some((_, timestamp)) = queries.get(index) else {
                    continue;
                };
                minimum = minimum.max(crate::protocol::offsets::minimum_version_for_timestamp(
                    *timestamp, isolation,
                ));
            }
            let version = conn.negotiated(LIST_OFFSETS, minimum, 11).ok_or_else(|| {
                Error::Unsupported(format!(
                    "broker does not support requested ListOffsets selector/isolation (requires v{minimum}+)"
                ))
            })?;
            let topics = grouped.remove(&node).unwrap_or_default();
            let timeout_ms = crate::consumer::duration_millis_i32(timeout);
            Ok(LeaderFrame::deferred(
                LIST_OFFSETS,
                version,
                Box::pin(async move {
                    let mut payload = BytesMut::new();
                    encode_list_offsets_named_topics_cooperative(
                        &mut payload,
                        version,
                        isolation,
                        &topics,
                        timeout_ms,
                    )
                    .await?;
                    Ok(payload.freeze())
                }),
            ))
        })
        .await;
        for &node in nodes {
            let idxs = by_node.get(&node).cloned().unwrap_or_default();
            let Some((version, body)) = finished.remove(&node) else {
                // A dial that finished without an RPC is still a clean socket.
                still.extend(idxs);
                continue;
            };
            match body {
                Err(error) if error.is_retriable() => {
                    self.discard_node_conn(node).await;
                    still.extend(idxs);
                }
                Err(error) => return Err(error),
                Ok(body) => {
                    let (done, retry) = self
                        .apply_list_offsets_body(node, version, queries, &idxs, body)
                        .await?;
                    for (i, offset) in done {
                        if let Some(slot) = out.get_mut(i) {
                            *slot = Some(offset);
                        }
                    }
                    still.extend(retry);
                }
            }
        }
        Ok(())
    }

    async fn list_offsets_on_node(
        &mut self,
        node: i32,
        isolation: i8,
        queries: &[(crate::TopicPartition, i64)],
        idxs: &[usize],
        deadline: Instant,
    ) -> Result<(Vec<(usize, crate::OffsetAndTimestamp)>, Vec<usize>)> {
        let topics = list_offset_topic_requests(queries, idxs, &self.cluster).await;
        let mut minimum = 1;
        for &index in idxs {
            let (_, timestamp) = queries
                .get(index)
                .ok_or_else(|| Error::protocol("missing ListOffsets query"))?;
            minimum = minimum.max(crate::protocol::offsets::minimum_version_for_timestamp(
                *timestamp, isolation,
            ));
        }
        self.prepare_node_until(node, deadline).await?;
        let version = self
            .negotiated_on(node, LIST_OFFSETS, minimum, 11)
            .ok_or_else(|| {
                Error::Unsupported(format!(
                    "broker does not support requested ListOffsets selector/isolation (requires v{minimum}+)"
                ))
            })?;
        let timeout = deadline.saturating_duration_since(Instant::now());
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let mut encoded = BytesMut::new();
        encode_list_offsets_named_topics_cooperative(
            &mut encoded,
            version,
            isolation,
            &topics,
            crate::consumer::duration_millis_i32(timeout),
        )
        .await?;
        let body = self
            .roundtrip_known_node(
                node,
                deadline,
                LIST_OFFSETS,
                version,
                |buf| {
                    buf.extend_from_slice(&encoded);
                    Ok(())
                },
                timeout,
            )
            .await?;
        self.apply_list_offsets_body(node, version, queries, idxs, body)
            .await
    }

    async fn apply_list_offsets_body(
        &mut self,
        node: i32,
        version: i16,
        queries: &[(crate::TopicPartition, i64)],
        idxs: &[usize],
        body: Bytes,
    ) -> Result<(Vec<(usize, crate::OffsetAndTimestamp)>, Vec<usize>)> {
        let mut cursor = body.as_ref();
        let (resp, ..) =
            decode_list_offsets_topics_response_cooperative(&mut cursor, version).await?;
        if !cursor.is_empty() {
            return Err(Error::protocol("trailing ListOffsets response bytes"));
        }
        let mut by_key = index_listed_offsets(resp).await;
        let mut order = Vec::with_capacity(idxs.len());
        let mut walked = 0usize;
        for &i in idxs {
            let (tp, _) = queries
                .get(i)
                .ok_or_else(|| Error::protocol("missing ListOffsets query"))?;
            order.push((i, tp.topic.as_str(), tp.partition));
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
        let popped = pop_listed_offsets(&mut by_key, &order).await;
        let mut done = Vec::new();
        let mut retry = Vec::new();
        let mut walked = 0usize;
        for ((i, topic, partition), part) in order.into_iter().zip(popped) {
            let part = part.ok_or_else(|| {
                Error::protocol(format!("ListOffsets missing {topic}-{partition}"))
            })?;
            if part.error_code == 0 {
                done.push((
                    i,
                    crate::OffsetAndTimestamp::new(part.offset, part.timestamp)
                        .with_leader_epoch(part.leader_epoch),
                ));
            } else {
                let e = Error::broker(part.error_code, format!("{topic}-{partition}"));
                if matches!(
                    part.error_code,
                    error::FENCED_LEADER_EPOCH | error::UNKNOWN_LEADER_EPOCH
                ) || e.is_retriable()
                {
                    self.discard_node_conn(node).await;
                    retry.push(i);
                } else {
                    return Err(e);
                }
            }
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
        Ok((done, retry))
    }

    /// Describe active producers on a partition (DescribeProducers api 61,
    /// KIP-360).
    ///
    /// Lands on the Metadata partition leader (same class as
    /// DeleteRecords / ListOffsets / OffsetForLeaderEpoch). Official
    /// Apache JSON listeners are `broker` only. This is not a
    /// controller hop and not a transaction-coordinator hop: there is
    /// no Metadata `controller_id` lookup, no `NOT_CONTROLLER` (41)
    /// retry, and no FindCoordinator / `NOT_COORDINATOR` (16) retry.
    /// `NOT_LEADER_OR_FOLLOWER` (6) and other `is_retriable` broker
    /// codes refresh Metadata and retry on the new leader. ErrorCode
    /// is per-partition (bytes 12–13 on leftover-empty fixture topic
    /// `"t"` partition `0`), not top-level after throttle.
    /// For several partitions in one RPC per leader (Java
    /// `describeProducers(Collection)`), use [`Self::describe_producers_for`].
    /// Optional at [`Self::new`] (Kafka 2.8+ / KIP-664); a broker that
    /// omits api 61 returns [`Error::Unsupported`]. DescribeProducers
    /// has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::describe_producers_timeout`].
    pub async fn describe_producers(
        &mut self,
        partition: impl Into<crate::TopicPartition>,
    ) -> Result<DescribeProducersPartition> {
        let timeout = self.cfg.request_timeout;
        self.describe_producers_timeout(partition, timeout).await
    }

    /// [`Self::describe_producers`] with a one-shot RPC deadline (Java
    /// `DescribeProducersOptions.timeoutMs`).
    ///
    /// DescribeProducers has no TimeoutMs; `timeout` is the RPC deadline
    /// and the `NOT_LEADER_OR_FOLLOWER` retry budget.
    pub async fn describe_producers_timeout(
        &mut self,
        partition: impl Into<crate::TopicPartition>,
        timeout: Duration,
    ) -> Result<DescribeProducersPartition> {
        let topics = self
            .describe_producers_for_timeout([partition.into()], timeout)
            .await?;
        topics
            .into_iter()
            .next()
            .and_then(|t| t.partitions.into_iter().next())
            .ok_or_else(|| Error::protocol("empty DescribeProducers response"))
    }

    /// [`Self::describe_producers`] for several partitions (Java
    /// `describeProducers(Collection)`; DescribeProducers Topics of N).
    ///
    /// Partitions that share a leader are sent together. An empty list does
    /// nothing. To pin every partition to one broker
    /// (`DescribeProducersOptions.brokerId`), use
    /// [`Self::describe_producers_for_on_broker`].
    ///
    /// Topic names are copied in slices of 8,192, so the deadline can still
    /// fire while a long list is prepared. Finished slices are kept.
    ///
    /// DescribeProducers has no TimeoutMs. The RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::describe_producers_for_timeout`].
    pub async fn describe_producers_for(
        &mut self,
        partitions: impl IntoIterator<Item = impl Into<crate::TopicPartition>>,
    ) -> Result<Vec<DescribeProducersTopic>> {
        let timeout = self.cfg.request_timeout;
        self.describe_producers_for_with(partitions, timeout, None)
            .await
    }

    /// [`Self::describe_producers_for`] with a one-shot RPC deadline (Java
    /// `describeProducers` plus `DescribeProducersOptions.timeoutMs`).
    ///
    /// DescribeProducers has no TimeoutMs; `timeout` is the RPC deadline
    /// and the `NOT_LEADER_OR_FOLLOWER` retry budget.
    pub async fn describe_producers_for_timeout(
        &mut self,
        partitions: impl IntoIterator<Item = impl Into<crate::TopicPartition>>,
        timeout: Duration,
    ) -> Result<Vec<DescribeProducersTopic>> {
        self.describe_producers_for_with(partitions, timeout, None)
            .await
    }

    /// [`Self::describe_producers_for`] pinned to one broker (Java
    /// `DescribeProducersOptions.brokerId`).
    ///
    /// Sends one DescribeProducers RPC to `broker_id` for every
    /// partition. `NOT_LEADER_OR_FOLLOWER` (6) is returned on that
    /// partition and is not retried on the Metadata leader.
    pub async fn describe_producers_for_on_broker(
        &mut self,
        partitions: impl IntoIterator<Item = impl Into<crate::TopicPartition>>,
        broker_id: i32,
    ) -> Result<Vec<DescribeProducersTopic>> {
        let timeout = self.cfg.request_timeout;
        self.describe_producers_for_with(partitions, timeout, Some(broker_id))
            .await
    }

    /// [`Self::describe_producers_for_on_broker`] with a one-shot RPC
    /// deadline (Java `DescribeProducersOptions.brokerId` + `timeoutMs`).
    ///
    /// DescribeProducers has no TimeoutMs; `timeout` is the RPC deadline.
    /// `NOT_LEADER_OR_FOLLOWER` is not retried onto another broker.
    pub async fn describe_producers_for_on_broker_timeout(
        &mut self,
        partitions: impl IntoIterator<Item = impl Into<crate::TopicPartition>>,
        broker_id: i32,
        timeout: Duration,
    ) -> Result<Vec<DescribeProducersTopic>> {
        self.describe_producers_for_with(partitions, timeout, Some(broker_id))
            .await
    }

    async fn describe_producers_for_with(
        &mut self,
        partitions: impl IntoIterator<Item = impl Into<crate::TopicPartition>>,
        timeout: Duration,
        broker_id: Option<i32>,
    ) -> Result<Vec<DescribeProducersTopic>> {
        let partitions = collect_topic_partitions(partitions).await;
        if partitions.is_empty() {
            return Ok(Vec::new());
        }
        let version = self.describe_producers_version.ok_or_else(|| {
            Error::Unsupported("broker does not support DescribeProducers".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut out: Vec<Option<DescribeProducersPartition>> =
            open_result_slots(partitions.len()).await;
        let mut pending = pending_indexes(partitions.len()).await;
        let pin_broker = broker_id.is_some();
        loop {
            if pending.is_empty() {
                break;
            }
            if !pin_broker {
                let need = topics_missing_leaders(
                    &self.cluster,
                    pending.iter().filter_map(|&i| {
                        partitions
                            .get(i)
                            .map(|tp| (tp.topic.as_str(), tp.partition))
                    }),
                )
                .await;
                if !need.is_empty() {
                    let known_nodes = self
                        .known_leader_nodes(pending.iter().filter_map(|&i| {
                            partitions
                                .get(i)
                                .map(|tp| (tp.topic.as_str(), tp.partition))
                        }))
                        .await;
                    self.refresh_topics_while_dialing(&need, &known_nodes, deadline)
                        .await?;
                }
            }
            let mut by_node: HashMap<i32, Vec<usize>> = HashMap::new();
            let mut nodes: Vec<i32> = Vec::new();
            if let Some(id) = broker_id {
                let _prev = by_node.insert(id, pending.clone());
                nodes.push(id);
            } else {
                let mut present = 0usize;
                (nodes, by_node) = group_pending_by_leader(
                    &self.cluster,
                    pending.iter().filter_map(|&i| {
                        let tp = partitions.get(i)?;
                        present = present.saturating_add(1);
                        Some((i, tp.topic.as_str(), tp.partition))
                    }),
                )
                .await?;
                if present != pending.len() {
                    return Err(Error::protocol("missing DescribeProducers query"));
                }
            }
            let mut still = Vec::new();
            if nodes.len() > 1 {
                let mut grouped = HashMap::new();
                for &node in &nodes {
                    let idxs = by_node.get(&node).map(Vec::as_slice).unwrap_or(&[]);
                    let topics = describe_producers_topics(&partitions, idxs).await;
                    let mut payload = BytesMut::new();
                    encode_describe_producers_named_topics_cooperative(&mut payload, &topics)
                        .await?;
                    let _ = grouped.insert(node, payload.freeze());
                }
                let mut finished = self
                    .exchange_leaders(&nodes, deadline, |_admin, node, _conn, _timeout| {
                        let payload = grouped.get(&node).cloned().unwrap_or_default();
                        Ok(LeaderFrame::ready(DESCRIBE_PRODUCERS, version, payload))
                    })
                    .await;
                for node in &nodes {
                    let idxs = by_node.get(node).cloned().unwrap_or_default();
                    let Some((_version, body)) = finished.remove(node) else {
                        self.discard_node_conn(*node).await;
                        still.extend(idxs);
                        continue;
                    };
                    match body {
                        Err(error) if error.is_retriable() => {
                            self.discard_node_conn(*node).await;
                            still.extend(idxs);
                        }
                        Err(error) => return Err(error),
                        Ok(body) => {
                            let (done, retry) = self
                                .apply_describe_producers_body(&partitions, &idxs, body, pin_broker)
                                .await?;
                            for (i, part) in done {
                                if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(part);
                                }
                            }
                            still.extend(retry);
                        }
                    }
                }
            } else {
                for node in nodes {
                    let idxs = by_node.remove(&node).unwrap_or_default();
                    match self
                        .describe_producers_on_node(
                            node,
                            version,
                            &partitions,
                            &idxs,
                            deadline,
                            pin_broker,
                        )
                        .await
                    {
                        Ok((done, retry)) => {
                            for (i, part) in done {
                                if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(part);
                                }
                            }
                            still.extend(retry);
                        }
                        Err(e) if e.is_retriable() => {
                            self.drop_node_conn(node).await;
                            still.extend(idxs);
                        }
                        Err(e) => return Err(e),
                    }
                }
            }
            pending = still;
            if pending.is_empty() {
                break;
            }
            self.wait_retry(&mut attempt, deadline).await?;
            if pin_broker {
                continue;
            }
            let known_nodes = self
                .known_leader_nodes(pending.iter().filter_map(|&i| {
                    partitions
                        .get(i)
                        .map(|tp| (tp.topic.as_str(), tp.partition))
                }))
                .await;
            let topics = unique_names_cooperative(
                pending
                    .iter()
                    .filter_map(|&i| partitions.get(i).map(|tp| tp.topic.as_str())),
            )
            .await;
            self.cluster
                .invalidate_topics_cooperative(topics.iter().copied())
                .await;
            if !topics.is_empty() {
                self.refresh_topics_while_dialing(&topics, &known_nodes, deadline)
                    .await?;
            }
        }
        let mut grouped: Vec<DescribeProducersTopic> = Vec::new();
        for (tp, part) in partitions.into_iter().zip(out) {
            let part = part.ok_or_else(|| Error::protocol("DescribeProducers missing result"))?;
            match grouped.last_mut() {
                Some(topic) if topic.name == tp.topic => topic.partitions.push(part),
                _ => grouped.push(DescribeProducersTopic::new(tp.topic, vec![part])),
            }
        }
        Ok(grouped)
    }

    async fn describe_producers_on_node(
        &mut self,
        node: i32,
        version: i16,
        partitions: &[crate::TopicPartition],
        idxs: &[usize],
        deadline: Instant,
        pin_broker: bool,
    ) -> Result<DescribeProducersNodeOutcome> {
        let topics = describe_producers_topics(partitions, idxs).await;
        let mut payload = BytesMut::new();
        encode_describe_producers_named_topics_cooperative(&mut payload, &topics).await?;
        let timeout = deadline.saturating_duration_since(Instant::now());
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let body = self
            .roundtrip_known_node(
                node,
                deadline,
                DESCRIBE_PRODUCERS,
                version,
                |buf| {
                    buf.extend_from_slice(&payload);
                    Ok(())
                },
                timeout,
            )
            .await?;
        self.apply_describe_producers_body(partitions, idxs, body, pin_broker)
            .await
    }

    async fn apply_describe_producers_body(
        &mut self,
        partitions: &[crate::TopicPartition],
        idxs: &[usize],
        body: Bytes,
        pin_broker: bool,
    ) -> Result<DescribeProducersNodeOutcome> {
        let resp = decode_describe_producers_response_cooperative(&mut body.clone()).await?;
        let mut by_tp = index_described_producers(resp.topics).await;
        let mut order = Vec::with_capacity(idxs.len());
        let mut walked = 0usize;
        for &i in idxs {
            let tp = partitions
                .get(i)
                .ok_or_else(|| Error::protocol("missing DescribeProducers query"))?;
            order.push((i, tp.topic.as_str(), tp.partition));
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
        let popped = pop_described_producers(&mut by_tp, &order).await;
        let mut done = Vec::new();
        let mut retry = Vec::new();
        let mut walked = 0usize;
        for ((i, topic, partition), part) in order.into_iter().zip(popped) {
            let part = part.ok_or_else(|| {
                Error::protocol(format!("DescribeProducers missing {topic}-{partition}"))
            })?;
            if part.error_code == 0 {
                done.push((i, part));
            } else {
                let e = Error::broker(part.error_code, format!("{topic}-{partition}"));
                if !pin_broker && e.is_retriable() {
                    retry.push(i);
                } else {
                    done.push((i, part));
                }
            }
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
        Ok((done, retry))
    }

    /// Brokers, controller, and cluster id (`DescribeCluster`).
    ///
    /// Negotiates v0–v2 (flexible from v0). v1 EndpointType is brokers
    /// (KIP-919). v2 omits fenced brokers (`IncludeFencedBrokers` false).
    /// Kafka 4.0 `validVersions` is `0-2`. v3+ is not spoken. See
    /// [`Self::describe_cluster_with`] for Java `DescribeClusterOptions`.
    /// Optional at [`Self::new`] (Kafka 2.8+ / KIP-700); a broker that
    /// omits api 60 returns [`Error::Unsupported`]. DescribeCluster has
    /// no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::describe_cluster_timeout`].
    pub async fn describe_cluster(&mut self) -> Result<ClusterDescription> {
        self.describe_cluster_with(false, ENDPOINT_TYPE_BROKERS, false)
            .await
    }

    /// [`Self::describe_cluster`] with a one-shot RPC deadline (Java
    /// `DescribeClusterOptions.timeoutMs`).
    ///
    /// DescribeCluster has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn describe_cluster_timeout(
        &mut self,
        timeout: Duration,
    ) -> Result<ClusterDescription> {
        self.describe_cluster_with_timeout(false, ENDPOINT_TYPE_BROKERS, false, timeout)
            .await
    }

    /// DescribeCluster with authorized operations, endpoint type, and
    /// fenced brokers (Java `describeCluster` plus
    /// `DescribeClusterOptions`).
    ///
    /// `endpoint_type` is [`EndpointType`] or a protocol `i8` (`1` brokers,
    /// `2` controllers). v1+ sends EndpointType. v2 sends
    /// IncludeFencedBrokers. v0 omits both even when set. DescribeCluster
    /// has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::describe_cluster_with_timeout`].
    pub async fn describe_cluster_with(
        &mut self,
        include_authorized_operations: bool,
        endpoint_type: impl Into<i8>,
        include_fenced_brokers: bool,
    ) -> Result<ClusterDescription> {
        let timeout = self.cfg.request_timeout;
        self.describe_cluster_with_timeout(
            include_authorized_operations,
            endpoint_type,
            include_fenced_brokers,
            timeout,
        )
        .await
    }

    /// [`Self::describe_cluster_with`] with Java
    /// `DescribeClusterOptions.timeoutMs`.
    ///
    /// DescribeCluster has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn describe_cluster_with_timeout(
        &mut self,
        include_authorized_operations: bool,
        endpoint_type: impl Into<i8>,
        include_fenced_brokers: bool,
        timeout: Duration,
    ) -> Result<ClusterDescription> {
        let endpoint_type = endpoint_type.into();
        let version = self.describe_cluster_version.ok_or_else(|| {
            Error::Unsupported("broker does not support DescribeCluster v0-2".into())
        })?;
        let body = self
            .roundtrip_bootstrap(
                DESCRIBE_CLUSTER,
                version,
                |buf| {
                    encode_describe_cluster_request(
                        buf,
                        version,
                        include_authorized_operations,
                        endpoint_type,
                        include_fenced_brokers,
                    )
                },
                timeout,
            )
            .await?;
        decode_describe_cluster_response_cooperative(&mut body.clone(), version).await
    }

    /// Delete ACL bindings (`DeleteAcls`) matching `resource_type`.
    ///
    /// Negotiates v0–v3 (v0–v1 classic; v2+ flexible). v1+ sends
    /// PatternTypeFilter ANY. Operation and Permission are ANY (Java
    /// `AccessControlEntryFilter.ANY`). Kafka 4.0 `validVersions` is
    /// `1-3`. v4+ is not spoken.
    ///
    /// `resource_type` is [`crate::AclResourceType`] or a protocol `i8`.
    /// Returns the first filter's error code. For principal / host / name
    /// filters or Filters of N, use [`Self::delete_acls_with`]. DeleteAcls
    /// has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::delete_acls_timeout`].
    pub async fn delete_acls(&mut self, resource_type: impl Into<i8>) -> Result<i16> {
        let results = self
            .delete_acls_with(&[AclBindingFilter::resource_type(resource_type)])
            .await?;
        Ok(results.first().map(|r| r.error_code).unwrap_or(0))
    }

    /// [`Self::delete_acls`] with a one-shot RPC deadline (Java
    /// `DeleteAclsOptions.timeoutMs`).
    pub async fn delete_acls_timeout(
        &mut self,
        resource_type: impl Into<i8>,
        timeout: Duration,
    ) -> Result<i16> {
        let results = self
            .delete_acls_with_timeout(&[AclBindingFilter::resource_type(resource_type)], timeout)
            .await?;
        Ok(results.first().map(|r| r.error_code).unwrap_or(0))
    }

    /// [`Self::delete_acls`] with Java `deleteAcls(Collection)` Filters of N.
    ///
    /// Empty `filters` is a no-op. DeleteAcls has no TimeoutMs; the RPC
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// deadline, use [`Self::delete_acls_with_timeout`].
    pub async fn delete_acls_with(
        &mut self,
        filters: &[AclBindingFilter],
    ) -> Result<Vec<DeletedAclsFilterResult>> {
        let timeout = self.cfg.request_timeout;
        self.delete_acls_with_timeout(filters, timeout).await
    }

    /// [`Self::delete_acls_with`] with Java `DeleteAclsOptions.timeoutMs`.
    ///
    /// Empty `filters` is a no-op. DeleteAcls has no TimeoutMs; `timeout`
    /// is the RPC deadline.
    pub async fn delete_acls_with_timeout(
        &mut self,
        filters: &[AclBindingFilter],
        timeout: Duration,
    ) -> Result<Vec<DeletedAclsFilterResult>> {
        if filters.is_empty() {
            return Ok(Vec::new());
        }
        let version = self
            .delete_acls_version
            .ok_or_else(|| Error::Unsupported("broker does not support DeleteAcls v0-3".into()))?;
        let mut encoded = BytesMut::new();
        encode_delete_acls_request_cooperative(&mut encoded, version, filters).await?;
        let body = self
            .roundtrip_bootstrap(
                DELETE_ACLS,
                version,
                |buf| {
                    buf.extend_from_slice(&encoded);
                    Ok(())
                },
                timeout,
            )
            .await?;
        let (results, ..) =
            decode_delete_acls_filter_results_cooperative(&mut body.clone(), version).await?;
        Ok(results)
    }

    /// Delete committed offsets for `group_id` (OffsetDelete api 47).
    ///
    /// Lands on the group coordinator (`FindCoordinator` `key_type=0`).
    /// `COORDINATOR_LOAD_IN_PROGRESS` / `COORDINATOR_NOT_AVAILABLE` /
    /// `NOT_COORDINATOR` refresh the coordinator and retry.
    ///
    /// Each item is a [`crate::TopicPartition`] (or anything that converts
    /// to one). Java `deleteConsumerGroupOffsets` is
    /// [`Self::delete_consumer_group_offsets`]. Optional at [`Self::new`]
    /// (Kafka 2.4+ / KIP-496); a broker that omits api 47 returns
    /// [`Error::Unsupported`]. OffsetDelete has no TimeoutMs; the RPC
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// deadline, use [`Self::delete_offsets_timeout`].
    pub async fn delete_offsets(
        &mut self,
        group_id: &str,
        partitions: impl IntoIterator<Item = impl Into<crate::TopicPartition>>,
    ) -> Result<Vec<OffsetDeleteResult>> {
        let timeout = self.cfg.request_timeout;
        self.delete_offsets_timeout(group_id, partitions, timeout)
            .await
    }

    /// [`Self::delete_offsets`] with a one-shot RPC deadline (Java
    /// `DeleteConsumerGroupOffsetsOptions.timeoutMs`).
    ///
    /// OffsetDelete has no TimeoutMs; `timeout` is the RPC deadline and
    /// the coordinator retry budget.
    pub async fn delete_offsets_timeout(
        &mut self,
        group_id: &str,
        partitions: impl IntoIterator<Item = impl Into<crate::TopicPartition>>,
        timeout: Duration,
    ) -> Result<Vec<OffsetDeleteResult>> {
        let partitions: Vec<(String, i32)> = partitions
            .into_iter()
            .map(|p| {
                let tp = p.into();
                (tp.topic, tp.partition)
            })
            .collect();
        let topics = offset_delete_named_topics(&partitions).await;
        let version = self
            .offset_delete_version
            .ok_or_else(|| Error::Unsupported("broker does not support OffsetDelete".into()))?;
        let mut payload = BytesMut::new();
        encode_offset_delete_named_topics_cooperative(&mut payload, group_id, &topics).await?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        loop {
            let stale = self.group_coord.as_ref().is_none_or(|(g, _)| g != group_id);
            if stale {
                let node = self.discover_group_coord(group_id, deadline).await?;
                self.group_coord = Some((group_id.to_string(), node));
            }
            let node = self
                .group_coord
                .as_ref()
                .map(|(_, n)| *n)
                .ok_or_else(|| Error::protocol("missing group coordinator"))?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    OFFSET_DELETE,
                    version,
                    |buf| {
                        buf.extend_from_slice(&payload);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.group_coord = None;
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let (top, results, ..) =
                decode_offset_delete_response_cooperative(&mut body.clone()).await?;
            if error::coordinator_retriable(top) {
                // 14/15/16: FindCoordinator, then the new group coordinator.
                self.group_coord = None;
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                continue;
            }
            if top != 0 {
                return Err(Error::broker(top, "OffsetDelete"));
            }
            return Ok(results);
        }
    }

    /// Delete committed offsets (Java `Admin.deleteConsumerGroupOffsets`).
    ///
    /// Same wire as [`Self::delete_offsets`]: OffsetDelete api 47 on the
    /// group coordinator. OffsetDelete has no TimeoutMs; the RPC deadline
    /// is [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::delete_consumer_group_offsets_timeout`].
    pub async fn delete_consumer_group_offsets(
        &mut self,
        group_id: &str,
        partitions: impl IntoIterator<Item = impl Into<crate::TopicPartition>>,
    ) -> Result<Vec<OffsetDeleteResult>> {
        let timeout = self.cfg.request_timeout;
        self.delete_consumer_group_offsets_timeout(group_id, partitions, timeout)
            .await
    }

    /// [`Self::delete_consumer_group_offsets`] with a one-shot RPC deadline
    /// (Java `DeleteConsumerGroupOffsetsOptions.timeoutMs`).
    ///
    /// OffsetDelete has no TimeoutMs; `timeout` is the RPC deadline and
    /// the coordinator retry budget.
    pub async fn delete_consumer_group_offsets_timeout(
        &mut self,
        group_id: &str,
        partitions: impl IntoIterator<Item = impl Into<crate::TopicPartition>>,
        timeout: Duration,
    ) -> Result<Vec<OffsetDeleteResult>> {
        self.delete_offsets_timeout(group_id, partitions, timeout)
            .await
    }

    /// List committed offsets for `group_id` (Java `listConsumerGroupOffsets`).
    ///
    /// OffsetFetch v1–v9 on the group coordinator. Partitions with no committed
    /// offset return [`crate::OffsetAndMetadata`] offset `-1`. Empty
    /// `partitions` returns an empty list. For every committed partition,
    /// use [`Self::list_all_consumer_group_offsets`]. `COORDINATOR_LOAD_IN_PROGRESS` /
    /// `COORDINATOR_NOT_AVAILABLE` / `NOT_COORDINATOR` refresh the coordinator
    /// and retry. Waits up to [`AdminConfig::request_timeout`]. For a one-shot
    /// timeout, use [`Self::list_consumer_group_offsets_timeout`].
    pub async fn list_consumer_group_offsets(
        &mut self,
        group_id: &str,
        partitions: impl IntoIterator<Item = impl Into<crate::TopicPartition>>,
    ) -> Result<Vec<(crate::TopicPartition, crate::OffsetAndMetadata)>> {
        let timeout = self.cfg.request_timeout;
        self.list_consumer_group_offsets_timeout(group_id, partitions, timeout)
            .await
    }

    /// [`Self::list_consumer_group_offsets`] with a one-shot timeout (Java
    /// `ListConsumerGroupOffsetsOptions.timeoutMs`).
    pub async fn list_consumer_group_offsets_timeout(
        &mut self,
        group_id: &str,
        partitions: impl IntoIterator<Item = impl Into<crate::TopicPartition>>,
        timeout: Duration,
    ) -> Result<Vec<(crate::TopicPartition, crate::OffsetAndMetadata)>> {
        self.list_consumer_group_offsets_with(group_id, partitions, false, timeout)
            .await
    }

    /// [`Self::list_consumer_group_offsets`] plus `requireStable` and timeout
    /// (Java `ListConsumerGroupOffsetsOptions.requireStable` and `timeoutMs`).
    ///
    /// `require_stable` is OffsetFetch v7+ RequireStable. `timeout` is the
    /// RPC deadline.
    pub async fn list_consumer_group_offsets_with(
        &mut self,
        group_id: &str,
        partitions: impl IntoIterator<Item = impl Into<crate::TopicPartition>>,
        require_stable: bool,
        timeout: Duration,
    ) -> Result<Vec<(crate::TopicPartition, crate::OffsetAndMetadata)>> {
        let started = Instant::now();
        let partitions = crate::offsets::collect_bounded_partitions(partitions)?;
        if partitions.is_empty() {
            return Ok(Vec::new());
        }
        let fetched = self
            .fetch_consumer_group_offsets(
                group_id,
                Some(partitions.as_slice()),
                require_stable,
                timeout.saturating_sub(started.elapsed()),
            )
            .await?;
        crate::group::check_fetched_offsets(&fetched)?;
        let index = crate::group::index_fetched_offsets_cooperative(&fetched).await;
        let mut listed = Vec::with_capacity(partitions.len());
        let mut walked = 0usize;
        for tp in partitions {
            let md = index
                .get(&(tp.topic.as_str(), tp.partition))
                .copied()
                .map(crate::group::offset_and_metadata_from)
                .unwrap_or_else(|| crate::OffsetAndMetadata::new(-1));
            listed.push((tp, md));
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
        Ok(listed)
    }

    /// List every committed offset for `group_id` (Java
    /// `listConsumerGroupOffsets(groupId)` with no topic-partition filter).
    ///
    /// OffsetFetch null Topics (v2+). Waits up to
    /// [`AdminConfig::request_timeout`]. For a one-shot timeout, use
    /// [`Self::list_all_consumer_group_offsets_timeout`]. For
    /// `requireStable` and a one-shot timeout, use
    /// [`Self::list_all_consumer_group_offsets_with`].
    pub async fn list_all_consumer_group_offsets(
        &mut self,
        group_id: &str,
    ) -> Result<Vec<(crate::TopicPartition, crate::OffsetAndMetadata)>> {
        let timeout = self.cfg.request_timeout;
        self.list_all_consumer_group_offsets_timeout(group_id, timeout)
            .await
    }

    /// [`Self::list_all_consumer_group_offsets`] with a one-shot timeout
    /// (Java `ListConsumerGroupOffsetsOptions.timeoutMs`).
    ///
    /// OffsetFetch has no TimeoutMs; `timeout` is the RPC deadline.
    /// RequireStable stays false. For `requireStable`, use
    /// [`Self::list_all_consumer_group_offsets_with`].
    pub async fn list_all_consumer_group_offsets_timeout(
        &mut self,
        group_id: &str,
        timeout: Duration,
    ) -> Result<Vec<(crate::TopicPartition, crate::OffsetAndMetadata)>> {
        self.list_all_consumer_group_offsets_with(group_id, false, timeout)
            .await
    }

    /// [`Self::list_all_consumer_group_offsets`] plus `requireStable` and
    /// timeout (Java `ListConsumerGroupOffsetsOptions`).
    pub async fn list_all_consumer_group_offsets_with(
        &mut self,
        group_id: &str,
        require_stable: bool,
        timeout: Duration,
    ) -> Result<Vec<(crate::TopicPartition, crate::OffsetAndMetadata)>> {
        let fetched = self
            .fetch_consumer_group_offsets(group_id, None, require_stable, timeout)
            .await?;
        let map = crate::group::committed_offset_map_cooperative(&fetched).await?;
        Ok(crate::group::committed_offset_pairs_cooperative(map).await)
    }

    /// List committed offsets for several groups (Java
    /// `listConsumerGroupOffsets(Map<String, ListConsumerGroupOffsetsSpec>)`).
    ///
    /// OffsetFetch v8+ Groups array of N (KIP-709): groups that share a
    /// coordinator go in one RPC. FindCoordinator v4+ CoordinatorKeys
    /// array of N (KIP-699): one FindCoordinator per retry, not one per
    /// group. Brokers that only speak OffsetFetch v1–v7 get one
    /// OffsetFetch per group. Brokers that only speak FindCoordinator
    /// v1–v3 get one FindCoordinator per group. Empty input is a no-op.
    /// Empty [`ListConsumerGroupOffsetsSpec::topic_partitions`] for a
    /// group is a no-op for that group. Waits up to
    /// [`AdminConfig::request_timeout`]. For a one-shot timeout, use
    /// [`Self::list_consumer_group_offsets_for_groups_timeout`]. For
    /// `requireStable` and a one-shot timeout, use
    /// [`Self::list_consumer_group_offsets_for_groups_with`].
    pub async fn list_consumer_group_offsets_for_groups(
        &mut self,
        groups: impl IntoIterator<Item = (impl Into<String>, ListConsumerGroupOffsetsSpec)>,
    ) -> Result<
        Vec<(
            String,
            Vec<(crate::TopicPartition, crate::OffsetAndMetadata)>,
        )>,
    > {
        let timeout = self.cfg.request_timeout;
        self.list_consumer_group_offsets_for_groups_timeout(groups, timeout)
            .await
    }

    /// [`Self::list_consumer_group_offsets_for_groups`] with a one-shot
    /// timeout (Java `ListConsumerGroupOffsetsOptions.timeoutMs`).
    ///
    /// OffsetFetch has no TimeoutMs; `timeout` is the RPC deadline.
    /// RequireStable stays false. For `requireStable`, use
    /// [`Self::list_consumer_group_offsets_for_groups_with`].
    pub async fn list_consumer_group_offsets_for_groups_timeout(
        &mut self,
        groups: impl IntoIterator<Item = (impl Into<String>, ListConsumerGroupOffsetsSpec)>,
        timeout: Duration,
    ) -> Result<
        Vec<(
            String,
            Vec<(crate::TopicPartition, crate::OffsetAndMetadata)>,
        )>,
    > {
        self.list_consumer_group_offsets_for_groups_with(groups, false, timeout)
            .await
    }

    /// [`Self::list_consumer_group_offsets_for_groups`] plus `requireStable`
    /// and timeout (Java `ListConsumerGroupOffsetsOptions`).
    ///
    /// `require_stable` is OffsetFetch v7+ RequireStable. `timeout` is the
    /// RPC deadline. Groups on different coordinators are fetched together.
    pub async fn list_consumer_group_offsets_for_groups_with(
        &mut self,
        groups: impl IntoIterator<Item = (impl Into<String>, ListConsumerGroupOffsetsSpec)>,
        require_stable: bool,
        timeout: Duration,
    ) -> Result<
        Vec<(
            String,
            Vec<(crate::TopicPartition, crate::OffsetAndMetadata)>,
        )>,
    > {
        let target = Instant::now().checked_add(timeout).ok_or(Error::Timeout)?;
        let deadline = crate::net::Deadline::from_std(target);
        let mut jobs = Vec::new();
        let mut parts = 0usize;
        let mut strings = 0usize;
        let limits = crate::protocol::group::OffsetLimits::default();
        for (group, spec) in groups {
            if jobs.len() >= 256 {
                return Err(Error::protocol("too many offset groups"));
            }
            let group = group.into();
            if group.len() > limits.string_bytes {
                return Err(Error::protocol("offset group string exceeds limit"));
            }
            strings = strings
                .checked_add(group.len())
                .filter(|count| *count <= limits.total_string_bytes)
                .ok_or_else(|| Error::protocol("offset group strings exceed limit"))?;
            if let Some(partitions) = &spec.partitions {
                if partitions.len() > limits.array_elements {
                    return Err(Error::protocol("too many offset partitions"));
                }
                parts = parts
                    .checked_add(partitions.len())
                    .filter(|count| *count <= limits.total_elements)
                    .ok_or_else(|| Error::protocol("offset aggregate partitions exceed limit"))?;
                for partition in partitions {
                    if partition.topic.len() > limits.string_bytes {
                        return Err(Error::protocol("offset topic string exceeds limit"));
                    }
                    strings = strings
                        .checked_add(partition.topic.len())
                        .filter(|count| *count <= limits.total_string_bytes)
                        .ok_or_else(|| Error::protocol("offset aggregate strings exceed limit"))?;
                }
            }
            jobs.push((group, spec));
        }
        if jobs.is_empty() {
            return Ok(Vec::new());
        }
        let mut out: Vec<(
            String,
            Vec<(crate::TopicPartition, crate::OffsetAndMetadata)>,
        )> = jobs.iter().map(|(g, _)| (g.clone(), Vec::new())).collect();
        let mut remaining: Vec<usize> = Vec::new();
        for (i, (_, spec)) in jobs.iter().enumerate() {
            if spec.partitions.as_ref().is_some_and(Vec::is_empty) {
                continue;
            }
            remaining.push(i);
        }
        if remaining.is_empty() {
            return Ok(out);
        }
        if self
            .versions
            .get(&OFFSET_FETCH)
            .is_some_and(|range| range.min_version <= 10 && range.max_version >= 10)
        {
            return self
                .fetch_named_groups_v10(&jobs, require_stable, deadline)
                .await;
        }
        {
            if let Some(_bootstrap_version) = self
                .versions
                .get(&OFFSET_FETCH)
                .and_then(|v| pick_version(v.min_version, v.max_version, 8, 9))
            {
                let deadline = target;
                let mut attempt = 0u32;
                loop {
                    if Instant::now() >= deadline {
                        return Err(Error::Timeout);
                    }
                    let group_ids: Vec<&str> = remaining
                        .iter()
                        .filter_map(|&i| jobs.get(i).map(|j| j.0.as_str()))
                        .collect();
                    let coords = self.discover_group_coords(&group_ids, deadline).await?;
                    let mut by_node: HashMap<i32, Vec<usize>> = HashMap::new();
                    for &i in &remaining {
                        let group_id = jobs
                            .get(i)
                            .ok_or_else(|| Error::protocol("missing group spec"))?
                            .0
                            .as_str();
                        let node = *coords.get(group_id).ok_or_else(|| {
                            Error::protocol(format!("missing coordinator for {group_id}"))
                        })?;
                        by_node.entry(node).or_default().push(i);
                    }
                    let mut nodes: Vec<i32> = by_node.keys().copied().collect();
                    nodes.sort_unstable();
                    let mut next_remaining = Vec::new();
                    let mut retry = false;
                    if nodes.len() > 1 {
                        let mut prepared = HashMap::new();
                        for node in &nodes {
                            let idxs = by_node.get(node).map(Vec::as_slice).unwrap_or(&[]);
                            let _ = prepared
                                .insert(*node, borrowed_offset_fetch_groups(&jobs, idxs).await?);
                        }
                        let mut encoded_groups = HashMap::new();
                        for node in &nodes {
                            let Ok(version) = self.offset_version_on(*node, OFFSET_FETCH, 8, 9)
                            else {
                                continue;
                            };
                            let groups = prepared.get(node).map(Vec::as_slice).unwrap_or(&[]);
                            let mut payload = BytesMut::new();
                            encode_offset_fetch_groups_named_cooperative(
                                &mut payload,
                                version,
                                groups,
                                require_stable,
                            )
                            .await?;
                            let _previous =
                                encoded_groups.insert(*node, (version, payload.freeze()));
                        }
                        let mut finished = self
                            .exchange_leaders(&nodes, deadline, |_admin, node, conn, _timeout| {
                                let version = conn.offset_version(OFFSET_FETCH, 8, 9)?;
                                if let Some((prepared_version, payload)) = encoded_groups.get(&node)
                                {
                                    if *prepared_version == version {
                                        return Ok(LeaderFrame::ready(
                                            OFFSET_FETCH,
                                            version,
                                            payload.clone(),
                                        ));
                                    }
                                }
                                let groups = prepared.get(&node).map(Vec::as_slice).unwrap_or(&[]);
                                let mut payload = BytesMut::new();
                                encode_offset_fetch_groups_named(
                                    &mut payload,
                                    version,
                                    groups,
                                    require_stable,
                                )?;
                                Ok(LeaderFrame::ready(OFFSET_FETCH, version, payload.freeze()))
                            })
                            .await;
                        for node in &nodes {
                            let idxs = by_node.get(node).cloned().unwrap_or_default();
                            let Some((version, body)) = finished.remove(node) else {
                                self.discard_node_conn(*node).await;
                                self.group_coord = None;
                                next_remaining.extend(idxs);
                                retry = true;
                                continue;
                            };
                            match body {
                                Err(error) if error.is_retriable() => {
                                    self.discard_node_conn(*node).await;
                                    self.group_coord = None;
                                    next_remaining.extend(idxs);
                                    retry = true;
                                }
                                Err(error) => return Err(error),
                                Ok(body) => {
                                    if Self::apply_batched_offset_fetch(
                                        version, &jobs, &idxs, body, &mut out,
                                    )
                                    .await?
                                    {
                                        self.group_coord = None;
                                        self.discard_node_conn(*node).await;
                                        next_remaining.extend(idxs);
                                        retry = true;
                                    }
                                }
                            }
                        }
                    } else {
                        for node in nodes {
                            let idxs = by_node.get(&node).cloned().unwrap_or_default();
                            let groups = borrowed_offset_fetch_groups(&jobs, &idxs).await?;
                            self.prepare_node_until(node, deadline).await?;
                            let version = self.offset_version_on(node, OFFSET_FETCH, 8, 9)?;
                            let timeout = deadline.saturating_duration_since(Instant::now());
                            if timeout.is_zero() {
                                return Err(Error::Timeout);
                            }
                            let mut encoded = BytesMut::new();
                            encode_offset_fetch_groups_named_cooperative(
                                &mut encoded,
                                version,
                                &groups,
                                require_stable,
                            )
                            .await?;
                            let body = {
                                self.roundtrip_known_node(
                                    node,
                                    deadline,
                                    OFFSET_FETCH,
                                    version,
                                    |buf| {
                                        buf.extend_from_slice(&encoded);
                                        Ok(())
                                    },
                                    timeout,
                                )
                                .await
                            };
                            let body = match body {
                                Ok(b) => b,
                                Err(e) if e.is_retriable() => {
                                    self.drop_node_conn(node).await;
                                    self.group_coord = None;
                                    next_remaining.extend(idxs);
                                    retry = true;
                                    continue;
                                }
                                Err(e) => return Err(e),
                            };
                            let results = match decode_offset_fetch_groups_response_cooperative(
                                &mut body.clone(),
                                version,
                            )
                            .await
                            {
                                Ok((r, ..)) => r,
                                Err(e)
                                    if e.broker_code()
                                        .is_some_and(error::coordinator_retriable) =>
                                {
                                    self.group_coord = None;
                                    self.drop_node_conn(node).await;
                                    next_remaining.extend(idxs);
                                    retry = true;
                                    continue;
                                }
                                Err(e) => return Err(e),
                            };
                            if results
                                .iter()
                                .any(|r| error::coordinator_retriable(r.error_code))
                            {
                                self.group_coord = None;
                                self.drop_node_conn(node).await;
                                next_remaining.extend(idxs);
                                retry = true;
                                continue;
                            }
                            let mut by_id: HashMap<
                                String,
                                crate::protocol::group::OffsetFetchGroupResult,
                            > = HashMap::new();
                            for g in results {
                                if g.error_code != 0 {
                                    return Err(Error::broker(g.error_code, g.group_id));
                                }
                                let _ = by_id.insert(g.group_id.clone(), g);
                            }
                            for i in idxs {
                                let job = jobs
                                    .get(i)
                                    .ok_or_else(|| Error::protocol("missing group spec"))?;
                                let Some(got) = by_id.remove(&job.0) else {
                                    return Err(Error::protocol(format!(
                                        "OffsetFetch response missing group {}",
                                        job.0
                                    )));
                                };
                                let listed = listed_group_offsets(&job.1, &got.topics).await?;
                                let slot = out
                                    .get_mut(i)
                                    .ok_or_else(|| Error::protocol("missing group result slot"))?;
                                slot.1 = listed;
                            }
                        }
                    }
                    if !retry {
                        break;
                    }
                    remaining = next_remaining;
                    self.wait_retry(&mut attempt, deadline).await?;
                }
                return Ok(out);
            }
            for i in remaining {
                let (group_id, spec) = {
                    let job = jobs
                        .get(i)
                        .ok_or_else(|| Error::protocol("missing group spec"))?;
                    (job.0.clone(), job.1.clone())
                };
                let fetched = self
                    .fetch_consumer_group_offsets(
                        &group_id,
                        spec.partitions.as_deref(),
                        require_stable,
                        deadline.remaining()?,
                    )
                    .await?;
                let listed = listed_group_offsets(&spec, &fetched).await?;
                let slot = out
                    .get_mut(i)
                    .ok_or_else(|| Error::protocol("missing group result slot"))?;
                slot.1 = listed;
            }
            Ok(out)
        }
    }

    /// `Ok(true)` means the whole coordinator batch must be rediscovered.
    async fn apply_batched_offset_fetch(
        version: i16,
        jobs: &[(String, ListConsumerGroupOffsetsSpec)],
        idxs: &[usize],
        body: Bytes,
        out: &mut [(
            String,
            Vec<(crate::TopicPartition, crate::OffsetAndMetadata)>,
        )],
    ) -> Result<bool> {
        let results =
            match decode_offset_fetch_groups_response_cooperative(&mut body.clone(), version).await
            {
                Ok((results, ..)) => results,
                Err(error)
                    if error
                        .broker_code()
                        .is_some_and(error::coordinator_retriable) =>
                {
                    return Ok(true);
                }
                Err(error) => return Err(error),
            };
        if results
            .iter()
            .any(|result| error::coordinator_retriable(result.error_code))
        {
            return Ok(true);
        }
        let mut by_id: HashMap<String, crate::protocol::group::OffsetFetchGroupResult> =
            HashMap::new();
        for group in results {
            if group.error_code != 0 {
                return Err(Error::broker(group.error_code, group.group_id));
            }
            let _ = by_id.insert(group.group_id.clone(), group);
        }
        for i in idxs {
            let job = jobs
                .get(*i)
                .ok_or_else(|| Error::protocol("missing group spec"))?;
            let Some(got) = by_id.remove(&job.0) else {
                return Err(Error::protocol(format!(
                    "OffsetFetch response missing group {}",
                    job.0
                )));
            };
            let listed = listed_group_offsets(&job.1, &got.topics).await?;
            let slot = out
                .get_mut(*i)
                .ok_or_else(|| Error::protocol("missing group result slot"))?;
            slot.1 = listed;
        }
        Ok(false)
    }

    async fn fetch_consumer_group_offsets(
        &mut self,
        group_id: &str,
        partitions: Option<&[crate::TopicPartition]>,
        require_stable: bool,
        timeout: Duration,
    ) -> Result<Vec<crate::protocol::group::FetchedOffsetTopic>> {
        let started = Instant::now();
        if group_id.len() > crate::protocol::group::OffsetLimits::default().string_bytes {
            return Err(Error::protocol("offset group string exceeds limit"));
        }
        if self
            .versions
            .get(&OFFSET_FETCH)
            .is_some_and(|range| range.min_version <= 10 && range.max_version >= 10)
        {
            let target = started.checked_add(timeout).ok_or(Error::Timeout)?;
            let deadline = crate::net::Deadline::from_std(target);
            let topics = match partitions {
                Some(parts) => {
                    Some(crate::group::group_offset_fetch_topics_cooperative(parts).await)
                }
                None => None,
            };
            return self
                .fetch_named_offsets_v10(group_id, topics.as_deref(), require_stable, deadline)
                .await;
        }
        let topics = match partitions {
            Some(parts) => {
                Some(crate::group::group_borrowed_offset_fetch_topics_cooperative(parts).await)
            }
            None => None,
        };
        let client_min = if topics.is_none() { 2 } else { 1 };
        let _bootstrap_version = self
            .versions
            .get(&OFFSET_FETCH)
            .and_then(|v| pick_version(v.min_version, v.max_version, client_min, 9))
            .ok_or_else(|| {
                Error::Unsupported(if topics.is_none() {
                    "broker does not support OffsetFetch v2-9 (null Topics)".into()
                } else {
                    "broker does not support OffsetFetch v1-9".into()
                })
            })?;
        let deadline = started.checked_add(timeout).ok_or(Error::Timeout)?;
        let mut attempt = 0u32;
        loop {
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            let stale = self.group_coord.as_ref().is_none_or(|(g, _)| g != group_id);
            if stale {
                let node = self.discover_group_coord(group_id, deadline).await?;
                self.group_coord = Some((group_id.to_string(), node));
            }
            let node = self
                .group_coord
                .as_ref()
                .map(|(_, n)| *n)
                .ok_or_else(|| Error::protocol("missing group coordinator"))?;
            self.prepare_node_until(node, deadline).await?;
            let version = self.offset_version_on(node, OFFSET_FETCH, client_min, 9)?;
            let timeout = deadline.saturating_duration_since(Instant::now());
            if timeout.is_zero() {
                return Err(Error::Timeout);
            }
            let mut encoded = BytesMut::new();
            encode_offset_fetch_named_cooperative(
                &mut encoded,
                version,
                group_id,
                None,
                -1,
                require_stable,
                topics.as_deref(),
            )
            .await?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    OFFSET_FETCH,
                    version,
                    |buf| {
                        buf.extend_from_slice(&encoded);
                        Ok(())
                    },
                    timeout,
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.group_coord = None;
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            match decode_offset_fetch_response_cooperative(&mut body.clone(), version).await {
                Ok(t) => return Ok(t),
                Err(e) if e.broker_code().is_some_and(error::coordinator_retriable) => {
                    self.group_coord = None;
                    self.drop_node_conn(node).await;
                    self.wait_retry(&mut attempt, deadline).await?;
                }
                Err(e) => return Err(e),
            }
        }
    }

    /// Write committed offsets for `group_id` (Java `alterConsumerGroupOffsets`).
    ///
    /// OffsetCommit v2–v10 on the group coordinator with generation `-1` and an
    /// empty member id (admin, not a group member). Empty `offsets` is a
    /// no-op. Coordinator load / move errors refresh and retry.
    /// OffsetCommit has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::alter_consumer_group_offsets_timeout`].
    pub async fn alter_consumer_group_offsets(
        &mut self,
        group_id: &str,
        offsets: impl IntoIterator<Item = (impl Into<crate::TopicPartition>, crate::OffsetAndMetadata)>,
    ) -> Result<()> {
        let timeout = self.cfg.request_timeout;
        self.alter_consumer_group_offsets_timeout(group_id, offsets, timeout)
            .await
    }

    /// [`Self::alter_consumer_group_offsets`] with a one-shot RPC deadline
    /// (Java `AlterConsumerGroupOffsetsOptions.timeoutMs`).
    ///
    /// OffsetCommit has no TimeoutMs; `timeout` is the RPC deadline and
    /// the coordinator retry budget. v2–v4 RetentionTimeMs stays `-1`.
    pub async fn alter_consumer_group_offsets_timeout(
        &mut self,
        group_id: &str,
        offsets: impl IntoIterator<Item = (impl Into<crate::TopicPartition>, crate::OffsetAndMetadata)>,
        timeout: Duration,
    ) -> Result<()> {
        let started = Instant::now();
        if group_id.len() > crate::protocol::group::OffsetLimits::default().string_bytes {
            return Err(Error::protocol("offset group string exceeds limit"));
        }
        let offsets = crate::offsets::collect_bounded_commits(offsets)?;
        if offsets.is_empty() {
            return Ok(());
        }
        if self
            .versions
            .get(&OFFSET_COMMIT)
            .is_some_and(|range| range.min_version <= 10 && range.max_version >= 10)
        {
            let target = started.checked_add(timeout).ok_or(Error::Timeout)?;
            let deadline = crate::net::Deadline::from_std(target);
            return self
                .commit_named_offsets_v10(group_id, &offsets, deadline)
                .await;
        }
        let topics = crate::group::group_borrowed_offset_topics_cooperative(&offsets).await;
        let _bootstrap_version = self
            .versions
            .get(&OFFSET_COMMIT)
            .and_then(|v| pick_version(v.min_version, v.max_version, 2, 9))
            .ok_or_else(|| {
                Error::Unsupported("broker does not support OffsetCommit v2-9".into())
            })?;
        let deadline = started.checked_add(timeout).ok_or(Error::Timeout)?;
        let mut attempt = 0u32;
        loop {
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            let stale = self.group_coord.as_ref().is_none_or(|(g, _)| g != group_id);
            if stale {
                let node = self.discover_group_coord(group_id, deadline).await?;
                self.group_coord = Some((group_id.to_string(), node));
            }
            let node = self
                .group_coord
                .as_ref()
                .map(|(_, n)| *n)
                .ok_or_else(|| Error::protocol("missing group coordinator"))?;
            self.prepare_node_until(node, deadline).await?;
            let version = self.offset_version_on(node, OFFSET_COMMIT, 2, 9)?;
            let timeout = deadline.saturating_duration_since(Instant::now());
            if timeout.is_zero() {
                return Err(Error::Timeout);
            }
            let mut encoded = BytesMut::new();
            encode_offset_commit_named_cooperative(
                &mut encoded,
                version,
                group_id,
                -1,
                "",
                None,
                DEFAULT_RETENTION_TIME,
                &topics,
            )
            .await?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    OFFSET_COMMIT,
                    version,
                    |buf| {
                        buf.extend_from_slice(&encoded);
                        Ok(())
                    },
                    timeout,
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.group_coord = None;
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let err = decode_offset_commit_response_cooperative(&mut body.clone(), version).await?;
            if error::coordinator_retriable(err) {
                self.group_coord = None;
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                continue;
            }
            if err != 0 {
                return Err(Error::broker(err, "OffsetCommit"));
            }
            return Ok(());
        }
    }

    /// Describe KIP-848 consumer groups (ConsumerGroupDescribe api 69).
    ///
    /// Lands on the group coordinator (`FindCoordinator` `key_type=0`).
    /// Negotiates ConsumerGroupDescribe v0–v1 (Kafka 4.0 `validVersions`
    /// `0-1`; flexible from v0). Request layout is the same on both
    /// versions. v1 adds MemberType INT8 (KIP-1099; `-1` unknown, `0`
    /// classic, `1` consumer). v0 omits MemberType; decode fills `-1`.
    /// Official Apache JSON listeners are `broker` only; the official
    /// response lists `NOT_COORDINATOR` among supported errors. This is
    /// not a controller hop and not a partition-leader hop: there is no
    /// Metadata `controller_id` lookup, no `NOT_CONTROLLER` (41) retry,
    /// and no `NOT_LEADER_OR_FOLLOWER` (6) hop. `COORDINATOR_LOAD_IN_PROGRESS`
    /// / `COORDINATOR_NOT_AVAILABLE` / `NOT_COORDINATOR` (16) refresh the
    /// coordinator and retry. ErrorCode is per-group (bytes 5–6 on
    /// leftover-empty fixture group `"g"`), not top-level after throttle.
    /// FindCoordinator v4+ CoordinatorKeys array of N (KIP-699): one
    /// FindCoordinator per retry for uncached groups. ConsumerGroupDescribe
    /// is one RPC per coordinator, and those RPCs run together. Brokers that only speak FindCoordinator
    /// v1–v3 get one FindCoordinator per uncached group. Empty input is
    /// a no-op. ConsumerGroupDescribe has no TimeoutMs; the RPC deadline
    /// is [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::consumer_group_describe_timeout`].
    pub async fn consumer_group_describe(
        &mut self,
        group_ids: &[&str],
        include_authorized_operations: bool,
    ) -> Result<Vec<DescribedConsumerGroup>> {
        let timeout = self.cfg.request_timeout;
        self.consumer_group_describe_timeout(group_ids, include_authorized_operations, timeout)
            .await
    }

    /// [`Self::consumer_group_describe`] with a one-shot RPC deadline.
    ///
    /// ConsumerGroupDescribe has no TimeoutMs; `timeout` is the RPC
    /// deadline and the coordinator retry budget.
    /// Java `Admin.describeConsumerGroups` is
    /// [`Self::describe_consumer_groups_timeout`] (tries this RPC, then
    /// DescribeGroups). This overload is the crate-first KIP-848 describe.
    pub async fn consumer_group_describe_timeout(
        &mut self,
        group_ids: &[&str],
        include_authorized_operations: bool,
        timeout: Duration,
    ) -> Result<Vec<DescribedConsumerGroup>> {
        let ids = group_ids;
        if ids.is_empty() {
            return Ok(Vec::new());
        }
        let version = self.consumer_group_describe_version.ok_or_else(|| {
            Error::Unsupported("broker does not support ConsumerGroupDescribe v0-1".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut out: Vec<Option<DescribedConsumerGroup>> = open_result_slots(ids.len()).await;
        let mut pending = pending_indexes(ids.len()).await;
        loop {
            let by_node = self.group_coord_nodes(ids, &pending, deadline).await?;
            let mut nodes: Vec<i32> = by_node.keys().copied().collect();
            nodes.sort_unstable();
            let mut still = Vec::new();
            if nodes.len() > 1 {
                let mut prepared = HashMap::new();
                for node in &nodes {
                    let idxs = by_node.get(node).map(Vec::as_slice).unwrap_or(&[]);
                    let subset = borrowed_ids(ids, idxs);
                    let mut payload = BytesMut::new();
                    encode_consumer_group_describe_ids_cooperative(
                        &mut payload,
                        version,
                        &subset,
                        include_authorized_operations,
                    )
                    .await?;
                    let _previous = prepared.insert(*node, payload.freeze());
                }
                let mut finished = self
                    .exchange_leaders(&nodes, deadline, |_admin, node, _conn, _timeout| {
                        let payload = prepared.get(&node).cloned().ok_or_else(|| {
                            Error::protocol("missing consumer group describe request")
                        })?;
                        Ok(LeaderFrame::ready(
                            CONSUMER_GROUP_DESCRIBE,
                            version,
                            payload,
                        ))
                    })
                    .await;
                for node in &nodes {
                    let idxs = by_node.get(node).cloned().unwrap_or_default();
                    let Some((spoken, body)) = finished.remove(node) else {
                        self.invalidate_group_coord_idxs(ids, &idxs, *node).await;
                        still.extend(idxs);
                        continue;
                    };
                    match body {
                        Err(error) if error.is_retriable() => {
                            self.invalidate_group_coord_idxs(ids, &idxs, *node).await;
                            still.extend(idxs);
                        }
                        Err(error) => return Err(error),
                        Ok(body) => {
                            let done =
                                Self::apply_consumer_group_describe_body(spoken, ids, &idxs, body)
                                    .await?;
                            for (i, g) in done {
                                if error::coordinator_retriable(g.error_code) {
                                    self.invalidate_group_coord_idxs(ids, &[i], *node).await;
                                    still.push(i);
                                } else if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(g);
                                }
                            }
                        }
                    }
                }
            } else {
                for node in nodes {
                    let idxs = by_node.get(&node).cloned().unwrap_or_default();
                    match self
                        .consumer_group_describe_on_node(
                            node,
                            version,
                            ids,
                            &idxs,
                            include_authorized_operations,
                            deadline,
                        )
                        .await
                    {
                        Ok(done) => {
                            for (i, g) in done {
                                if error::coordinator_retriable(g.error_code) {
                                    self.invalidate_group_coord_idxs(ids, &[i], node).await;
                                    still.push(i);
                                } else if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(g);
                                }
                            }
                        }
                        Err(e) if e.is_retriable() => {
                            self.invalidate_group_coord_idxs(ids, &idxs, node).await;
                            still.extend(idxs);
                        }
                        Err(e) => return Err(e),
                    }
                }
            }
            pending = still;
            if pending.is_empty() {
                break;
            }
            self.wait_retry(&mut attempt, deadline).await?;
        }
        out.into_iter()
            .zip(ids)
            .map(|(g, id)| {
                g.ok_or_else(|| Error::protocol(format!("ConsumerGroupDescribe missing {id}")))
            })
            .collect()
    }

    /// Describe classic consumer groups (DescribeGroups api 15).
    ///
    /// Lands on the group coordinator (`FindCoordinator` `key_type=0`).
    /// Official Apache JSON listeners are `broker` only. Official
    /// listed per-group errors include `NOT_COORDINATOR` (16). This is
    /// not a controller hop and not a partition-leader hop: there is no
    /// Metadata `controller_id` lookup, no `NOT_CONTROLLER` (41) retry,
    /// and no `NOT_LEADER_OR_FOLLOWER` (6) hop. `COORDINATOR_LOAD_IN_PROGRESS`
    /// / `COORDINATOR_NOT_AVAILABLE` / `NOT_COORDINATOR` (16) refresh the
    /// coordinator and retry. ErrorCode is per-group (bytes 5–6 on
    /// leftover-empty fixture group `"g"` at v6), not top-level after throttle.
    /// Negotiates v0–v6 (v3 IncludeAuthorizedOperations; v4 GroupInstanceId;
    /// v5 flexible; v6 ErrorMessage / GROUP_ID_NOT_FOUND).
    /// Java `describeClassicGroups` is [`Self::describe_classic_groups`].
    /// Java `describeConsumerGroups` is [`Self::describe_consumer_groups`].
    /// FindCoordinator v4+ CoordinatorKeys array of N (KIP-699): one
    /// FindCoordinator per retry for uncached groups. DescribeGroups is
    /// one RPC per coordinator, and those RPCs run together. Brokers that only speak FindCoordinator
    /// v1–v3 get one FindCoordinator per uncached group. Empty input is
    /// a no-op. DescribeGroups has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::describe_groups_timeout`].
    pub async fn describe_groups(
        &mut self,
        group_ids: &[&str],
        include_authorized_operations: bool,
    ) -> Result<Vec<DescribedGroup>> {
        let timeout = self.cfg.request_timeout;
        self.describe_groups_timeout(group_ids, include_authorized_operations, timeout)
            .await
    }

    /// [`Self::describe_groups`] with a one-shot RPC deadline (Java
    /// `DescribeClassicGroupsOptions` / `DescribeConsumerGroupsOptions.timeoutMs`).
    ///
    /// DescribeGroups has no TimeoutMs; `timeout` is the RPC deadline
    /// and the coordinator retry budget.
    pub async fn describe_groups_timeout(
        &mut self,
        group_ids: &[&str],
        include_authorized_operations: bool,
        timeout: Duration,
    ) -> Result<Vec<DescribedGroup>> {
        let ids = group_ids;
        if ids.is_empty() {
            return Ok(Vec::new());
        }
        let version = self.describe_groups_version.ok_or_else(|| {
            Error::Unsupported("broker does not support DescribeGroups v0-6".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut out: Vec<Option<DescribedGroup>> = open_result_slots(ids.len()).await;
        let mut pending = pending_indexes(ids.len()).await;
        loop {
            let by_node = self.group_coord_nodes(ids, &pending, deadline).await?;
            let mut nodes: Vec<i32> = by_node.keys().copied().collect();
            nodes.sort_unstable();
            let mut still = Vec::new();
            if nodes.len() > 1 {
                let mut prepared = HashMap::new();
                for node in &nodes {
                    let idxs = by_node.get(node).map(Vec::as_slice).unwrap_or(&[]);
                    let subset = borrowed_ids(ids, idxs);
                    let mut payload = BytesMut::new();
                    encode_describe_groups_ids_cooperative(
                        &mut payload,
                        version,
                        &subset,
                        include_authorized_operations,
                    )
                    .await?;
                    let _previous = prepared.insert(*node, payload.freeze());
                }
                let mut finished = self
                    .exchange_leaders(&nodes, deadline, |_admin, node, _conn, _timeout| {
                        let payload = prepared
                            .get(&node)
                            .cloned()
                            .ok_or_else(|| Error::protocol("missing describe groups request"))?;
                        Ok(LeaderFrame::ready(DESCRIBE_GROUPS, version, payload))
                    })
                    .await;
                for node in &nodes {
                    let idxs = by_node.get(node).cloned().unwrap_or_default();
                    let Some((spoken, body)) = finished.remove(node) else {
                        self.invalidate_group_coord_idxs(ids, &idxs, *node).await;
                        still.extend(idxs);
                        continue;
                    };
                    match body {
                        Err(error) if error.is_retriable() => {
                            self.invalidate_group_coord_idxs(ids, &idxs, *node).await;
                            still.extend(idxs);
                        }
                        Err(error) => return Err(error),
                        Ok(body) => {
                            let done =
                                Self::apply_describe_groups_body(spoken, ids, &idxs, body).await?;
                            for (i, g) in done {
                                if error::coordinator_retriable(g.error_code) {
                                    self.invalidate_group_coord_idxs(ids, &[i], *node).await;
                                    still.push(i);
                                } else if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(g);
                                }
                            }
                        }
                    }
                }
            } else {
                for node in nodes {
                    let idxs = by_node.get(&node).cloned().unwrap_or_default();
                    match self
                        .describe_groups_on_node(
                            node,
                            version,
                            ids,
                            &idxs,
                            include_authorized_operations,
                            deadline,
                        )
                        .await
                    {
                        Ok(done) => {
                            for (i, g) in done {
                                if error::coordinator_retriable(g.error_code) {
                                    self.invalidate_group_coord_idxs(ids, &[i], node).await;
                                    still.push(i);
                                } else if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(g);
                                }
                            }
                        }
                        Err(e) if e.is_retriable() => {
                            self.invalidate_group_coord_idxs(ids, &idxs, node).await;
                            still.extend(idxs);
                        }
                        Err(e) => return Err(e),
                    }
                }
            }
            pending = still;
            if pending.is_empty() {
                break;
            }
            self.wait_retry(&mut attempt, deadline).await?;
        }
        out.into_iter()
            .zip(ids)
            .map(|(g, id)| g.ok_or_else(|| Error::protocol(format!("DescribeGroups missing {id}"))))
            .collect()
    }

    /// Describe classic groups (Java `Admin.describeClassicGroups`).
    ///
    /// Same wire as [`Self::describe_groups`]: DescribeGroups api 15 on
    /// the group coordinator. Java's `DescribeClassicGroupsHandler`
    /// builds a DescribeGroups request. Empty input is a no-op.
    /// DescribeGroups has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::describe_classic_groups_timeout`].
    pub async fn describe_classic_groups(
        &mut self,
        group_ids: &[&str],
        include_authorized_operations: bool,
    ) -> Result<Vec<DescribedGroup>> {
        let timeout = self.cfg.request_timeout;
        self.describe_classic_groups_timeout(group_ids, include_authorized_operations, timeout)
            .await
    }

    /// [`Self::describe_classic_groups`] with a one-shot RPC deadline (Java
    /// `DescribeClassicGroupsOptions.timeoutMs`).
    ///
    /// DescribeGroups has no TimeoutMs; `timeout` is the RPC deadline
    /// and the coordinator retry budget.
    pub async fn describe_classic_groups_timeout(
        &mut self,
        group_ids: &[&str],
        include_authorized_operations: bool,
        timeout: Duration,
    ) -> Result<Vec<DescribedGroup>> {
        self.describe_groups_timeout(group_ids, include_authorized_operations, timeout)
            .await
    }

    /// Describe consumer groups (Java `Admin.describeConsumerGroups`).
    ///
    /// Kafka 4.0 `DescribeConsumerGroupsHandler` sends ConsumerGroupDescribe
    /// (api 69) on the group coordinator first. Per-group
    /// [`crate::error::UNSUPPORTED_VERSION`] (35) or
    /// [`crate::error::GROUP_ID_NOT_FOUND`] (69) retries that group with
    /// DescribeGroups (api 15). A broker that does not advertise api 69, or
    /// an RPC-level [`Error::Unsupported`] for that API, uses DescribeGroups
    /// for every group. Coordinator errors still refresh FindCoordinator
    /// and retry. Empty input is a no-op. Neither RPC has TimeoutMs; the
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// deadline, use [`Self::describe_consumer_groups_timeout`].
    pub async fn describe_consumer_groups(
        &mut self,
        group_ids: &[&str],
        include_authorized_operations: bool,
    ) -> Result<Vec<ConsumerGroupDescription>> {
        let timeout = self.cfg.request_timeout;
        self.describe_consumer_groups_timeout(group_ids, include_authorized_operations, timeout)
            .await
    }

    /// [`Self::describe_consumer_groups`] with a one-shot RPC deadline (Java
    /// `DescribeConsumerGroupsOptions.timeoutMs`).
    ///
    /// Neither ConsumerGroupDescribe nor DescribeGroups has TimeoutMs;
    /// `timeout` is the RPC deadline and the coordinator retry budget
    /// across both hops.
    pub async fn describe_consumer_groups_timeout(
        &mut self,
        group_ids: &[&str],
        include_authorized_operations: bool,
        timeout: Duration,
    ) -> Result<Vec<ConsumerGroupDescription>> {
        if group_ids.is_empty() {
            return Ok(Vec::new());
        }
        let deadline = Instant::now() + timeout;
        let mut out: Vec<Option<ConsumerGroupDescription>> =
            open_result_slots(group_ids.len()).await;
        let mut classic_pending: Vec<usize> = Vec::new();
        if self.consumer_group_describe_version.is_some() {
            match self
                .consumer_group_describe_timeout(group_ids, include_authorized_operations, timeout)
                .await
            {
                Ok(groups) => {
                    for (i, g) in groups.into_iter().enumerate() {
                        if error::consumer_group_describe_classic_fallback(g.error_code) {
                            classic_pending.push(i);
                        } else if let Some(slot) = out.get_mut(i) {
                            *slot = Some(ConsumerGroupDescription::Consumer(g));
                        }
                    }
                }
                Err(Error::Unsupported(_)) => {
                    classic_pending.extend(0..group_ids.len());
                }
                Err(e) => return Err(e),
            }
        } else {
            classic_pending.extend(0..group_ids.len());
        }
        if !classic_pending.is_empty() {
            let classic_ids: Vec<&str> = classic_pending
                .iter()
                .filter_map(|&i| group_ids.get(i).copied())
                .collect();
            let remaining = deadline.saturating_duration_since(Instant::now());
            let classic = self
                .describe_groups_timeout(&classic_ids, include_authorized_operations, remaining)
                .await?;
            for (i, g) in classic_pending.iter().copied().zip(classic) {
                if let Some(slot) = out.get_mut(i) {
                    *slot = Some(ConsumerGroupDescription::Classic(g));
                }
            }
        }
        out.into_iter()
            .enumerate()
            .map(|(i, g)| {
                g.ok_or_else(|| {
                    let id = group_ids.get(i).copied().unwrap_or("");
                    Error::protocol(format!("describeConsumerGroups missing {id}"))
                })
            })
            .collect()
    }

    /// List consumer groups (ListGroups api 16).
    ///
    /// Lands on the connected broker (bootstrap is fine). Official Apache
    /// JSON listeners are `broker` only. Official listed errors are
    /// `COORDINATOR_LOAD_IN_PROGRESS` (14), `COORDINATOR_NOT_AVAILABLE`
    /// (15), `AUTHORIZATION_FAILED` (29). `NOT_COORDINATOR` (16) is not
    /// listed. This is not a group-coordinator hop, not a controller hop,
    /// and not a partition-leader hop: there is no FindCoordinator,
    /// no Metadata `controller_id` lookup, no `NOT_CONTROLLER` (41)
    /// retry, and no `NOT_LEADER_OR_FOLLOWER` (6) hop. Top-level
    /// `error_code` is the INT16 at bytes 4–5 on v1+ (after throttle) — not a
    /// first-group field. Negotiates v0–v5 (v3 flexible; v4 StatesFilter /
    /// GroupState; v5 TypesFilter / GroupType). Java `listConsumerGroups` is
    /// [`Self::list_consumer_groups`]. ListGroups has no TimeoutMs; the
    /// RPC deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// deadline, use [`Self::list_groups_timeout`].
    pub async fn list_groups(
        &mut self,
        states_filter: &[&str],
        types_filter: &[&str],
    ) -> Result<Vec<ListedGroup>> {
        let timeout = self.cfg.request_timeout;
        self.list_groups_timeout(states_filter, types_filter, timeout)
            .await
    }

    /// [`Self::list_groups`] with a one-shot RPC deadline (Java
    /// `ListGroupsOptions.timeoutMs`).
    ///
    /// ListGroups has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn list_groups_timeout(
        &mut self,
        states_filter: &[&str],
        types_filter: &[&str],
        timeout: Duration,
    ) -> Result<Vec<ListedGroup>> {
        self.list_groups_filters(states_filter, types_filter, timeout)
            .await
    }

    async fn list_groups_filters<S: AsRef<str> + Sync, T: AsRef<str> + Sync>(
        &mut self,
        states: &[S],
        types: &[T],
        timeout: Duration,
    ) -> Result<Vec<ListedGroup>> {
        let version = self
            .list_groups_version
            .ok_or_else(|| Error::Unsupported("broker does not support ListGroups v0-5".into()))?;
        let mut payload = BytesMut::new();
        encode_list_groups_filters_cooperative(&mut payload, version, states, types).await?;
        let body = self
            .roundtrip_bootstrap(
                LIST_GROUPS,
                version,
                |buf| {
                    buf.extend_from_slice(&payload);
                    Ok(())
                },
                timeout,
            )
            .await?;
        let (resp, ..) =
            decode_list_groups_response_cooperative(&mut body.clone(), version).await?;
        if resp.error_code != 0 {
            return Err(Error::broker(resp.error_code, "ListGroups"));
        }
        Ok(resp.groups)
    }

    /// [`Self::list_groups`] with Java `GroupState` / `GroupType`
    /// (`ListGroupsOptions.inGroupStates` / `withTypes`).
    ///
    /// TypesFilter strings are Java `GroupType.toString` (`Classic`, not
    /// `classic`). ListGroups has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::list_groups_with_timeout`].
    pub async fn list_groups_with(
        &mut self,
        states: impl IntoIterator<Item = GroupState>,
        types: impl IntoIterator<Item = GroupType>,
    ) -> Result<Vec<ListedGroup>> {
        let timeout = self.cfg.request_timeout;
        self.list_groups_with_timeout(states, types, timeout).await
    }

    /// [`Self::list_groups_with`] with a one-shot RPC deadline (Java
    /// `ListGroupsOptions.timeoutMs`).
    ///
    /// ListGroups has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn list_groups_with_timeout(
        &mut self,
        states: impl IntoIterator<Item = GroupState>,
        types: impl IntoIterator<Item = GroupType>,
        timeout: Duration,
    ) -> Result<Vec<ListedGroup>> {
        let states: Vec<&str> = states.into_iter().map(GroupState::as_str).collect();
        let types: Vec<&str> = types.into_iter().map(GroupType::as_str).collect();
        self.list_groups_filters(&states, &types, timeout).await
    }

    /// List every group (Java `Admin.listGroups()`).
    ///
    /// Same wire as [`Self::list_groups`] with empty StatesFilter and
    /// TypesFilter (Java `ListGroupsOptions` default).
    pub async fn list_groups_all(&mut self) -> Result<Vec<ListedGroup>> {
        self.list_groups(&[], &[]).await
    }

    /// [`Self::list_groups_all`] with a one-shot RPC deadline (Java
    /// `ListGroupsOptions.timeoutMs`).
    pub async fn list_groups_all_timeout(&mut self, timeout: Duration) -> Result<Vec<ListedGroup>> {
        self.list_groups_timeout(&[], &[], timeout).await
    }

    /// List consumer groups (Java `Admin.listConsumerGroups`).
    ///
    /// Same wire as [`Self::list_groups`]: ListGroups api 16 on the
    /// connected broker. Java's `ListConsumerGroupsHandler` builds a
    /// ListGroups request. ListGroups has no TimeoutMs; the RPC
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// deadline, use [`Self::list_consumer_groups_timeout`].
    pub async fn list_consumer_groups(
        &mut self,
        states_filter: &[&str],
        types_filter: &[&str],
    ) -> Result<Vec<ListedGroup>> {
        self.list_groups(states_filter, types_filter).await
    }

    /// [`Self::list_consumer_groups`] with a one-shot RPC deadline (Java
    /// `ListConsumerGroupsOptions.timeoutMs`).
    ///
    /// ListGroups has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn list_consumer_groups_timeout(
        &mut self,
        states_filter: &[&str],
        types_filter: &[&str],
        timeout: Duration,
    ) -> Result<Vec<ListedGroup>> {
        self.list_groups_timeout(states_filter, types_filter, timeout)
            .await
    }

    /// [`Self::list_consumer_groups`] with Java `GroupState` / `GroupType`
    /// (`ListConsumerGroupsOptions.inGroupStates` / `withTypes`).
    ///
    /// Same wire as [`Self::list_groups_with`].
    pub async fn list_consumer_groups_with(
        &mut self,
        states: impl IntoIterator<Item = GroupState>,
        types: impl IntoIterator<Item = GroupType>,
    ) -> Result<Vec<ListedGroup>> {
        self.list_groups_with(states, types).await
    }

    /// [`Self::list_consumer_groups_with`] with a one-shot RPC deadline
    /// (Java `ListConsumerGroupsOptions.timeoutMs`).
    pub async fn list_consumer_groups_with_timeout(
        &mut self,
        states: impl IntoIterator<Item = GroupState>,
        types: impl IntoIterator<Item = GroupType>,
        timeout: Duration,
    ) -> Result<Vec<ListedGroup>> {
        self.list_groups_with_timeout(states, types, timeout).await
    }

    /// List every consumer group (Java `Admin.listConsumerGroups()`).
    ///
    /// Same wire as [`Self::list_consumer_groups`] with empty StatesFilter
    /// and TypesFilter (Java `ListConsumerGroupsOptions` default).
    pub async fn list_consumer_groups_all(&mut self) -> Result<Vec<ListedGroup>> {
        self.list_groups_all().await
    }

    /// [`Self::list_consumer_groups_all`] with a one-shot RPC deadline
    /// (Java `ListConsumerGroupsOptions.timeoutMs`).
    pub async fn list_consumer_groups_all_timeout(
        &mut self,
        timeout: Duration,
    ) -> Result<Vec<ListedGroup>> {
        self.list_groups_all_timeout(timeout).await
    }

    /// Delete consumer groups (DeleteGroups api 42).
    ///
    /// Lands on the group coordinator (`FindCoordinator` `key_type=0`).
    /// Negotiates DeleteGroups v0–v2 (Kafka 4.0 `validVersions` `0-2`).
    /// v0–v1 are classic; v2 is the first flexible version. Response
    /// ThrottleTimeMs is present on every spoken version. Official Apache
    /// JSON listeners are `broker` only. Official listed per-group errors
    /// include `NOT_COORDINATOR` (16). This is not a controller hop and
    /// not a partition-leader hop: there is no Metadata `controller_id`
    /// lookup, no `NOT_CONTROLLER` (41) retry, and no
    /// `NOT_LEADER_OR_FOLLOWER` (6) hop. `COORDINATOR_LOAD_IN_PROGRESS` /
    /// `COORDINATOR_NOT_AVAILABLE` / `NOT_COORDINATOR` (16) refresh the
    /// coordinator and retry. ErrorCode is per-group after GroupId
    /// (bytes 7–8 on leftover-empty fixture group `"g"` on v2; classic
    /// v0–v1 place that ErrorCode later). Java `deleteShareGroups` is
    /// [`Self::delete_share_groups`]. Java `deleteConsumerGroups` is
    /// [`Self::delete_consumer_groups`]. FindCoordinator v4+
    /// CoordinatorKeys array of N (KIP-699): one FindCoordinator per
    /// retry for uncached groups. DeleteGroups is one RPC per
    /// coordinator, and those RPCs run together. Brokers that only speak FindCoordinator v1–v3 get
    /// one FindCoordinator per uncached group. Empty input is a no-op.
    /// DeleteGroups has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::delete_groups_timeout`].
    pub async fn delete_groups(&mut self, group_ids: &[&str]) -> Result<Vec<DeletableGroupResult>> {
        let timeout = self.cfg.request_timeout;
        self.delete_groups_timeout(group_ids, timeout).await
    }

    /// [`Self::delete_groups`] with a one-shot RPC deadline (Java
    /// `DeleteConsumerGroupsOptions` / `DeleteShareGroupsOptions.timeoutMs`).
    ///
    /// DeleteGroups has no TimeoutMs; `timeout` is the RPC deadline and
    /// the coordinator retry budget.
    pub async fn delete_groups_timeout(
        &mut self,
        group_ids: &[&str],
        timeout: Duration,
    ) -> Result<Vec<DeletableGroupResult>> {
        self.delete_group_ids(group_ids, timeout).await
    }

    async fn delete_group_ids<T: AsRef<str>>(
        &mut self,
        ids: &[T],
        timeout: Duration,
    ) -> Result<Vec<DeletableGroupResult>> {
        if ids.is_empty() {
            return Ok(Vec::new());
        }
        let version = self.delete_groups_version.ok_or_else(|| {
            Error::Unsupported("broker does not support DeleteGroups v0-2".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut out: Vec<Option<DeletableGroupResult>> = open_result_slots(ids.len()).await;
        let mut pending = pending_indexes(ids.len()).await;
        loop {
            let by_node = self.group_coord_nodes(ids, &pending, deadline).await?;
            let mut nodes: Vec<i32> = by_node.keys().copied().collect();
            nodes.sort_unstable();
            let mut still = Vec::new();
            if nodes.len() > 1 {
                let mut prepared = HashMap::new();
                for node in &nodes {
                    let idxs = by_node.get(node).map(Vec::as_slice).unwrap_or(&[]);
                    let subset = borrowed_ids(ids, idxs);
                    let mut payload = BytesMut::new();
                    encode_delete_groups_ids_cooperative(&mut payload, version, &subset).await?;
                    let _previous = prepared.insert(*node, payload.freeze());
                }
                let mut finished = self
                    .exchange_leaders(&nodes, deadline, |_admin, node, _conn, _timeout| {
                        let payload = prepared
                            .get(&node)
                            .cloned()
                            .ok_or_else(|| Error::protocol("missing delete groups request"))?;
                        Ok(LeaderFrame::ready(DELETE_GROUPS, version, payload))
                    })
                    .await;
                for node in &nodes {
                    let idxs = by_node.get(node).cloned().unwrap_or_default();
                    let Some((spoken, body)) = finished.remove(node) else {
                        self.invalidate_group_coord_idxs(ids, &idxs, *node).await;
                        still.extend(idxs);
                        continue;
                    };
                    match body {
                        Err(error) if error.is_retriable() => {
                            self.invalidate_group_coord_idxs(ids, &idxs, *node).await;
                            still.extend(idxs);
                        }
                        Err(error) => return Err(error),
                        Ok(body) => {
                            let done =
                                Self::apply_delete_groups_body(spoken, ids, &idxs, body).await?;
                            for (i, g) in done {
                                if error::coordinator_retriable(g.error_code) {
                                    self.invalidate_group_coord_idxs(ids, &[i], *node).await;
                                    still.push(i);
                                } else if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(g);
                                }
                            }
                        }
                    }
                }
            } else {
                for node in nodes {
                    let idxs = by_node.get(&node).cloned().unwrap_or_default();
                    match self
                        .delete_groups_on_node(node, version, ids, &idxs, deadline)
                        .await
                    {
                        Ok(done) => {
                            for (i, g) in done {
                                if error::coordinator_retriable(g.error_code) {
                                    self.invalidate_group_coord_idxs(ids, &[i], node).await;
                                    still.push(i);
                                } else if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(g);
                                }
                            }
                        }
                        Err(e) if e.is_retriable() => {
                            self.invalidate_group_coord_idxs(ids, &idxs, node).await;
                            still.extend(idxs);
                        }
                        Err(e) => return Err(e),
                    }
                }
            }
            pending = still;
            if pending.is_empty() {
                break;
            }
            self.wait_retry(&mut attempt, deadline).await?;
        }
        out.into_iter()
            .zip(ids)
            .map(|(g, id)| {
                g.ok_or_else(|| Error::protocol(format!("DeleteGroups missing {}", id.as_ref())))
            })
            .collect()
    }

    /// Delete share groups (Java `Admin.deleteShareGroups`).
    ///
    /// Same wire as [`Self::delete_groups`]: DeleteGroups api 42 on the
    /// group coordinator (`FindCoordinator` `key_type=0`). Java's
    /// `DeleteShareGroupsHandler` extends `DeleteGroupsHandler`. Empty
    /// input is a no-op. DeleteGroups has no TimeoutMs; the RPC deadline
    /// is [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::delete_share_groups_timeout`].
    pub async fn delete_share_groups<'a, S>(
        &mut self,
        group_ids: impl IntoIterator<Item = &'a S>,
    ) -> Result<Vec<DeletableGroupResult>>
    where
        S: AsRef<str> + ?Sized + 'a,
    {
        let timeout = self.cfg.request_timeout;
        self.delete_share_groups_timeout(group_ids, timeout).await
    }

    /// [`Self::delete_share_groups`] with a one-shot RPC deadline (Java
    /// `DeleteShareGroupsOptions.timeoutMs`).
    ///
    /// DeleteGroups has no TimeoutMs; `timeout` is the RPC deadline and
    /// the coordinator retry budget.
    pub async fn delete_share_groups_timeout<'a, S>(
        &mut self,
        group_ids: impl IntoIterator<Item = &'a S>,
        timeout: Duration,
    ) -> Result<Vec<DeletableGroupResult>>
    where
        S: AsRef<str> + ?Sized + 'a,
    {
        let ids: Vec<&str> = group_ids.into_iter().map(AsRef::as_ref).collect();
        self.delete_group_ids(&ids, timeout).await
    }

    /// Delete consumer groups (Java `Admin.deleteConsumerGroups`).
    ///
    /// Same wire as [`Self::delete_groups`]: DeleteGroups api 42 on the
    /// group coordinator (`FindCoordinator` `key_type=0`). Java's
    /// `DeleteConsumerGroupsHandler` sends DeleteGroups. Empty
    /// input is a no-op. DeleteGroups has no TimeoutMs; the RPC deadline
    /// is [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::delete_consumer_groups_timeout`].
    pub async fn delete_consumer_groups<'a, S>(
        &mut self,
        group_ids: impl IntoIterator<Item = &'a S>,
    ) -> Result<Vec<DeletableGroupResult>>
    where
        S: AsRef<str> + ?Sized + 'a,
    {
        let timeout = self.cfg.request_timeout;
        self.delete_consumer_groups_timeout(group_ids, timeout)
            .await
    }

    /// [`Self::delete_consumer_groups`] with a one-shot RPC deadline (Java
    /// `DeleteConsumerGroupsOptions.timeoutMs`).
    ///
    /// DeleteGroups has no TimeoutMs; `timeout` is the RPC deadline and
    /// the coordinator retry budget.
    pub async fn delete_consumer_groups_timeout<'a, S>(
        &mut self,
        group_ids: impl IntoIterator<Item = &'a S>,
        timeout: Duration,
    ) -> Result<Vec<DeletableGroupResult>>
    where
        S: AsRef<str> + ?Sized + 'a,
    {
        let ids: Vec<&str> = group_ids.into_iter().map(AsRef::as_ref).collect();
        self.delete_group_ids(&ids, timeout).await
    }

    /// Remove static members from a consumer group (Java
    /// `removeMembersFromConsumerGroup`).
    ///
    /// LeaveGroup v3 (classic), v4 (flexible), or v5 (KIP-800 Reason)
    /// on the group coordinator (`FindCoordinator` `key_type=0`) with a
    /// members array. Each [`MemberToRemove`] is a `group.instance.id`
    /// (KIP-345); member id on the wire is empty. v5 sends
    /// [`DEFAULT_LEAVE_GROUP_REASON`]. Empty `members` returns an empty
    /// list. Coordinator load / move errors refresh and retry. To remove
    /// every member, use [`Self::remove_all_members_from_consumer_group`].
    /// For a custom LeaveGroup v5 Reason, use
    /// [`Self::remove_members_from_consumer_group_with_reason`].
    /// LeaveGroup has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::remove_members_from_consumer_group_timeout`].
    pub async fn remove_members_from_consumer_group(
        &mut self,
        group_id: &str,
        members: impl IntoIterator<Item = impl Into<MemberToRemove>>,
    ) -> Result<Vec<RemovedMember>> {
        let timeout = self.cfg.request_timeout;
        self.remove_members_from_consumer_group_timeout(group_id, members, timeout)
            .await
    }

    /// [`Self::remove_members_from_consumer_group`] with a one-shot RPC
    /// deadline (Java `RemoveMembersFromConsumerGroupOptions.timeoutMs`).
    ///
    /// LeaveGroup has no TimeoutMs; `timeout` is the RPC deadline and the
    /// coordinator retry budget.
    pub async fn remove_members_from_consumer_group_timeout(
        &mut self,
        group_id: &str,
        members: impl IntoIterator<Item = impl Into<MemberToRemove>>,
        timeout: Duration,
    ) -> Result<Vec<RemovedMember>> {
        self.remove_members_from_consumer_group_timeout_with_reason(group_id, members, timeout, "")
            .await
    }

    /// [`Self::remove_members_from_consumer_group`] with Java
    /// `RemoveMembersFromConsumerGroupOptions.reason`.
    ///
    /// LeaveGroup v5 sends `reason` (KIP-800). Empty reason uses
    /// [`DEFAULT_LEAVE_GROUP_REASON`]. The string is truncated to 255
    /// characters. Kafka 4.0 `KafkaAdminClient` does not wire this
    /// Options field; later Java and this crate do. For a one-shot
    /// deadline, use
    /// [`Self::remove_members_from_consumer_group_timeout_with_reason`].
    pub async fn remove_members_from_consumer_group_with_reason(
        &mut self,
        group_id: &str,
        members: impl IntoIterator<Item = impl Into<MemberToRemove>>,
        reason: impl Into<String>,
    ) -> Result<Vec<RemovedMember>> {
        let timeout = self.cfg.request_timeout;
        self.remove_members_from_consumer_group_timeout_with_reason(
            group_id, members, timeout, reason,
        )
        .await
    }

    /// [`Self::remove_members_from_consumer_group_with_reason`] with a
    /// one-shot RPC deadline (Java
    /// `RemoveMembersFromConsumerGroupOptions.timeoutMs` plus `reason`).
    ///
    /// LeaveGroup has no TimeoutMs; `timeout` is the RPC deadline and the
    /// coordinator retry budget. Duration is before `reason`.
    pub async fn remove_members_from_consumer_group_timeout_with_reason(
        &mut self,
        group_id: &str,
        members: impl IntoIterator<Item = impl Into<MemberToRemove>>,
        timeout: Duration,
        reason: impl Into<String>,
    ) -> Result<Vec<RemovedMember>> {
        let reason = reason.into();
        let members: Vec<LeaveGroupMember> = members
            .into_iter()
            .map(|m| {
                let m = m.into();
                LeaveGroupMember {
                    member_id: String::new(),
                    group_instance_id: Some(m.group_instance_id),
                    reason: Some(reason.clone()),
                }
            })
            .collect();
        if members.is_empty() {
            return Ok(Vec::new());
        }
        self.leave_group_members(group_id, members, timeout).await
    }

    /// Remove every member of a consumer group (Java
    /// `RemoveMembersFromConsumerGroupOptions.removeAll`).
    ///
    /// DescribeGroups, then LeaveGroup v3–v5 with those members (member
    /// id plus `group.instance.id` when present). v5 sends
    /// [`DEFAULT_LEAVE_GROUP_REASON`]. A group with no members is a
    /// no-op (no LeaveGroup). This is not
    /// [`Self::remove_members_from_consumer_group`] with an empty list.
    /// For a custom LeaveGroup v5 Reason, use
    /// [`Self::remove_all_members_from_consumer_group_with_reason`].
    /// DescribeGroups and LeaveGroup have no TimeoutMs; the RPC deadline
    /// is [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::remove_all_members_from_consumer_group_timeout`].
    pub async fn remove_all_members_from_consumer_group(
        &mut self,
        group_id: &str,
    ) -> Result<Vec<RemovedMember>> {
        let timeout = self.cfg.request_timeout;
        self.remove_all_members_from_consumer_group_timeout(group_id, timeout)
            .await
    }

    /// [`Self::remove_all_members_from_consumer_group`] with a one-shot RPC
    /// deadline (Java `RemoveMembersFromConsumerGroupOptions.timeoutMs`
    /// plus `removeAll`).
    ///
    /// DescribeGroups and LeaveGroup have no TimeoutMs; `timeout` is the
    /// RPC deadline and the coordinator retry budget for both hops.
    pub async fn remove_all_members_from_consumer_group_timeout(
        &mut self,
        group_id: &str,
        timeout: Duration,
    ) -> Result<Vec<RemovedMember>> {
        self.remove_all_members_from_consumer_group_timeout_with_reason(group_id, timeout, "")
            .await
    }

    /// [`Self::remove_all_members_from_consumer_group`] with Java
    /// `RemoveMembersFromConsumerGroupOptions.reason` plus `removeAll`.
    ///
    /// LeaveGroup v5 sends `reason` (KIP-800). Empty reason uses
    /// [`DEFAULT_LEAVE_GROUP_REASON`]. The string is truncated to 255
    /// characters. Kafka 4.0 `KafkaAdminClient` does not wire this
    /// Options field; later Java and this crate do. For a one-shot
    /// deadline, use
    /// [`Self::remove_all_members_from_consumer_group_timeout_with_reason`].
    pub async fn remove_all_members_from_consumer_group_with_reason(
        &mut self,
        group_id: &str,
        reason: impl Into<String>,
    ) -> Result<Vec<RemovedMember>> {
        let timeout = self.cfg.request_timeout;
        self.remove_all_members_from_consumer_group_timeout_with_reason(group_id, timeout, reason)
            .await
    }

    /// [`Self::remove_all_members_from_consumer_group_with_reason`] with a
    /// one-shot RPC deadline (Java
    /// `RemoveMembersFromConsumerGroupOptions.timeoutMs` plus `removeAll`
    /// and `reason`).
    ///
    /// DescribeGroups and LeaveGroup have no TimeoutMs; `timeout` is the
    /// RPC deadline and the coordinator retry budget for both hops.
    /// Duration is before `reason`.
    pub async fn remove_all_members_from_consumer_group_timeout_with_reason(
        &mut self,
        group_id: &str,
        timeout: Duration,
        reason: impl Into<String>,
    ) -> Result<Vec<RemovedMember>> {
        let described = self
            .describe_groups_timeout(&[group_id], false, timeout)
            .await?;
        let Some(g) = described.first() else {
            return Ok(Vec::new());
        };
        if g.error_code != 0 {
            return Err(Error::broker(g.error_code, "DescribeGroups"));
        }
        let reason = reason.into();
        let members: Vec<LeaveGroupMember> = g
            .members
            .iter()
            .map(|m| LeaveGroupMember {
                member_id: m.member_id.clone(),
                group_instance_id: m.group_instance_id.clone(),
                reason: Some(reason.clone()),
            })
            .collect();
        if members.is_empty() {
            return Ok(Vec::new());
        }
        self.leave_group_members(group_id, members, timeout).await
    }

    async fn leave_group_members(
        &mut self,
        group_id: &str,
        members: Vec<LeaveGroupMember>,
        timeout: Duration,
    ) -> Result<Vec<RemovedMember>> {
        let version = self
            .versions
            .get(&LEAVE_GROUP)
            .and_then(|v| pick_version(v.min_version, v.max_version, 3, 5))
            .ok_or_else(|| Error::Unsupported("broker does not support LeaveGroup v3+".into()))?;
        let members: Vec<LeaveGroupMember> = members
            .into_iter()
            .map(|mut m| {
                m.reason = Some(admin_leave_reason(m.reason.as_deref()));
                m
            })
            .collect();
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut encoded = BytesMut::new();
        encode_leave_group_request_members_cooperative(&mut encoded, version, group_id, &members)
            .await?;
        loop {
            let stale = self.group_coord.as_ref().is_none_or(|(g, _)| g != group_id);
            if stale {
                let node = self.discover_group_coord(group_id, deadline).await?;
                self.group_coord = Some((group_id.to_string(), node));
            }
            let node = self
                .group_coord
                .as_ref()
                .map(|(_, n)| *n)
                .ok_or_else(|| Error::protocol("missing group coordinator"))?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    LEAVE_GROUP,
                    version,
                    |buf| {
                        buf.extend_from_slice(&encoded);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.group_coord = None;
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let (err, results, ..) =
                decode_leave_group_response_version_cooperative(&mut body.clone(), version).await?;
            if error::coordinator_retriable(err) {
                self.group_coord = None;
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                continue;
            }
            if err != 0 {
                return Err(Error::broker(err, "LeaveGroup"));
            }
            return Ok(results
                .into_iter()
                .map(|m| RemovedMember {
                    member_id: m.member_id,
                    group_instance_id: m.group_instance_id,
                    error_code: m.error_code,
                })
                .collect());
        }
    }

    /// Describe KIP-932 share groups (ShareGroupDescribe api 77).
    ///
    /// Lands on the group coordinator (`FindCoordinator` `key_type=0`).
    /// Negotiates ShareGroupDescribe v0–v1. Kafka 4.0 `validVersions` is
    /// `"0"` (`latestVersionUnstable`). Kafka 4.1 `validVersions` is
    /// `"1"` (v0 removed). Request and response fields are identical.
    /// This crate speaks 0–1. Official Apache JSON listeners are
    /// `broker` only. Official listed errors include `NOT_COORDINATOR`
    /// (16). Official Java `DescribeShareGroupsHandler` uses
    /// `CoordinatorType.GROUP`. This is not a controller hop and not a
    /// partition-leader hop: there is no Metadata `controller_id`
    /// lookup, no `NOT_CONTROLLER` (41) retry, and no
    /// `NOT_LEADER_OR_FOLLOWER` (6) hop. SHARE (`key_type=2`) is the
    /// FindCoordinator v6 share-state key
    /// (`groupId:topicId:partition`) and is not used here.
    /// `COORDINATOR_LOAD_IN_PROGRESS` / `COORDINATOR_NOT_AVAILABLE` /
    /// `NOT_COORDINATOR` (16) refresh the coordinator and retry.
    /// ErrorCode is per-group (bytes 5–6 on leftover-empty fixture
    /// group `"g"`), not top-level after throttle.
    /// Java `describeShareGroups` is [`Self::describe_share_groups`].
    /// FindCoordinator v4+ CoordinatorKeys array of N (KIP-699): one
    /// FindCoordinator per retry for uncached groups. ShareGroupDescribe
    /// is one RPC per coordinator, and those RPCs run together. Brokers that only speak FindCoordinator
    /// v1–v3 get one FindCoordinator per uncached group. Empty input is
    /// a no-op. ShareGroupDescribe has no TimeoutMs; the RPC deadline
    /// is [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::share_group_describe_timeout`].
    pub async fn share_group_describe(
        &mut self,
        group_ids: &[&str],
        include_authorized_operations: bool,
    ) -> Result<Vec<DescribedShareGroup>> {
        let timeout = self.cfg.request_timeout;
        self.share_group_describe_timeout(group_ids, include_authorized_operations, timeout)
            .await
    }

    /// [`Self::share_group_describe`] with a one-shot RPC deadline (Java
    /// `DescribeShareGroupsOptions.timeoutMs`).
    ///
    /// ShareGroupDescribe has no TimeoutMs; `timeout` is the RPC deadline
    /// and the coordinator retry budget.
    pub async fn share_group_describe_timeout(
        &mut self,
        group_ids: &[&str],
        include_authorized_operations: bool,
        timeout: Duration,
    ) -> Result<Vec<DescribedShareGroup>> {
        let ids = group_ids;
        if ids.is_empty() {
            return Ok(Vec::new());
        }
        let version = self.share_group_describe_version.ok_or_else(|| {
            Error::Unsupported("broker does not support ShareGroupDescribe v0-1".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut out: Vec<Option<DescribedShareGroup>> = open_result_slots(ids.len()).await;
        let mut pending = pending_indexes(ids.len()).await;
        loop {
            let by_node = self.group_coord_nodes(ids, &pending, deadline).await?;
            let mut nodes: Vec<i32> = by_node.keys().copied().collect();
            nodes.sort_unstable();
            let mut still = Vec::new();
            if nodes.len() > 1 {
                let mut prepared = HashMap::new();
                for node in &nodes {
                    let idxs = by_node.get(node).map(Vec::as_slice).unwrap_or(&[]);
                    let subset = borrowed_ids(ids, idxs);
                    let mut payload = BytesMut::new();
                    encode_share_group_describe_ids_cooperative(
                        &mut payload,
                        version,
                        &subset,
                        include_authorized_operations,
                    )
                    .await?;
                    let _previous = prepared.insert(*node, payload.freeze());
                }
                let mut finished = self
                    .exchange_leaders(&nodes, deadline, |_admin, node, _conn, _timeout| {
                        let payload = prepared.get(&node).cloned().ok_or_else(|| {
                            Error::protocol("missing share group describe request")
                        })?;
                        Ok(LeaderFrame::ready(SHARE_GROUP_DESCRIBE, version, payload))
                    })
                    .await;
                for node in &nodes {
                    let idxs = by_node.get(node).cloned().unwrap_or_default();
                    let Some((spoken, body)) = finished.remove(node) else {
                        self.invalidate_group_coord_idxs(ids, &idxs, *node).await;
                        still.extend(idxs);
                        continue;
                    };
                    match body {
                        Err(error) if error.is_retriable() => {
                            self.invalidate_group_coord_idxs(ids, &idxs, *node).await;
                            still.extend(idxs);
                        }
                        Err(error) => return Err(error),
                        Ok(body) => {
                            let done =
                                Self::apply_share_group_describe_body(spoken, ids, &idxs, body)
                                    .await?;
                            for (i, g) in done {
                                if error::coordinator_retriable(g.error_code) {
                                    self.invalidate_group_coord_idxs(ids, &[i], *node).await;
                                    still.push(i);
                                } else if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(g);
                                }
                            }
                        }
                    }
                }
            } else {
                for node in nodes {
                    let idxs = by_node.get(&node).cloned().unwrap_or_default();
                    match self
                        .share_group_describe_on_node(
                            node,
                            version,
                            ids,
                            &idxs,
                            include_authorized_operations,
                            deadline,
                        )
                        .await
                    {
                        Ok(done) => {
                            for (i, g) in done {
                                if error::coordinator_retriable(g.error_code) {
                                    self.invalidate_group_coord_idxs(ids, &[i], node).await;
                                    still.push(i);
                                } else if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(g);
                                }
                            }
                        }
                        Err(e) if e.is_retriable() => {
                            self.invalidate_group_coord_idxs(ids, &idxs, node).await;
                            still.extend(idxs);
                        }
                        Err(e) => return Err(e),
                    }
                }
            }
            pending = still;
            if pending.is_empty() {
                break;
            }
            self.wait_retry(&mut attempt, deadline).await?;
        }
        out.into_iter()
            .zip(ids)
            .map(|(g, id)| {
                g.ok_or_else(|| Error::protocol(format!("ShareGroupDescribe missing {id}")))
            })
            .collect()
    }

    /// Describe share groups (Java `Admin.describeShareGroups`).
    ///
    /// Same wire as [`Self::share_group_describe`]: ShareGroupDescribe
    /// api 77 v0–v1 on the group coordinator. Java's
    /// `DescribeShareGroupsHandler` uses `CoordinatorType.GROUP`. Empty
    /// input is a no-op. ShareGroupDescribe has no TimeoutMs; the RPC
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// deadline, use [`Self::describe_share_groups_timeout`].
    pub async fn describe_share_groups(
        &mut self,
        group_ids: &[&str],
        include_authorized_operations: bool,
    ) -> Result<Vec<DescribedShareGroup>> {
        let timeout = self.cfg.request_timeout;
        self.describe_share_groups_timeout(group_ids, include_authorized_operations, timeout)
            .await
    }

    /// [`Self::describe_share_groups`] with a one-shot RPC deadline (Java
    /// `DescribeShareGroupsOptions.timeoutMs`).
    ///
    /// ShareGroupDescribe has no TimeoutMs; `timeout` is the RPC deadline
    /// and the coordinator retry budget.
    pub async fn describe_share_groups_timeout(
        &mut self,
        group_ids: &[&str],
        include_authorized_operations: bool,
        timeout: Duration,
    ) -> Result<Vec<DescribedShareGroup>> {
        self.share_group_describe_timeout(group_ids, include_authorized_operations, timeout)
            .await
    }

    /// Describe KIP-932 share-group offsets (DescribeShareGroupOffsets
    /// api 90), negotiating v0–1 and explicitly projecting the typed v1 lag
    /// result to the legacy result shape. Use [`Self::describe_share_group_offsets_with_lag`]
    /// to retain lag values.
    ///
    /// Lands on the group coordinator (`FindCoordinator` `key_type=0`).
    /// Official Apache JSON listeners are `broker` only. Official listed
    /// errors include `NOT_COORDINATOR` (16). Official Java
    /// `ListShareGroupOffsetsHandler` (the AdminClient handler for this
    /// RPC) uses `CoordinatorType.GROUP`. This is not a controller hop
    /// and not a partition-leader hop: there is no Metadata
    /// `controller_id` lookup, no `NOT_CONTROLLER` (41) retry, and no
    /// `NOT_LEADER_OR_FOLLOWER` (6) hop. SHARE (`key_type=2`) is the
    /// FindCoordinator v6 share-state key
    /// (`groupId:topicId:partition`) and is not used here.
    /// `COORDINATOR_LOAD_IN_PROGRESS` / `COORDINATOR_NOT_AVAILABLE` /
    /// `NOT_COORDINATOR` (16) refresh the coordinator and retry.
    /// Group-level ErrorCode is per-group after GroupId and Topics
    /// (bytes 8–9 on leftover-empty fixture group `"g"`), not
    /// top-level after throttle and not first-partition.
    /// Java `listShareGroupOffsets` is [`Self::list_share_group_offsets`].
    /// FindCoordinator v4+ CoordinatorKeys array of N (KIP-699): one
    /// FindCoordinator per retry for uncached groups. DescribeShareGroupOffsets
    /// is one RPC per coordinator, and those RPCs run together. Brokers that only speak FindCoordinator
    /// v1–v3 get one FindCoordinator per uncached group. Empty input is
    /// a no-op. DescribeShareGroupOffsets has no TimeoutMs; the RPC
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// deadline, use [`Self::describe_share_group_offsets_timeout`].
    pub async fn describe_share_group_offsets(
        &mut self,
        groups: &[DescribeShareGroupOffsetsGroup],
    ) -> Result<Vec<DescribedShareGroupOffsets>> {
        let timeout = self.cfg.request_timeout;
        self.describe_share_group_offsets_timeout(groups, timeout)
            .await
    }

    /// [`Self::describe_share_group_offsets`] with a one-shot RPC deadline
    /// (Java `ListShareGroupOffsetsOptions.timeoutMs`).
    ///
    /// DescribeShareGroupOffsets has no TimeoutMs; `timeout` is the RPC
    /// deadline and the coordinator retry budget.
    pub async fn describe_share_group_offsets_timeout(
        &mut self,
        groups: &[DescribeShareGroupOffsetsGroup],
        timeout: Duration,
    ) -> Result<Vec<DescribedShareGroupOffsets>> {
        // This documented legacy projection still negotiates/consumes v1.
        self.describe_share_group_offsets_with_lag_timeout(groups, timeout)
            .await
            .map(|groups| {
                groups
                    .into_iter()
                    .map(DescribedShareGroupOffsetsWithLag::into_legacy)
                    .collect()
            })
    }

    /// Describe share offsets retaining version1 lag (negative means absent).
    ///
    /// Version0 falls back to absent lag. Coordinator routing, retry and the
    /// absolute deadline are shared with the legacy operation.
    pub async fn describe_share_group_offsets_with_lag(
        &mut self,
        groups: &[DescribeShareGroupOffsetsGroup],
    ) -> Result<Vec<DescribedShareGroupOffsetsWithLag>> {
        let timeout = self.cfg.request_timeout;
        self.describe_share_group_offsets_with_lag_timeout(groups, timeout)
            .await
    }

    /// The typed lag operation with one absolute coordinator/RPC retry budget.
    pub async fn describe_share_group_offsets_with_lag_timeout(
        &mut self,
        groups: &[DescribeShareGroupOffsetsGroup],
        timeout: Duration,
    ) -> Result<Vec<DescribedShareGroupOffsetsWithLag>> {
        if groups.is_empty() {
            return Ok(Vec::new());
        }
        let ids: Vec<&str> = groups.iter().map(|g| g.group_id.as_str()).collect();
        let version = self.describe_share_group_offsets_version.ok_or_else(|| {
            Error::Unsupported("broker does not support DescribeShareGroupOffsets".into())
        })?;
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let deadline = Instant::now()
            .checked_add(timeout)
            .ok_or_else(|| Error::protocol("DescribeShareGroupOffsets deadline overflow"))?;
        let mut attempt = 0u32;
        let mut out: Vec<Option<DescribedShareGroupOffsetsWithLag>> =
            open_result_slots(groups.len()).await;
        let mut pending = pending_indexes(groups.len()).await;
        loop {
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            let by_node = self.group_coord_nodes(&ids, &pending, deadline).await?;
            let mut nodes: Vec<i32> = by_node.keys().copied().collect();
            nodes.sort_unstable();
            let mut still = Vec::new();
            if nodes.len() > 1 {
                let mut prepared = HashMap::new();
                for node in &nodes {
                    let idxs = by_node.get(node).map(Vec::as_slice).unwrap_or(&[]);
                    let subset: Vec<&DescribeShareGroupOffsetsGroup> =
                        idxs.iter().filter_map(|&i| groups.get(i)).collect();
                    let mut payload = BytesMut::new();
                    encode_describe_share_group_offsets_request_refs_cooperative(
                        &mut payload,
                        version,
                        &subset,
                    )
                    .await?;
                    let _previous = prepared.insert(*node, payload.freeze());
                }
                let mut finished = self
                    .exchange_leaders(&nodes, deadline, |_admin, node, _conn, _timeout| {
                        let payload = prepared.get(&node).cloned().ok_or_else(|| {
                            Error::protocol("missing describe share group offsets request")
                        })?;
                        Ok(LeaderFrame::ready(
                            DESCRIBE_SHARE_GROUP_OFFSETS,
                            version,
                            payload,
                        ))
                    })
                    .await;
                for node in &nodes {
                    let idxs = by_node.get(node).cloned().unwrap_or_default();
                    let Some((spoken, body)) = finished.remove(node) else {
                        self.invalidate_group_coord_idxs(&ids, &idxs, *node).await;
                        still.extend(idxs);
                        continue;
                    };
                    match body {
                        Err(error) if error.is_retriable() => {
                            self.invalidate_group_coord_idxs(&ids, &idxs, *node).await;
                            still.extend(idxs);
                        }
                        Err(error) => return Err(error),
                        Ok(body) => {
                            let done = Self::apply_describe_share_group_offsets_body(
                                spoken, groups, &idxs, body,
                            )
                            .await?;
                            for (i, g) in done {
                                if error::coordinator_retriable(g.error_code) {
                                    self.invalidate_group_coord_idxs(&ids, &[i], *node).await;
                                    still.push(i);
                                } else if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(g);
                                }
                            }
                        }
                    }
                }
            } else {
                for node in nodes {
                    let idxs = by_node.get(&node).cloned().unwrap_or_default();
                    match self
                        .describe_share_group_offsets_on_node(
                            node, version, groups, &idxs, deadline,
                        )
                        .await
                    {
                        Ok(done) => {
                            for (i, g) in done {
                                if error::coordinator_retriable(g.error_code) {
                                    self.invalidate_group_coord_idxs(&ids, &[i], node).await;
                                    still.push(i);
                                } else if let Some(slot) = out.get_mut(i) {
                                    *slot = Some(g);
                                }
                            }
                        }
                        Err(e) if e.is_retriable() => {
                            self.invalidate_group_coord_idxs(&ids, &idxs, node).await;
                            still.extend(idxs);
                        }
                        Err(e) => return Err(e),
                    }
                }
            }
            pending = still;
            if pending.is_empty() {
                break;
            }
            self.wait_retry(&mut attempt, deadline).await?;
        }
        out.into_iter()
            .zip(ids)
            .map(|(g, id)| {
                g.ok_or_else(|| Error::protocol(format!("DescribeShareGroupOffsets missing {id}")))
            })
            .collect()
    }

    /// List share-group offsets (Java `Admin.listShareGroupOffsets`).
    ///
    /// Same wire as [`Self::describe_share_group_offsets`]:
    /// DescribeShareGroupOffsets api 90 on the group coordinator.
    /// Java's `ListShareGroupOffsetsHandler` sends that RPC. Empty
    /// input is a no-op. DescribeShareGroupOffsets has no TimeoutMs;
    /// the RPC deadline is [`AdminConfig::request_timeout`]. For a
    /// one-shot deadline, use [`Self::list_share_group_offsets_timeout`].
    pub async fn list_share_group_offsets(
        &mut self,
        groups: &[DescribeShareGroupOffsetsGroup],
    ) -> Result<Vec<DescribedShareGroupOffsets>> {
        let timeout = self.cfg.request_timeout;
        self.list_share_group_offsets_timeout(groups, timeout).await
    }

    /// [`Self::list_share_group_offsets`] with a one-shot RPC deadline (Java
    /// `ListShareGroupOffsetsOptions.timeoutMs`).
    ///
    /// DescribeShareGroupOffsets has no TimeoutMs; `timeout` is the RPC
    /// deadline and the coordinator retry budget.
    pub async fn list_share_group_offsets_timeout(
        &mut self,
        groups: &[DescribeShareGroupOffsetsGroup],
        timeout: Duration,
    ) -> Result<Vec<DescribedShareGroupOffsets>> {
        self.describe_share_group_offsets_timeout(groups, timeout)
            .await
    }

    /// Alter KIP-932 share-group offsets (AlterShareGroupOffsets
    /// api 91).
    ///
    /// Lands on the group coordinator (`FindCoordinator` `key_type=0`).
    /// Official Apache JSON listeners are `broker` only. Official listed
    /// errors include `NOT_COORDINATOR` (16). Official Java
    /// `AlterShareGroupOffsetsHandler` uses `CoordinatorType.GROUP`.
    /// This is not a controller hop and not a partition-leader hop:
    /// there is no Metadata `controller_id` lookup, no
    /// `NOT_CONTROLLER` (41) retry, and no `NOT_LEADER_OR_FOLLOWER`
    /// (6) hop. SHARE (`key_type=2`) is the FindCoordinator v6
    /// share-state key (`groupId:topicId:partition`) and is not used
    /// here. `COORDINATOR_LOAD_IN_PROGRESS` /
    /// `COORDINATOR_NOT_AVAILABLE` / `NOT_COORDINATOR` (16) refresh
    /// the coordinator and retry. ErrorCode is top-level after
    /// throttle (bytes 4–5 on leftover-empty fixture group `"g"`),
    /// not first-group and not first-partition (bytes 31–32 when
    /// leftover-empty topic `"t"` partition `0` is present).
    /// AlterShareGroupOffsets has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::alter_share_group_offsets_timeout`].
    pub async fn alter_share_group_offsets(
        &mut self,
        group_id: &str,
        topics: &[AlterShareGroupOffsetsTopic],
    ) -> Result<AlteredShareGroupOffsets> {
        let timeout = self.cfg.request_timeout;
        self.alter_share_group_offsets_timeout(group_id, topics, timeout)
            .await
    }

    /// [`Self::alter_share_group_offsets`] with a one-shot RPC deadline (Java
    /// `AlterShareGroupOffsetsOptions.timeoutMs`).
    ///
    /// AlterShareGroupOffsets has no TimeoutMs; `timeout` is the RPC
    /// deadline and the coordinator retry budget.
    pub async fn alter_share_group_offsets_timeout(
        &mut self,
        group_id: &str,
        topics: &[AlterShareGroupOffsetsTopic],
        timeout: Duration,
    ) -> Result<AlteredShareGroupOffsets> {
        let version = self.alter_share_group_offsets_version.ok_or_else(|| {
            Error::Unsupported("broker does not support AlterShareGroupOffsets".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut encoded = BytesMut::new();
        encode_alter_share_group_offsets_request_cooperative(&mut encoded, group_id, topics)
            .await?;
        loop {
            let stale = self.group_coord.as_ref().is_none_or(|(g, _)| g != group_id);
            if stale {
                let node = self.discover_group_coord(group_id, deadline).await?;
                self.group_coord = Some((group_id.to_string(), node));
            }
            let node = self
                .group_coord
                .as_ref()
                .map(|(_, n)| *n)
                .ok_or_else(|| Error::protocol("missing group coordinator"))?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    ALTER_SHARE_GROUP_OFFSETS,
                    version,
                    |buf| {
                        buf.extend_from_slice(&encoded);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.group_coord = None;
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let result =
                decode_alter_share_group_offsets_response_cooperative(&mut body.clone()).await?;
            if error::coordinator_retriable(result.error_code) {
                // 14/15/16: FindCoordinator, then the new group coordinator.
                self.group_coord = None;
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                continue;
            }
            return Ok(result);
        }
    }

    /// Delete KIP-932 share-group offsets (DeleteShareGroupOffsets
    /// api 92).
    ///
    /// Lands on the group coordinator (`FindCoordinator` `key_type=0`).
    /// Official Apache JSON listeners are `broker` only. Official listed
    /// errors include `NOT_COORDINATOR` (16). Official Java
    /// `DeleteShareGroupOffsetsHandler` uses `CoordinatorType.GROUP`.
    /// This is not a controller hop and not a partition-leader hop:
    /// there is no Metadata `controller_id` lookup, no
    /// `NOT_CONTROLLER` (41) retry, and no `NOT_LEADER_OR_FOLLOWER`
    /// (6) hop. SHARE (`key_type=2`) is the FindCoordinator v6
    /// share-state key (`groupId:topicId:partition`) and is not used
    /// here. `COORDINATOR_LOAD_IN_PROGRESS` /
    /// `COORDINATOR_NOT_AVAILABLE` / `NOT_COORDINATOR` (16) refresh
    /// the coordinator and retry. ErrorCode is top-level after
    /// throttle (bytes 4–5 on leftover-empty fixture group `"g"`),
    /// not first-group and not first-topic (bytes 26–27 when
    /// leftover-empty topic `"t"` is present). Official request topics
    /// are names only — no partitions. DeleteShareGroupOffsets has no
    /// TimeoutMs; the RPC deadline is [`AdminConfig::request_timeout`].
    /// For a one-shot deadline, use
    /// [`Self::delete_share_group_offsets_timeout`].
    pub async fn delete_share_group_offsets(
        &mut self,
        group_id: &str,
        topics: &[DeleteShareGroupOffsetsTopic],
    ) -> Result<DeletedShareGroupOffsets> {
        let timeout = self.cfg.request_timeout;
        self.delete_share_group_offsets_timeout(group_id, topics, timeout)
            .await
    }

    /// [`Self::delete_share_group_offsets`] with a one-shot RPC deadline
    /// (Java `DeleteShareGroupOffsetsOptions.timeoutMs`).
    ///
    /// DeleteShareGroupOffsets has no TimeoutMs; `timeout` is the RPC
    /// deadline and the coordinator retry budget.
    pub async fn delete_share_group_offsets_timeout(
        &mut self,
        group_id: &str,
        topics: &[DeleteShareGroupOffsetsTopic],
        timeout: Duration,
    ) -> Result<DeletedShareGroupOffsets> {
        let version = self.delete_share_group_offsets_version.ok_or_else(|| {
            Error::Unsupported("broker does not support DeleteShareGroupOffsets".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        loop {
            let stale = self.group_coord.as_ref().is_none_or(|(g, _)| g != group_id);
            if stale {
                let node = self.discover_group_coord(group_id, deadline).await?;
                self.group_coord = Some((group_id.to_string(), node));
            }
            let node = self
                .group_coord
                .as_ref()
                .map(|(_, n)| *n)
                .ok_or_else(|| Error::protocol("missing group coordinator"))?;
            let mut encoded = BytesMut::new();
            encode_delete_share_group_offsets_request_cooperative(&mut encoded, group_id, topics)
                .await?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    DELETE_SHARE_GROUP_OFFSETS,
                    version,
                    |buf| {
                        buf.extend_from_slice(&encoded);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.group_coord = None;
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let result =
                decode_delete_share_group_offsets_response_cooperative(&mut body.clone()).await?;
            if error::coordinator_retriable(result.error_code) {
                // 14/15/16: FindCoordinator, then the new group coordinator.
                self.group_coord = None;
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                continue;
            }
            return Ok(result);
        }
    }

    /// Describe topic partitions (DescribeTopicPartitions api 75,
    /// KIP-966).
    ///
    /// Lands on the connected broker (bootstrap is fine). Official
    /// Apache JSON listeners are `broker` only. Official JSON lists no
    /// `errorCodes`. Official Java
    /// `DescribeTopicPartitionsRequestHandler` answers from the broker
    /// `MetadataCache`. `NOT_COORDINATOR` (16) is not listed. This is
    /// not a group-coordinator hop, not a controller hop, and not a
    /// partition-leader hop: there is no FindCoordinator, no Metadata
    /// `controller_id` lookup, no `NOT_CONTROLLER` (41) retry, and no
    /// `NOT_LEADER_OR_FOLLOWER` (6) hop. ErrorCode is first-topic after
    /// throttle and the compact topics length (bytes 5–6 on leftover-
    /// empty fixture topic `"t"`), not top-level after throttle.
    /// First-partition ErrorCode is at bytes 27–28 when leftover-empty
    /// partition `0` is present and is not the first ErrorCode.
    /// DescribeTopicPartitions has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::describe_topic_partitions_timeout`]. Java `describeTopics`
    /// is [`Self::describe_topics_timeout`].
    pub async fn describe_topic_partitions(
        &mut self,
        topics: &[&str],
        response_partition_limit: i32,
        cursor: Option<&TopicPartitionCursor>,
    ) -> Result<DescribeTopicPartitionsResponse> {
        let timeout = self.cfg.request_timeout;
        self.describe_topic_partitions_timeout(topics, response_partition_limit, cursor, timeout)
            .await
    }

    /// [`Self::describe_topic_partitions`] with a one-shot RPC deadline.
    ///
    /// DescribeTopicPartitions has no TimeoutMs; `timeout` is the RPC
    /// deadline. Java `Admin.describeTopics` uses
    /// [`Self::describe_topics_timeout`]. This overload is the crate-first
    /// raw DescribeTopicPartitions (api 75) path.
    pub async fn describe_topic_partitions_timeout(
        &mut self,
        topics: &[&str],
        response_partition_limit: i32,
        cursor: Option<&TopicPartitionCursor>,
        timeout: Duration,
    ) -> Result<DescribeTopicPartitionsResponse> {
        self.describe_topic_partitions_once(topics, response_partition_limit, cursor, timeout)
            .await
    }

    async fn describe_topic_partitions_once<T: AsRef<str> + Sync>(
        &mut self,
        names: &[T],
        response_partition_limit: i32,
        cursor: Option<&TopicPartitionCursor>,
        timeout: Duration,
    ) -> Result<DescribeTopicPartitionsResponse> {
        let version = self.describe_topic_partitions_version.ok_or_else(|| {
            Error::Unsupported("broker does not support DescribeTopicPartitions".into())
        })?;
        let mut encoded = BytesMut::new();
        encode_describe_topic_partitions_names_cooperative(
            &mut encoded,
            names,
            response_partition_limit,
            cursor,
        )
        .await?;
        let body = self
            .roundtrip_bootstrap(
                DESCRIBE_TOPIC_PARTITIONS,
                version,
                |buf| {
                    buf.extend_from_slice(&encoded);
                    Ok(())
                },
                timeout,
            )
            .await?;
        decode_describe_topic_partitions_response_cooperative(&mut body.clone()).await
    }

    async fn describe_topics_dtp<T: AsRef<str> + Sync>(
        &mut self,
        names: &[T],
        include_authorized_operations: bool,
        response_partition_limit: i32,
        timeout: Duration,
    ) -> Result<Vec<TopicDescription>> {
        let deadline = Instant::now() + timeout;
        let mut cursor: Option<TopicPartitionCursor> = None;
        let mut out: Vec<TopicDescription> = Vec::new();
        let mut described: HashMap<String, usize> = HashMap::new();
        loop {
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            let resp = self
                .describe_topic_partitions_once(
                    names,
                    response_partition_limit,
                    cursor.as_ref(),
                    timeout,
                )
                .await?;
            let mut page = Vec::with_capacity(resp.topics.len());
            for topic in &resp.topics {
                page.push(topic_description_from_dtp(topic, include_authorized_operations).await);
            }
            extend_described_topics(&mut out, &mut described, page).await;
            match resp.next_cursor {
                Some(next) if cursor.as_ref() != Some(&next) => cursor = Some(next),
                _ => break,
            }
        }
        Ok(out)
    }

    async fn describe_topics_metadata<T: AsRef<str> + Sync>(
        &mut self,
        names: &[T],
        include_authorized_operations: bool,
        timeout: Duration,
    ) -> Result<Vec<TopicDescription>> {
        let deadline = Instant::now().checked_add(timeout).ok_or(Error::Timeout)?;
        self.ensure_bootstrap(deadline).await?;
        let version = self.metadata_version;
        let mut encoded = BytesMut::new();
        encode_metadata_request_named_cooperative(
            &mut encoded,
            version,
            Some(names),
            false,
            include_authorized_operations,
        )
        .await?;
        self.exchange_prepared_metadata(
            true,
            include_authorized_operations,
            deadline,
            version,
            &encoded,
        )
        .await?;
        Ok(topic_descriptions_for_names(&self.metadata_image, names).await)
    }

    /// List configuration resources (ListConfigResources api 74,
    /// KIP-1142; formerly ListClientMetricsResources).
    ///
    /// Java `listClientMetricsResources` is
    /// [`Self::list_client_metrics_resources`] (CLIENT_METRICS only).
    ///
    /// Lands on the connected broker (bootstrap is fine). Negotiates
    /// ListConfigResources v0–v1 (flexible from v0). Kafka 4.0 api 74
    /// is ListClientMetricsResources v0 only (empty request; response
    /// names, ResourceType decode-fills `CLIENT_METRICS`). v1 adds
    /// ResourceTypes / ResourceType (KIP-1142). Official
    /// Apache JSON listeners are `broker` only. Official JSON lists no
    /// `errorCodes`. Official Java `KafkaApis.handleListConfigResources`
    /// answers from the connected broker. Official Java
    /// `ListConfigResourcesRequest.getErrorResponse` writes the
    /// exception onto the top-level ErrorCode.
    /// `CLUSTER_AUTHORIZATION_FAILED` (31) and `UNSUPPORTED_VERSION`
    /// (35) are handler-observed. `NOT_COORDINATOR` (16) is not listed.
    /// This is not a group-coordinator hop, not a controller hop, and
    /// not a partition-leader hop: there is no FindCoordinator, no
    /// Metadata `controller_id` lookup, no `NOT_CONTROLLER` (41) retry,
    /// and no `NOT_LEADER_OR_FOLLOWER` (6) hop. Top-level `error_code`
    /// is the INT16 at bytes 4–5, after throttle — not a first-resource
    /// field. Resources have no ErrorCode.
    ///
    /// `resource_types` is [`ConfigResourceType`] or a protocol `i8`
    /// (`CONFIG_RESOURCE_TOPIC`, …). Empty is Java `listConfigResources()`
    /// ([`Self::list_config_resources_all`]). ListConfigResources has no
    /// TimeoutMs; the RPC deadline is [`AdminConfig::request_timeout`].
    /// For a one-shot deadline, use [`Self::list_config_resources_timeout`].
    pub async fn list_config_resources(
        &mut self,
        resource_types: impl IntoIterator<Item = impl Into<i8>>,
    ) -> Result<Vec<ListedConfigResource>> {
        let timeout = self.cfg.request_timeout;
        self.list_config_resources_timeout(resource_types, timeout)
            .await
    }

    /// [`Self::list_config_resources`] with a one-shot RPC deadline (Java
    /// `ListConfigResourcesOptions.timeoutMs`).
    ///
    /// ListConfigResources has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn list_config_resources_timeout(
        &mut self,
        resource_types: impl IntoIterator<Item = impl Into<i8>>,
        timeout: Duration,
    ) -> Result<Vec<ListedConfigResource>> {
        let types: Vec<i8> = resource_types.into_iter().map(Into::into).collect();
        let version = self.list_config_resources_version.ok_or_else(|| {
            Error::Unsupported("broker does not support ListConfigResources v0-1".into())
        })?;
        let body = self
            .roundtrip_bootstrap(
                LIST_CONFIG_RESOURCES,
                version,
                |buf| encode_list_config_resources_request(buf, version, &types),
                timeout,
            )
            .await?;
        let resp =
            decode_list_config_resources_response_cooperative(&mut body.clone(), version).await?;
        if resp.error_code != 0 {
            return Err(Error::broker(resp.error_code, "ListConfigResources"));
        }
        Ok(resp.config_resources)
    }

    /// List every configuration resource (Java `listConfigResources()`).
    ///
    /// Same wire as [`Self::list_config_resources`] with an empty
    /// ResourceTypes array (Java `Set.of()`). Kafka 4.1 Admin; Kafka 4.0
    /// has [`Self::list_client_metrics_resources`] only.
    pub async fn list_config_resources_all(&mut self) -> Result<Vec<ListedConfigResource>> {
        self.list_config_resources(std::iter::empty::<i8>()).await
    }

    /// [`Self::list_config_resources_all`] with a one-shot RPC deadline
    /// (Java `ListConfigResourcesOptions.timeoutMs`).
    ///
    /// ListConfigResources has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn list_config_resources_all_timeout(
        &mut self,
        timeout: Duration,
    ) -> Result<Vec<ListedConfigResource>> {
        self.list_config_resources_timeout(std::iter::empty::<i8>(), timeout)
            .await
    }

    /// List client-metrics resources (Java
    /// `Admin.listClientMetricsResources`).
    ///
    /// Same wire as [`Self::list_config_resources`] with
    /// [`ConfigResourceType::ClientMetrics`]. Java 4.0 implements the
    /// deprecated `listClientMetricsResources` as ListConfigResources
    /// for that type. ListConfigResources has no TimeoutMs; the RPC
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// deadline, use [`Self::list_client_metrics_resources_timeout`].
    pub async fn list_client_metrics_resources(&mut self) -> Result<Vec<ListedConfigResource>> {
        self.list_config_resources([ConfigResourceType::ClientMetrics])
            .await
    }

    /// [`Self::list_client_metrics_resources`] with a one-shot RPC deadline
    /// (Java `ListClientMetricsResourcesOptions.timeoutMs`).
    ///
    /// ListConfigResources has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn list_client_metrics_resources_timeout(
        &mut self,
        timeout: Duration,
    ) -> Result<Vec<ListedConfigResource>> {
        self.list_config_resources_timeout([ConfigResourceType::ClientMetrics], timeout)
            .await
    }

    /// Get client telemetry subscriptions (GetTelemetrySubscriptions
    /// api 71, KIP-714).
    ///
    /// Lands on the connected broker (bootstrap is fine). Official
    /// Apache JSON listeners are `broker` only. Official JSON lists no
    /// `errorCodes`. Official Java
    /// `KafkaApis.handleGetTelemetrySubscriptionsRequest` answers from
    /// the connected broker (`clientMetricsManager`). Official Java
    /// `GetTelemetrySubscriptionsRequest.getErrorResponse` writes the
    /// exception onto the top-level ErrorCode. `INVALID_REQUEST` (42),
    /// `UNSUPPORTED_VERSION` (35), and `THROTTLING_QUOTA_EXCEEDED` (89)
    /// are handler-observed. `NOT_COORDINATOR` (16) is not listed.
    /// This is not a group-coordinator hop, not a controller hop, and
    /// not a partition-leader hop: there is no FindCoordinator, no
    /// Metadata `controller_id` lookup, no `NOT_CONTROLLER` (41) retry,
    /// and no `NOT_LEADER_OR_FOLLOWER` (6) hop. Top-level `error_code`
    /// is the INT16 at bytes 4–5, after throttle — not a first-
    /// subscription field and not a first-metric field.
    /// `client_instance_id` is Java `Uuid` ([`Uuid`]) or `[u8; 16]`.
    pub async fn get_telemetry_subscriptions(
        &mut self,
        client_instance_id: impl Into<[u8; 16]>,
    ) -> Result<GetTelemetrySubscriptionsResponse> {
        let version = self.get_telemetry_subscriptions_version.ok_or_else(|| {
            Error::Unsupported("broker does not support GetTelemetrySubscriptions".into())
        })?;
        let timeout = self.cfg.request_timeout;
        let client_instance_id = client_instance_id.into();
        let body = self
            .roundtrip_bootstrap(
                GET_TELEMETRY_SUBSCRIPTIONS,
                version,
                |buf| encode_get_telemetry_subscriptions_request(buf, &client_instance_id),
                timeout,
            )
            .await?;
        let resp =
            decode_get_telemetry_subscriptions_response_cooperative(&mut body.clone()).await?;
        if resp.error_code != 0 {
            return Err(Error::broker(resp.error_code, "GetTelemetrySubscriptions"));
        }
        Ok(resp)
    }

    /// Push client telemetry metrics (PushTelemetry api 72, KIP-714).
    ///
    /// Lands on the connected broker (bootstrap is fine). Official
    /// Apache JSON listeners are `broker` only. Official JSON lists no
    /// `errorCodes`. Official Java
    /// `KafkaApis.handlePushTelemetryRequest` answers from the
    /// connected broker (`clientMetricsManager`). Official Java
    /// `PushTelemetryRequest.getErrorResponse` writes the exception
    /// onto the top-level ErrorCode. `INVALID_REQUEST` (42),
    /// `UNKNOWN_SUBSCRIPTION_ID` (117), `THROTTLING_QUOTA_EXCEEDED`
    /// (89), `UNSUPPORTED_COMPRESSION_TYPE` (76),
    /// `TELEMETRY_TOO_LARGE` (118), and `INVALID_RECORD` (87) are
    /// handler-observed. `NOT_COORDINATOR` (16) is not listed.
    /// This is not a group-coordinator hop, not a controller hop, and
    /// not a partition-leader hop: there is no FindCoordinator, no
    /// Metadata `controller_id` lookup, no `NOT_CONTROLLER` (41) retry,
    /// and no `NOT_LEADER_OR_FOLLOWER` (6) hop. Top-level `error_code`
    /// is the INT16 at bytes 4–5, after throttle — not a first-metric
    /// field and not a first-payload field.
    /// `client_instance_id` is Java `Uuid` ([`Uuid`]) or `[u8; 16]`.
    pub async fn push_telemetry(
        &mut self,
        client_instance_id: impl Into<[u8; 16]>,
        subscription_id: i32,
        terminating: bool,
        compression_type: i8,
        metrics: &[u8],
    ) -> Result<PushTelemetryResponse> {
        let version = self
            .push_telemetry_version
            .ok_or_else(|| Error::Unsupported("broker does not support PushTelemetry".into()))?;
        let timeout = self.cfg.request_timeout;
        let client_instance_id = client_instance_id.into();
        let body = self
            .roundtrip_bootstrap(
                PUSH_TELEMETRY,
                version,
                |buf| {
                    encode_push_telemetry_metrics(
                        buf,
                        &client_instance_id,
                        subscription_id,
                        terminating,
                        compression_type,
                        metrics,
                    )
                },
                timeout,
            )
            .await?;
        let resp = decode_push_telemetry_response(&mut body.clone())?;
        if resp.error_code != 0 {
            return Err(Error::broker(resp.error_code, "PushTelemetry"));
        }
        Ok(resp)
    }

    /// Assign replicas to log directories (AssignReplicasToDirs api 73,
    /// KIP-858).
    ///
    /// Lands on the Metadata controller. Official Apache JSON listeners
    /// are `controller` only. Official JSON lists no `errorCodes`.
    /// Official Java `AssignReplicasToDirsRequest.getErrorResponse`
    /// writes `Errors.forException(e).code()` onto the top-level
    /// ErrorCode. Official Java `QuorumController.assignReplicasToDirs`
    /// is an `appendWriteEvent`; `ControllerWriteEvent.run` throws
    /// `NotControllerException` when the node is not the active
    /// controller, which `getErrorResponse` writes as
    /// `NOT_CONTROLLER` (41). `NOT_CONTROLLER` (41) refreshes Metadata
    /// and retries on the new controller. Official
    /// `ReplicationControlManager.handleAssignReplicasToDirs` does not
    /// write `NOT_COORDINATOR` (16); per-partition
    /// `NOT_LEADER_OR_FOLLOWER` (6) is a handler code when the broker
    /// is not a replica, not a partition-leader hop. This is not a
    /// FindCoordinator hop and has no `key_type`. Top-level
    /// `error_code` is the INT16 at bytes 4–5, after throttle — not a
    /// first-directory field and not a first-partition field. Fixture
    /// broker id/epoch and directory UUIDs only; this is not a replica
    /// directory store. AssignReplicasToDirs has no TimeoutMs; the RPC
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// deadline, use [`Self::assign_replicas_to_dirs_timeout`].
    pub async fn assign_replicas_to_dirs(
        &mut self,
        broker_id: i32,
        broker_epoch: i64,
        directories: Vec<AssignReplicasToDirsDirectory>,
    ) -> Result<AssignReplicasToDirsResponse> {
        let timeout = self.cfg.request_timeout;
        self.assign_replicas_to_dirs_timeout(broker_id, broker_epoch, directories, timeout)
            .await
    }

    /// [`Self::assign_replicas_to_dirs`] with a one-shot RPC deadline (Java
    /// `AssignReplicasToDirsOptions.timeoutMs`).
    ///
    /// AssignReplicasToDirs has no TimeoutMs; `timeout` is the RPC deadline
    /// and the `NOT_CONTROLLER` retry budget.
    pub async fn assign_replicas_to_dirs_timeout(
        &mut self,
        broker_id: i32,
        broker_epoch: i64,
        directories: Vec<AssignReplicasToDirsDirectory>,
        timeout: Duration,
    ) -> Result<AssignReplicasToDirsResponse> {
        let version = self.assign_replicas_to_dirs_version.ok_or_else(|| {
            Error::Unsupported("broker does not support AssignReplicasToDirs".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let req = AssignReplicasToDirsRequest::new(broker_id, broker_epoch, directories);
        loop {
            if self.cluster.controller().is_err() {
                self.refresh_broker_directory(deadline).await?;
            }
            let node = self.cluster.controller()?;
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    ASSIGN_REPLICAS_TO_DIRS,
                    version,
                    |buf| encode_assign_replicas_to_dirs_request(buf, &req),
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.forget_controller();
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let resp = decode_assign_replicas_to_dirs_response(&mut body.clone())?;
            if resp.error_code == error::NOT_CONTROLLER {
                // NOT_CONTROLLER (41): Metadata, then the new controller.
                self.forget_controller();
                self.drop_node_conn(node).await;
                self.wait_retry(&mut attempt, deadline).await?;
                self.refresh_broker_directory(deadline).await?;
                continue;
            }
            if resp.error_code != 0 {
                return Err(Error::broker(resp.error_code, "AssignReplicasToDirs"));
            }
            return Ok(resp);
        }
    }

    /// Alter replica log directories (AlterReplicaLogDirs api 34,
    /// KIP-113; v1–v2, classic at v1, flexible from v2).
    ///
    /// Lands on the connected broker (bootstrap is fine). Official
    /// Apache JSON listeners are `broker` only. Official JSON lists no
    /// `errorCodes`. Official Java
    /// `KafkaApis.handleAlterReplicaLogDirsRequest` answers from the
    /// connected broker (`replicaManager.alterReplicaLogDirs`).
    /// Official Java `AlterReplicaLogDirsRequest.getErrorResponse`
    /// writes the exception onto each partition ErrorCode (no
    /// top-level field). `CLUSTER_AUTHORIZATION_FAILED` (31),
    /// `INVALID_TOPIC_EXCEPTION` (17), `KAFKA_STORAGE_ERROR` (56),
    /// `INVALID_REPLICA_ASSIGNMENT` (39), `LOG_DIR_NOT_FOUND` (57),
    /// and `REPLICA_NOT_AVAILABLE` (9) (handler converts
    /// `NotLeaderOrFollowerException` to 9) are handler-observed.
    /// `NOT_COORDINATOR` (16) is not listed. `NOT_CONTROLLER` (41) is
    /// not listed. This is not a group-coordinator hop, not a
    /// controller hop, and not a partition-leader hop: there is no
    /// FindCoordinator, no Metadata `controller_id` lookup, no
    /// `NOT_CONTROLLER` (41) retry, and no `NOT_LEADER_OR_FOLLOWER`
    /// (6) hop. First-partition `error_code` is the INT16 at bytes
    /// 12–13 on leftover-empty **v2** fixture topic `"t"` partition `0`
    /// — not a top-level field after throttle. Classic **v1** places
    /// that ErrorCode later (bytes 19–20 on the same fixture). Fixture
    /// directory path and topic/partition indexes only; this is not a
    /// log-dir store. AlterReplicaLogDirs has no TimeoutMs; the RPC
    /// deadline is [`AdminConfig::request_timeout`]. For a one-shot
    /// deadline, use [`Self::alter_replica_log_dirs_timeout`]. Optional at
    /// [`Self::new`] (Kafka 1.1+ / KIP-113); a broker that omits api 34
    /// returns [`Error::Unsupported`]. Java `alterReplicaLogDirs(Map)` is
    /// [`Self::alter_replica_log_dirs_for`].
    pub async fn alter_replica_log_dirs(
        &mut self,
        dirs: Vec<AlterReplicaLogDirsDirectory>,
    ) -> Result<AlterReplicaLogDirsResponse> {
        let timeout = self.cfg.request_timeout;
        self.alter_replica_log_dirs_timeout(dirs, timeout).await
    }

    /// [`Self::alter_replica_log_dirs`] with a one-shot RPC deadline (Java
    /// `AlterReplicaLogDirsOptions.timeoutMs`).
    ///
    /// AlterReplicaLogDirs has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn alter_replica_log_dirs_timeout(
        &mut self,
        dirs: Vec<AlterReplicaLogDirsDirectory>,
        timeout: Duration,
    ) -> Result<AlterReplicaLogDirsResponse> {
        let version = self.alter_replica_log_dirs_version.ok_or_else(|| {
            Error::Unsupported("broker does not support AlterReplicaLogDirs".into())
        })?;
        let req = AlterReplicaLogDirsRequest::new(dirs);
        let mut payload = BytesMut::new();
        encode_alter_replica_log_dirs_request_cooperative(&mut payload, version, &req).await?;
        let body = self
            .roundtrip_bootstrap(
                ALTER_REPLICA_LOG_DIRS,
                version,
                |buf| {
                    buf.extend_from_slice(&payload);
                    Ok(())
                },
                timeout,
            )
            .await?;
        decode_alter_replica_log_dirs_response_cooperative(&mut body.clone(), version).await
    }

    /// Java `Admin.alterReplicaLogDirs(Map)`.
    ///
    /// Groups by [`TopicPartitionReplica::broker_id`] and sends
    /// AlterReplicaLogDirs (api 34) to each replica's broker. Empty
    /// input is a no-op. Per-replica error codes follow input order
    /// (`0` is success). This is not [`Self::alter_replica_log_dirs`]
    /// (bootstrap only) and not a coordinator or controller hop.
    /// AlterReplicaLogDirs has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::alter_replica_log_dirs_for_timeout`].
    pub async fn alter_replica_log_dirs_for<I, Dir>(
        &mut self,
        replica_assignment: I,
    ) -> Result<Vec<(TopicPartitionReplica, i16)>>
    where
        I: IntoIterator<Item = (TopicPartitionReplica, Dir)>,
        Dir: Into<String>,
    {
        let timeout = self.cfg.request_timeout;
        self.alter_replica_log_dirs_for_timeout(replica_assignment, timeout)
            .await
    }

    /// [`Self::alter_replica_log_dirs_for`] with a one-shot RPC deadline
    /// (Java `alterReplicaLogDirs` plus `AlterReplicaLogDirsOptions.timeoutMs`).
    ///
    /// AlterReplicaLogDirs has no TimeoutMs. Distinct replica brokers are
    /// queried together under `timeout`.
    pub async fn alter_replica_log_dirs_for_timeout<I, Dir>(
        &mut self,
        replica_assignment: I,
        timeout: Duration,
    ) -> Result<Vec<(TopicPartitionReplica, i16)>>
    where
        I: IntoIterator<Item = (TopicPartitionReplica, Dir)>,
        Dir: Into<String>,
    {
        let assignment: Vec<(TopicPartitionReplica, String)> = replica_assignment
            .into_iter()
            .map(|(replica, dir)| (replica, dir.into()))
            .collect();
        if assignment.is_empty() {
            return Ok(Vec::new());
        }
        let mut errors: HashMap<TopicPartitionReplica, i16> = HashMap::new();
        let grouped = group_alter_replica_log_dirs(&assignment).await;
        if grouped.len() <= 1 {
            for (broker_id, dirs) in grouped {
                let deadline = Instant::now()
                    .checked_add(timeout)
                    .ok_or_else(|| Error::protocol("AlterReplicaLogDirs deadline overflow"))?;
                self.ensure_broker(broker_id, deadline).await?;
                let remaining = deadline.saturating_duration_since(Instant::now());
                if remaining.is_zero() {
                    return Err(Error::Timeout);
                }
                let resp = self
                    .alter_replica_log_dirs_on(broker_id, &dirs, remaining)
                    .await?;
                record_alter_replica_errors_cooperative(&mut errors, &assignment, broker_id, &resp)
                    .await;
            }
        } else {
            let version = self.alter_replica_log_dirs_version.ok_or_else(|| {
                Error::Unsupported("broker does not support AlterReplicaLogDirs".into())
            })?;
            let deadline = Instant::now()
                .checked_add(timeout)
                .ok_or_else(|| Error::protocol("AlterReplicaLogDirs deadline overflow"))?;
            let ids: Vec<i32> = grouped.iter().map(|(broker_id, _)| *broker_id).collect();
            for id in &ids {
                self.ensure_broker(*id, deadline).await?;
            }
            let mut prepared = HashMap::new();
            for (broker_id, dirs) in &grouped {
                let mut payload = BytesMut::new();
                encode_alter_replica_log_dirs_named_cooperative(&mut payload, version, dirs)
                    .await?;
                let _previous = prepared.insert(*broker_id, payload.freeze());
            }
            let mut finished = self
                .exchange_leaders(&ids, deadline, |_admin, node, _conn, _timeout| {
                    let payload = prepared
                        .get(&node)
                        .cloned()
                        .ok_or_else(|| Error::protocol("missing alter replica log dirs request"))?;
                    Ok(LeaderFrame::ready(ALTER_REPLICA_LOG_DIRS, version, payload))
                })
                .await;
            for (broker_id, dirs) in grouped {
                let Some((spoken, body)) = finished.remove(&broker_id) else {
                    return Err(Error::Timeout);
                };
                let resp = match body {
                    Err(error) if error.is_retriable() && !matches!(error, Error::Timeout) => {
                        self.discard_node_conn(broker_id).await;
                        self.alter_replica_log_dirs_on(broker_id, &dirs, timeout)
                            .await?
                    }
                    Err(error) => return Err(error),
                    Ok(body) => {
                        decode_alter_replica_log_dirs_response_cooperative(
                            &mut body.clone(),
                            spoken,
                        )
                        .await?
                    }
                };
                record_alter_replica_errors_cooperative(&mut errors, &assignment, broker_id, &resp)
                    .await;
            }
        }
        let mut out = Vec::with_capacity(assignment.len());
        for (replica, _) in assignment {
            let code = errors.get(&replica).copied().unwrap_or(0);
            out.push((replica, code));
        }
        Ok(out)
    }

    /// Describe log directories (DescribeLogDirs api 35, KIP-113 /
    /// KIP-784 / KIP-827; v1–v5, classic at v1, flexible from v2,
    /// top-level ErrorCode v3+, TotalBytes / UsableBytes v4, IsCordoned v5).
    ///
    /// Lands on the connected broker (bootstrap is fine). Official
    /// Apache JSON listeners are `broker` only. Official JSON lists no
    /// `errorCodes`. Official Java
    /// `KafkaApis.handleDescribeLogDirsRequest` answers from the
    /// connected broker (`replicaManager.describeLogDirs`). Auth
    /// failure writes `CLUSTER_AUTHORIZATION_FAILED` (31) onto the
    /// top-level ErrorCode (v3+; v1–v2 omit that field and decode
    /// fills `0`). Official `ReplicaManager.describeLogDirs`
    /// writes `KAFKA_STORAGE_ERROR` (56) onto a first-directory
    /// ErrorCode when that dir is offline. `NOT_COORDINATOR` (16) is
    /// not listed. `NOT_CONTROLLER` (41) is not listed. This is not a
    /// group-coordinator hop, not a controller hop, and not a
    /// partition-leader hop: there is no FindCoordinator, no Metadata
    /// `controller_id` lookup, no `NOT_CONTROLLER` (41) retry, and no
    /// `NOT_LEADER_OR_FOLLOWER` (6) hop. Top-level `error_code` is the
    /// INT16 at bytes 4–5 on leftover-empty **v3+**, after throttle —
    /// not a first-directory field and not a first-partition field.
    /// Typed results include the v5 cordoned state; older versions
    /// decode the Apache default false. Each attempt refreshes the connected
    /// peer's ApiVersions within the same deadline (one extra control RPC),
    /// so a mixed-version cluster uses each broker's own v1–v5 range.
    /// Java `describeLogDirs(Collection<Integer>)` is
    /// [`Self::describe_broker_log_dirs`]. DescribeLogDirs has no
    /// TimeoutMs; the RPC deadline is [`AdminConfig::request_timeout`].
    /// For a one-shot deadline, use [`Self::describe_log_dirs_timeout`].
    /// Optional at [`Self::new`] (Kafka 1.0+ / KIP-113); a broker that
    /// omits api 35 returns [`Error::Unsupported`].
    pub async fn describe_log_dirs(
        &mut self,
        topics: Option<Vec<DescribableLogDirTopic>>,
    ) -> Result<DescribeLogDirsResponse> {
        let timeout = self.cfg.request_timeout;
        self.describe_log_dirs_timeout(topics, timeout).await
    }

    /// [`Self::describe_log_dirs`] with a one-shot RPC deadline (Java
    /// `DescribeLogDirsOptions.timeoutMs`).
    ///
    /// DescribeLogDirs has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn describe_log_dirs_timeout(
        &mut self,
        topics: Option<Vec<DescribableLogDirTopic>>,
        timeout: Duration,
    ) -> Result<DescribeLogDirsResponse> {
        self.describe_log_dirs_at(None, topics, timeout).await
    }

    /// Replica log directories (Java `Admin.describeReplicaLogDirs`).
    ///
    /// Groups replicas by [`TopicPartitionReplica::broker_id`] and
    /// sends DescribeLogDirs (api 35) to each replica's broker. Empty
    /// input is a no-op. This is not [`Self::describe_log_dirs`]
    /// (bootstrap only) and not a controller or partition-leader hop.
    /// Replicas missing from the response get [`ReplicaLogDirInfo::unknown`].
    /// DescribeLogDirs has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::describe_replica_log_dirs_timeout`].
    pub async fn describe_replica_log_dirs(
        &mut self,
        replicas: impl IntoIterator<Item = TopicPartitionReplica>,
    ) -> Result<Vec<(TopicPartitionReplica, ReplicaLogDirInfo)>> {
        let timeout = self.cfg.request_timeout;
        self.describe_replica_log_dirs_timeout(replicas, timeout)
            .await
    }

    /// [`Self::describe_replica_log_dirs`] with a one-shot RPC deadline
    /// (Java `describeReplicaLogDirs` plus `DescribeLogDirsOptions.timeoutMs`).
    ///
    /// DescribeLogDirs has no TimeoutMs. Distinct replica brokers are
    /// queried together under `timeout`.
    pub async fn describe_replica_log_dirs_timeout(
        &mut self,
        replicas: impl IntoIterator<Item = TopicPartitionReplica>,
        timeout: Duration,
    ) -> Result<Vec<(TopicPartitionReplica, ReplicaLogDirInfo)>> {
        let replicas: Vec<TopicPartitionReplica> = replicas.into_iter().collect();
        if replicas.is_empty() {
            return Ok(Vec::new());
        }
        let mut infos: HashMap<String, HashMap<(i32, i32), ReplicaLogDirInfo>> = HashMap::new();
        let ids = replica_broker_ids(&replicas).await;
        if ids.len() <= 1 {
            for broker_id in ids {
                let topics = describable_topics_for_broker_cooperative(&replicas, broker_id).await;
                let deadline = Instant::now()
                    .checked_add(timeout)
                    .ok_or_else(|| Error::protocol("DescribeLogDirs deadline overflow"))?;
                self.ensure_broker(broker_id, deadline).await?;
                let prepared = self.negotiated_on(broker_id, DESCRIBE_LOG_DIRS, 1, 5);
                let mut encoded = BytesMut::new();
                if let Some(version) = prepared {
                    encode_describe_log_dirs_named_cooperative(
                        &mut encoded,
                        version,
                        Some(topics.as_slice()),
                    )
                    .await?;
                }
                let resp = self
                    .describe_log_dirs_with(Some(broker_id), timeout, |output, version| {
                        if prepared == Some(version) {
                            output.extend_from_slice(&encoded);
                            Ok(())
                        } else {
                            encode_describe_log_dirs_named(output, version, Some(topics.as_slice()))
                        }
                    })
                    .await?;
                remember_replica_dirs_cooperative(&mut infos, &replicas, broker_id, &resp).await?;
            }
        } else {
            let deadline = Instant::now()
                .checked_add(timeout)
                .ok_or_else(|| Error::protocol("DescribeLogDirs deadline overflow"))?;
            for id in &ids {
                self.ensure_broker(*id, deadline).await?;
            }
            let mut topics_of: HashMap<i32, Vec<(&str, Vec<i32>)>> = HashMap::new();
            for id in &ids {
                let _ = topics_of.insert(
                    *id,
                    describable_topics_for_broker_cooperative(&replicas, *id).await,
                );
            }
            let mut prepared = HashMap::new();
            for id in &ids {
                let Some(version) = self.negotiated_on(*id, DESCRIBE_LOG_DIRS, 1, 5) else {
                    continue;
                };
                let topics = topics_of.get(id).map(Vec::as_slice).unwrap_or(&[]);
                let mut payload = BytesMut::new();
                encode_describe_log_dirs_named_cooperative(&mut payload, version, Some(topics))
                    .await?;
                let _previous = prepared.insert(*id, (version, payload.freeze()));
            }
            let mut finished = self
                .exchange_leaders(&ids, deadline, |_admin, node, conn, _timeout| {
                    let version = conn.negotiated(DESCRIBE_LOG_DIRS, 1, 5).ok_or_else(|| {
                        Error::Unsupported("broker does not support DescribeLogDirs v1-5".into())
                    })?;
                    if let Some((prepared_version, payload)) = prepared.get(&node) {
                        if *prepared_version == version {
                            return Ok(LeaderFrame::ready(
                                DESCRIBE_LOG_DIRS,
                                version,
                                payload.clone(),
                            ));
                        }
                    }
                    let topics = topics_of.get(&node).map(Vec::as_slice).unwrap_or(&[]);
                    let mut payload = BytesMut::new();
                    encode_describe_log_dirs_named(&mut payload, version, Some(topics))?;
                    Ok(LeaderFrame::ready(
                        DESCRIBE_LOG_DIRS,
                        version,
                        payload.freeze(),
                    ))
                })
                .await;
            for broker_id in ids {
                let Some((version, body)) = finished.remove(&broker_id) else {
                    return Err(Error::Timeout);
                };
                let resp = match body {
                    Err(error) if error.is_retriable() && !matches!(error, Error::Timeout) => {
                        self.discard_node_conn(broker_id).await;
                        let topics =
                            describable_topics_for_broker_cooperative(&replicas, broker_id).await;
                        let prepared = self.negotiated_on(broker_id, DESCRIBE_LOG_DIRS, 1, 5);
                        let mut encoded = BytesMut::new();
                        if let Some(version) = prepared {
                            encode_describe_log_dirs_named_cooperative(
                                &mut encoded,
                                version,
                                Some(topics.as_slice()),
                            )
                            .await?;
                        }
                        self.describe_log_dirs_with(Some(broker_id), timeout, |output, version| {
                            if prepared == Some(version) {
                                output.extend_from_slice(&encoded);
                                Ok(())
                            } else {
                                encode_describe_log_dirs_named(
                                    output,
                                    version,
                                    Some(topics.as_slice()),
                                )
                            }
                        })
                        .await?
                    }
                    Err(error) => return Err(error),
                    Ok(body) => {
                        let mut cursor = body.as_ref();
                        let response =
                            decode_describe_log_dirs_response_cooperative(&mut cursor, version)
                                .await?;
                        if !cursor.is_empty() {
                            return Err(Error::protocol("trailing DescribeLogDirs response bytes"));
                        }
                        response
                    }
                };
                remember_replica_dirs_cooperative(&mut infos, &replicas, broker_id, &resp).await?;
            }
        }
        let mut out = Vec::with_capacity(replicas.len());
        for r in replicas {
            let info = infos
                .get(r.topic.as_str())
                .and_then(|parts| parts.get(&(r.partition, r.broker_id)))
                .cloned()
                .unwrap_or_else(ReplicaLogDirInfo::unknown);
            out.push((r, info));
        }
        Ok(out)
    }

    /// Log directories on these brokers (Java
    /// `Admin.describeLogDirs(Collection<Integer>)`).
    ///
    /// Sends DescribeLogDirs with a null topic array (all dirs) to
    /// each broker. Duplicate ids are sent once, in first-seen order.
    /// Empty input is a no-op. Unknown broker ids refresh Metadata
    /// then fail. This is not [`Self::describe_log_dirs`] (bootstrap,
    /// optional topic filter) and not
    /// [`Self::describe_replica_log_dirs`]. DescribeLogDirs has no
    /// TimeoutMs; the RPC deadline is [`AdminConfig::request_timeout`].
    /// For a one-shot deadline, use
    /// [`Self::describe_broker_log_dirs_timeout`].
    pub async fn describe_broker_log_dirs(
        &mut self,
        brokers: impl IntoIterator<Item = i32>,
    ) -> Result<Vec<(i32, DescribeLogDirsResponse)>> {
        let timeout = self.cfg.request_timeout;
        self.describe_broker_log_dirs_timeout(brokers, timeout)
            .await
    }

    /// [`Self::describe_broker_log_dirs`] with a one-shot RPC deadline
    /// (Java `describeLogDirs` plus `DescribeLogDirsOptions.timeoutMs`).
    ///
    /// DescribeLogDirs has no TimeoutMs; `timeout` is the RPC deadline
    /// for each broker hop.
    pub async fn describe_broker_log_dirs_timeout(
        &mut self,
        brokers: impl IntoIterator<Item = i32>,
        timeout: Duration,
    ) -> Result<Vec<(i32, DescribeLogDirsResponse)>> {
        let broker_ids: Vec<i32> = brokers.into_iter().collect();
        let ids = first_seen_i32(&broker_ids).await;
        if ids.is_empty() {
            return Ok(Vec::new());
        }
        if ids.len() == 1 {
            let mut out = Vec::with_capacity(1);
            for broker_id in ids {
                let resp = self.describe_log_dirs_on(broker_id, None, timeout).await?;
                out.push((broker_id, resp));
            }
            return Ok(out);
        }
        let deadline = Instant::now()
            .checked_add(timeout)
            .ok_or_else(|| Error::protocol("DescribeLogDirs deadline overflow"))?;
        for id in &ids {
            self.ensure_broker(*id, deadline).await?;
        }
        let request = DescribeLogDirsRequest::new(None);
        let mut finished = self
            .exchange_leaders(&ids, deadline, |_admin, _node, conn, _timeout| {
                let version = conn.negotiated(DESCRIBE_LOG_DIRS, 1, 5).ok_or_else(|| {
                    Error::Unsupported("broker does not support DescribeLogDirs v1-5".into())
                })?;
                let mut payload = BytesMut::new();
                encode_describe_log_dirs_request(&mut payload, version, &request)?;
                Ok(LeaderFrame::ready(
                    DESCRIBE_LOG_DIRS,
                    version,
                    payload.freeze(),
                ))
            })
            .await;
        let mut out = Vec::with_capacity(ids.len());
        for broker_id in ids {
            let Some((version, body)) = finished.remove(&broker_id) else {
                return Err(Error::Timeout);
            };
            match body {
                Err(error) if error.is_retriable() && !matches!(error, Error::Timeout) => {
                    self.discard_node_conn(broker_id).await;
                    let resp = self.describe_log_dirs_on(broker_id, None, timeout).await?;
                    out.push((broker_id, resp));
                }
                Err(error) => return Err(error),
                Ok(body) => {
                    let mut cursor = body.as_ref();
                    let response =
                        decode_describe_log_dirs_response_cooperative(&mut cursor, version).await?;
                    if !cursor.is_empty() {
                        return Err(Error::protocol("trailing DescribeLogDirs response bytes"));
                    }
                    out.push((broker_id, response));
                }
            }
        }
        Ok(out)
    }

    async fn describe_log_dirs_on(
        &mut self,
        node: i32,
        topics: Option<Vec<DescribableLogDirTopic>>,
        timeout: Duration,
    ) -> Result<DescribeLogDirsResponse> {
        self.describe_log_dirs_at(Some(node), topics, timeout).await
    }

    // The socket's handshake selects DescribeLogDirs. A replacement socket
    // negotiates again. Connection, auth, request, and retry waits share one budget.
    async fn describe_log_dirs_at(
        &mut self,
        node: Option<i32>,
        topics: Option<Vec<DescribableLogDirTopic>>,
        timeout: Duration,
    ) -> Result<DescribeLogDirsResponse> {
        let request = DescribeLogDirsRequest::new(topics);
        self.describe_log_dirs_with(node, timeout, |output, version| {
            encode_describe_log_dirs_request(output, version, &request)
        })
        .await
    }

    async fn describe_log_dirs_with(
        &mut self,
        node: Option<i32>,
        timeout: Duration,
        encode: impl Fn(&mut BytesMut, i16) -> Result<()>,
    ) -> Result<DescribeLogDirsResponse> {
        if timeout.is_zero() {
            return Err(Error::Timeout);
        }
        let deadline = Instant::now()
            .checked_add(timeout)
            .ok_or_else(|| Error::protocol("DescribeLogDirs deadline overflow"))?;
        if let Some(node) = node {
            self.ensure_broker(node, deadline).await?;
        }
        let mut attempt = 0;
        loop {
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            let result = async {
                if let Some(node) = node {
                    self.prepare_node_until(node, deadline).await?;
                } else {
                    self.ensure_bootstrap(deadline).await?;
                }
                let version = if let Some(node) = node {
                    self.negotiated_on(node, DESCRIBE_LOG_DIRS, 1, 5)
                } else {
                    self.negotiated(DESCRIBE_LOG_DIRS, 1, 5)
                }
                .ok_or_else(|| {
                    Error::Unsupported("broker does not support DescribeLogDirs v1-5".into())
                })?;
                let remaining = deadline.saturating_duration_since(Instant::now());
                let body = if let Some(node) = node {
                    self.roundtrip_known_node(
                        node,
                        deadline,
                        DESCRIBE_LOG_DIRS,
                        version,
                        |output| encode(output, version),
                        remaining,
                    )
                    .await?
                } else {
                    self.conn
                        .roundtrip(
                            DESCRIBE_LOG_DIRS,
                            version,
                            |output| encode(output, version),
                            remaining,
                        )
                        .await?
                };
                let mut cursor = body.as_ref();
                let response =
                    decode_describe_log_dirs_response_cooperative(&mut cursor, version).await?;
                if !cursor.is_empty() {
                    return Err(Error::protocol("trailing DescribeLogDirs response bytes"));
                }
                Ok(response)
            }
            .await;
            match result {
                Err(error) if node.is_some() && error.is_retriable() => {
                    if let Some(node) = node {
                        self.drop_node_conn(node).await;
                    }
                    self.wait_retry(&mut attempt, deadline).await?;
                }
                other => return other,
            }
        }
    }

    async fn alter_replica_log_dirs_on(
        &mut self,
        node: i32,
        dirs: &[BorrowedAlterReplicaLogDir<'_>],
        timeout: Duration,
    ) -> Result<AlterReplicaLogDirsResponse> {
        let version = self.alter_replica_log_dirs_version.ok_or_else(|| {
            Error::Unsupported("broker does not support AlterReplicaLogDirs".into())
        })?;
        let deadline = Instant::now() + timeout;
        let mut attempt = 0u32;
        let mut encoded = BytesMut::new();
        encode_alter_replica_log_dirs_named_cooperative(&mut encoded, version, dirs).await?;
        loop {
            let body = {
                self.roundtrip_known_node(
                    node,
                    deadline,
                    ALTER_REPLICA_LOG_DIRS,
                    version,
                    |buf| {
                        buf.extend_from_slice(&encoded);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await
            };
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.drop_node_conn(node).await;
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            return decode_alter_replica_log_dirs_response_cooperative(&mut body.clone(), version)
                .await;
        }
    }

    async fn ensure_broker(&mut self, node: i32, deadline: Instant) -> Result<()> {
        if !self.cluster.brokers.contains_key(&node) {
            self.refresh_broker_directory(deadline).await?;
        }
        if self.cluster.brokers.contains_key(&node) {
            Ok(())
        } else {
            Err(Error::protocol(format!("unknown broker {node}")))
        }
    }

    /// Create a delegation token (CreateDelegationToken api 38, KIP-48 /
    /// KIP-373; v1–v3, classic at v1, flexible from v2, owner /
    /// requester principals v3).
    ///
    /// Lands on the connected broker (bootstrap is fine). Official
    /// Apache JSON listeners are `broker` and `controller`. Official
    /// JSON lists no `errorCodes`. Official Java
    /// `KafkaApis.handleCreateTokenRequest` validates the connection
    /// then `forwardToController` (broker-side envelope, not a client
    /// hop). Official Java `KafkaAdminClient.createDelegationToken`
    /// uses `LeastLoadedNodeProvider`. Official handler writes
    /// `DELEGATION_TOKEN_REQUEST_NOT_ALLOWED` (64) onto the top-level
    /// ErrorCode when the channel is not allowed. `NOT_COORDINATOR`
    /// (16) is not listed. `NOT_CONTROLLER` (41) is not listed. This
    /// is not a group-coordinator hop, not a controller hop, and not
    /// a partition-leader hop: there is no FindCoordinator, no
    /// Metadata `controller_id` lookup, no `NOT_CONTROLLER` (41)
    /// retry, and no `NOT_LEADER_OR_FOLLOWER` (6) hop. Top-level
    /// `error_code` is the INT16 at bytes 0–1, first field — not after
    /// throttle, not a first-renewer field, and not a first-token
    /// field. Fixture principal / lifetime only; this is not a token
    /// store. Kafka 4.0 `validVersions` is `1-3`. This crate speaks
    /// 1–3. v0 and v4+ are not spoken. v1–v2 omit owner on the wire
    /// (decode fills `None`) and omit requester (decode fills empty).
    /// CreateDelegationToken has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::create_delegation_token_timeout`]. Optional at [`Self::new`]
    /// (Kafka 1.1+ / KIP-48); a broker that omits api 38 returns
    /// [`Error::Unsupported`].
    pub async fn create_delegation_token(
        &mut self,
        req: CreateDelegationTokenRequest,
    ) -> Result<CreateDelegationTokenResponse> {
        let timeout = self.cfg.request_timeout;
        self.create_delegation_token_timeout(req, timeout).await
    }

    /// [`Self::create_delegation_token`] with a one-shot RPC deadline (Java
    /// `CreateDelegationTokenOptions.timeoutMs`).
    ///
    /// CreateDelegationToken has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn create_delegation_token_timeout(
        &mut self,
        req: CreateDelegationTokenRequest,
        timeout: Duration,
    ) -> Result<CreateDelegationTokenResponse> {
        let version = self.create_delegation_token_version.ok_or_else(|| {
            Error::Unsupported("broker does not support CreateDelegationToken".into())
        })?;
        let mut payload = BytesMut::new();
        encode_create_delegation_token_request_cooperative(&mut payload, version, &req).await?;
        let body = self
            .roundtrip_bootstrap(
                CREATE_DELEGATION_TOKEN,
                version,
                |buf| {
                    buf.extend_from_slice(&payload);
                    Ok(())
                },
                timeout,
            )
            .await?;
        decode_create_delegation_token_response(&mut body.clone(), version)
    }

    /// Create a delegation token with default options (Java
    /// `Admin.createDelegationToken()`).
    ///
    /// Same wire as [`Self::create_delegation_token`] with
    /// [`CreateDelegationTokenRequest::default`] (request principal,
    /// empty renewers, `max_lifetime_ms = -1`).
    pub async fn create_delegation_token_default(
        &mut self,
    ) -> Result<CreateDelegationTokenResponse> {
        let timeout = self.cfg.request_timeout;
        self.create_delegation_token_default_timeout(timeout).await
    }

    /// [`Self::create_delegation_token_default`] with a one-shot RPC
    /// deadline (Java `CreateDelegationTokenOptions.timeoutMs`).
    pub async fn create_delegation_token_default_timeout(
        &mut self,
        timeout: Duration,
    ) -> Result<CreateDelegationTokenResponse> {
        self.create_delegation_token_timeout(CreateDelegationTokenRequest::default(), timeout)
            .await
    }

    /// Renew a delegation token (RenewDelegationToken api 39, KIP-48 /
    /// KIP-373; v1–v2, classic at v1, flexible from v2).
    ///
    /// Lands on the connected broker (bootstrap is fine). Official
    /// Apache JSON listeners are `broker` and `controller`. Official
    /// JSON lists no `errorCodes`. Official Java
    /// `KafkaApis.handleRenewTokenRequest` validates the connection
    /// then `forwardToController` (broker-side envelope, not a client
    /// hop). Official Java `KafkaAdminClient.renewDelegationToken`
    /// uses `LeastLoadedNodeProvider`. Official handler writes
    /// `DELEGATION_TOKEN_REQUEST_NOT_ALLOWED` (64) onto the top-level
    /// ErrorCode when the channel is not allowed. `NOT_COORDINATOR`
    /// (16) is not listed. `NOT_CONTROLLER` (41) is not listed. This
    /// is not a group-coordinator hop, not a controller hop, and not
    /// a partition-leader hop: there is no FindCoordinator, no
    /// Metadata `controller_id` lookup, no `NOT_CONTROLLER` (41)
    /// retry, and no `NOT_LEADER_OR_FOLLOWER` (6) hop. Top-level
    /// `error_code` is the INT16 at bytes 0–1, first field — not after
    /// throttle and not a first-token field. Fixture hmac / period
    /// only; this is not a token store. Kafka 4.0 `validVersions` is
    /// `1-2`. This crate speaks 1–2. v0 and v3+ are not spoken. Same
    /// fields on v1 and v2. Do not copy CreateDelegationToken just
    /// because it is the previous slice. RenewDelegationToken has no
    /// TimeoutMs; the RPC deadline is [`AdminConfig::request_timeout`].
    /// For a one-shot deadline, use [`Self::renew_delegation_token_timeout`].
    /// Optional at [`Self::new`] (Kafka 1.1+ / KIP-48); a broker that
    /// omits api 39 returns [`Error::Unsupported`].
    pub async fn renew_delegation_token(
        &mut self,
        req: RenewDelegationTokenRequest,
    ) -> Result<RenewDelegationTokenResponse> {
        let timeout = self.cfg.request_timeout;
        self.renew_delegation_token_timeout(req, timeout).await
    }

    /// [`Self::renew_delegation_token`] with a one-shot RPC deadline (Java
    /// `RenewDelegationTokenOptions.timeoutMs`).
    ///
    /// RenewDelegationToken has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn renew_delegation_token_timeout(
        &mut self,
        req: RenewDelegationTokenRequest,
        timeout: Duration,
    ) -> Result<RenewDelegationTokenResponse> {
        let version = self.renew_delegation_token_version.ok_or_else(|| {
            Error::Unsupported("broker does not support RenewDelegationToken".into())
        })?;
        let body = self
            .roundtrip_bootstrap(
                RENEW_DELEGATION_TOKEN,
                version,
                |buf| encode_renew_delegation_token_request(buf, version, &req),
                timeout,
            )
            .await?;
        decode_renew_delegation_token_response(&mut body.clone(), version)
    }

    /// Renew a delegation token by HMAC (Java
    /// `Admin.renewDelegationToken(byte[])`).
    ///
    /// `renew_period_ms` is `-1` (Java `RenewDelegationTokenOptions`
    /// default: broker default period).
    pub async fn renew_delegation_token_hmac(
        &mut self,
        hmac: impl AsRef<[u8]>,
    ) -> Result<RenewDelegationTokenResponse> {
        let timeout = self.cfg.request_timeout;
        self.renew_delegation_token_hmac_timeout(hmac, timeout)
            .await
    }

    /// [`Self::renew_delegation_token_hmac`] with a one-shot RPC deadline
    /// (Java `RenewDelegationTokenOptions.timeoutMs`).
    pub async fn renew_delegation_token_hmac_timeout(
        &mut self,
        hmac: impl AsRef<[u8]>,
        timeout: Duration,
    ) -> Result<RenewDelegationTokenResponse> {
        let version = self.renew_delegation_token_version.ok_or_else(|| {
            Error::Unsupported("broker does not support RenewDelegationToken".into())
        })?;
        let hmac = hmac.as_ref();
        let body = self
            .roundtrip_bootstrap(
                RENEW_DELEGATION_TOKEN,
                version,
                |buf| encode_renew_delegation_token_hmac(buf, version, hmac, -1),
                timeout,
            )
            .await?;
        decode_renew_delegation_token_response(&mut body.clone(), version)
    }

    /// Expire a delegation token (ExpireDelegationToken api 40, KIP-48 /
    /// KIP-373; v1–v2, classic at v1, flexible from v2).
    ///
    /// Lands on the connected broker (bootstrap is fine). Official
    /// Apache JSON listeners are `broker` and `controller`. Official
    /// JSON lists no `errorCodes`. Official Java
    /// `KafkaApis.handleExpireTokenRequest` validates the connection
    /// then `forwardToController` (broker-side envelope, not a client
    /// hop). Official Java `KafkaAdminClient.expireDelegationToken`
    /// uses `LeastLoadedNodeProvider`. Official handler writes
    /// `DELEGATION_TOKEN_REQUEST_NOT_ALLOWED` (64) onto the top-level
    /// ErrorCode when the channel is not allowed. `NOT_COORDINATOR`
    /// (16) is not listed. `NOT_CONTROLLER` (41) is not listed. This
    /// is not a group-coordinator hop, not a controller hop, and not
    /// a partition-leader hop: there is no FindCoordinator, no
    /// Metadata `controller_id` lookup, no `NOT_CONTROLLER` (41)
    /// retry, and no `NOT_LEADER_OR_FOLLOWER` (6) hop. Top-level
    /// `error_code` is the INT16 at bytes 0–1, first field — not after
    /// throttle and not a first-token field. Fixture hmac / period
    /// only; this is not a token store. Kafka 4.0 `validVersions` is
    /// `1-2`. This crate speaks 1–2. v0 and v3+ are not spoken. Same
    /// fields on v1 and v2. Do not copy RenewDelegationToken just
    /// because it is the previous slice. ExpireDelegationToken has no
    /// TimeoutMs; the RPC deadline is [`AdminConfig::request_timeout`].
    /// For a one-shot deadline, use [`Self::expire_delegation_token_timeout`].
    /// Optional at [`Self::new`] (Kafka 1.1+ / KIP-48); a broker that
    /// omits api 40 returns [`Error::Unsupported`].
    pub async fn expire_delegation_token(
        &mut self,
        req: ExpireDelegationTokenRequest,
    ) -> Result<ExpireDelegationTokenResponse> {
        let timeout = self.cfg.request_timeout;
        self.expire_delegation_token_timeout(req, timeout).await
    }

    /// [`Self::expire_delegation_token`] with a one-shot RPC deadline (Java
    /// `ExpireDelegationTokenOptions.timeoutMs`).
    ///
    /// ExpireDelegationToken has no TimeoutMs; `timeout` is the RPC deadline.
    pub async fn expire_delegation_token_timeout(
        &mut self,
        req: ExpireDelegationTokenRequest,
        timeout: Duration,
    ) -> Result<ExpireDelegationTokenResponse> {
        let version = self.expire_delegation_token_version.ok_or_else(|| {
            Error::Unsupported("broker does not support ExpireDelegationToken".into())
        })?;
        let body = self
            .roundtrip_bootstrap(
                EXPIRE_DELEGATION_TOKEN,
                version,
                |buf| encode_expire_delegation_token_request(buf, version, &req),
                timeout,
            )
            .await?;
        decode_expire_delegation_token_response(&mut body.clone(), version)
    }

    /// Expire a delegation token by HMAC (Java
    /// `Admin.expireDelegationToken(byte[])`).
    ///
    /// `expiry_time_period_ms` is `-1` (Java default: expire immediately).
    pub async fn expire_delegation_token_hmac(
        &mut self,
        hmac: impl AsRef<[u8]>,
    ) -> Result<ExpireDelegationTokenResponse> {
        let timeout = self.cfg.request_timeout;
        self.expire_delegation_token_hmac_timeout(hmac, timeout)
            .await
    }

    /// [`Self::expire_delegation_token_hmac`] with a one-shot RPC deadline
    /// (Java `ExpireDelegationTokenOptions.timeoutMs`).
    pub async fn expire_delegation_token_hmac_timeout(
        &mut self,
        hmac: impl AsRef<[u8]>,
        timeout: Duration,
    ) -> Result<ExpireDelegationTokenResponse> {
        let version = self.expire_delegation_token_version.ok_or_else(|| {
            Error::Unsupported("broker does not support ExpireDelegationToken".into())
        })?;
        let hmac = hmac.as_ref();
        let body = self
            .roundtrip_bootstrap(
                EXPIRE_DELEGATION_TOKEN,
                version,
                |buf| encode_expire_delegation_token_hmac(buf, version, hmac, -1),
                timeout,
            )
            .await?;
        decode_expire_delegation_token_response(&mut body.clone(), version)
    }

    /// Describe delegation tokens (DescribeDelegationToken api 41,
    /// KIP-48 / KIP-373; v1–v3, classic at v1, flexible from v2,
    /// TokenRequester v3).
    ///
    /// Lands on the connected broker (bootstrap is fine). Official
    /// Apache JSON listeners are `broker` and `controller`. Official
    /// JSON lists no `errorCodes`. Official Java
    /// `KafkaApis.handleDescribeTokensRequest` answers locally
    /// (`allowTokenRequests` → `DELEGATION_TOKEN_REQUEST_NOT_ALLOWED`
    /// (64); it does not `forwardToController`). Official Java
    /// `KafkaAdminClient.describeDelegationToken` uses
    /// `LeastLoadedNodeProvider`. Official handler writes
    /// `DELEGATION_TOKEN_REQUEST_NOT_ALLOWED` (64) onto the top-level
    /// ErrorCode when the channel is not allowed. `NOT_COORDINATOR`
    /// (16) is not listed. `NOT_CONTROLLER` (41) is not listed.
    /// apiKey 41 is not error code 41 and is not a hop. This is not a
    /// group-coordinator hop, not a controller hop, and not a
    /// partition-leader hop: there is no FindCoordinator, no
    /// Metadata `controller_id` lookup, no `NOT_CONTROLLER` (41)
    /// retry, and no `NOT_LEADER_OR_FOLLOWER` (6) hop. Top-level
    /// `error_code` is the INT16 at bytes 0–1, first field — not after
    /// throttle and not a first-token field. Fixture owners only;
    /// this is not a token store. Kafka 4.0 `validVersions` is `1-3`.
    /// This crate speaks 1–3. v0 and v4+ are not spoken. Request
    /// Owners is the same on v1–v3. v1–v2 omit TokenRequester on each
    /// token (decode fills empty). Do not copy ExpireDelegationToken
    /// just because it is the previous slice. DescribeDelegationToken
    /// has no TimeoutMs; the RPC deadline is
    /// [`AdminConfig::request_timeout`]. For a one-shot deadline, use
    /// [`Self::describe_delegation_token_timeout`]. Optional at
    /// [`Self::new`] (Kafka 1.1+ / KIP-48); a broker that omits api 41
    /// returns [`Error::Unsupported`].
    pub async fn describe_delegation_token(
        &mut self,
        req: DescribeDelegationTokenRequest,
    ) -> Result<DescribeDelegationTokenResponse> {
        let timeout = self.cfg.request_timeout;
        self.describe_delegation_token_timeout(req, timeout).await
    }

    /// [`Self::describe_delegation_token`] with a one-shot RPC deadline
    /// (Java `DescribeDelegationTokenOptions.timeoutMs`).
    ///
    /// DescribeDelegationToken has no TimeoutMs; `timeout` is the RPC
    /// deadline.
    pub async fn describe_delegation_token_timeout(
        &mut self,
        req: DescribeDelegationTokenRequest,
        timeout: Duration,
    ) -> Result<DescribeDelegationTokenResponse> {
        let version = self.describe_delegation_token_version.ok_or_else(|| {
            Error::Unsupported("broker does not support DescribeDelegationToken".into())
        })?;
        let mut payload = BytesMut::new();
        encode_describe_delegation_token_request_cooperative(&mut payload, version, &req).await?;
        let body = self
            .roundtrip_bootstrap(
                DESCRIBE_DELEGATION_TOKEN,
                version,
                |buf| {
                    buf.extend_from_slice(&payload);
                    Ok(())
                },
                timeout,
            )
            .await?;
        decode_describe_delegation_token_response_cooperative(&mut body.clone(), version).await
    }

    /// Describe visible delegation tokens (Java
    /// `Admin.describeDelegationToken()`).
    ///
    /// Same wire as [`Self::describe_delegation_token`] with owners
    /// `None` (Java `DescribeDelegationTokenOptions` default).
    pub async fn describe_delegation_tokens(&mut self) -> Result<DescribeDelegationTokenResponse> {
        let timeout = self.cfg.request_timeout;
        self.describe_delegation_tokens_timeout(timeout).await
    }

    /// [`Self::describe_delegation_tokens`] with a one-shot RPC deadline
    /// (Java `DescribeDelegationTokenOptions.timeoutMs`).
    pub async fn describe_delegation_tokens_timeout(
        &mut self,
        timeout: Duration,
    ) -> Result<DescribeDelegationTokenResponse> {
        self.describe_delegation_token_timeout(DescribeDelegationTokenRequest::default(), timeout)
            .await
    }

    /// Store a FindCoordinator host when it can be dialed.
    ///
    /// A missing or unusable host leaves the broker map unchanged so the
    /// caller can load the directory.
    async fn remember_coordinator(&mut self, node: i32, host: &str, port: i32) -> Result<bool> {
        let Some(address) = crate::cluster::dial_address(host, port) else {
            return Ok(false);
        };
        if node < 0 {
            return Ok(false);
        }
        if !self.cluster.brokers.contains_key(&node) && self.cluster.brokers.len() >= 256 {
            return Err(Error::protocol("coordinator broker limit"));
        }
        if self.cluster.brokers.get(&node) != Some(&address) {
            if let Some(mut conn) = self.conns.remove(&node) {
                conn.inner.close();
                conn.inner.release_if_closed().await;
            }
            let _old = self.cluster.brokers.insert(node, address);
        }
        Ok(true)
    }

    async fn ensure_coordinator_node(
        &mut self,
        node: i32,
        host: &str,
        port: i32,
        deadline: Instant,
    ) -> Result<()> {
        if self.remember_coordinator(node, host, port).await? {
            return Ok(());
        }
        if !self.cluster.brokers.contains_key(&node) {
            self.refresh_broker_directory(deadline).await?;
        }
        if !self.cluster.brokers.contains_key(&node) {
            return Err(Error::protocol("invalid coordinator address"));
        }
        Ok(())
    }

    async fn discover_group_coord(&mut self, group_id: &str, deadline: Instant) -> Result<i32> {
        if group_id.len() > i16::MAX as usize {
            return Err(Error::protocol("coordinator key exceeds discovery limit"));
        }
        if self.find_coord_version.is_none() {
            return Err(Error::Unsupported(
                "broker does not support FindCoordinator v0-6".into(),
            ));
        }
        let mut attempt = 0u32;
        loop {
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            if attempt >= 8 {
                return Err(Error::protocol("FindCoordinator retry limit"));
            }
            self.ensure_bootstrap(deadline).await?;
            let version = self.find_coord_version.ok_or_else(|| {
                Error::Unsupported("broker does not support FindCoordinator v0-6".into())
            })?;
            let body = self
                .roundtrip_bootstrap(
                    FIND_COORDINATOR,
                    version,
                    |buf| {
                        encode_find_coordinator_request_typed(
                            buf,
                            version,
                            group_id,
                            COORDINATOR_GROUP,
                        )
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await;
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let (err, node, host, port) =
                decode_find_coordinator_response(&mut body.clone(), version)?;
            if err == 0 {
                self.ensure_coordinator_node(node, &host, port, deadline)
                    .await?;
                return Ok(node);
            }
            if error::coordinator_retriable(err) {
                self.wait_retry(&mut attempt, deadline).await?;
                continue;
            }
            return Err(Error::broker(err, "FindCoordinator"));
        }
    }

    async fn discover_group_coords(
        &mut self,
        group_ids: &[&str],
        deadline: Instant,
    ) -> Result<HashMap<String, i32>> {
        self.discover_coords(group_ids, COORDINATOR_GROUP, deadline)
            .await
    }

    async fn discover_txn_coords(
        &mut self,
        transactional_ids: &[&str],
        deadline: Instant,
    ) -> Result<HashMap<String, i32>> {
        self.discover_coords(transactional_ids, COORDINATOR_TRANSACTION, deadline)
            .await
    }

    async fn discover_coords(
        &mut self,
        keys: &[&str],
        key_type: i8,
        deadline: Instant,
    ) -> Result<HashMap<String, i32>> {
        let uniq = unique_in_order(keys).await;
        if uniq.is_empty() {
            return Ok(HashMap::new());
        }
        let version = self.find_coord_version.ok_or_else(|| {
            Error::Unsupported("broker does not support FindCoordinator v1-6".into())
        })?;
        if version < 4 {
            let mut out = HashMap::new();
            for k in &uniq {
                let node = if key_type == COORDINATOR_TRANSACTION {
                    self.discover_txn_coord(k, deadline).await?
                } else {
                    self.discover_group_coord(k, deadline).await?
                };
                let _prev = out.insert((*k).to_owned(), node);
            }
            return Ok(out);
        }
        let mut attempt = 0u32;
        let mut encoded = BytesMut::new();
        encode_find_coordinator_request_keys_cooperative(&mut encoded, version, &uniq, key_type)
            .await?;
        loop {
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            let body = self
                .roundtrip_bootstrap(
                    FIND_COORDINATOR,
                    version,
                    |buf| {
                        buf.extend_from_slice(&encoded);
                        Ok(())
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await;
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let (coords, ..) = decode_find_coordinator_response_coordinators_cooperative(
                &mut body.clone(),
                version,
            )
            .await?;
            let mut by_key = index_coordinators(coords).await;
            let slots = take_coordinator_slots(&mut by_key, &uniq).await?;
            let mut retry = false;
            let mut out = HashMap::new();
            let mut walked = 0usize;
            for (k, (err, node, host, port)) in uniq.iter().zip(slots) {
                if err == 0 {
                    self.ensure_coordinator_node(node, &host, port, deadline)
                        .await?;
                    let _prev = out.insert((*k).to_owned(), node);
                } else if error::coordinator_retriable(err) {
                    retry = true;
                } else {
                    return Err(Error::broker(err, (*k).to_owned()));
                }
                walked = walked.saturating_add(1);
                if walked == 8 * 1024 {
                    walked = 0;
                    tokio::task::yield_now().await;
                }
            }
            if retry {
                self.wait_retry(&mut attempt, deadline).await?;
                continue;
            }
            return Ok(out);
        }
    }

    async fn group_coord_nodes<T: AsRef<str>>(
        &mut self,
        ids: &[T],
        pending: &[usize],
        deadline: Instant,
    ) -> Result<HashMap<i32, Vec<usize>>> {
        let need = first_seen_missing_ids_cooperative(ids, pending, &self.group_coords).await;
        if !need.is_empty() {
            let (mut known_nodes, mut seen_nodes) =
                cached_coordinator_nodes(ids, pending, &self.group_coords).await;
            for node in self.group_coord_redial.drain(..) {
                if seen_nodes.insert(node) {
                    known_nodes.push(node);
                }
            }
            let dials = self.take_broker_dials(&known_nodes).await;
            let found = if dials.is_empty() {
                self.discover_group_coords(&need, deadline).await?
            } else {
                let cfg = self.cfg.clone();
                let stats = Arc::clone(&self.stats);
                let dialed = Self::dial_admin_nodes(cfg, stats, dials, deadline);
                let found = self.discover_group_coords(&need, deadline);
                let (dialed, found) = tokio::join!(dialed, found);
                self.store_admin_dials(dialed);
                found?
            };
            self.group_coords.extend(found);
        }
        group_ids_by_coordinator(ids, pending, &self.group_coords, "missing group id").await
    }

    async fn invalidate_group_coord_idxs<T: AsRef<str>>(
        &mut self,
        ids: &[T],
        idxs: &[usize],
        node: i32,
    ) {
        if node >= 0 && !self.group_coord_redial.contains(&node) {
            self.group_coord_redial.push(node);
        }
        if let Some(mut conn) = self.conns.remove(&node) {
            conn.inner.close();
            conn.inner.release_if_closed().await;
        }
        for &i in idxs {
            if let Some(id) = ids.get(i) {
                let _ = self.group_coords.remove(id.as_ref());
            }
        }
    }

    async fn txn_coord_nodes<T: AsRef<str>>(
        &mut self,
        ids: &[T],
        pending: &[usize],
        deadline: Instant,
    ) -> Result<HashMap<i32, Vec<usize>>> {
        let need = first_seen_missing_ids_cooperative(ids, pending, &self.txn_coords).await;
        if !need.is_empty() {
            let (mut known_nodes, mut seen_nodes) =
                cached_coordinator_nodes(ids, pending, &self.txn_coords).await;
            for node in self.txn_coord_redial.drain(..) {
                if seen_nodes.insert(node) {
                    known_nodes.push(node);
                }
            }
            let dials = self.take_broker_dials(&known_nodes).await;
            let found = if dials.is_empty() {
                self.discover_txn_coords(&need, deadline).await?
            } else {
                let cfg = self.cfg.clone();
                let stats = Arc::clone(&self.stats);
                let dialed = Self::dial_admin_nodes(cfg, stats, dials, deadline);
                let found = self.discover_txn_coords(&need, deadline);
                let (dialed, found) = tokio::join!(dialed, found);
                self.store_admin_dials(dialed);
                found?
            };
            self.txn_coords.extend(found);
        }
        group_ids_by_coordinator(ids, pending, &self.txn_coords, "missing transactional id").await
    }

    async fn invalidate_txn_coord_idxs<T: AsRef<str>>(
        &mut self,
        ids: &[T],
        idxs: &[usize],
        node: i32,
    ) {
        if node >= 0 && !self.txn_coord_redial.contains(&node) {
            self.txn_coord_redial.push(node);
        }
        if let Some(mut conn) = self.conns.remove(&node) {
            conn.inner.close();
            conn.inner.release_if_closed().await;
        }
        for &i in idxs {
            if let Some(id) = ids.get(i) {
                let _ = self.txn_coords.remove(id.as_ref());
            }
        }
    }

    async fn describe_groups_on_node<T: AsRef<str>>(
        &mut self,
        node: i32,
        version: i16,
        ids: &[T],
        idxs: &[usize],
        include_authorized_operations: bool,
        deadline: Instant,
    ) -> Result<Vec<(usize, DescribedGroup)>> {
        let subset = borrowed_ids(ids, idxs);
        let timeout = startup_remaining(deadline)?;
        let mut encoded = BytesMut::new();
        encode_describe_groups_ids_cooperative(
            &mut encoded,
            version,
            &subset,
            include_authorized_operations,
        )
        .await?;
        let body = self
            .roundtrip_known_node(
                node,
                deadline,
                DESCRIBE_GROUPS,
                version,
                |buf| {
                    buf.extend_from_slice(&encoded);
                    Ok(())
                },
                timeout,
            )
            .await?;
        Self::apply_describe_groups_body(version, ids, idxs, body).await
    }

    async fn apply_describe_groups_body<T: AsRef<str>>(
        version: i16,
        ids: &[T],
        idxs: &[usize],
        body: Bytes,
    ) -> Result<Vec<(usize, DescribedGroup)>> {
        let (results, ..) =
            decode_describe_groups_response_cooperative(&mut body.clone(), version).await?;
        let mut by_id = group_named(results, |group| group.group_id.as_str()).await;
        let mut out = Vec::new();
        for &i in idxs {
            let id = ids
                .get(i)
                .map(AsRef::as_ref)
                .ok_or_else(|| Error::protocol("missing group id"))?;
            let g = by_id
                .get_mut(id)
                .and_then(VecDeque::pop_front)
                .ok_or_else(|| Error::protocol(format!("DescribeGroups missing {id}")))?;
            out.push((i, g));
        }
        Ok(out)
    }

    async fn delete_groups_on_node<T: AsRef<str>>(
        &mut self,
        node: i32,
        version: i16,
        ids: &[T],
        idxs: &[usize],
        deadline: Instant,
    ) -> Result<Vec<(usize, DeletableGroupResult)>> {
        let subset = borrowed_ids(ids, idxs);
        let timeout = startup_remaining(deadline)?;
        let mut encoded = BytesMut::new();
        encode_delete_groups_ids_cooperative(&mut encoded, version, &subset).await?;
        let body = self
            .roundtrip_known_node(
                node,
                deadline,
                DELETE_GROUPS,
                version,
                |buf| {
                    buf.extend_from_slice(&encoded);
                    Ok(())
                },
                timeout,
            )
            .await?;
        Self::apply_delete_groups_body(version, ids, idxs, body).await
    }

    async fn apply_delete_groups_body<T: AsRef<str>>(
        version: i16,
        ids: &[T],
        idxs: &[usize],
        body: Bytes,
    ) -> Result<Vec<(usize, DeletableGroupResult)>> {
        let (results, ..) =
            decode_delete_groups_response_cooperative(&mut body.clone(), version).await?;
        let mut by_id = group_named(results, |group| group.group_id.as_str()).await;
        let mut out = Vec::new();
        for &i in idxs {
            let id = ids
                .get(i)
                .map(AsRef::as_ref)
                .ok_or_else(|| Error::protocol("missing group id"))?;
            let g = by_id
                .get_mut(id)
                .and_then(VecDeque::pop_front)
                .ok_or_else(|| Error::protocol(format!("DeleteGroups missing {id}")))?;
            out.push((i, g));
        }
        Ok(out)
    }

    async fn consumer_group_describe_on_node<T: AsRef<str>>(
        &mut self,
        node: i32,
        version: i16,
        ids: &[T],
        idxs: &[usize],
        include_authorized_operations: bool,
        deadline: Instant,
    ) -> Result<Vec<(usize, DescribedConsumerGroup)>> {
        let subset = borrowed_ids(ids, idxs);
        let timeout = startup_remaining(deadline)?;
        let mut encoded = BytesMut::new();
        encode_consumer_group_describe_ids_cooperative(
            &mut encoded,
            version,
            &subset,
            include_authorized_operations,
        )
        .await?;
        let body = self
            .roundtrip_known_node(
                node,
                deadline,
                CONSUMER_GROUP_DESCRIBE,
                version,
                |buf| {
                    buf.extend_from_slice(&encoded);
                    Ok(())
                },
                timeout,
            )
            .await?;
        Self::apply_consumer_group_describe_body(version, ids, idxs, body).await
    }

    async fn apply_consumer_group_describe_body<T: AsRef<str>>(
        version: i16,
        ids: &[T],
        idxs: &[usize],
        body: Bytes,
    ) -> Result<Vec<(usize, DescribedConsumerGroup)>> {
        let (results, ..) =
            decode_consumer_group_describe_response_cooperative(&mut body.clone(), version).await?;
        let mut by_id = group_named(results, |group| group.group_id.as_str()).await;
        let mut out = Vec::new();
        for &i in idxs {
            let id = ids
                .get(i)
                .map(AsRef::as_ref)
                .ok_or_else(|| Error::protocol("missing group id"))?;
            let g = by_id
                .get_mut(id)
                .and_then(VecDeque::pop_front)
                .ok_or_else(|| Error::protocol(format!("ConsumerGroupDescribe missing {id}")))?;
            out.push((i, g));
        }
        Ok(out)
    }

    async fn share_group_describe_on_node<T: AsRef<str>>(
        &mut self,
        node: i32,
        version: i16,
        ids: &[T],
        idxs: &[usize],
        include_authorized_operations: bool,
        deadline: Instant,
    ) -> Result<Vec<(usize, DescribedShareGroup)>> {
        let subset = borrowed_ids(ids, idxs);
        let timeout = startup_remaining(deadline)?;
        let mut encoded = BytesMut::new();
        encode_share_group_describe_ids_cooperative(
            &mut encoded,
            version,
            &subset,
            include_authorized_operations,
        )
        .await?;
        let body = self
            .roundtrip_known_node(
                node,
                deadline,
                SHARE_GROUP_DESCRIBE,
                version,
                |buf| {
                    buf.extend_from_slice(&encoded);
                    Ok(())
                },
                timeout,
            )
            .await?;
        Self::apply_share_group_describe_body(version, ids, idxs, body).await
    }

    async fn apply_share_group_describe_body<T: AsRef<str>>(
        version: i16,
        ids: &[T],
        idxs: &[usize],
        body: Bytes,
    ) -> Result<Vec<(usize, DescribedShareGroup)>> {
        let (results, ..) =
            decode_share_group_describe_response_cooperative(&mut body.clone(), version).await?;
        let mut by_id = group_named(results, |group| group.group_id.as_str()).await;
        let mut out = Vec::new();
        for &i in idxs {
            let id = ids
                .get(i)
                .map(AsRef::as_ref)
                .ok_or_else(|| Error::protocol("missing group id"))?;
            let g = by_id
                .get_mut(id)
                .and_then(VecDeque::pop_front)
                .ok_or_else(|| Error::protocol(format!("ShareGroupDescribe missing {id}")))?;
            out.push((i, g));
        }
        Ok(out)
    }

    async fn describe_share_group_offsets_on_node(
        &mut self,
        node: i32,
        version: i16,
        groups: &[DescribeShareGroupOffsetsGroup],
        idxs: &[usize],
        deadline: Instant,
    ) -> Result<Vec<(usize, DescribedShareGroupOffsetsWithLag)>> {
        let subset: Vec<&DescribeShareGroupOffsetsGroup> =
            idxs.iter().filter_map(|&i| groups.get(i)).collect();
        let timeout = startup_remaining(deadline)?;
        let mut encoded = BytesMut::new();
        encode_describe_share_group_offsets_request_refs_cooperative(
            &mut encoded,
            version,
            &subset,
        )
        .await?;
        let body = self
            .roundtrip_known_node(
                node,
                deadline,
                DESCRIBE_SHARE_GROUP_OFFSETS,
                version,
                |buf| {
                    buf.extend_from_slice(&encoded);
                    Ok(())
                },
                timeout,
            )
            .await?;
        Self::apply_describe_share_group_offsets_body(version, groups, idxs, body).await
    }

    async fn apply_describe_share_group_offsets_body(
        version: i16,
        groups: &[DescribeShareGroupOffsetsGroup],
        idxs: &[usize],
        body: Bytes,
    ) -> Result<Vec<(usize, DescribedShareGroupOffsetsWithLag)>> {
        let mut cursor = body;
        let (results, ..) = decode_describe_share_group_offsets_response_versioned_cooperative(
            &mut cursor,
            version,
        )
        .await?;
        if !cursor.is_empty() {
            return Err(Error::protocol(
                "DescribeShareGroupOffsets trailing response bytes",
            ));
        }
        let mut by_id = group_named(results, |group| group.group_id.as_str()).await;
        let mut out = Vec::new();
        for &i in idxs {
            let id = groups
                .get(i)
                .map(|g| g.group_id.as_str())
                .ok_or_else(|| Error::protocol("missing group id"))?;
            let g = by_id
                .get_mut(id)
                .and_then(VecDeque::pop_front)
                .ok_or_else(|| {
                    Error::protocol(format!("DescribeShareGroupOffsets missing {id}"))
                })?;
            out.push((i, g));
        }
        Ok(out)
    }

    async fn describe_transactions_on_node<T: AsRef<str>>(
        &mut self,
        node: i32,
        ids: &[T],
        idxs: &[usize],
        version: i16,
        deadline: Instant,
    ) -> Result<Vec<(usize, TransactionState)>> {
        let subset = borrowed_ids(ids, idxs);
        let timeout = startup_remaining(deadline)?;
        let mut encoded = BytesMut::new();
        encode_describe_transactions_ids_cooperative(&mut encoded, &subset).await?;
        let body = self
            .roundtrip_known_node(
                node,
                deadline,
                DESCRIBE_TRANSACTIONS,
                version,
                |buf| {
                    buf.extend_from_slice(&encoded);
                    Ok(())
                },
                timeout,
            )
            .await?;
        Self::apply_describe_transactions_body(ids, idxs, body).await
    }

    async fn apply_describe_transactions_body<T: AsRef<str>>(
        ids: &[T],
        idxs: &[usize],
        body: Bytes,
    ) -> Result<Vec<(usize, TransactionState)>> {
        let (results, ..) =
            decode_describe_transactions_response_cooperative(&mut body.clone()).await?;
        let mut by_id = group_named(results, |txn| txn.transactional_id.as_str()).await;
        let mut out = Vec::new();
        for &i in idxs {
            let id = ids
                .get(i)
                .map(AsRef::as_ref)
                .ok_or_else(|| Error::protocol("missing transactional id"))?;
            let t = by_id
                .get_mut(id)
                .and_then(VecDeque::pop_front)
                .ok_or_else(|| Error::protocol(format!("DescribeTransactions missing {id}")))?;
            out.push((i, t));
        }
        Ok(out)
    }

    async fn discover_txn_coord(
        &mut self,
        transactional_id: &str,
        deadline: Instant,
    ) -> Result<i32> {
        let version = self.find_coord_version.ok_or_else(|| {
            Error::Unsupported("broker does not support FindCoordinator v1-6".into())
        })?;
        if version == 0 {
            return Err(Error::Unsupported(
                "transaction discovery requires FindCoordinator v1-6".into(),
            ));
        }
        let mut attempt = 0u32;
        loop {
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            let body = self
                .roundtrip_bootstrap(
                    FIND_COORDINATOR,
                    version,
                    |buf| {
                        encode_find_coordinator_request_typed(
                            buf,
                            version,
                            transactional_id,
                            COORDINATOR_TRANSACTION,
                        )
                    },
                    deadline.saturating_duration_since(Instant::now()),
                )
                .await;
            let body = match body {
                Ok(b) => b,
                Err(e) if e.is_retriable() => {
                    self.wait_retry(&mut attempt, deadline).await?;
                    continue;
                }
                Err(e) => return Err(e),
            };
            let (err, node, host, port) =
                decode_find_coordinator_response(&mut body.clone(), version)?;
            if err == 0 {
                self.ensure_coordinator_node(node, &host, port, deadline)
                    .await?;
                return Ok(node);
            }
            if error::coordinator_retriable(err) {
                self.wait_retry(&mut attempt, deadline).await?;
                continue;
            }
            return Err(Error::broker(err, "FindCoordinator"));
        }
    }
}

fn validate_reassignments(assignments: &[PartitionReassignment]) -> Result<()> {
    if assignments.len() > crate::protocol::admin::MAX_REASSIGNMENT_PARTITIONS {
        return Err(Error::protocol("too many reassignment partitions"));
    }
    let mut replicas = 0usize;
    for assignment in assignments {
        if assignment.topic.len() > 249 {
            return Err(Error::protocol("reassignment topic name exceeds249 bytes"));
        }
        replicas = replicas.saturating_add(assignment.replicas.as_ref().map_or(0, Vec::len));
        if replicas > crate::protocol::admin::MAX_REASSIGNMENT_REPLICAS {
            return Err(Error::protocol("too many reassignment replica IDs"));
        }
    }
    Ok(())
}

fn group_reassignments(
    assignments: &[PartitionReassignment],
) -> Vec<(&str, Vec<BorrowedReassignmentPartition<'_>>)> {
    let mut groups: Vec<(&str, Vec<BorrowedReassignmentPartition<'_>>)> = Vec::new();
    let mut slots: HashMap<&str, usize> = HashMap::new();
    for a in assignments {
        let part = BorrowedReassignmentPartition {
            partition_index: a.partition,
            replicas: a.replicas.as_deref(),
        };
        let topic = a.topic.as_str();
        if let Some(&slot) = slots.get(topic) {
            if let Some((_, parts)) = groups.get_mut(slot) {
                parts.push(part);
                continue;
            }
        }
        let slot = groups.len();
        let _ = slots.insert(topic, slot);
        groups.push((topic, vec![part]));
    }
    groups
}

async fn group_list_reassignments(partitions: &[crate::TopicPartition]) -> Vec<(&str, Vec<i32>)> {
    let mut groups: Vec<(&str, Vec<i32>)> = Vec::new();
    let mut slots: HashMap<&str, usize> = HashMap::new();
    let mut walked = 0usize;
    for tp in partitions {
        let topic = tp.topic.as_str();
        if let Some(&slot) = slots.get(topic) {
            if let Some((_, parts)) = groups.get_mut(slot) {
                parts.push(tp.partition);
            }
        } else {
            let slot = groups.len();
            let _ = slots.insert(topic, slot);
            groups.push((topic, vec![tp.partition]));
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    groups
}

pub(crate) async fn pop_listed_offsets(
    indexed: &mut HashMap<String, HashMap<i32, VecDeque<ListOffsetsResponsePartition>>>,
    order: &[(usize, &str, i32)],
) -> Vec<Option<ListOffsetsResponsePartition>> {
    let mut out = Vec::with_capacity(order.len());
    let mut walked = 0usize;
    for (_, topic, partition) in order {
        out.push(
            indexed
                .get_mut(*topic)
                .and_then(|parts| parts.get_mut(partition))
                .and_then(VecDeque::pop_front),
        );
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    out
}

pub(crate) async fn index_listed_offsets(
    topics: Vec<crate::protocol::offsets::ListOffsetsTopicResponse>,
) -> HashMap<String, HashMap<i32, VecDeque<ListOffsetsResponsePartition>>> {
    let mut by_key: HashMap<String, HashMap<i32, VecDeque<ListOffsetsResponsePartition>>> =
        HashMap::new();
    let mut walked = 0usize;
    for topic in topics {
        let parts = by_key.entry(topic.name).or_default();
        for partition in topic.partitions {
            let index = partition.partition_index;
            parts.entry(index).or_default().push_back(partition);
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
    }
    by_key
}

type DeletedRecordIndex = HashMap<String, HashMap<i32, VecDeque<(i64, i16)>>>;

async fn pop_deleted_records(
    indexed: &mut DeletedRecordIndex,
    order: &[(usize, &str, i32)],
) -> Vec<Option<(i64, i16)>> {
    let mut out = Vec::with_capacity(order.len());
    let mut walked = 0usize;
    for (_, topic, partition) in order {
        out.push(
            indexed
                .get_mut(*topic)
                .and_then(|parts| parts.get_mut(partition))
                .and_then(VecDeque::pop_front),
        );
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    out
}

async fn index_deleted_records(
    topics: Vec<crate::protocol::admin::DeletedRecordsTopic>,
) -> DeletedRecordIndex {
    let mut by_key: DeletedRecordIndex = HashMap::new();
    let mut walked = 0usize;
    for topic in topics {
        let parts = by_key.entry(topic.topic).or_default();
        for partition in topic.partitions {
            parts
                .entry(partition.partition)
                .or_default()
                .push_back((partition.low_watermark, partition.error_code));
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
    }
    by_key
}

type DescribedProducerIndex = HashMap<String, HashMap<i32, DescribeProducersPartition>>;

async fn pop_described_producers(
    indexed: &mut DescribedProducerIndex,
    order: &[(usize, &str, i32)],
) -> Vec<Option<DescribeProducersPartition>> {
    let mut out = Vec::with_capacity(order.len());
    let mut walked = 0usize;
    for (_, topic, partition) in order {
        out.push(
            indexed
                .get_mut(*topic)
                .and_then(|parts| parts.remove(partition)),
        );
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    out
}

async fn index_described_producers(topics: Vec<DescribeProducersTopic>) -> DescribedProducerIndex {
    let mut by_tp: DescribedProducerIndex = HashMap::new();
    let mut walked = 0usize;
    for topic in topics {
        let parts = by_tp.entry(topic.name).or_default();
        for part in topic.partitions {
            let _ = parts.insert(part.partition_index, part);
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
    }
    by_tp
}

async fn flatten_list_reassignments(
    topics: &[crate::protocol::admin::OngoingTopicReassignment],
) -> Vec<OngoingReassignment> {
    let mut out = Vec::new();
    let mut walked = 0usize;
    for t in topics {
        for p in &t.partitions {
            out.push(OngoingReassignment {
                topic: t.name.clone(),
                partition: p.partition_index,
                replicas: p.replicas.clone(),
                adding_replicas: p.adding_replicas.clone(),
                removing_replicas: p.removing_replicas.clone(),
            });
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
    }
    out
}

async fn flatten_reassignment_results(
    results: &[crate::protocol::admin::ReassignmentTopicResult],
) -> Vec<ReassignmentResult> {
    let mut out = Vec::new();
    let mut walked = 0usize;
    for t in results {
        for p in &t.partitions {
            out.push(ReassignmentResult {
                topic: t.name.clone(),
                partition: p.partition_index,
                error_code: p.error_code,
                error_message: p.error_message.clone(),
            });
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
    }
    out
}

async fn offset_delete_named_topics(partitions: &[(String, i32)]) -> Vec<(&str, Vec<i32>)> {
    let mut groups: Vec<(&str, Vec<i32>)> = Vec::new();
    let mut slots: HashMap<&str, usize> = HashMap::new();
    let mut walked = 0usize;
    for (topic, part) in partitions {
        let name = topic.as_str();
        if let Some(&slot) = slots.get(name) {
            if let Some((_, parts)) = groups.get_mut(slot) {
                parts.push(*part);
            }
        } else {
            let slot = groups.len();
            let _ = slots.insert(name, slot);
            groups.push((name, vec![*part]));
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    groups
}

/// Java DescribeTopicPartitions default ResponsePartitionLimit.
const DESCRIBE_TOPIC_PARTITIONS_LIMIT: i32 = 2000;

fn topic_listings_from(md: &MetadataResponse, list_internal: bool) -> Vec<TopicListing> {
    md.topics
        .iter()
        .filter(|t| t.error_code == 0)
        .filter(|t| list_internal || !t.is_internal)
        .filter_map(|t| {
            t.name.as_ref().map(|name| TopicListing {
                name: name.clone(),
                topic_id: t.topic_id,
                is_internal: t.is_internal,
            })
        })
        .collect()
}

async fn topic_descriptions_including_unnamed(md: &MetadataResponse) -> Vec<TopicDescription> {
    let mut out = Vec::with_capacity(md.topics.len());
    for topic in &md.topics {
        out.push(topic_description_from(topic).await);
    }
    out
}

async fn topic_descriptions_for_names<T: AsRef<str>>(
    md: &MetadataResponse,
    names: &[T],
) -> Vec<TopicDescription> {
    let mut slots: HashMap<&str, usize> = HashMap::with_capacity(md.topics.len());
    for (index, topic) in md.topics.iter().enumerate() {
        let Some(name) = topic.name.as_deref() else {
            continue;
        };
        if slots.contains_key(name) {
            continue;
        }
        let _ = slots.insert(name, index);
    }
    let mut out = Vec::with_capacity(names.len());
    for name in names {
        let name = name.as_ref();
        out.push(
            match slots.get(name).and_then(|index| md.topics.get(*index)) {
                Some(topic) => topic_description_from(topic).await,
                None => TopicDescription::new(
                    name,
                    [0; 16],
                    false,
                    error::UNKNOWN_TOPIC_OR_PARTITION,
                    Vec::new(),
                ),
            },
        );
    }
    out
}

async fn topic_description_from(t: &crate::protocol::api::TopicMetadata) -> TopicDescription {
    let name = t.name.clone().unwrap_or_default();
    let mut partitions = Vec::new();
    if t.error_code == 0 {
        partitions.reserve(t.partitions.len());
        let mut walked = 0usize;
        for partition in &t.partitions {
            partitions.push(crate::PartitionInfo::from_partition_metadata(
                name.as_str(),
                partition,
            ));
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
    }
    TopicDescription {
        name,
        topic_id: t.topic_id,
        is_internal: t.is_internal,
        error_code: t.error_code,
        partitions,
        authorized_operations: t.topic_authorized_operations,
    }
}

async fn topic_description_from_dtp(
    t: &DescribedTopicPartitions,
    include_authorized_operations: bool,
) -> TopicDescription {
    let name = t.name.clone().unwrap_or_default();
    let mut partitions = Vec::new();
    if t.error_code == 0 {
        partitions.reserve(t.partitions.len());
        let mut walked = 0usize;
        for partition in &t.partitions {
            partitions.push(crate::PartitionInfo {
                topic: name.clone(),
                partition: partition.partition_index,
                leader: partition.leader_id,
                leader_epoch: partition.leader_epoch,
                replicas: partition.replica_nodes.clone(),
                isr: partition.isr_nodes.clone(),
                offline_replicas: partition.offline_replicas.clone(),
            });
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
    }
    TopicDescription {
        name,
        topic_id: t.topic_id,
        is_internal: t.is_internal,
        error_code: t.error_code,
        partitions,
        authorized_operations: if include_authorized_operations {
            t.topic_authorized_operations
        } else {
            AUTHORIZED_OPERATIONS_OMITTED
        },
    }
}

async fn own_list_offset_topics(
    borrowed: Vec<(&str, Vec<ListOffsetsPartitionRequest>)>,
) -> Vec<ListOffsetsTopicRequest> {
    let mut topics = Vec::with_capacity(borrowed.len());
    let mut walked = 0usize;
    for (name, partitions) in borrowed {
        topics.push(ListOffsetsTopicRequest::new(name, partitions));
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    topics
}

async fn list_offset_topic_requests<'a>(
    queries: &'a [(crate::TopicPartition, i64)],
    idxs: &[usize],
    cluster: &Cluster,
) -> Vec<(&'a str, Vec<ListOffsetsPartitionRequest>)> {
    let mut groups: Vec<(&str, Vec<ListOffsetsPartitionRequest>)> = Vec::new();
    let mut slots: HashMap<&str, usize> = HashMap::new();
    let mut epochs = crate::cluster::EpochList::new();
    let mut walked = 0usize;
    for &i in idxs {
        let Some((tp, ts)) = queries.get(i) else {
            continue;
        };
        let part = ListOffsetsPartitionRequest {
            partition: tp.partition,
            current_leader_epoch: epochs.epoch(cluster, &tp.topic, tp.partition),
            timestamp: *ts,
        };
        let topic = tp.topic.as_str();
        if let Some(&slot) = slots.get(topic) {
            if let Some((_, parts)) = groups.get_mut(slot) {
                parts.push(part);
            } else {
                let slot = groups.len();
                let _ = slots.insert(topic, slot);
                groups.push((topic, vec![part]));
            }
        } else {
            let slot = groups.len();
            let _ = slots.insert(topic, slot);
            groups.push((topic, vec![part]));
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    groups
}

fn place_described_topic(
    out: &mut Vec<TopicDescription>,
    index: &mut HashMap<String, usize>,
    desc: TopicDescription,
) {
    if let Some(&slot) = index.get(desc.name.as_str()) {
        if let Some(existing) = out.get_mut(slot) {
            existing.partitions.extend(desc.partitions);
        }
        return;
    }
    let slot = out.len();
    let _previous = index.insert(desc.name.clone(), slot);
    out.push(desc);
}

async fn extend_described_topics(
    out: &mut Vec<TopicDescription>,
    index: &mut HashMap<String, usize>,
    incoming: Vec<TopicDescription>,
) {
    let mut walked = 0usize;
    for desc in incoming {
        place_described_topic(out, index, desc);
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
}

async fn unique_in_order<'a>(keys: &[&'a str]) -> Vec<&'a str> {
    let mut uniq = Vec::new();
    let mut seen = HashSet::new();
    let mut walked = 0usize;
    for key in keys {
        if seen.insert(*key) {
            uniq.push(*key);
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    uniq
}

#[cfg(test)]
fn first_seen_missing_ids<'a, T: AsRef<str>>(
    ids: &'a [T],
    pending: &[usize],
    known: &HashMap<String, i32>,
) -> Vec<&'a str> {
    let mut need = Vec::new();
    let mut seen = HashSet::new();
    for &index in pending {
        let Some(id) = ids.get(index) else {
            continue;
        };
        let id = id.as_ref();
        if known.contains_key(id) || !seen.insert(id) {
            continue;
        }
        need.push(id);
    }
    need
}

fn owned_string_chunk() -> usize {
    8 * 1024
}

/// Copy each id into an owned string.
///
/// The walk pauses every 8,192 ids. Without that pause, copying 2,000,000
/// ids held the caller for 181 milliseconds.
///
/// Each id is still copied.
async fn collect_strings<T: Into<String>>(items: impl IntoIterator<Item = T>) -> Vec<String> {
    let mut out = Vec::new();
    let mut walked = 0usize;
    for item in items {
        out.push(item.into());
        walked = walked.saturating_add(1);
        if walked == owned_string_chunk() {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    out
}

fn result_slot_chunk() -> usize {
    8 * 1024
}

/// Open one empty result slot per item.
///
/// The walk pauses every 8,192 slots. Without that pause, opening 2,000,000
/// group results and their indexes held the caller for 229 milliseconds.
///
/// Every slot starts empty.
async fn open_result_slots<T>(count: usize) -> Vec<Option<T>> {
    let mut out = Vec::with_capacity(count);
    let chunk = result_slot_chunk();
    while out.len() < count {
        let extra = count.saturating_sub(out.len()).min(chunk);
        out.extend(std::iter::repeat_with(|| None).take(extra));
        if out.len() < count {
            tokio::task::yield_now().await;
        }
    }
    out
}

/// Number each input once, in order.
///
/// The walk pauses every 8,192 indexes. Without that pause, numbering
/// 2,000,000 inputs was part of the 229 millisecond group-result hold.
///
/// Index 0 stays first.
async fn pending_indexes(count: usize) -> Vec<usize> {
    let mut pending = Vec::with_capacity(count);
    let mut next = 0usize;
    let chunk = result_slot_chunk();
    while next < count {
        let end = next.saturating_add(chunk).min(count);
        pending.extend(next..end);
        next = end;
        if next < count {
            tokio::task::yield_now().await;
        }
    }
    pending
}

fn topic_record_chunk() -> usize {
    8 * 1024
}

/// Copy topic names and offsets into owned topic partitions.
///
/// The walk pauses every 8,192 partitions. Without that pause, copying
/// 2,000,000 names held the caller for 269 milliseconds.
///
/// Each topic name is still copied.
async fn collect_topic_pairs<Tp, Off>(
    records: impl IntoIterator<Item = (Tp, Off)>,
) -> Vec<(crate::TopicPartition, i64)>
where
    Tp: Into<crate::TopicPartition>,
    Off: Into<i64>,
{
    let mut out = Vec::new();
    let mut walked = 0usize;
    for (topic, offset) in records {
        out.push((topic.into(), offset.into()));
        walked = walked.saturating_add(1);
        if walked == topic_record_chunk() {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    out
}

/// Copy topic names into owned topic partitions.
///
/// The walk pauses every 8,192 partitions. Without that pause, copying
/// 2,000,000 names held the caller for 269 milliseconds.
///
/// Each topic name is still copied.
async fn collect_topic_partitions<Tp>(
    partitions: impl IntoIterator<Item = Tp>,
) -> Vec<crate::TopicPartition>
where
    Tp: Into<crate::TopicPartition>,
{
    let mut out = Vec::new();
    let mut walked = 0usize;
    for topic in partitions {
        out.push(topic.into());
        walked = walked.saturating_add(1);
        if walked == topic_record_chunk() {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    out
}

fn known_coord_chunk() -> usize {
    8 * 1024
}

/// Collect coordinators that are already cached.
///
/// The walk pauses every 8,192 ids. Without that pause, collecting
/// 2,000,000 cached coordinators held the caller for 1.04 seconds.
///
/// A coordinator is kept once, the first time it is seen. An id without a
/// coordinator is skipped.
async fn cached_coordinator_nodes<T: AsRef<str>>(
    ids: &[T],
    pending: &[usize],
    coords: &HashMap<String, i32>,
) -> (Vec<i32>, HashSet<i32>) {
    let mut known_nodes = Vec::new();
    let mut seen = HashSet::new();
    let mut walked = 0usize;
    for &index in pending {
        walked = walked.saturating_add(1);
        if let Some(id) = ids.get(index) {
            if let Some(&node) = coords.get(id.as_ref()) {
                if seen.insert(node) {
                    known_nodes.push(node);
                }
            }
        }
        if walked == known_coord_chunk() {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    (known_nodes, seen)
}

fn coordinator_group_chunk() -> usize {
    8 * 1024
}

/// File each id under its cached coordinator.
///
/// The walk pauses every 8,192 ids. Without that pause, grouping 2,000,000
/// coordinators held the caller for 1.11 seconds.
///
/// A missing id or a missing coordinator stops the walk and returns an error.
async fn group_ids_by_coordinator<T: AsRef<str>>(
    ids: &[T],
    pending: &[usize],
    coords: &HashMap<String, i32>,
    missing_id: &'static str,
) -> Result<HashMap<i32, Vec<usize>>> {
    let mut by_node: HashMap<i32, Vec<usize>> = HashMap::new();
    let mut walked = 0usize;
    for &index in pending {
        walked = walked.saturating_add(1);
        let id = ids
            .get(index)
            .map(AsRef::as_ref)
            .ok_or_else(|| Error::protocol(missing_id))?;
        let node = *coords
            .get(id)
            .ok_or_else(|| Error::protocol(format!("missing coordinator for {id}")))?;
        by_node.entry(node).or_default().push(index);
        if walked == coordinator_group_chunk() {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    Ok(by_node)
}

fn missing_id_chunk() -> usize {
    8 * 1024
}

/// List ids that do not have a cached coordinator.
///
/// The walk pauses every 8,192 ids. Without that pause, listing 2,000,000
/// ids held the caller for 1.76 seconds.
///
/// The first copy of an id is kept. A later copy, and an id that already has
/// a coordinator, are skipped.
async fn first_seen_missing_ids_cooperative<'a, T: AsRef<str>>(
    ids: &'a [T],
    pending: &[usize],
    known: &HashMap<String, i32>,
) -> Vec<&'a str> {
    let mut need = Vec::new();
    let mut seen = HashSet::new();
    let mut walked = 0usize;
    for &index in pending {
        walked = walked.saturating_add(1);
        if let Some(id) = ids.get(index) {
            let id = id.as_ref();
            if !known.contains_key(id) && seen.insert(id) {
                need.push(id);
            }
        }
        if walked == missing_id_chunk() {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    need
}

async fn first_seen_i32(values: &[i32]) -> Vec<i32> {
    let mut ids = Vec::new();
    let mut seen = HashSet::new();
    let mut walked = 0usize;
    for id in values {
        if seen.insert(*id) {
            ids.push(*id);
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    ids
}

#[cfg(test)]
fn first_seen_i32_now(values: impl IntoIterator<Item = i32>) -> Vec<i32> {
    let mut ids = Vec::new();
    let mut seen = HashSet::new();
    for id in values {
        if seen.insert(id) {
            ids.push(id);
        }
    }
    ids
}

async fn replica_broker_ids(replicas: &[TopicPartitionReplica]) -> Vec<i32> {
    let mut ids = Vec::new();
    let mut seen = HashSet::new();
    let mut walked = 0usize;
    for replica in replicas {
        if seen.insert(replica.broker_id) {
            ids.push(replica.broker_id);
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    ids
}

async fn group_alter_replica_log_dirs(
    assignment: &[(TopicPartitionReplica, String)],
) -> Vec<(i32, Vec<BorrowedAlterReplicaLogDir<'_>>)> {
    let broker_ids: Vec<i32> = assignment
        .iter()
        .map(|(replica, _)| replica.broker_id)
        .collect();
    let ids = first_seen_i32(&broker_ids).await;
    let mut grouped = Vec::with_capacity(ids.len());
    for broker_id in ids {
        grouped.push((
            broker_id,
            alter_replica_dirs_for_broker_cooperative(assignment, broker_id).await,
        ));
    }
    grouped
}

#[cfg(test)]
fn group_alter_replica_log_dirs_sync(
    assignment: &[(TopicPartitionReplica, String)],
) -> Vec<(i32, Vec<BorrowedAlterReplicaLogDir<'_>>)> {
    let ids = first_seen_i32_now(assignment.iter().map(|(replica, _)| replica.broker_id));
    ids.into_iter()
        .map(|broker_id| {
            (
                broker_id,
                alter_replica_dirs_for_broker(assignment, broker_id),
            )
        })
        .collect()
}

fn place_replica_dir<'a>(
    directories: &mut Vec<BorrowedAlterReplicaLogDir<'a>>,
    path_slots: &mut HashMap<&'a str, usize>,
    topic_slots: &mut HashMap<(&'a str, &'a str), usize>,
    seen: &mut HashMap<(&'a str, &'a str), HashSet<i32>>,
    replica: &'a TopicPartitionReplica,
    path_name: &'a str,
) {
    let topic_name = replica.topic.as_str();
    let key = (path_name, topic_name);
    if topic_slots.contains_key(&key) {
        let fresh = seen
            .get_mut(&key)
            .is_some_and(|known| known.insert(replica.partition));
        if !fresh {
            return;
        }
        let Some(&dir_index) = path_slots.get(path_name) else {
            return;
        };
        let Some(directory) = directories.get_mut(dir_index) else {
            return;
        };
        let Some(&topic_index) = topic_slots.get(&key) else {
            return;
        };
        let Some(topic) = directory.topics.get_mut(topic_index) else {
            return;
        };
        topic.partitions.push(replica.partition);
        return;
    }
    let dir_index = if let Some(&slot) = path_slots.get(path_name) {
        slot
    } else {
        let slot = directories.len();
        let _ = path_slots.insert(path_name, slot);
        directories.push(BorrowedAlterReplicaLogDir {
            path: path_name,
            topics: Vec::new(),
        });
        slot
    };
    let Some(directory) = directories.get_mut(dir_index) else {
        return;
    };
    let topic_index = directory.topics.len();
    directory.topics.push(BorrowedAlterReplicaLogDirTopic {
        name: topic_name,
        partitions: vec![replica.partition],
    });
    let _ = topic_slots.insert(key, topic_index);
    let mut known = HashSet::new();
    let _ = known.insert(replica.partition);
    let _ = seen.insert(key, known);
}

#[cfg(test)]
fn alter_replica_dirs_for_broker<'a>(
    assignment: &'a [(TopicPartitionReplica, String)],
    broker_id: i32,
) -> Vec<BorrowedAlterReplicaLogDir<'a>> {
    let mut directories = Vec::new();
    let mut path_slots = HashMap::new();
    let mut topic_slots = HashMap::new();
    let mut seen = HashMap::new();
    for (replica, path) in assignment {
        if replica.broker_id != broker_id {
            continue;
        }
        place_replica_dir(
            &mut directories,
            &mut path_slots,
            &mut topic_slots,
            &mut seen,
            replica,
            path.as_str(),
        );
    }
    directories
}

async fn alter_replica_dirs_for_broker_cooperative<'a>(
    assignment: &'a [(TopicPartitionReplica, String)],
    broker_id: i32,
) -> Vec<BorrowedAlterReplicaLogDir<'a>> {
    let mut directories = Vec::new();
    let mut path_slots = HashMap::new();
    let mut topic_slots = HashMap::new();
    let mut seen = HashMap::new();
    let mut walked = 0usize;
    for (replica, path) in assignment {
        if replica.broker_id == broker_id {
            place_replica_dir(
                &mut directories,
                &mut path_slots,
                &mut topic_slots,
                &mut seen,
                replica,
                path.as_str(),
            );
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    directories
}

#[cfg(test)]
fn index_alter_replica_errors(
    results: &[AlterReplicaLogDirsResponseTopic],
) -> HashMap<(&str, i32), i16> {
    let mut index = HashMap::new();
    for result in results {
        for part in &result.partitions {
            if let std::collections::hash_map::Entry::Vacant(slot) =
                index.entry((result.topic_name.as_str(), part.partition_index))
            {
                let _ = slot.insert(part.error_code);
            }
        }
    }
    index
}

async fn index_alter_replica_errors_cooperative(
    results: &[AlterReplicaLogDirsResponseTopic],
) -> HashMap<(&str, i32), i16> {
    let mut index = HashMap::new();
    let mut walked = 0usize;
    for result in results {
        for part in &result.partitions {
            if let std::collections::hash_map::Entry::Vacant(slot) =
                index.entry((result.topic_name.as_str(), part.partition_index))
            {
                let _ = slot.insert(part.error_code);
            }
            walked = walked.saturating_add(1);
            if walked == 8 * 1024 {
                walked = 0;
                tokio::task::yield_now().await;
            }
        }
    }
    index
}

#[cfg(test)]
fn alter_replica_partition_error(
    results: &[AlterReplicaLogDirsResponseTopic],
    topic: &str,
    partition: i32,
) -> i16 {
    index_alter_replica_errors(results)
        .get(&(topic, partition))
        .copied()
        .unwrap_or(0)
}

async fn record_alter_replica_errors_cooperative(
    errors: &mut HashMap<TopicPartitionReplica, i16>,
    assignment: &[(TopicPartitionReplica, String)],
    broker_id: i32,
    resp: &AlterReplicaLogDirsResponse,
) {
    let index = index_alter_replica_errors_cooperative(&resp.results).await;
    let mut walked = 0usize;
    for (replica, _) in assignment {
        if replica.broker_id == broker_id {
            let code = index
                .get(&(replica.topic(), replica.partition))
                .copied()
                .unwrap_or(0);
            let _ = errors.insert(replica.clone(), code);
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
}

fn place_describable_topic<'a>(
    groups: &mut Vec<(&'a str, Vec<i32>)>,
    slots: &mut HashMap<&'a str, usize>,
    seen: &mut Vec<HashSet<i32>>,
    topic: &'a str,
    partition: i32,
) {
    if let Some(&slot) = slots.get(topic) {
        let fresh = seen
            .get_mut(slot)
            .is_some_and(|known| known.insert(partition));
        if !fresh {
            return;
        }
        if let Some((_, parts)) = groups.get_mut(slot) {
            parts.push(partition);
        }
        return;
    }
    let slot = groups.len();
    let mut known = HashSet::new();
    let _ = known.insert(partition);
    seen.push(known);
    let _ = slots.insert(topic, slot);
    groups.push((topic, vec![partition]));
}

#[cfg(test)]
fn describable_topics_for_broker(
    replicas: &[TopicPartitionReplica],
    broker_id: i32,
) -> Vec<(&str, Vec<i32>)> {
    let mut groups = Vec::new();
    let mut slots = HashMap::new();
    let mut seen = Vec::new();
    for replica in replicas {
        if replica.broker_id != broker_id {
            continue;
        }
        place_describable_topic(
            &mut groups,
            &mut slots,
            &mut seen,
            replica.topic.as_str(),
            replica.partition,
        );
    }
    groups
}

async fn describable_topics_for_broker_cooperative(
    replicas: &[TopicPartitionReplica],
    broker_id: i32,
) -> Vec<(&str, Vec<i32>)> {
    let mut groups = Vec::new();
    let mut slots = HashMap::new();
    let mut seen = Vec::new();
    let mut walked = 0usize;
    for replica in replicas {
        if replica.broker_id == broker_id {
            place_describable_topic(
                &mut groups,
                &mut slots,
                &mut seen,
                replica.topic.as_str(),
                replica.partition,
            );
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    groups
}

fn note_log_dir(
    info: &mut ReplicaLogDirInfo,
    dir: &DescribeLogDirsResult,
    part: &DescribeLogDirsPartition,
) {
    if part.is_future_key {
        info.future_log_dir = Some(dir.log_dir.clone());
        info.future_offset_lag = part.offset_lag;
    } else {
        info.current_log_dir = Some(dir.log_dir.clone());
        info.current_offset_lag = part.offset_lag;
    }
}

#[cfg(test)]
fn index_log_dirs(results: &[DescribeLogDirsResult]) -> HashMap<(&str, i32), ReplicaLogDirInfo> {
    let mut index = HashMap::new();
    for dir in results {
        if dir.error_code != 0 {
            continue;
        }
        for topic in &dir.topics {
            for part in &topic.partitions {
                let info = index
                    .entry((topic.name.as_str(), part.partition_index))
                    .or_insert_with(ReplicaLogDirInfo::unknown);
                note_log_dir(info, dir, part);
            }
        }
    }
    index
}

async fn index_log_dirs_cooperative(
    results: &[DescribeLogDirsResult],
) -> HashMap<(&str, i32), ReplicaLogDirInfo> {
    let mut index = HashMap::new();
    let mut walked = 0usize;
    for dir in results {
        if dir.error_code != 0 {
            continue;
        }
        for topic in &dir.topics {
            for part in &topic.partitions {
                let info = index
                    .entry((topic.name.as_str(), part.partition_index))
                    .or_insert_with(ReplicaLogDirInfo::unknown);
                note_log_dir(info, dir, part);
                walked = walked.saturating_add(1);
                if walked == 8 * 1024 {
                    walked = 0;
                    tokio::task::yield_now().await;
                }
            }
        }
    }
    index
}

fn store_replica_dir(
    infos: &mut HashMap<String, HashMap<(i32, i32), ReplicaLogDirInfo>>,
    replica: &TopicPartitionReplica,
    info: ReplicaLogDirInfo,
) {
    if let Some(parts) = infos.get_mut(replica.topic.as_str()) {
        let _ = parts.insert((replica.partition, replica.broker_id), info);
        return;
    }
    let mut parts = HashMap::new();
    let _ = parts.insert((replica.partition, replica.broker_id), info);
    let _ = infos.insert(replica.topic.clone(), parts);
}

async fn remember_replica_dirs_cooperative(
    infos: &mut HashMap<String, HashMap<(i32, i32), ReplicaLogDirInfo>>,
    replicas: &[TopicPartitionReplica],
    broker_id: i32,
    resp: &DescribeLogDirsResponse,
) -> Result<()> {
    if resp.error_code != 0 {
        return Err(Error::broker(resp.error_code, "DescribeLogDirs"));
    }
    let index = index_log_dirs_cooperative(&resp.results).await;
    let mut walked = 0usize;
    for replica in replicas {
        if replica.broker_id == broker_id {
            let info = index
                .get(&(replica.topic.as_str(), replica.partition))
                .cloned()
                .unwrap_or_else(ReplicaLogDirInfo::unknown);
            store_replica_dir(infos, replica, info);
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    Ok(())
}

#[cfg(test)]
fn replica_log_dir_info_from(
    replica: &TopicPartitionReplica,
    results: &[DescribeLogDirsResult],
) -> ReplicaLogDirInfo {
    index_log_dirs(results)
        .get(&(replica.topic.as_str(), replica.partition))
        .cloned()
        .unwrap_or_else(ReplicaLogDirInfo::unknown)
}

async fn record_election_partitions(
    selection: &mut ElectionSelection,
    partitions: Vec<TopicPartition>,
) -> (Vec<(usize, i32)>, Vec<(usize, i32)>) {
    let mut order = Vec::new();
    let mut kept = Vec::new();
    let mut walked = 0usize;
    for tp in partitions {
        let partition = tp.partition;
        if let Some(index) = selection.adopt(tp.topic, partition) {
            order.push((index, partition));
            kept.push((index, partition));
        }
        walked = walked.saturating_add(1);
        if walked == 8 * 1024 {
            walked = 0;
            tokio::task::yield_now().await;
        }
    }
    (order, kept)
}

/// Topic names for one election, stored once. Partitions remember the name's index.
#[derive(Default)]
struct ElectionSelection {
    names: Vec<String>,
    parts: Vec<HashSet<i32>>,
    slots: HashMap<String, usize>,
}

impl ElectionSelection {
    /// Keep `topic` when it is new. A repeated partition returns `None`.
    fn adopt(&mut self, topic: String, partition: i32) -> Option<usize> {
        let index = if let Some(&index) = self.slots.get(&topic) {
            index
        } else {
            let index = self.names.len();
            let _ = self.slots.insert(topic.clone(), index);
            self.names.push(topic);
            self.parts.push(HashSet::new());
            index
        };
        let parts = self.parts.get_mut(index)?;
        if !parts.insert(partition) {
            return None;
        }
        Some(index)
    }

    fn name_index(&mut self, topic: &str) -> usize {
        if let Some(&index) = self.slots.get(topic) {
            return index;
        }
        let index = self.names.len();
        let _ = self.slots.insert(topic.to_owned(), index);
        self.names.push(topic.to_owned());
        self.parts.push(HashSet::new());
        index
    }

    fn contains(&self, index: usize, partition: i32) -> bool {
        self.parts
            .get(index)
            .is_some_and(|parts| parts.contains(&partition))
    }
}

fn mark_returned(returned: &mut Vec<HashSet<i32>>, index: usize, partition: i32) -> bool {
    if returned.len() <= index {
        returned.resize_with(index.saturating_add(1), HashSet::new);
    }
    returned
        .get_mut(index)
        .is_some_and(|parts| parts.insert(partition))
}

fn election_request_topics<'a>(
    names: &'a [String],
    pending: &[(usize, i32)],
) -> Vec<(&'a str, Vec<i32>)> {
    let mut topics: Vec<(&str, Vec<i32>)> = Vec::new();
    let mut slots: Vec<Option<usize>> = Vec::new();
    for &(index, partition) in pending {
        if let Some(Some(slot)) = slots.get(index).copied() {
            if let Some((_, parts)) = topics.get_mut(slot) {
                parts.push(partition);
                continue;
            }
        }
        let Some(name) = names.get(index) else {
            continue;
        };
        let slot = topics.len();
        if slots.len() <= index {
            slots.resize_with(index.saturating_add(1), || None);
        }
        if let Some(entry) = slots.get_mut(index) {
            *entry = Some(slot);
        }
        topics.push((name.as_str(), vec![partition]));
    }
    topics
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::protocol::admin::{
        decode_list_config_resources_response, encode_list_config_resources_response,
        CreatedTopicConfig, ListConfigResourcesResponse, TopicConfig,
    };
    use bytes::BytesMut;

    #[tokio::test(flavor = "current_thread")]
    async fn listing_many_missing_leaders_does_not_hold_the_caller() {
        let cluster = Cluster::default();
        let parts: Vec<i32> = (0..4_000_000).collect();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = topics_missing_leaders(&cluster, parts.iter().map(|part| ("orders", *part))) => {}
            () = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        assert!(
            started.elapsed() < std::time::Duration::from_millis(80),
            "listing missing leaders held the caller for {:?}",
            started.elapsed()
        );
        let mut known = Cluster::default();
        let _broker = known.brokers.insert(4, "127.0.0.1:9092".to_string());
        let _leaders = known
            .leaders
            .insert(std::sync::Arc::from("payments"), vec![4]);
        let need =
            topics_missing_leaders(&known, [("orders", 0), ("orders", 1), ("payments", 0)]).await;
        assert_eq!(need, vec!["orders"]);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn collecting_many_transactional_ids_does_not_hold_the_caller() {
        let names: Vec<&str> = (0..2_000_000).map(|_| "orders-transaction").collect();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = collect_strings(names.iter().copied()) => {}
            () = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        assert!(
            started.elapsed() < std::time::Duration::from_millis(80),
            "collecting transactional ids held the caller for {:?}",
            started.elapsed()
        );
        let sample = collect_strings(["orders", "payments"]).await;
        assert_eq!(sample, vec!["orders".to_string(), "payments".to_string()]);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn opening_many_group_result_slots_does_not_hold_the_caller() {
        use crate::protocol::admin::DescribedConsumerGroup;
        let started = std::time::Instant::now();
        tokio::select! {
            _ = async {
                let out: Vec<Option<DescribedConsumerGroup>> = open_result_slots(2_000_000).await;
                let pending = pending_indexes(out.len()).await;
                let _stored = (out, pending);
            } => {}
            () = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        assert!(
            started.elapsed() < std::time::Duration::from_millis(80),
            "opening group result slots held the caller for {:?}",
            started.elapsed()
        );
        let sample: Vec<Option<DescribedConsumerGroup>> = open_result_slots(3).await;
        assert_eq!(sample.len(), 3);
        assert!(sample.iter().all(Option::is_none));
        assert_eq!(pending_indexes(3).await, vec![0, 1, 2]);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn collecting_many_topic_partitions_does_not_hold_the_caller() {
        let names: Vec<String> = (0..2_000_000)
            .map(|index| format!("topic-{index}"))
            .collect();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = collect_topic_pairs(names.iter().enumerate().map(|(index, name)| {
                ((name.as_str(), i32::try_from(index).unwrap_or(0)), 0i64)
            })) => {}
            () = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        assert!(
            started.elapsed() < std::time::Duration::from_millis(80),
            "collecting topic partitions held the caller for {:?}",
            started.elapsed()
        );
        let collected = collect_topic_pairs([(("orders", 3), 9i64), (("payments", 1), 4i64)]).await;
        assert_eq!(collected[0].0.topic(), "orders");
        assert_eq!(collected[0].0.partition(), 3);
        assert_eq!(collected[0].1, 9);
        assert_eq!(collected[1].0.topic(), "payments");
        assert_eq!(collected[1].1, 4);
        let partitions = collect_topic_partitions([("orders", 3), ("payments", 1)]).await;
        assert_eq!(partitions[0].topic(), "orders");
        assert_eq!(partitions[1].partition(), 1);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn listing_many_missing_coordinators_does_not_hold_the_caller() {
        let ids: Vec<String> = (0..2_000_000)
            .map(|index| format!("group-{index}"))
            .collect();
        let pending: Vec<usize> = (0..ids.len()).collect();
        let known = HashMap::<String, i32>::new();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = first_seen_missing_ids_cooperative(&ids, &pending, &known) => {}
            () = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        assert!(
            started.elapsed() < std::time::Duration::from_millis(80),
            "listing missing coordinators held the caller for {:?}",
            started.elapsed()
        );
        let sample = [
            "orders".to_string(),
            "payments".to_string(),
            "orders".to_string(),
        ];
        let sample_pending = [0usize, 1, 2];
        let mut sample_known = HashMap::new();
        let _stored = sample_known.insert("payments".to_string(), 5);
        assert_eq!(
            first_seen_missing_ids_cooperative(&sample, &sample_pending, &sample_known).await,
            first_seen_missing_ids(&sample, &sample_pending, &sample_known)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn collecting_many_known_coordinators_does_not_hold_the_caller() {
        let ids: Vec<String> = (0..2_000_000)
            .map(|index| format!("group-{index}"))
            .collect();
        let pending: Vec<usize> = (0..ids.len()).collect();
        let mut known = HashMap::<String, i32>::new();
        for (index, id) in ids.iter().enumerate() {
            let _stored = known.insert(id.clone(), i32::try_from(index % 8).unwrap_or(0));
        }
        let started = std::time::Instant::now();
        tokio::select! {
            _ = cached_coordinator_nodes(&ids, &pending, &known) => {}
            () = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        assert!(
            started.elapsed() < std::time::Duration::from_millis(80),
            "collecting known coordinators held the caller for {:?}",
            started.elapsed()
        );
        let sample = [
            "orders".to_string(),
            "payments".to_string(),
            "missing".to_string(),
        ];
        let mut sample_known = HashMap::new();
        let _orders = sample_known.insert("orders".to_string(), 4);
        let _payments = sample_known.insert("payments".to_string(), 5);
        let (nodes, _) = cached_coordinator_nodes(&sample, &[0, 1, 2, 0], &sample_known).await;
        assert_eq!(nodes, vec![4, 5]);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn grouping_many_coordinators_does_not_hold_the_caller() {
        let ids: Vec<String> = (0..2_000_000)
            .map(|index| format!("group-{index}"))
            .collect();
        let pending: Vec<usize> = (0..ids.len()).collect();
        let mut known = HashMap::<String, i32>::new();
        for (index, id) in ids.iter().enumerate() {
            let _stored = known.insert(id.clone(), i32::try_from(index % 8).unwrap_or(0));
        }
        let started = std::time::Instant::now();
        tokio::select! {
            _ = group_ids_by_coordinator(&ids, &pending, &known, "missing group id") => {}
            () = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        assert!(
            started.elapsed() < std::time::Duration::from_millis(80),
            "grouping coordinators held the caller for {:?}",
            started.elapsed()
        );
        let sample = [
            "orders".to_string(),
            "payments".to_string(),
            "orders".to_string(),
        ];
        let mut sample_known = HashMap::new();
        let _orders = sample_known.insert("orders".to_string(), 4);
        let _payments = sample_known.insert("payments".to_string(), 5);
        let grouped =
            group_ids_by_coordinator(&sample, &[0, 1, 2], &sample_known, "missing group id")
                .await
                .unwrap();
        assert_eq!(grouped.get(&4).map(Vec::as_slice), Some(&[0, 2][..]));
        assert_eq!(grouped.get(&5).map(Vec::as_slice), Some(&[1][..]));
    }

    #[tokio::test(flavor = "current_thread")]
    async fn grouping_many_pending_leaders_does_not_hold_the_caller() {
        let mut cluster = Cluster::default();
        let _broker = cluster.brokers.insert(4, "127.0.0.1:9092".to_string());
        let _leaders = cluster
            .leaders
            .insert(std::sync::Arc::from("orders"), vec![4; 4_000_000]);
        let parts: Vec<i32> = (0..4_000_000).collect();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = group_pending_by_leader(
                &cluster,
                parts.iter().copied().enumerate().map(|(index, partition)| {
                    (index, "orders", partition)
                }),
            ) => {}
            () = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        assert!(
            started.elapsed() < std::time::Duration::from_millis(80),
            "grouping pending leaders held the caller for {:?}",
            started.elapsed()
        );
        let mut sample = Cluster::default();
        let _sample_broker = sample.brokers.insert(4, "127.0.0.1:9092".to_string());
        let _other_broker = sample.brokers.insert(5, "127.0.0.1:9093".to_string());
        let _orders = sample
            .leaders
            .insert(std::sync::Arc::from("orders"), vec![4, 4]);
        let _payments = sample
            .leaders
            .insert(std::sync::Arc::from("payments"), vec![5]);
        let (nodes, by_node) = group_pending_by_leader(
            &sample,
            [
                (0usize, "orders", 0i32),
                (1, "payments", 0),
                (2, "orders", 1),
            ],
        )
        .await
        .unwrap();
        assert_eq!(nodes, vec![4, 5]);
        assert_eq!(by_node.get(&4).map(Vec::as_slice), Some(&[0, 2][..]));
        assert_eq!(by_node.get(&5).map(Vec::as_slice), Some(&[1][..]));
    }

    #[tokio::test(flavor = "current_thread")]
    async fn finding_many_known_leaders_does_not_hold_the_caller() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let address = listener.local_addr().unwrap().to_string();
        let accept = tokio::spawn(async move {
            let _held = listener.accept().await;
            std::future::pending::<()>().await;
        });
        let conn =
            crate::net::BrokerConn::connect(&address, "leaders", std::time::Duration::from_secs(2))
                .await
                .unwrap();
        let mut admin = Admin::test_holding(conn);
        let parts: Vec<i32> = (0..4_000_000).collect();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = admin.known_leader_nodes(parts.iter().map(|part| ("orders", *part))) => {}
            () = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        assert!(
            started.elapsed() < std::time::Duration::from_millis(80),
            "finding known leaders held the caller for {:?}",
            started.elapsed()
        );
        let _broker = admin
            .cluster
            .brokers
            .insert(4, "127.0.0.1:9092".to_string());
        let _leaders = admin
            .cluster
            .leaders
            .insert(std::sync::Arc::from("orders"), vec![4]);
        let found = admin
            .known_leader_nodes([("orders", 0), ("missing", 1)])
            .await;
        assert_eq!(found, vec![4]);
        accept.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn collecting_many_unique_topic_names_does_not_hold_the_caller() {
        let names: Vec<String> = (0..2_000_000)
            .map(|index| format!("topic-{index}"))
            .collect();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = unique_names_cooperative(names.iter().map(String::as_str)) => {}
            () = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        assert!(
            started.elapsed() < std::time::Duration::from_millis(80),
            "collecting unique topic names held the caller for {:?}",
            started.elapsed()
        );
        let sample = ["orders", "payments", "orders"];
        assert_eq!(unique_names_cooperative(sample).await, unique_names(sample));
    }

    #[tokio::test(flavor = "current_thread")]
    async fn describing_one_huge_partition_page_does_not_hold_the_caller() {
        use crate::protocol::admin::{DescribedTopicPartition, DescribedTopicPartitions};
        // 2_000_000 partitions: copying the topic name onto each held the caller 259ms.
        let partitions: Vec<DescribedTopicPartition> = (0..2_000_000)
            .map(|index| {
                let mut partition = DescribedTopicPartition::new(0);
                partition.partition_index = index;
                partition.leader_id = 1;
                partition
            })
            .collect();
        let mut topic = DescribedTopicPartitions::new("orders", 0);
        topic.topic_authorized_operations = 7;
        topic.partitions = partitions;
        let started = std::time::Instant::now();
        tokio::select! {
            described = topic_description_from_dtp(&topic, true) => {
                assert_eq!(described.partitions.len(), 2_000_000);
                assert_eq!(described.partitions.first().map(|info| info.topic.as_str()), Some("orders"));
                assert_eq!(described.partitions.first().map(|info| info.partition), Some(0));
                assert_eq!(described.partitions.first().map(|info| info.leader), Some(1));
                assert_eq!(described.authorized_operations, 7);
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "describing a partition page held the caller for {elapsed:?}"
        );
        let mut replica = DescribedTopicPartition::new(0);
        replica.partition_index = 4;
        replica.leader_id = 2;
        replica.leader_epoch = 9;
        replica.replica_nodes = vec![2, 3];
        replica.isr_nodes = vec![2];
        replica.offline_replicas = vec![3];
        let mut stored = DescribedTopicPartitions::new("orders", 0);
        stored.topic_authorized_operations = 7;
        stored.partitions = vec![replica];
        let described = topic_description_from_dtp(&stored, false).await;
        assert_eq!(described.partitions.len(), 1);
        assert_eq!(described.partitions[0].topic, "orders");
        assert_eq!(described.partitions[0].replicas, vec![2, 3]);
        assert_eq!(described.partitions[0].isr, vec![2]);
        assert_eq!(described.partitions[0].offline_replicas, vec![3]);
        assert_eq!(described.partitions[0].leader_epoch, 9);
        assert_eq!(
            described.authorized_operations,
            AUTHORIZED_OPERATIONS_OMITTED
        );
        assert_eq!(stored.partitions[0].replica_nodes, vec![2, 3]);
        let mut errored = DescribedTopicPartitions::new("orders", 5);
        errored.partitions = stored.partitions;
        let hidden = topic_description_from_dtp(&errored, true).await;
        assert!(hidden.partitions.is_empty());
        assert_eq!(hidden.error_code, 5);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn describing_one_huge_topic_does_not_hold_the_caller() {
        // 2_000_000 partitions: copying the topic name onto each held the caller 290ms.
        let partitions: Vec<crate::protocol::api::PartitionMetadata> = (0..2_000_000)
            .map(|index| {
                crate::protocol::api::PartitionMetadata::new(
                    0,
                    index,
                    Some(1),
                    Some(1),
                    Vec::new(),
                    Vec::new(),
                    Vec::new(),
                )
            })
            .collect();
        let topic = crate::protocol::api::TopicMetadata::new(0, "orders", false, partitions);
        let started = std::time::Instant::now();
        tokio::select! {
            described = topic_description_from(&topic) => {
                assert_eq!(described.partitions.len(), 2_000_000);
                assert_eq!(described.partitions.first().map(|info| info.topic.as_str()), Some("orders"));
                assert_eq!(described.partitions.first().map(|info| info.partition), Some(0));
                assert_eq!(described.partitions.first().map(|info| info.leader), Some(1));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "describing one topic held the caller for {elapsed:?}"
        );
        let mut replica = crate::protocol::api::PartitionMetadata::new(
            0,
            4,
            Some(2),
            Some(9),
            vec![2, 3],
            vec![2],
            vec![3],
        );
        replica.error_code = 0;
        let errored =
            crate::protocol::api::TopicMetadata::new(5, "orders", false, vec![replica.clone()]);
        let hidden = topic_description_from(&errored).await;
        assert!(hidden.partitions.is_empty());
        assert_eq!(hidden.error_code, 5);
        let stored = crate::protocol::api::TopicMetadata::new(0, "orders", false, vec![replica]);
        let described = topic_description_from(&stored).await;
        assert_eq!(described.partitions.len(), 1);
        assert_eq!(described.partitions[0].topic, "orders");
        assert_eq!(described.partitions[0].replicas, vec![2, 3]);
        assert_eq!(described.partitions[0].isr, vec![2]);
        assert_eq!(described.partitions[0].offline_replicas, vec![3]);
        assert_eq!(described.partitions[0].leader_epoch, 9);
        assert_eq!(stored.partitions[0].replica_nodes, vec![2, 3]);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn describing_many_named_topics_does_not_hold_the_caller() {
        // 20_000 names: scanning the image for each name held the caller 1.84s.
        let mut md = MetadataResponse::blank();
        md.topics = (0..20_000)
            .map(|index| {
                crate::protocol::api::TopicMetadata::new(0, format!("t{index}"), false, Vec::new())
            })
            .collect();
        md.topics.push(crate::protocol::api::TopicMetadata::new(
            5,
            "t0",
            false,
            Vec::new(),
        ));
        let names: Vec<String> = (0..20_000).map(|index| format!("t{index}")).collect();
        let started = std::time::Instant::now();
        let described = topic_descriptions_for_names(&md, &names).await;
        let elapsed = started.elapsed();
        assert_eq!(described.len(), 20_000);
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "describing named topics held the caller for {elapsed:?}"
        );
        assert_eq!(described.first().map(|topic| topic.error_code), Some(0));
        let missing = topic_descriptions_for_names(&md, &["other".to_string()]).await;
        assert_eq!(
            missing.first().map(|topic| topic.error_code),
            Some(error::UNKNOWN_TOPIC_OR_PARTITION)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn extending_many_described_topics_does_not_hold_the_caller() {
        // Scanning earlier descriptions is the same name scan that held assignment
        // grouping for 1.2s. Indexing 1_000_000 topics without a pause held the
        // caller 1.2s.
        let incoming: Vec<TopicDescription> = (0..1_000_000)
            .map(|index| {
                TopicDescription::new(format!("topic-{index}"), [0; 16], false, 0, Vec::new())
            })
            .collect();
        let mut out = Vec::new();
        let mut index = std::collections::HashMap::new();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = extend_described_topics(&mut out, &mut index, incoming) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "extending described topics held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn described_topics_keep_the_first_page() {
        let first = TopicDescription::new(
            "orders",
            [1; 16],
            false,
            0,
            vec![crate::PartitionInfo {
                topic: "orders".into(),
                partition: 0,
                leader: 1,
                leader_epoch: 0,
                replicas: Vec::new(),
                isr: Vec::new(),
                offline_replicas: Vec::new(),
            }],
        );
        let again = TopicDescription::new(
            "orders",
            [1; 16],
            false,
            0,
            vec![crate::PartitionInfo {
                topic: "orders".into(),
                partition: 1,
                leader: 1,
                leader_epoch: 0,
                replicas: Vec::new(),
                isr: Vec::new(),
                offline_replicas: Vec::new(),
            }],
        );
        let other = TopicDescription::new("payments", [2; 16], false, 0, Vec::new());
        let mut out = Vec::new();
        let mut index = std::collections::HashMap::new();
        extend_described_topics(&mut out, &mut index, vec![first, other, again]).await;
        assert_eq!(out.len(), 2);
        assert_eq!(out.first().map(|topic| topic.name.as_str()), Some("orders"));
        assert_eq!(
            out.first().map(|topic| {
                topic
                    .partitions
                    .iter()
                    .map(|partition| partition.partition)
                    .collect::<Vec<_>>()
            }),
            Some(vec![0, 1])
        );
        assert_eq!(
            out.get(1).map(|topic| topic.name.as_str()),
            Some("payments")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn listing_many_coordinator_keys_does_not_hold_the_caller() {
        // Scanning earlier keys is the same membership scan that held share
        // partitions for 714ms. Listing 1_000_000 keys without a pause held the
        // caller 671ms.
        let owned: Vec<String> = (0..1_000_000)
            .map(|index| format!("group-{index}"))
            .collect();
        let keys: Vec<&str> = owned.iter().map(String::as_str).collect();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = unique_in_order(&keys) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "listing coordinator keys held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn coordinator_keys_keep_the_first_seen_order() {
        let keys = unique_in_order(&["b", "a", "b", "a", "c"]).await;
        assert_eq!(keys, vec!["b", "a", "c"]);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn replacing_a_coordinator_address_lets_the_broker_leave() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use tokio::io::AsyncReadExt;

        let leader_listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let leader_addr = leader_listener.local_addr().unwrap();
        let other = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let other_addr = other.local_addr().unwrap().to_string();
        let open = Arc::new(AtomicUsize::new(0));
        let flag = Arc::clone(&open);
        let leader_peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = leader_listener.accept().await else {
                return;
            };
            let _started = flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = flag.fetch_sub(1, Ordering::SeqCst);
        });
        let other_peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = other.accept().await else {
                return;
            };
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
        });
        let leader = crate::net::BrokerConn::connect(
            &leader_addr.to_string(),
            "old-coord",
            Duration::from_secs(2),
        )
        .await
        .unwrap();
        while open.load(Ordering::SeqCst) == 0 {
            tokio::task::yield_now().await;
        }
        let bootstrap =
            crate::net::BrokerConn::connect(&other_addr, "admin-boot", Duration::from_secs(2))
                .await
                .unwrap();
        let mut admin = Admin::test_holding(bootstrap);
        let _stored = admin
            .conns
            .insert(4, super::offsets::AdminOffsetConn::test_holding(leader));
        let _old = admin.cluster.brokers.insert(4, "127.0.0.1:1".to_string());
        let remembered = admin
            .remember_coordinator(4, "127.0.0.1", i32::from(leader_addr.port()))
            .await
            .unwrap();
        assert!(remembered, "the new coordinator address was rejected");
        assert!(
            !admin.conns.contains_key(&4),
            "the old coordinator socket was kept"
        );
        assert_eq!(
            open.load(Ordering::SeqCst),
            0,
            "replacing a coordinator address left the broker blocked in a read"
        );
        drop(admin);
        leader_peer.abort();
        other_peer.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn dropping_a_group_coordinator_lets_the_broker_leave() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use tokio::io::AsyncReadExt;

        let leader_listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let leader_addr = leader_listener.local_addr().unwrap().to_string();
        let other = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let other_addr = other.local_addr().unwrap().to_string();
        let open = Arc::new(AtomicUsize::new(0));
        let flag = Arc::clone(&open);
        let leader_peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = leader_listener.accept().await else {
                return;
            };
            let _started = flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = flag.fetch_sub(1, Ordering::SeqCst);
        });
        let other_peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = other.accept().await else {
                return;
            };
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
        });
        let leader =
            crate::net::BrokerConn::connect(&leader_addr, "group-coord", Duration::from_secs(2))
                .await
                .unwrap();
        while open.load(Ordering::SeqCst) == 0 {
            tokio::task::yield_now().await;
        }
        let bootstrap =
            crate::net::BrokerConn::connect(&other_addr, "admin-boot", Duration::from_secs(2))
                .await
                .unwrap();
        let mut admin = Admin::test_holding(bootstrap);
        let _stored = admin
            .conns
            .insert(4, super::offsets::AdminOffsetConn::test_holding(leader));
        admin.invalidate_group_coord_idxs(&["group"], &[0], 4).await;
        assert_eq!(
            open.load(Ordering::SeqCst),
            0,
            "dropping a group coordinator left the broker blocked in a read"
        );
        drop(admin);
        leader_peer.abort();
        other_peer.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn retrying_an_admin_node_lets_the_broker_leave() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use tokio::io::AsyncReadExt;

        let leader_listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let leader_addr = leader_listener.local_addr().unwrap().to_string();
        let other = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let other_addr = other.local_addr().unwrap().to_string();
        let open = Arc::new(AtomicUsize::new(0));
        let flag = Arc::clone(&open);
        let leader_peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = leader_listener.accept().await else {
                return;
            };
            let _started = flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = flag.fetch_sub(1, Ordering::SeqCst);
        });
        let other_peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = other.accept().await else {
                return;
            };
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
        });
        let leader =
            crate::net::BrokerConn::connect(&leader_addr, "admin-retry", Duration::from_secs(2))
                .await
                .unwrap();
        while open.load(Ordering::SeqCst) == 0 {
            tokio::task::yield_now().await;
        }
        let bootstrap =
            crate::net::BrokerConn::connect(&other_addr, "admin-boot", Duration::from_secs(2))
                .await
                .unwrap();
        let mut admin = Admin::test_holding(bootstrap);
        let _stored = admin
            .conns
            .insert(2, offsets::AdminOffsetConn::test_holding(leader));
        admin.discard_node_conn(2).await;
        assert_eq!(
            open.load(Ordering::SeqCst),
            0,
            "retrying an admin node left the broker blocked in a read"
        );
        drop(admin);
        leader_peer.abort();
        other_peer.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn an_admin_bootstrap_race_lets_the_other_broker_leave() {
        use crate::protocol::api::{encode_api_versions_response, ApiVersionsResponse};
        use std::sync::atomic::{AtomicUsize, Ordering};
        use std::sync::Arc;
        use std::time::{Duration, Instant};
        use tokio::io::{AsyncReadExt, AsyncWriteExt};

        async fn answer(
            mut socket: tokio::net::TcpStream,
            open: Arc<AtomicUsize>,
            accepted: Arc<AtomicUsize>,
        ) {
            let _accepted = accepted.fetch_add(1, Ordering::SeqCst);
            let _started = open.fetch_add(1, Ordering::SeqCst);
            let mut size_buf = [0u8; 4];
            if socket.read_exact(&mut size_buf).await.is_ok() {
                let size = i32::from_be_bytes(size_buf).max(0) as usize;
                let mut request = vec![0u8; size];
                if socket.read_exact(&mut request).await.is_ok() {
                    if let Some(bytes) = request.get(4..8) {
                        let correlation = i32::from_be_bytes([
                            bytes.first().copied().unwrap_or(0),
                            bytes.get(1).copied().unwrap_or(0),
                            bytes.get(2).copied().unwrap_or(0),
                            bytes.get(3).copied().unwrap_or(0),
                        ]);
                        let mut body = bytes::BytesMut::new();
                        let encoded = encode_api_versions_response(
                            &mut body,
                            4,
                            &ApiVersionsResponse {
                                error_code: 0,
                                api_keys: Vec::new(),
                                throttle_time_ms: 0,
                                supported_features: Vec::new(),
                                finalized_features_epoch: None,
                                finalized_features: Vec::new(),
                                zk_migration_ready: false,
                            },
                        );
                        if encoded.is_ok() {
                            let mut response = Vec::new();
                            let len = i32::try_from(4 + body.len()).unwrap_or(0);
                            response.extend_from_slice(&len.to_be_bytes());
                            response.extend_from_slice(&correlation.to_be_bytes());
                            response.extend_from_slice(&body);
                            let _wrote = socket.write_all(&response).await;
                        }
                    }
                }
            }
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = open.fetch_sub(1, Ordering::SeqCst);
        }

        let first = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let second = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let first_addr = first.local_addr().unwrap().to_string();
        let second_addr = second.local_addr().unwrap().to_string();
        let open = Arc::new(AtomicUsize::new(0));
        let accepted = Arc::new(AtomicUsize::new(0));
        let first_peer = {
            let open = Arc::clone(&open);
            let accepted = Arc::clone(&accepted);
            tokio::spawn(async move {
                let Ok((socket, _)) = first.accept().await else {
                    return;
                };
                answer(socket, open, accepted).await;
            })
        };
        let second_peer = {
            let open = Arc::clone(&open);
            let accepted = Arc::clone(&accepted);
            tokio::spawn(async move {
                let Ok((socket, _)) = second.accept().await else {
                    return;
                };
                answer(socket, open, accepted).await;
            })
        };
        let cfg = AdminConfig::bootstrap([first_addr, second_addr]);
        let stats = Arc::new(crate::metrics::AdminTracker::default());
        let opened =
            Admin::open_bootstrap(&cfg, &stats, Instant::now() + Duration::from_secs(2)).await;
        assert!(opened.is_ok(), "the admin bootstrap race did not finish");
        assert_eq!(
            accepted.load(Ordering::SeqCst),
            2,
            "a bootstrap was not dialed"
        );
        assert_eq!(
            open.load(Ordering::SeqCst),
            1,
            "an admin bootstrap race left the unused broker blocked in a read"
        );
        drop(opened);
        first_peer.abort();
        second_peer.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn stopping_a_finished_admin_rpc_lets_the_broker_leave() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use tokio::io::AsyncReadExt;

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let open = Arc::new(AtomicUsize::new(0));
        let flag = Arc::clone(&open);
        let peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = listener.accept().await else {
                return;
            };
            let _started = flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = flag.fetch_sub(1, Ordering::SeqCst);
        });
        let conn = BrokerConn::connect(&addr, "admin-rpc", Duration::from_secs(2))
            .await
            .unwrap();
        while open.load(Ordering::SeqCst) == 0 {
            tokio::task::yield_now().await;
        }
        let held = offsets::AdminOffsetConn::test_holding(conn);
        let mut rpcing = tokio::task::JoinSet::new();
        let _ = rpcing.spawn(async move {
            (
                1i32,
                0i16,
                held,
                Ok::<bytes::Bytes, crate::Error>(bytes::Bytes::new()),
            )
        });
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }
        let dialing = tokio::task::JoinSet::<(i32, Result<offsets::AdminOffsetConn>)>::new();
        Admin::stop_leader_exchange(dialing, rpcing).await;
        assert_eq!(
            open.load(Ordering::SeqCst),
            0,
            "stopping a finished admin rpc left the broker blocked in a read"
        );
        peer.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn stopping_a_finished_admin_handshake_lets_the_broker_leave() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use tokio::io::AsyncReadExt;

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let open = Arc::new(AtomicUsize::new(0));
        let flag = Arc::clone(&open);
        let peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = listener.accept().await else {
                return;
            };
            let _started = flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = flag.fetch_sub(1, Ordering::SeqCst);
        });
        let conn = BrokerConn::connect(&addr, "admin-handshake", Duration::from_secs(2))
            .await
            .unwrap();
        while open.load(Ordering::SeqCst) == 0 {
            tokio::task::yield_now().await;
        }
        let versions = crate::protocol::api::ApiVersionsResponse {
            error_code: 0,
            api_keys: Vec::new(),
            throttle_time_ms: 0,
            supported_features: Vec::new(),
            finalized_features_epoch: None,
            finalized_features: Vec::new(),
            zk_migration_ready: false,
        };
        let mut set = tokio::task::JoinSet::<
            crate::Result<(BrokerConn, crate::protocol::api::ApiVersionsResponse)>,
        >::new();
        let _ = set.spawn(async move { Ok((conn, versions)) });
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }
        Admin::finish_aborted_handshakes(set).await;
        assert_eq!(
            open.load(Ordering::SeqCst),
            0,
            "stopping a finished admin handshake left the broker blocked in a read"
        );
        peer.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn an_aborted_admin_handshake_lets_the_broker_leave() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use tokio::io::AsyncReadExt;

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let open = Arc::new(AtomicUsize::new(0));
        let flag = Arc::clone(&open);
        let peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = listener.accept().await else {
                return;
            };
            let _started = flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = flag.fetch_sub(1, Ordering::SeqCst);
        });
        let conn = BrokerConn::connect(&addr, "abort-admin", Duration::from_secs(2))
            .await
            .unwrap();
        while open.load(Ordering::SeqCst) == 0 {
            tokio::task::yield_now().await;
        }
        let mut set = tokio::task::JoinSet::<
            crate::Result<(BrokerConn, crate::protocol::api::ApiVersionsResponse)>,
        >::new();
        let _spawned = set.spawn(async move {
            let _hold = conn;
            std::future::pending().await
        });
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }
        Admin::finish_aborted_handshakes(set).await;
        assert_eq!(
            open.load(Ordering::SeqCst),
            0,
            "an aborted admin handshake left the broker blocked in a read"
        );
        peer.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn an_aborted_indexed_admin_handshake_lets_the_broker_leave() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use tokio::io::AsyncReadExt;

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let open = Arc::new(AtomicUsize::new(0));
        let flag = Arc::clone(&open);
        let peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = listener.accept().await else {
                return;
            };
            let _started = flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = flag.fetch_sub(1, Ordering::SeqCst);
        });
        let conn = BrokerConn::connect(&addr, "abort-indexed-admin", Duration::from_secs(2))
            .await
            .unwrap();
        while open.load(Ordering::SeqCst) == 0 {
            tokio::task::yield_now().await;
        }
        let mut set = tokio::task::JoinSet::<(
            usize,
            crate::Result<(BrokerConn, crate::protocol::api::ApiVersionsResponse)>,
        )>::new();
        let _spawned = set.spawn(async move {
            let _hold = conn;
            std::future::pending().await
        });
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }
        Admin::finish_aborted_indexed_handshakes(set).await;
        assert_eq!(
            open.load(Ordering::SeqCst),
            0,
            "an aborted indexed admin handshake left the broker blocked in a read"
        );
        peer.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn stopping_a_leader_exchange_lets_the_broker_leave() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use tokio::io::AsyncReadExt;

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let open = Arc::new(AtomicUsize::new(0));
        let flag = Arc::clone(&open);
        let peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = listener.accept().await else {
                return;
            };
            let _started = flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = flag.fetch_sub(1, Ordering::SeqCst);
        });
        let conn = crate::net::BrokerConn::connect(&addr, "stop-exchange", Duration::from_secs(2))
            .await
            .unwrap();
        while open.load(Ordering::SeqCst) == 0 {
            tokio::task::yield_now().await;
        }
        let held = offsets::AdminOffsetConn::test_holding(conn);
        let mut dialing = tokio::task::JoinSet::new();
        let _spawned = dialing.spawn(async move {
            let _hold = held;
            std::future::pending::<(i32, Result<offsets::AdminOffsetConn>)>().await
        });
        for _ in 0..8 {
            tokio::task::yield_now().await;
        }
        let rpcing = tokio::task::JoinSet::new();
        Admin::stop_leader_exchange(dialing, rpcing).await;
        assert_eq!(
            open.load(Ordering::SeqCst),
            0,
            "stopping a leader exchange left the broker blocked in a read"
        );
        peer.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn replacing_an_admin_socket_lets_the_broker_leave() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use tokio::io::AsyncReadExt;

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let open = Arc::new(AtomicUsize::new(0));
        let flag = Arc::clone(&open);
        let peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = listener.accept().await else {
                return;
            };
            let _started = flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = flag.fetch_sub(1, Ordering::SeqCst);
        });
        let mut conn =
            crate::net::BrokerConn::connect(&addr, "admin-replace", Duration::from_secs(2))
                .await
                .unwrap();
        while open.load(Ordering::SeqCst) == 0 {
            tokio::task::yield_now().await;
        }
        Admin::retire_admin_socket(&mut conn).await;
        assert_eq!(
            open.load(Ordering::SeqCst),
            0,
            "replacing an admin socket left the broker blocked in a read"
        );
        peer.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn dropping_the_bootstrap_socket_lets_the_broker_leave() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use tokio::io::AsyncReadExt;

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let open = Arc::new(AtomicUsize::new(0));
        let flag = Arc::clone(&open);
        let peer = tokio::spawn(async move {
            let Ok((mut socket, _)) = listener.accept().await else {
                return;
            };
            let _started = flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 8];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = flag.fetch_sub(1, Ordering::SeqCst);
        });
        let conn = crate::net::BrokerConn::connect(&addr, "admin-drop", Duration::from_secs(2))
            .await
            .unwrap();
        while open.load(Ordering::SeqCst) == 0 {
            tokio::task::yield_now().await;
        }
        let mut admin = Admin::test_holding(conn);
        let _inserted = admin
            .cluster
            .brokers
            .insert(1, admin.conn.addr().to_string());
        admin.drop_node_conn(1).await;
        assert_eq!(
            open.load(Ordering::SeqCst),
            0,
            "dropping the admin socket left the broker blocked in a read"
        );
        peer.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn bootstrap_handshake_timeout_closes_the_socket() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use tokio::io::AsyncReadExt;

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let open = Arc::new(AtomicUsize::new(0));
        let open_flag = Arc::clone(&open);
        let peer = tokio::spawn(async move {
            let (mut sock, _) = listener.accept().await.unwrap();
            let _started = open_flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 64];
            loop {
                match sock.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = open_flag.fetch_sub(1, Ordering::SeqCst);
        });
        let mut cfg = AdminConfig::bootstrap([addr.clone()]);
        cfg.request_timeout = Duration::from_millis(200);
        cfg.connect_timeout = Duration::from_millis(200);
        let stats = Arc::new(crate::metrics::AdminTracker::default());
        let result = Admin::open_one_bootstrap(
            &cfg,
            &addr,
            &stats,
            Instant::now() + Duration::from_millis(200),
        )
        .await;
        assert!(
            matches!(result, Err(Error::Timeout)),
            "a silent bootstrap should time out the handshake"
        );
        assert_eq!(
            open.load(Ordering::SeqCst),
            0,
            "bootstrap handshake left the socket blocked in a broker read"
        );
        peer.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn remembered_sasl_timeout_closes_the_socket() {
        use crate::protocol::api::ApiVersion;
        use crate::protocol::api_keys::{SASL_AUTHENTICATE, SASL_HANDSHAKE};
        use std::sync::atomic::{AtomicUsize, Ordering};
        use tokio::io::AsyncReadExt;

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let open = Arc::new(AtomicUsize::new(0));
        let open_flag = Arc::clone(&open);
        let peer = tokio::spawn(async move {
            let (mut sock, _) = listener.accept().await.unwrap();
            let _started = open_flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 64];
            loop {
                match sock.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = open_flag.fetch_sub(1, Ordering::SeqCst);
        });
        let mut cfg = AdminConfig::bootstrap([addr.clone()]);
        cfg.connect_timeout = Duration::from_millis(200);
        cfg.sasl_plain = Some(("user".into(), "pass".into()));
        let keys = [
            ApiVersion {
                api_key: SASL_HANDSHAKE,
                min_version: 0,
                max_version: 1,
            },
            ApiVersion {
                api_key: SASL_AUTHENTICATE,
                min_version: 0,
                max_version: 2,
            },
        ];
        let stats = Arc::new(crate::metrics::AdminTracker::default());
        let result = dial_known_admin_socket(
            &addr,
            &cfg,
            &stats,
            &keys,
            Instant::now() + Duration::from_millis(200),
        )
        .await;
        assert!(matches!(result, Err(Error::Timeout)));
        assert_eq!(
            open.load(Ordering::SeqCst),
            0,
            "admin sasl left the socket open"
        );
        peer.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn admin_handshake_timeout_closes_the_socket() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use tokio::io::AsyncReadExt;

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let open = Arc::new(AtomicUsize::new(0));
        let open_flag = Arc::clone(&open);
        let peer = tokio::spawn(async move {
            let (mut sock, _) = listener.accept().await.unwrap();
            let _started = open_flag.fetch_add(1, Ordering::SeqCst);
            let mut buf = [0u8; 64];
            loop {
                match sock.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => continue,
                }
            }
            let _left = open_flag.fetch_sub(1, Ordering::SeqCst);
        });
        let mut cfg = AdminConfig::bootstrap([addr.clone()]);
        cfg.request_timeout = Duration::from_millis(200);
        cfg.connect_timeout = Duration::from_millis(200);
        let stats = Arc::new(crate::metrics::AdminTracker::default());
        let result = dial_admin_socket(
            &addr,
            &cfg,
            &stats,
            Instant::now() + Duration::from_millis(200),
        )
        .await;
        assert!(
            matches!(result, Err(Error::Timeout)),
            "a silent admin broker should time out the handshake"
        );
        assert_eq!(
            open.load(Ordering::SeqCst),
            0,
            "admin handshake left the socket blocked in a broker read"
        );
        peer.abort();
    }

    #[test]
    fn elect_leader_topics_group_partitions_under_one_name() {
        let orders = "orders-topic-name-is-long".to_string();
        let orders_ptr = orders.as_ptr();
        let payments = "payments-topic-name-is-long".to_string();
        let payments_ptr = payments.as_ptr();
        let mut selection = ElectionSelection::default();
        let mut order = Vec::new();
        let mut kept = Vec::new();
        for (topic, partition) in [
            (orders, 1),
            ("orders-topic-name-is-long".to_string(), 0),
            (payments, 2),
        ] {
            if let Some(index) = selection.adopt(topic, partition) {
                order.push((index, partition));
                kept.push((index, partition));
            }
        }
        assert!(selection
            .adopt("orders-topic-name-is-long".to_string(), 1)
            .is_none());
        assert_eq!(
            selection.names.first().map(|name| name.as_ptr()),
            Some(orders_ptr)
        );
        assert_eq!(
            selection.names.get(1).map(|name| name.as_ptr()),
            Some(payments_ptr)
        );
        assert_eq!(order, vec![(0, 1), (0, 0), (1, 2)]);
        let topics = election_request_topics(&selection.names, &kept);
        assert_eq!(topics.len(), 2);
        assert_eq!(
            topics.first().map(|topic| topic.0),
            Some("orders-topic-name-is-long")
        );
        assert_eq!(
            topics.first().map(|topic| topic.1.as_slice()),
            Some([1, 0].as_slice())
        );
        assert_eq!(
            topics.get(1).map(|topic| topic.0),
            Some("payments-topic-name-is-long")
        );
        assert_eq!(
            topics.get(1).map(|topic| topic.1.as_slice()),
            Some([2].as_slice())
        );
        let mut returned = Vec::new();
        let orders_index = selection.name_index("orders-topic-name-is-long");
        assert!(mark_returned(&mut returned, orders_index, 1));
        assert!(mark_returned(&mut returned, orders_index, 0));
        assert!(!mark_returned(&mut returned, orders_index, 1));
        assert_eq!(
            selection.names.first().map(|name| name.as_ptr()),
            Some(orders_ptr)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_coordinators_does_not_hold_the_caller() {
        // 200_000 coordinators: reading each one held the caller 159ms.
        let coords: Vec<crate::protocol::group::CoordinatorResult> = (0..200_000)
            .map(|index| crate::protocol::group::CoordinatorResult {
                key: format!("group-{index}"),
                node_id: 1,
                host: "127.0.0.1".to_string(),
                port: 9092,
                error_code: 0,
                error_message: None,
            })
            .collect();
        let mut body = bytes::BytesMut::new();
        crate::protocol::group::encode_find_coordinator_response_coordinators(
            &mut body, 4, &coords,
        )
        .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_find_coordinator_response_coordinators_cooperative(&mut body, 4) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.len(), 200_000);
                assert_eq!(decoded.first().map(|item| item.key.as_str()), Some("group-0"));
                assert_eq!(decoded.first().map(|item| item.host.as_str()), Some("127.0.0.1"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding coordinators held the caller for {elapsed:?}"
        );
        let small = [
            crate::protocol::group::CoordinatorResult {
                key: "orders".to_string(),
                node_id: 4,
                host: "b".to_string(),
                port: 2,
                error_code: 7,
                error_message: Some("busy".to_string()),
            },
            crate::protocol::group::CoordinatorResult {
                key: "orders".to_string(),
                node_id: 4,
                host: "b".to_string(),
                port: 2,
                error_code: 0,
                error_message: None,
            },
        ];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::group::encode_find_coordinator_response_coordinators(
            &mut encoded,
            4,
            &small,
        )
        .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync =
            crate::protocol::group::decode_find_coordinator_response_coordinators(&mut once, 4)
                .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_find_coordinator_response_coordinators_cooperative(&mut paced, 4)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(coop.0.len(), 2);
        assert_eq!(coop.0[1].error_message, None);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_listed_groups_does_not_hold_the_caller() {
        let groups: Vec<ListedGroup> = (0..200_000)
            .map(|index| ListedGroup {
                group_id: format!("group-{index}"),
                protocol_type: "consumer".to_string(),
                group_state: "Stable".to_string(),
                group_type: "Classic".to_string(),
            })
            .collect();
        let resp = crate::protocol::admin::ListGroupsResponse {
            error_code: 0,
            groups,
        };
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_list_groups_response(&mut body, 5, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_list_groups_response_cooperative(&mut body, 5) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.groups.len(), 200_000);
                assert_eq!(decoded.groups.first().map(|item| item.group_id.as_str()), Some("group-0"));
                assert_eq!(decoded.groups.first().map(|item| item.group_state.as_str()), Some("Stable"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding listed groups held the caller for {elapsed:?}"
        );
        let small = crate::protocol::admin::ListGroupsResponse {
            error_code: 7,
            groups: vec![ListedGroup {
                group_id: "orders".to_string(),
                protocol_type: "consumer".to_string(),
                group_state: "Stable".to_string(),
                group_type: "Classic".to_string(),
            }],
        };
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_list_groups_response(&mut encoded, 5, &small)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_list_groups_response(&mut once, 5)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_list_groups_response_cooperative(&mut paced, 5)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(coop.0.error_code, 7);
        assert_eq!(
            coop.0.groups.first().map(|item| item.group_type.as_str()),
            Some("Classic")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_described_group_members_does_not_hold_the_caller() {
        let members: Vec<DescribedGroupMember> = (0..200_000)
            .map(|index| {
                DescribedGroupMember::new(format!("member-{index}"), "client", "127.0.0.1")
            })
            .collect();
        let mut group = DescribedGroup::new("orders", 0);
        group.members = members;
        let groups = [group];
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_groups_response(&mut body, 5, &groups)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_describe_groups_response_cooperative(&mut body, 5) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.first().map(|item| item.members.len()), Some(200_000));
                assert_eq!(
                    decoded.first().and_then(|item| item.members.first()).map(|item| item.member_id.as_str()),
                    Some("member-0")
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding described group members held the caller for {elapsed:?}"
        );
        let mut member = DescribedGroupMember::new("m", "client", "127.0.0.1");
        member.group_instance_id = Some("static".to_string());
        member.member_assignment = b"assign".to_vec();
        let mut group = DescribedGroup::new("orders", 7);
        group.error_message = Some("busy".to_string());
        group.members = vec![member];
        let groups = [group];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_groups_response(&mut encoded, 6, &groups)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_describe_groups_response(&mut once, 6)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_describe_groups_response_cooperative(&mut paced, 6)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.members.first())
                .and_then(|item| item.group_instance_id.as_deref()),
            Some("static")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_consumer_group_members_does_not_hold_the_caller() {
        let members: Vec<ConsumerGroupMember> = (0..200_000)
            .map(|index| {
                ConsumerGroupMember::new(format!("member-{index}"), 1, "client", "127.0.0.1")
            })
            .collect();
        let mut group = DescribedConsumerGroup::new("orders", 0);
        group.members = members;
        let groups = [group];
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_consumer_group_describe_response(&mut body, 1, &groups)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_consumer_group_describe_response_cooperative(&mut body, 1) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.first().map(|item| item.members.len()), Some(200_000));
                assert_eq!(
                    decoded.first().and_then(|item| item.members.first()).map(|item| item.member_id.as_str()),
                    Some("member-0")
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding consumer group members held the caller for {elapsed:?}"
        );
        let mut member = ConsumerGroupMember::new("m", 4, "client", "127.0.0.1");
        member.instance_id = Some("static".to_string());
        member.member_type = 1;
        member.assignment = ConsumerGroupAssignment::new(vec![
            crate::protocol::admin::ConsumerGroupTopicPartitions::new([1; 16], "orders", vec![7]),
        ]);
        let mut group = DescribedConsumerGroup::new("orders", 7);
        group.error_message = Some("busy".to_string());
        group.members = vec![member];
        let groups = [group];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_consumer_group_describe_response(&mut encoded, 1, &groups)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_consumer_group_describe_response(&mut once, 1)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_consumer_group_describe_response_cooperative(&mut paced, 1)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.members.first())
                .and_then(|item| item.instance_id.as_deref()),
            Some("static")
        );
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.members.first())
                .and_then(|item| item.assignment.topic_partitions.first())
                .and_then(|item| item.partitions.first())
                .copied(),
            Some(7)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_share_group_members_does_not_hold_the_caller() {
        let members: Vec<ShareGroupMember> = (0..200_000)
            .map(|index| ShareGroupMember::new(format!("member-{index}"), 1, "client", "127.0.0.1"))
            .collect();
        let mut group = DescribedShareGroup::new("orders", 0);
        group.members = members;
        let groups = [group];
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_share_group_describe_response(&mut body, 1, &groups)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_share_group_describe_response_cooperative(&mut body, 1) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.first().map(|item| item.members.len()), Some(200_000));
                assert_eq!(
                    decoded.first().and_then(|item| item.members.first()).map(|item| item.member_id.as_str()),
                    Some("member-0")
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding share group members held the caller for {elapsed:?}"
        );
        let mut member = ShareGroupMember::new("m", 4, "client", "127.0.0.1");
        member.rack_id = Some("rack-a".to_string());
        member.assignment = ShareGroupAssignment::new(vec![
            crate::protocol::admin::ShareGroupTopicPartitions::new([2; 16], "orders", vec![3]),
        ]);
        let mut group = DescribedShareGroup::new("orders", 7);
        group.error_message = Some("busy".to_string());
        group.members = vec![member];
        let groups = [group];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_share_group_describe_response(&mut encoded, 1, &groups)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_share_group_describe_response(&mut once, 1)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_share_group_describe_response_cooperative(&mut paced, 1)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.members.first())
                .and_then(|item| item.rack_id.as_deref()),
            Some("rack-a")
        );
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.members.first())
                .and_then(|item| item.assignment.topic_partitions.first())
                .and_then(|item| item.partitions.first())
                .copied(),
            Some(3)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_transactions_does_not_hold_the_caller() {
        let states: Vec<TransactionState> = (0..200_000)
            .map(|index| {
                let mut state = TransactionState::error(format!("txn-{index}"), 0);
                state.transaction_state = "Ongoing".to_string();
                state.producer_id = 9;
                state.producer_epoch = 2;
                state
            })
            .collect();
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_transactions_response(&mut body, &states)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_describe_transactions_response_cooperative(&mut body) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.len(), 200_000);
                assert_eq!(
                    decoded.first().map(|item| item.transactional_id.as_str()),
                    Some("txn-0")
                );
                assert_eq!(
                    decoded.first().map(|item| item.transaction_state.as_str()),
                    Some("Ongoing")
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding transactions held the caller for {elapsed:?}"
        );
        let mut state = TransactionState::error("orders", 7);
        state.transaction_state = "Ongoing".to_string();
        state.producer_id = 11;
        state.producer_epoch = 3;
        state.topics = vec![TransactionTopic {
            name: "orders".to_string(),
            partitions: vec![4],
        }];
        let states = [state];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_transactions_response(&mut encoded, &states)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_describe_transactions_response(&mut once)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_describe_transactions_response_cooperative(&mut paced)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(coop.0.first().map(|item| item.producer_epoch), Some(3));
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.topics.first())
                .and_then(|item| item.partitions.first())
                .copied(),
            Some(4)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_topic_partitions_does_not_hold_the_caller() {
        let partitions: Vec<DescribedTopicPartition> = (0..200_000)
            .map(|index| {
                let mut partition = DescribedTopicPartition::new(0);
                partition.partition_index = index;
                partition.leader_id = 1;
                partition
            })
            .collect();
        let mut topic = DescribedTopicPartitions::new("orders", 0);
        topic.partitions = partitions;
        let resp = DescribeTopicPartitionsResponse::new(vec![topic]);
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_topic_partitions_response(&mut body, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_describe_topic_partitions_response_cooperative(&mut body) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.throttle_time_ms, 0);
                assert_eq!(decoded.topics.first().map(|item| item.partitions.len()), Some(200_000));
                assert_eq!(
                    decoded.topics.first().and_then(|item| item.partitions.first()).map(|item| item.leader_id),
                    Some(1)
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding topic partitions held the caller for {elapsed:?}"
        );
        let mut partition = DescribedTopicPartition::new(0);
        partition.partition_index = 4;
        partition.leader_id = 2;
        partition.replica_nodes = vec![2, 3];
        partition.eligible_leader_replicas = Some(vec![2]);
        let mut topic = DescribedTopicPartitions::new("orders", 0);
        topic.topic_id = [9; 16];
        topic.partitions = vec![partition];
        let mut resp = DescribeTopicPartitionsResponse::new(vec![topic]);
        resp.next_cursor = Some(TopicPartitionCursor::new("orders", 5));
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_topic_partitions_response(&mut encoded, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_describe_topic_partitions_response(&mut once)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_describe_topic_partitions_response_cooperative(&mut paced)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(
            coop.topics
                .first()
                .and_then(|item| item.partitions.first())
                .map(|item| item.replica_nodes.as_slice()),
            Some([2, 3].as_slice())
        );
        assert_eq!(
            coop.next_cursor
                .as_ref()
                .map(|cursor| cursor.partition_index),
            Some(5)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_config_entries_does_not_hold_the_caller() {
        let entries: Vec<ConfigEntry> = (0..200_000)
            .map(|index| ConfigEntry::new(format!("key-{index}"), Some("1".to_string())))
            .collect();
        let mut result = DescribeConfigsResult::error(CONFIG_RESOURCE_TOPIC, "orders", 0);
        result.entries = entries;
        let results = [result];
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_configs_response(&mut body, 4, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_describe_configs_response_cooperative(&mut body, 4) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.first().map(|item| item.entries.len()), Some(200_000));
                assert_eq!(
                    decoded.first().and_then(|item| item.entries.first()).map(|item| item.name.as_str()),
                    Some("key-0")
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding config entries held the caller for {elapsed:?}"
        );
        let mut entry = ConfigEntry::new("retention.ms", Some("1000".to_string()));
        entry.documentation = Some("keep".to_string());
        entry.synonyms = vec![ConfigSynonym {
            name: "log.retention.ms".to_string(),
            value: Some("1000".to_string()),
            source: 5,
        }];
        let mut result = DescribeConfigsResult::error(CONFIG_RESOURCE_TOPIC, "orders", 7);
        result.error_message = Some("busy".to_string());
        result.entries = vec![entry];
        let results = [result];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_configs_response(&mut encoded, 4, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_describe_configs_response(&mut once, 4)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_describe_configs_response_cooperative(&mut paced, 4)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.entries.first())
                .and_then(|item| item.documentation.as_deref()),
            Some("keep")
        );
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.entries.first())
                .and_then(|item| item.synonyms.first())
                .map(|item| item.name.as_str()),
            Some("log.retention.ms")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_fetched_offsets_does_not_hold_the_caller() {
        let topics: Vec<crate::protocol::group::FetchedOffsetTopic> = (0..200_000)
            .map(|index| crate::protocol::group::FetchedOffsetTopic {
                topic: format!("topic-{index}"),
                partitions: vec![crate::protocol::group::FetchedOffset::new(0, 1, 0)],
            })
            .collect();
        let groups = [crate::protocol::group::OffsetFetchGroupResult {
            group_id: "orders".to_string(),
            topics,
            error_code: 0,
        }];
        let mut body = bytes::BytesMut::new();
        crate::protocol::group::encode_offset_fetch_groups_response(&mut body, 8, &groups)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_offset_fetch_groups_response_cooperative(&mut body, 8) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.first().map(|item| item.topics.len()), Some(200_000));
                assert_eq!(
                    decoded.first().and_then(|item| item.topics.first()).map(|item| item.topic.as_str()),
                    Some("topic-0")
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding fetched offsets held the caller for {elapsed:?}"
        );
        let groups = [crate::protocol::group::OffsetFetchGroupResult {
            group_id: "orders".to_string(),
            topics: vec![crate::protocol::group::FetchedOffsetTopic {
                topic: "orders".to_string(),
                partitions: vec![crate::protocol::group::FetchedOffset::partition_data(
                    4,
                    9,
                    Some(3),
                    "mark",
                    0,
                )],
            }],
            error_code: 0,
        }];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::group::encode_offset_fetch_groups_response(&mut encoded, 8, &groups)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::group::decode_offset_fetch_groups_response(&mut once, 8)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_offset_fetch_groups_response_cooperative(&mut paced, 8)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.topics.first())
                .and_then(|item| item.partitions.first())
                .map(|item| item.metadata.as_str()),
            Some("mark")
        );
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.topics.first())
                .and_then(|item| item.partitions.first())
                .map(|item| item.leader_epoch),
            Some(3)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_log_dir_partitions_does_not_hold_the_caller() {
        let partitions: Vec<DescribeLogDirsPartition> = (0..2_000_000)
            .map(|index| DescribeLogDirsPartition::new(index, 64, 1, false))
            .collect();
        let topic = DescribeLogDirsTopic::new("orders", partitions);
        let result = DescribeLogDirsResult::new(0, "/var/lib/kafka", vec![topic], 100, 50);
        let resp = DescribeLogDirsResponse::new(0, vec![result]);
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_log_dirs_response(&mut body, 4, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_describe_log_dirs_response_cooperative(&mut body, 4) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.throttle_time_ms, 0);
                assert_eq!(
                    decoded.results.first().and_then(|item| item.topics.first()).map(|item| item.partitions.len()),
                    Some(2_000_000)
                );
                assert_eq!(
                    decoded.results.first().and_then(|item| item.topics.first()).and_then(|item| item.partitions.first()).map(|item| item.partition_size),
                    Some(64)
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding log directory partitions held the caller for {elapsed:?}"
        );
        let partition = DescribeLogDirsPartition::new(4, 64, 2, true);
        let topic = DescribeLogDirsTopic::new("orders", vec![partition]);
        let result = DescribeLogDirsResult::new(0, "/var/lib/kafka", vec![topic], 100, 50);
        let resp = DescribeLogDirsResponse::new(7, vec![result]);
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_log_dirs_response(&mut encoded, 4, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_describe_log_dirs_response(&mut once, 4)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_describe_log_dirs_response_cooperative(&mut paced, 4)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.error_code, 7);
        assert_eq!(coop.results.first().map(|item| item.total_bytes), Some(100));
        assert_eq!(
            coop.results
                .first()
                .and_then(|item| item.topics.first())
                .and_then(|item| item.partitions.first())
                .map(|item| item.is_future_key),
            Some(true)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_described_producers_does_not_hold_the_caller() {
        let partitions: Vec<DescribeProducersPartition> = (0..2_000_000)
            .map(|index| DescribeProducersPartition::new(index, 0, None, Vec::new()))
            .collect();
        let topic = DescribeProducersTopic::new("orders", partitions);
        let resp = crate::protocol::admin::DescribeProducersResponse::new(vec![topic]);
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_producers_response(&mut body, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_describe_producers_response_cooperative(&mut body) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.throttle_time_ms, 0);
                assert_eq!(
                    decoded.topics.first().map(|item| item.partitions.len()),
                    Some(2_000_000)
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding described producers held the caller for {elapsed:?}"
        );
        let producer = ActiveProducer {
            producer_id: 9,
            producer_epoch: 2,
            last_sequence: 4,
            last_timestamp: 8,
            coordinator_epoch: 1,
            current_txn_start_offset: 3,
        };
        let partition =
            DescribeProducersPartition::new(7, 5, Some("busy".to_string()), vec![producer]);
        let topic = DescribeProducersTopic::new("orders", vec![partition]);
        let resp = crate::protocol::admin::DescribeProducersResponse::new(vec![topic]);
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_producers_response(&mut encoded, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_describe_producers_response(&mut once)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_describe_producers_response_cooperative(&mut paced)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(
            coop.topics
                .first()
                .and_then(|item| item.partitions.first())
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
        assert_eq!(
            coop.topics
                .first()
                .and_then(|item| item.partitions.first())
                .and_then(|item| item.active_producers.first())
                .map(|item| item.producer_id),
            Some(9)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_acls_does_not_hold_the_caller() {
        let acls: Vec<AclBinding> = (0..200_000)
            .map(|index| AclBinding::allow_topic(format!("topic-{index}"), "User:alice"))
            .collect();
        let mut body = bytes::BytesMut::new();
        crate::protocol::acl::encode_describe_acls_response(&mut body, 3, &acls)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_describe_acls_response_cooperative(&mut body, 3) => {
                let (decoded, throttle, message, error_code) =
                    decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(error_code, 0);
                assert_eq!(message, None);
                assert_eq!(decoded.len(), 200_000);
                assert_eq!(decoded.first().map(|item| item.resource_name.as_str()), Some("topic-0"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding acls held the caller for {elapsed:?}"
        );
        let mut kept = AclBinding::allow_topic("orders", "User:alice");
        kept.host = "10.0.0.1".to_string();
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::acl::encode_describe_acls_response_with_error_message(
            &mut encoded,
            3,
            &[kept],
            Some("busy"),
        )
        .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::acl::decode_describe_acls_response(&mut once, 3)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_describe_acls_response_cooperative(&mut paced, 3)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(sync.2.as_deref(), Some("busy"));
        assert_eq!(coop.2.as_deref(), Some("busy"));
        assert_eq!(
            coop.0.first().map(|item| item.host.as_str()),
            Some("10.0.0.1")
        );
        let rejected = [AclBinding::allow_topic("orders", "User:alice")];
        let mut failed = bytes::BytesMut::new();
        crate::protocol::acl::encode_describe_acls_response_with_error_code(
            &mut failed,
            3,
            &rejected,
            7,
        )
        .unwrap_or_else(|error| panic!("{error}"));
        let mut failed_once = failed.clone();
        let mut failed_paced = failed;
        let sync_failed = crate::protocol::acl::decode_describe_acls_response(&mut failed_once, 3)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop_failed = decode_describe_acls_response_cooperative(&mut failed_paced, 3)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert!(sync_failed.0.is_empty());
        assert!(coop_failed.0.is_empty());
        assert_eq!(coop_failed.3, 7);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_deleted_groups_does_not_hold_the_caller() {
        let results: Vec<DeletableGroupResult> = (0..2_000_000)
            .map(|index| DeletableGroupResult::new(format!("group-{index}"), 0))
            .collect();
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_delete_groups_response(&mut body, 2, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_delete_groups_response_cooperative(&mut body, 2) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.len(), 2_000_000);
                assert_eq!(decoded.first().map(|item| item.group_id.as_str()), Some("group-0"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding deleted groups held the caller for {elapsed:?}"
        );
        let small = [
            DeletableGroupResult::new("orders", 0),
            DeletableGroupResult::new("orders", 7),
        ];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_delete_groups_response(&mut encoded, 2, &small)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_delete_groups_response(&mut once, 2)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_delete_groups_response_cooperative(&mut paced, 2)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(coop.0.len(), 2);
        assert_eq!(coop.0.get(1).map(|item| item.error_code), Some(7));
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_share_offsets_does_not_hold_the_caller() {
        let partitions: Vec<DescribedShareGroupOffsetsPartitionWithLag> = (0..500_000)
            .map(|index| DescribedShareGroupOffsetsPartitionWithLag {
                partition: DescribedShareGroupOffsetsPartition {
                    partition_index: index,
                    start_offset: 8,
                    leader_epoch: 1,
                    error_code: 0,
                    error_message: None,
                },
                raw_lag: 3,
            })
            .collect();
        let groups = [DescribedShareGroupOffsetsWithLag {
            group_id: "orders".to_string(),
            topics: vec![DescribedShareGroupOffsetsTopicWithLag {
                topic_name: "orders".to_string(),
                topic_id: [1; 16],
                partitions,
            }],
            error_code: 0,
            error_message: None,
        }];
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_share_group_offsets_response_versioned(
            &mut body, 1, &groups, 0,
        )
        .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_describe_share_group_offsets_response_versioned_cooperative(&mut body, 1) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(
                    decoded.first().and_then(|item| item.topics.first()).map(|item| item.partitions.len()),
                    Some(500_000)
                );
                assert_eq!(
                    decoded.first().and_then(|item| item.topics.first()).and_then(|item| item.partitions.first()).map(|item| item.raw_lag),
                    Some(3)
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding share offsets held the caller for {elapsed:?}"
        );
        let groups = [DescribedShareGroupOffsetsWithLag {
            group_id: "orders".to_string(),
            topics: vec![DescribedShareGroupOffsetsTopicWithLag {
                topic_name: "orders".to_string(),
                topic_id: [4; 16],
                partitions: vec![DescribedShareGroupOffsetsPartitionWithLag {
                    partition: DescribedShareGroupOffsetsPartition {
                        partition_index: 7,
                        start_offset: 11,
                        leader_epoch: 2,
                        error_code: 0,
                        error_message: Some("busy".to_string()),
                    },
                    raw_lag: 5,
                }],
            }],
            error_code: 9,
            error_message: Some("group".to_string()),
        }];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_share_group_offsets_response_versioned(
            &mut encoded,
            1,
            &groups,
            0,
        )
        .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_describe_share_group_offsets_response_versioned(
            &mut once, 1,
        )
        .unwrap_or_else(|error| panic!("{error}"));
        let coop =
            decode_describe_share_group_offsets_response_versioned_cooperative(&mut paced, 1)
                .await
                .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("group")
        );
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.topics.first())
                .and_then(|item| item.partitions.first())
                .map(|item| item.raw_lag),
            Some(5)
        );
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.topics.first())
                .and_then(|item| item.partitions.first())
                .and_then(|item| item.partition.error_message.as_deref()),
            Some("busy")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_election_results_does_not_hold_the_caller() {
        let partitions: Vec<ElectLeadersPartitionResult> = (0..1_000_000)
            .map(|index| ElectLeadersPartitionResult {
                partition_id: index,
                error_code: 0,
                error_message: None,
            })
            .collect();
        let resp = ElectLeadersResponse::new(
            0,
            0,
            vec![ElectLeadersResult {
                topic: "orders".to_string(),
                partitions,
            }],
        );
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_elect_leaders_response(&mut body, 2, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = crate::protocol::admin::decode_elect_leaders_response_cooperative(&mut body, 2) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.throttle_time_ms, 0);
                assert_eq!(
                    decoded.results.first().map(|item| item.partitions.len()),
                    Some(1_000_000)
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding election results held the caller for {elapsed:?}"
        );
        let resp = ElectLeadersResponse::new(
            4,
            7,
            vec![ElectLeadersResult {
                topic: "orders".to_string(),
                partitions: vec![ElectLeadersPartitionResult {
                    partition_id: 3,
                    error_code: 5,
                    error_message: Some("busy".to_string()),
                }],
            }],
        );
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_elect_leaders_response(&mut encoded, 2, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_elect_leaders_response(&mut once, 2)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = crate::protocol::admin::decode_elect_leaders_response_cooperative(&mut paced, 2)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.error_code, 7);
        assert_eq!(coop.throttle_time_ms, 4);
        assert_eq!(
            coop.results
                .first()
                .and_then(|item| item.partitions.first())
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_created_topics_does_not_hold_the_caller() {
        let results: Vec<TopicResult> = (0..1_000_000)
            .map(|index| {
                let mut topic = TopicResult::new(format!("topic-{index}"), 0, None);
                topic.topic_id = [1; 16];
                topic.num_partitions = 3;
                topic.replication_factor = 2;
                topic
            })
            .collect();
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_create_topics_response(&mut body, 7, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_create_topics_response_cooperative(&mut body, 7) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.len(), 1_000_000);
                assert_eq!(decoded.first().map(|item| item.name.as_str()), Some("topic-0"));
                assert_eq!(decoded.first().map(|item| item.num_partitions), Some(3));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding created topics held the caller for {elapsed:?}"
        );
        let mut topic = TopicResult::new("orders", 7, Some("busy".to_string()));
        topic.topic_id = [9; 16];
        topic.num_partitions = 4;
        topic.replication_factor = 3;
        topic.configs = vec![CreatedTopicConfig {
            name: "retention.ms".to_string(),
            value: Some("1000".to_string()),
            read_only: false,
            config_source: 1,
            is_sensitive: false,
        }];
        let results = [topic];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_create_topics_response(&mut encoded, 7, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_create_topics_response(&mut once, 7)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_create_topics_response_cooperative(&mut paced, 7)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
        assert_eq!(coop.0.first().map(|item| item.topic_id), Some([9; 16]));
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.configs.first())
                .map(|item| item.name.as_str()),
            Some("retention.ms")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_deleted_topics_does_not_hold_the_caller() {
        let results: Vec<TopicResult> = (0..1_000_000)
            .map(|index| {
                let mut topic = TopicResult::new(format!("topic-{index}"), 0, None);
                topic.topic_id = [2; 16];
                topic
            })
            .collect();
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_delete_topics_response(&mut body, 6, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_delete_topics_response_cooperative(&mut body, 6) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.len(), 1_000_000);
                assert_eq!(decoded.first().map(|item| item.name.as_str()), Some("topic-0"));
                assert_eq!(decoded.first().map(|item| item.topic_id), Some([2; 16]));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding deleted topics held the caller for {elapsed:?}"
        );
        let mut topic = TopicResult::new("orders", 7, Some("busy".to_string()));
        topic.topic_id = [4; 16];
        let results = [topic];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_delete_topics_response(&mut encoded, 6, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_delete_topics_response(&mut once, 6)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_delete_topics_response_cooperative(&mut paced, 6)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
        assert_eq!(coop.0.first().map(|item| item.topic_id), Some([4; 16]));
        assert_eq!(coop.0.first().map(|item| item.num_partitions), Some(-1));
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_deleted_acls_does_not_hold_the_caller() {
        let matching: Vec<AclBinding> = (0..200_000)
            .map(|index| AclBinding::allow_topic(format!("topic-{index}"), "User:alice"))
            .collect();
        let mut body = bytes::BytesMut::new();
        crate::protocol::acl::encode_delete_acls_response(&mut body, 3, 0, &matching)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_delete_acls_filter_results_cooperative(&mut body, 3) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.first().map(|item| item.matching.len()), Some(200_000));
                assert_eq!(
                    decoded.first().and_then(|item| item.matching.first()).map(|item| item.resource_name.as_str()),
                    Some("topic-0")
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding deleted acls held the caller for {elapsed:?}"
        );
        let filters = [
            crate::protocol::acl::DeletedAclsFilterResult {
                error_code: 0,
                error_message: Some("busy".to_string()),
                matching: vec![crate::protocol::acl::DeleteAclsMatchingAcl {
                    error_code: 0,
                    error_message: None,
                    resource_type: 2,
                    resource_name: "orders".to_string(),
                    pattern_type: 3,
                    principal: "User:alice".to_string(),
                    host: "10.0.0.1".to_string(),
                    operation: 3,
                    permission: 3,
                }],
            },
            crate::protocol::acl::DeletedAclsFilterResult {
                error_code: 7,
                error_message: None,
                matching: Vec::new(),
            },
        ];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::acl::encode_delete_acls_filter_results(&mut encoded, 3, &filters)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::acl::decode_delete_acls_filter_results(&mut once, 3)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_delete_acls_filter_results_cooperative(&mut paced, 3)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(coop.0.len(), 2);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.matching.first())
                .map(|item| item.host.as_str()),
            Some("10.0.0.1")
        );
        assert_eq!(coop.0.get(1).map(|item| item.error_code), Some(7));
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_delegation_tokens_does_not_hold_the_caller() {
        let tokens: Vec<DescribedDelegationToken> = (0..200_000)
            .map(|index| DescribedDelegationToken {
                principal_type: "User".to_string(),
                principal_name: format!("user-{index}"),
                token_requester_principal_type: "User".to_string(),
                token_requester_principal_name: "admin".to_string(),
                issue_timestamp: 1,
                expiry_timestamp: 2,
                max_timestamp: 3,
                token_id: format!("token-{index}"),
                hmac: vec![1, 2, 3, 4],
                renewers: Vec::new(),
            })
            .collect();
        let resp = DescribeDelegationTokenResponse::new(0, tokens);
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_delegation_token_response(&mut body, 3, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_describe_delegation_token_response_cooperative(&mut body, 3) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.error_code, 0);
                assert_eq!(decoded.tokens.len(), 200_000);
                assert_eq!(
                    decoded.tokens.first().map(|item| item.token_id.as_str()),
                    Some("token-0")
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding delegation tokens held the caller for {elapsed:?}"
        );
        let token = DescribedDelegationToken {
            principal_type: "User".to_string(),
            principal_name: "alice".to_string(),
            token_requester_principal_type: "User".to_string(),
            token_requester_principal_name: "admin".to_string(),
            issue_timestamp: 1,
            expiry_timestamp: 2,
            max_timestamp: 3,
            token_id: "token-a".to_string(),
            hmac: vec![9, 8],
            renewers: vec![DescribedDelegationTokenRenewer {
                principal_type: "User".to_string(),
                principal_name: "bob".to_string(),
            }],
        };
        let mut resp = DescribeDelegationTokenResponse::new(7, vec![token]);
        resp.throttle_time_ms = 4;
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_delegation_token_response(&mut encoded, 3, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_describe_delegation_token_response(&mut once, 3)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_describe_delegation_token_response_cooperative(&mut paced, 3)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.error_code, 7);
        assert_eq!(coop.throttle_time_ms, 4);
        assert_eq!(
            coop.tokens
                .first()
                .and_then(|item| item.renewers.first())
                .map(|item| item.principal_name.as_str()),
            Some("bob")
        );
        assert_eq!(
            coop.tokens.first().map(|item| item.hmac.as_slice()),
            Some([9, 8].as_slice())
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_altered_share_offsets_does_not_hold_the_caller() {
        let partitions: Vec<AlteredShareGroupOffsetsPartition> = (0..1_000_000)
            .map(|index| AlteredShareGroupOffsetsPartition {
                partition_index: index,
                error_code: 0,
                error_message: None,
            })
            .collect();
        let mut resp = AlteredShareGroupOffsets::new(0);
        resp.topics = vec![AlteredShareGroupOffsetsTopic {
            topic_name: "orders".to_string(),
            topic_id: [1; 16],
            partitions,
        }];
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_alter_share_group_offsets_response(&mut body, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_alter_share_group_offsets_response_cooperative(&mut body) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.throttle_time_ms, 0);
                assert_eq!(
                    decoded.topics.first().map(|item| item.partitions.len()),
                    Some(1_000_000)
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding altered share offsets held the caller for {elapsed:?}"
        );
        let mut resp = AlteredShareGroupOffsets::new(7);
        resp.throttle_time_ms = 4;
        resp.error_message = Some("group".to_string());
        resp.topics = vec![AlteredShareGroupOffsetsTopic {
            topic_name: "orders".to_string(),
            topic_id: [3; 16],
            partitions: vec![AlteredShareGroupOffsetsPartition {
                partition_index: 2,
                error_code: 5,
                error_message: Some("busy".to_string()),
            }],
        }];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_alter_share_group_offsets_response(&mut encoded, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_alter_share_group_offsets_response(&mut once)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_alter_share_group_offsets_response_cooperative(&mut paced)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.error_message.as_deref(), Some("group"));
        assert_eq!(
            coop.topics
                .first()
                .and_then(|item| item.partitions.first())
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
        assert_eq!(coop.topics.first().map(|item| item.topic_id), Some([3; 16]));
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_deleted_share_offsets_does_not_hold_the_caller() {
        let topics: Vec<DeletedShareGroupOffsetsTopic> = (0..1_000_000)
            .map(|index| DeletedShareGroupOffsetsTopic {
                topic_name: format!("topic-{index}"),
                topic_id: [1; 16],
                error_code: 0,
                error_message: None,
            })
            .collect();
        let mut resp = DeletedShareGroupOffsets::new(0);
        resp.topics = topics;
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_delete_share_group_offsets_response(&mut body, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_delete_share_group_offsets_response_cooperative(&mut body) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.throttle_time_ms, 0);
                assert_eq!(decoded.topics.len(), 1_000_000);
                assert_eq!(decoded.topics.first().map(|item| item.topic_name.as_str()), Some("topic-0"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding deleted share offsets held the caller for {elapsed:?}"
        );
        let mut resp = DeletedShareGroupOffsets::new(7);
        resp.throttle_time_ms = 4;
        resp.error_message = Some("group".to_string());
        resp.topics = vec![DeletedShareGroupOffsetsTopic {
            topic_name: "orders".to_string(),
            topic_id: [5; 16],
            error_code: 3,
            error_message: Some("busy".to_string()),
        }];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_delete_share_group_offsets_response(&mut encoded, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_delete_share_group_offsets_response(&mut once)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_delete_share_group_offsets_response_cooperative(&mut paced)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.error_message.as_deref(), Some("group"));
        assert_eq!(
            coop.topics
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
        assert_eq!(coop.topics.first().map(|item| item.topic_id), Some([5; 16]));
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_created_partitions_does_not_hold_the_caller() {
        let results: Vec<TopicResult> = (0..1_000_000)
            .map(|index| TopicResult::new(format!("topic-{index}"), 0, None))
            .collect();
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_create_partitions_response(&mut body, 3, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_create_partitions_response_cooperative(&mut body, 3) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.len(), 1_000_000);
                assert_eq!(decoded.first().map(|item| item.name.as_str()), Some("topic-0"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding created partitions held the caller for {elapsed:?}"
        );
        let results = [TopicResult::new("orders", 7, Some("busy".to_string()))];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_create_partitions_response(&mut encoded, 3, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_create_partitions_response(&mut once, 3)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_create_partitions_response_cooperative(&mut paced, 3)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_created_acls_does_not_hold_the_caller() {
        let results: Vec<AclCreationResult> = (0..1_000_000)
            .map(|_| AclCreationResult {
                error_code: 0,
                error_message: None,
            })
            .collect();
        let mut body = bytes::BytesMut::new();
        crate::protocol::acl::encode_create_acls_response(&mut body, 3, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_create_acls_response_cooperative(&mut body, 3) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.len(), 1_000_000);
                assert_eq!(decoded.first().map(|item| item.error_code), Some(0));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding created acls held the caller for {elapsed:?}"
        );
        let results = [AclCreationResult {
            error_code: 7,
            error_message: Some("busy".to_string()),
        }];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::acl::encode_create_acls_response(&mut encoded, 3, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::acl::decode_create_acls_response(&mut once, 3)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_create_acls_response_cooperative(&mut paced, 3)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_listed_reassignments_does_not_hold_the_caller() {
        let partitions: Vec<crate::protocol::admin::OngoingPartitionReassignment> = (0..1_000_000)
            .map(crate::protocol::admin::OngoingPartitionReassignment::new)
            .collect();
        let resp = crate::protocol::admin::ListPartitionReassignmentsResponse::new(
            0,
            None,
            vec![crate::protocol::admin::OngoingTopicReassignment::new(
                "orders", partitions,
            )],
        );
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_list_partition_reassignments_response(&mut body, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_list_partition_reassignments_response_cooperative(&mut body) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.throttle_time_ms, 0);
                assert_eq!(
                    decoded.topics.first().map(|item| item.partitions.len()),
                    Some(1_000_000)
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding listed reassignments held the caller for {elapsed:?}"
        );
        let mut partition = crate::protocol::admin::OngoingPartitionReassignment::new(4);
        partition.replicas = vec![1, 2];
        partition.adding_replicas = vec![3];
        partition.removing_replicas = vec![1];
        let resp = crate::protocol::admin::ListPartitionReassignmentsResponse::new(
            7,
            Some("busy".to_string()),
            vec![crate::protocol::admin::OngoingTopicReassignment::new(
                "orders",
                vec![partition],
            )],
        );
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_list_partition_reassignments_response(&mut encoded, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_list_partition_reassignments_response(&mut once)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_list_partition_reassignments_response_cooperative(&mut paced)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.error_message.as_deref(), Some("busy"));
        assert_eq!(
            coop.topics
                .first()
                .and_then(|item| item.partitions.first())
                .map(|item| item.replicas.as_slice()),
            Some([1, 2].as_slice())
        );
        assert_eq!(
            coop.topics
                .first()
                .and_then(|item| item.partitions.first())
                .map(|item| item.adding_replicas.as_slice()),
            Some([3].as_slice())
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_config_resources_does_not_hold_the_caller() {
        let resources: Vec<ListedConfigResource> = (0..1_000_000)
            .map(|index| ListedConfigResource::new(format!("resource-{index}"), 2))
            .collect();
        let resp = crate::protocol::admin::ListConfigResourcesResponse::new(0, resources);
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_list_config_resources_response(&mut body, 1, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_list_config_resources_response_cooperative(&mut body, 1) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.throttle_time_ms, 0);
                assert_eq!(decoded.config_resources.len(), 1_000_000);
                assert_eq!(
                    decoded.config_resources.first().map(|item| item.resource_name.as_str()),
                    Some("resource-0")
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding config resources held the caller for {elapsed:?}"
        );
        let resp =
            ListConfigResourcesResponse::new(7, vec![ListedConfigResource::new("orders", 2)]);
        let mut encoded = bytes::BytesMut::new();
        encode_list_config_resources_response(&mut encoded, 1, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = decode_list_config_resources_response(&mut once, 1)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_list_config_resources_response_cooperative(&mut paced, 1)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.error_code, 7);
        assert_eq!(
            coop.config_resources.first().map(|item| item.resource_type),
            Some(2)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_client_quotas_does_not_hold_the_caller() {
        let entries: Vec<ClientQuotaEntry> = (0..200_000)
            .map(|index| ClientQuotaEntry {
                entity: vec![ClientQuotaEntity {
                    entity_type: "client-id".to_string(),
                    name: Some(format!("client-{index}")),
                }],
                values: vec![ClientQuotaValue::new("producer_byte_rate", 1.0)],
            })
            .collect();
        let resp =
            crate::protocol::admin::DescribeClientQuotasResponse::new(0, None, Some(entries));
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_client_quotas_response(&mut body, 1, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_describe_client_quotas_response_cooperative(&mut body, 1) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.throttle_time_ms, 0);
                assert_eq!(decoded.entries.as_ref().map(Vec::len), Some(200_000));
                assert_eq!(
                    decoded.entries.as_ref().and_then(|items| items.first()).and_then(|item| item.entity.first()).and_then(|item| item.name.as_deref()),
                    Some("client-0")
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding client quotas held the caller for {elapsed:?}"
        );
        let mut resp = crate::protocol::admin::DescribeClientQuotasResponse::new(
            7,
            Some("busy".to_string()),
            Some(vec![ClientQuotaEntry {
                entity: vec![ClientQuotaEntity {
                    entity_type: "user".to_string(),
                    name: Some("alice".to_string()),
                }],
                values: vec![ClientQuotaValue::new("producer_byte_rate", 2.5)],
            }]),
        );
        resp.throttle_time_ms = 4;
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_client_quotas_response(&mut encoded, 1, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_describe_client_quotas_response(&mut once, 1)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_describe_client_quotas_response_cooperative(&mut paced, 1)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.error_message.as_deref(), Some("busy"));
        assert_eq!(coop.throttle_time_ms, 4);
        assert_eq!(
            coop.entries
                .as_ref()
                .and_then(|items| items.first())
                .and_then(|item| item.values.first())
                .map(|item| item.value),
            Some(2.5)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_altered_log_dirs_does_not_hold_the_caller() {
        let partitions: Vec<AlterReplicaLogDirsResponsePartition> = (0..1_000_000)
            .map(|index| AlterReplicaLogDirsResponsePartition::new(index, 0))
            .collect();
        let resp = AlterReplicaLogDirsResponse::new(vec![AlterReplicaLogDirsResponseTopic::new(
            "orders", partitions,
        )]);
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_alter_replica_log_dirs_response(&mut body, 2, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_alter_replica_log_dirs_response_cooperative(&mut body, 2) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.throttle_time_ms, 0);
                assert_eq!(
                    decoded.results.first().map(|item| item.partitions.len()),
                    Some(1_000_000)
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding altered log directories held the caller for {elapsed:?}"
        );
        let resp = AlterReplicaLogDirsResponse::new(vec![AlterReplicaLogDirsResponseTopic::new(
            "orders",
            vec![AlterReplicaLogDirsResponsePartition::new(4, 7)],
        )]);
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_alter_replica_log_dirs_response(&mut encoded, 2, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_alter_replica_log_dirs_response(&mut once, 2)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_alter_replica_log_dirs_response_cooperative(&mut paced, 2)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(
            coop.results
                .first()
                .and_then(|item| item.partitions.first())
                .map(|item| item.error_code),
            Some(7)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_txn_markers_does_not_hold_the_caller() {
        let partitions: Vec<crate::protocol::txn::WritableTxnMarkerPartitionResult> = (0
            ..1_000_000)
            .map(
                |index| crate::protocol::txn::WritableTxnMarkerPartitionResult {
                    partition_index: index,
                    error_code: 0,
                },
            )
            .collect();
        let markers = [crate::protocol::txn::WritableTxnMarkerResult {
            producer_id: 9,
            topics: vec![crate::protocol::txn::WritableTxnMarkerTopicResult {
                name: "orders".to_string(),
                partitions,
            }],
        }];
        let mut body = bytes::BytesMut::new();
        crate::protocol::txn::encode_write_txn_markers_response(&mut body, 1, &markers)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_write_txn_markers_response_cooperative(&mut body, 1) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(
                    decoded.first().and_then(|item| item.topics.first()).map(|item| item.partitions.len()),
                    Some(1_000_000)
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding transaction markers held the caller for {elapsed:?}"
        );
        let markers = [crate::protocol::txn::WritableTxnMarkerResult {
            producer_id: 11,
            topics: vec![crate::protocol::txn::WritableTxnMarkerTopicResult {
                name: "orders".to_string(),
                partitions: vec![crate::protocol::txn::WritableTxnMarkerPartitionResult {
                    partition_index: 4,
                    error_code: 7,
                }],
            }],
        }];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::txn::encode_write_txn_markers_response(&mut encoded, 1, &markers)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::txn::decode_write_txn_markers_response(&mut once, 1)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_write_txn_markers_response_cooperative(&mut paced, 1)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.first().map(|item| item.producer_id), Some(11));
        assert_eq!(
            coop.first()
                .and_then(|item| item.topics.first())
                .and_then(|item| item.partitions.first())
                .map(|item| item.error_code),
            Some(7)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_deleted_records_does_not_hold_the_caller() {
        let partitions: Vec<crate::protocol::admin::DeletedRecordsPartition> = (0..1_000_000)
            .map(|index| crate::protocol::admin::DeletedRecordsPartition {
                partition: index,
                low_watermark: 8,
                error_code: 0,
            })
            .collect();
        let topics = [crate::protocol::admin::DeletedRecordsTopic {
            topic: "orders".to_string(),
            partitions,
        }];
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_delete_records_topics_response(&mut body, 2, &topics)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_delete_records_topics_response_cooperative(&mut body, 2) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.first().map(|item| item.partitions.len()), Some(1_000_000));
                assert_eq!(
                    decoded.first().and_then(|item| item.partitions.first()).map(|item| item.low_watermark),
                    Some(8)
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding deleted records held the caller for {elapsed:?}"
        );
        let topics = [crate::protocol::admin::DeletedRecordsTopic {
            topic: "orders".to_string(),
            partitions: vec![crate::protocol::admin::DeletedRecordsPartition {
                partition: 4,
                low_watermark: 11,
                error_code: 7,
            }],
        }];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_delete_records_topics_response(&mut encoded, 2, &topics)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_delete_records_topics_response(&mut once, 2)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_delete_records_topics_response_cooperative(&mut paced, 2)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.partitions.first())
                .map(|item| item.error_code),
            Some(7)
        );
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.partitions.first())
                .map(|item| item.low_watermark),
            Some(11)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_altered_configs_does_not_hold_the_caller() {
        let results: Vec<AlterConfigsResourceResult> = (0..1_000_000)
            .map(|index| AlterConfigsResourceResult {
                error_code: 0,
                error_message: None,
                resource_type: 2,
                name: format!("topic-{index}"),
            })
            .collect();
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_incremental_alter_configs_resource_results(
            &mut body, 1, &results,
        )
        .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_incremental_alter_configs_resource_results_cooperative(&mut body, 1) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.len(), 1_000_000);
                assert_eq!(decoded.first().map(|item| item.name.as_str()), Some("topic-0"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding altered configs held the caller for {elapsed:?}"
        );
        let results = [AlterConfigsResourceResult {
            error_code: 7,
            error_message: Some("busy".to_string()),
            resource_type: 2,
            name: "orders".to_string(),
        }];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_incremental_alter_configs_resource_results(
            &mut encoded,
            1,
            &results,
        )
        .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync =
            crate::protocol::admin::decode_incremental_alter_configs_resource_results(&mut once, 1)
                .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_incremental_alter_configs_resource_results_cooperative(&mut paced, 1)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
        assert_eq!(coop.0.first().map(|item| item.resource_type), Some(2));
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_replaced_configs_does_not_hold_the_caller() {
        let results: Vec<AlterConfigsResourceResult> = (0..1_000_000)
            .map(|index| AlterConfigsResourceResult {
                error_code: 0,
                error_message: None,
                resource_type: 2,
                name: format!("topic-{index}"),
            })
            .collect();
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_alter_configs_resource_results(&mut body, 2, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_alter_configs_resource_results_cooperative(&mut body, 2) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.len(), 1_000_000);
                assert_eq!(decoded.first().map(|item| item.name.as_str()), Some("topic-0"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding replaced configs held the caller for {elapsed:?}"
        );
        let results = [AlterConfigsResourceResult {
            error_code: 7,
            error_message: Some("busy".to_string()),
            resource_type: 2,
            name: "orders".to_string(),
        }];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_alter_configs_resource_results(&mut encoded, 2, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_alter_configs_resource_results(&mut once, 2)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_alter_configs_resource_results_cooperative(&mut paced, 2)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync.0, coop.0);
        assert_eq!(sync.1, coop.1);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_cluster_brokers_does_not_hold_the_caller() {
        let brokers: Vec<DescribeClusterBroker> = (0..200_000)
            .map(|index| {
                DescribeClusterBroker::new(
                    index,
                    format!("host-{index}"),
                    9092,
                    Some(format!("rack-{index}")),
                    false,
                )
            })
            .collect();
        let desc = ClusterDescription::new(
            0,
            None,
            Some("cluster".to_string()),
            1,
            1,
            i32::MIN,
            brokers,
        );
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_cluster_response(&mut body, 2, &desc)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_describe_cluster_response_cooperative(&mut body, 2) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.throttle_time_ms, 0);
                assert_eq!(decoded.brokers.len(), 200_000);
                assert_eq!(decoded.brokers.first().map(|item| item.host.as_str()), Some("host-0"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding cluster brokers held the caller for {elapsed:?}"
        );
        let sample = ClusterDescription::new(
            7,
            Some("busy".to_string()),
            Some("cluster".to_string()),
            2,
            1,
            4,
            vec![DescribeClusterBroker::new(
                9,
                "broker-a",
                9092,
                Some("rack-a".to_string()),
                true,
            )],
        );
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_cluster_response(&mut encoded, 2, &sample)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_describe_cluster_response(&mut once, 2)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_describe_cluster_response_cooperative(&mut paced, 2)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.error_message.as_deref(), Some("busy"));
        assert_eq!(
            coop.brokers.first().map(|item| item.host.as_str()),
            Some("broker-a")
        );
        assert_eq!(
            coop.brokers.first().and_then(|item| item.rack.as_deref()),
            Some("rack-a")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_left_members_does_not_hold_the_caller() {
        let members: Vec<crate::protocol::group::LeaveGroupMemberResult> = (0..200_000)
            .map(|index| crate::protocol::group::LeaveGroupMemberResult {
                member_id: format!("member-{index}"),
                group_instance_id: Some(format!("instance-{index}")),
                error_code: 0,
            })
            .collect();
        let mut body = bytes::BytesMut::new();
        crate::protocol::group::encode_leave_group_response_version(&mut body, 4, 0, &members)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_leave_group_response_version_cooperative(&mut body, 4) => {
                let (error_code, decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(error_code, 0);
                assert_eq!(throttle, 0);
                assert_eq!(decoded.len(), 200_000);
                assert_eq!(decoded.first().map(|item| item.member_id.as_str()), Some("member-0"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding left members held the caller for {elapsed:?}"
        );
        let sample = [crate::protocol::group::LeaveGroupMemberResult {
            member_id: "member-a".to_string(),
            group_instance_id: Some("instance-a".to_string()),
            error_code: 25,
        }];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::group::encode_leave_group_response_version(&mut encoded, 4, 7, &sample)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::group::decode_leave_group_response_version(&mut once, 4)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_leave_group_response_version_cooperative(&mut paced, 4)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.0, 7);
        assert_eq!(
            coop.1.first().map(|item| item.member_id.as_str()),
            Some("member-a")
        );
        assert_eq!(
            coop.1
                .first()
                .and_then(|item| item.group_instance_id.as_deref()),
            Some("instance-a")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_feature_results_does_not_hold_the_caller() {
        let results: Vec<crate::protocol::admin::UpdatableFeatureResult> = (0..400_000)
            .map(|index| crate::protocol::admin::UpdatableFeatureResult {
                name: format!("feature-{index}"),
                error_code: 0,
                error_message: None,
            })
            .collect();
        let resp = crate::protocol::admin::UpdateFeaturesResponse {
            throttle_time_ms: 0,
            error_code: 0,
            error_message: None,
            results,
        };
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_update_features_response(&mut body, 1, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_update_features_response_cooperative(&mut body, 1) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.throttle_time_ms, 0);
                assert_eq!(decoded.results.len(), 400_000);
                assert_eq!(decoded.results.first().map(|item| item.name.as_str()), Some("feature-0"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding feature results held the caller for {elapsed:?}"
        );
        let sample = crate::protocol::admin::UpdateFeaturesResponse {
            throttle_time_ms: 4,
            error_code: 7,
            error_message: Some("busy".to_string()),
            results: vec![crate::protocol::admin::UpdatableFeatureResult {
                name: "metadata.version".to_string(),
                error_code: 41,
                error_message: Some("not controller".to_string()),
            }],
        };
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_update_features_response(&mut encoded, 1, &sample)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_update_features_response(&mut once, 1)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_update_features_response_cooperative(&mut paced, 1)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.error_message.as_deref(), Some("busy"));
        assert_eq!(
            coop.results
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("not controller")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_altered_scram_users_does_not_hold_the_caller() {
        let results: Vec<crate::protocol::admin::AlterUserScramCredentialsResult> = (0..400_000)
            .map(
                |index| crate::protocol::admin::AlterUserScramCredentialsResult {
                    user: format!("user-{index}"),
                    error_code: 0,
                    error_message: None,
                },
            )
            .collect();
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_alter_user_scram_credentials_response(&mut body, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_alter_user_scram_credentials_response_cooperative(&mut body) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.len(), 400_000);
                assert_eq!(decoded.first().map(|item| item.user.as_str()), Some("user-0"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding altered scram users held the caller for {elapsed:?}"
        );
        let sample = [crate::protocol::admin::AlterUserScramCredentialsResult {
            user: "alice".to_string(),
            error_code: 41,
            error_message: Some("busy".to_string()),
        }];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_alter_user_scram_credentials_response(&mut encoded, &sample)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_alter_user_scram_credentials_response(&mut once)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_alter_user_scram_credentials_response_cooperative(&mut paced)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
        assert_eq!(coop.0.first().map(|item| item.user.as_str()), Some("alice"));
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_described_scram_users_does_not_hold_the_caller() {
        let results: Vec<crate::protocol::admin::DescribeUserScramCredentialsResult> = (0..400_000)
            .map(
                |index| crate::protocol::admin::DescribeUserScramCredentialsResult {
                    user: format!("user-{index}"),
                    error_code: 0,
                    error_message: None,
                    credential_infos: vec![crate::protocol::admin::ScramCredentialInfo {
                        mechanism: 1,
                        iterations: 4096,
                    }],
                },
            )
            .collect();
        let resp = crate::protocol::admin::DescribeUserScramCredentialsResponse {
            throttle_time_ms: 0,
            error_code: 0,
            error_message: None,
            results,
        };
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_user_scram_credentials_response(&mut body, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_describe_user_scram_credentials_response_cooperative(&mut body) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.throttle_time_ms, 0);
                assert_eq!(decoded.results.len(), 400_000);
                assert_eq!(decoded.results.first().map(|item| item.user.as_str()), Some("user-0"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding described scram users held the caller for {elapsed:?}"
        );
        let sample = crate::protocol::admin::DescribeUserScramCredentialsResponse {
            throttle_time_ms: 4,
            error_code: 7,
            error_message: Some("busy".to_string()),
            results: vec![crate::protocol::admin::DescribeUserScramCredentialsResult {
                user: "alice".to_string(),
                error_code: 41,
                error_message: Some("missing".to_string()),
                credential_infos: vec![crate::protocol::admin::ScramCredentialInfo {
                    mechanism: 2,
                    iterations: 8192,
                }],
            }],
        };
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_describe_user_scram_credentials_response(
            &mut encoded,
            &sample,
        )
        .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync =
            crate::protocol::admin::decode_describe_user_scram_credentials_response(&mut once)
                .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_describe_user_scram_credentials_response_cooperative(&mut paced)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.error_message.as_deref(), Some("busy"));
        assert_eq!(
            coop.results
                .first()
                .and_then(|item| item.credential_infos.first())
                .map(|item| item.iterations),
            Some(8192)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_telemetry_metrics_does_not_hold_the_caller() {
        let requested_metrics: Vec<String> = (0..800_000)
            .map(|index| format!("metric-{index}"))
            .collect();
        let resp = crate::protocol::admin::GetTelemetrySubscriptionsResponse {
            throttle_time_ms: 0,
            error_code: 0,
            client_instance_id: [0x11; 16],
            subscription_id: 1,
            accepted_compression_types: vec![1],
            push_interval_ms: 1000,
            telemetry_max_bytes: 100,
            delta_temporality: true,
            requested_metrics,
        };
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_get_telemetry_subscriptions_response(&mut body, &resp)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_get_telemetry_subscriptions_response_cooperative(&mut body) => {
                let decoded = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(decoded.throttle_time_ms, 0);
                assert_eq!(decoded.requested_metrics.len(), 800_000);
                assert_eq!(decoded.requested_metrics.first().map(String::as_str), Some("metric-0"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding telemetry metrics held the caller for {elapsed:?}"
        );
        let sample = crate::protocol::admin::GetTelemetrySubscriptionsResponse {
            throttle_time_ms: 4,
            error_code: 35,
            client_instance_id: [0x22; 16],
            subscription_id: 9,
            accepted_compression_types: vec![2],
            push_interval_ms: 500,
            telemetry_max_bytes: 64,
            delta_temporality: false,
            requested_metrics: vec!["org.apache.kafka.producer".to_string()],
        };
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_get_telemetry_subscriptions_response(&mut encoded, &sample)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_get_telemetry_subscriptions_response(&mut once)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_get_telemetry_subscriptions_response_cooperative(&mut paced)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.error_code, 35);
        assert_eq!(
            coop.requested_metrics.first().map(String::as_str),
            Some("org.apache.kafka.producer")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_altered_quotas_does_not_hold_the_caller() {
        let results: Vec<ClientQuotaAlterationResult> = (0..200_000)
            .map(|index| ClientQuotaAlterationResult {
                error_code: 0,
                error_message: None,
                entity: vec![ClientQuotaEntity {
                    entity_type: "client-id".to_string(),
                    name: Some(format!("client-{index}")),
                }],
            })
            .collect();
        let mut body = bytes::BytesMut::new();
        crate::protocol::admin::encode_alter_client_quotas_response(&mut body, 1, &results)
            .unwrap_or_else(|error| panic!("{error}"));
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_alter_client_quotas_response_cooperative(&mut body, 1) => {
                let (decoded, throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(throttle, 0);
                assert_eq!(decoded.len(), 200_000);
                assert_eq!(
                    decoded.first().and_then(|item| item.entity.first()).and_then(|item| item.name.as_deref()),
                    Some("client-0")
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding altered quotas held the caller for {elapsed:?}"
        );
        let sample = vec![ClientQuotaAlterationResult {
            error_code: 41,
            error_message: Some("busy".to_string()),
            entity: vec![ClientQuotaEntity {
                entity_type: "user".to_string(),
                name: Some("alice".to_string()),
            }],
        }];
        let mut encoded = bytes::BytesMut::new();
        crate::protocol::admin::encode_alter_client_quotas_response(&mut encoded, 1, &sample)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync = crate::protocol::admin::decode_alter_client_quotas_response(&mut once, 1)
            .unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_alter_client_quotas_response_cooperative(&mut paced, 1)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.error_message.as_deref()),
            Some("busy")
        );
        assert_eq!(
            coop.0
                .first()
                .and_then(|item| item.entity.first())
                .and_then(|item| item.name.as_deref()),
            Some("alice")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn matching_many_coordinators_does_not_hold_the_caller() {
        // 500_000 keys: taking each coordinator held the caller 234ms.
        let coords: Vec<crate::protocol::group::CoordinatorResult> = (0..500_000)
            .map(|index| crate::protocol::group::CoordinatorResult {
                key: format!("group-{index}"),
                node_id: 1,
                host: "127.0.0.1".to_string(),
                port: 9092,
                error_code: 0,
                error_message: None,
            })
            .collect();
        let mut indexed = index_coordinators(coords).await;
        let keys: Vec<String> = (0..500_000).map(|index| format!("group-{index}")).collect();
        let key_refs: Vec<&str> = keys.iter().map(String::as_str).collect();
        let started = std::time::Instant::now();
        tokio::select! {
            taken = take_coordinator_slots(&mut indexed, &key_refs) => {
                let taken = taken.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(taken.len(), 500_000);
                assert_eq!(taken.first().map(|slot| slot.1), Some(1));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "matching coordinators held the caller for {elapsed:?}"
        );
        let mut indexed = index_coordinators(vec![crate::protocol::group::CoordinatorResult {
            key: "orders".to_string(),
            node_id: 4,
            host: "b".to_string(),
            port: 2,
            error_code: 0,
            error_message: None,
        }])
        .await;
        let taken = take_coordinator_slots(&mut indexed, &["orders", "missing"])
            .await
            .unwrap_err();
        assert!(taken
            .to_string()
            .contains("FindCoordinator missing missing"));
        assert!(!indexed.contains_key("orders"));
    }

    #[tokio::test(flavor = "current_thread")]
    async fn indexing_many_coordinators_does_not_hold_the_caller() {
        // 500_000 coordinators: recording each one held the caller 458ms.
        let coords: Vec<crate::protocol::group::CoordinatorResult> = (0..500_000)
            .map(|index| crate::protocol::group::CoordinatorResult {
                key: format!("group-{index}"),
                node_id: index % 8,
                host: "127.0.0.1".to_string(),
                port: 9092,
                error_code: 0,
                error_message: None,
            })
            .collect();
        let started = std::time::Instant::now();
        tokio::select! {
            indexed = index_coordinators(coords) => {
                assert_eq!(indexed.len(), 500_000);
                assert_eq!(indexed.get("group-0").map(|slot| slot.1), Some(0));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "indexing coordinators held the caller for {elapsed:?}"
        );
        let repeated = vec![
            crate::protocol::group::CoordinatorResult {
                key: "orders".to_string(),
                node_id: 1,
                host: "a".to_string(),
                port: 1,
                error_code: 0,
                error_message: Some("ignored".to_string()),
            },
            crate::protocol::group::CoordinatorResult {
                key: "orders".to_string(),
                node_id: 4,
                host: "b".to_string(),
                port: 2,
                error_code: 7,
                error_message: None,
            },
        ];
        let indexed = index_coordinators(repeated).await;
        assert_eq!(
            indexed
                .get("orders")
                .map(|slot| (slot.0, slot.1, slot.2.as_str(), slot.3)),
            Some((7, 4, "b", 2))
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn grouping_many_named_results_does_not_hold_the_caller() {
        // 500_000 names: recording each one held the caller 572ms.
        let ids: Vec<String> = (0..500_000).map(|index| format!("group-{index}")).collect();
        let started = std::time::Instant::now();
        tokio::select! {
            grouped = group_named(ids, |id| id.as_str()) => {
                assert_eq!(grouped.len(), 500_000);
                assert!(grouped.contains_key("group-0"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "grouping named results held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn a_repeated_group_id_stays_in_arrival_order() {
        let grouped = group_named(
            [
                ("orders".to_owned(), 1),
                ("orders".to_owned(), 2),
                ("payments".to_owned(), 3),
            ],
            |item| item.0.as_str(),
        )
        .await;
        assert_eq!(grouped.len(), 2);
        let orders = grouped
            .get("orders")
            .map(|queue| queue.iter().map(|item| item.1).collect::<Vec<_>>());
        assert_eq!(orders, Some(vec![1, 2]));
        assert_eq!(
            grouped
                .get("payments")
                .and_then(|queue| queue.front())
                .map(|item| item.1),
            Some(3)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn indexing_many_topic_names_does_not_hold_the_caller() {
        // 500_000 names: recording the first copy of each held the caller 350ms.
        let names: Vec<String> = (0..500_000).map(|index| format!("topic-{index}")).collect();
        let started = std::time::Instant::now();
        tokio::select! {
            slots = first_name_index(names.iter().map(String::as_str)) => {
                assert_eq!(slots.len(), 500_000);
                assert_eq!(slots.get("topic-0").copied(), Some(0));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "indexing topic names held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn the_first_pending_topic_is_the_one_a_result_finds() {
        let slots = first_name_index(["orders", "payments", "orders"]).await;
        assert_eq!(slots.get("orders").copied(), Some(0));
        assert_eq!(slots.get("payments").copied(), Some(1));
        assert_eq!(slots.get("other"), None);
        let pending = [
            DeleteTopicState::by_id([9; 16]),
            DeleteTopicState::by_name("orders"),
            DeleteTopicState::by_name("orders"),
        ];
        let index = index_delete_pending(&pending);
        let both = TopicResult::error(0, Some("orders"), [9; 16]);
        assert_eq!(delete_pending_slot(&index, &both), Some(0));
        assert!(pending
            .get(0)
            .is_some_and(|topic| delete_state_matches(topic, &both)));
        assert!(pending
            .get(1)
            .is_some_and(|topic| delete_state_matches(topic, &both)));
        assert_eq!(
            delete_pending_slot(&index, &TopicResult::error(0, Some("orders"), [0; 16])),
            Some(1)
        );
        assert_eq!(
            delete_pending_slot(&index, &TopicResult::error(0, None, [9; 16])),
            Some(0)
        );
        assert_eq!(
            delete_pending_slot(&index, &TopicResult::error(0, Some("other"), [1; 16])),
            None
        );
    }

    #[test]
    fn unique_topic_names_keep_the_first_copy() {
        assert_eq!(
            unique_names(["orders", "payments", "orders"]),
            ["orders", "payments"]
        );
        assert!(unique_names(std::iter::empty()).is_empty());
    }

    #[tokio::test(flavor = "current_thread")]
    async fn grouping_many_replica_dirs_does_not_hold_the_caller() {
        // 20_000 partitions: scanning the growing list held the caller 765ms.
        // A longer walk still has to pause after membership is a set.
        let assignment: Vec<(TopicPartitionReplica, String)> = (0..500_000)
            .map(|index| {
                (
                    TopicPartitionReplica::new("orders", index, 2),
                    "/data".to_owned(),
                )
            })
            .collect();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = alter_replica_dirs_for_broker_cooperative(&assignment, 2) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "grouping replica directories held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn cooperative_replica_dirs_match_one_shot() {
        let assignment = [
            (TopicPartitionReplica::new("orders", 1, 2), "/a".to_owned()),
            (TopicPartitionReplica::new("orders", 1, 2), "/a".to_owned()),
            (TopicPartitionReplica::new("orders", 0, 2), "/a".to_owned()),
            (
                TopicPartitionReplica::new("payments", 4, 2),
                "/b".to_owned(),
            ),
        ];
        let one = alter_replica_dirs_for_broker(&assignment, 2);
        let two = alter_replica_dirs_for_broker_cooperative(&assignment, 2).await;
        assert_eq!(one.len(), two.len());
        assert_eq!(one[0].path, two[0].path);
        assert_eq!(one[0].topics[0].partitions, two[0].topics[0].partitions);
        assert_eq!(one[1].topics[0].name, two[1].topics[0].name);
    }

    #[test]
    fn alter_replica_dirs_keep_first_seen_topics() {
        let assignment = [
            (TopicPartitionReplica::new("orders", 1, 2), "/a".to_owned()),
            (
                TopicPartitionReplica::new("payments", 0, 2),
                "/a".to_owned(),
            ),
            (TopicPartitionReplica::new("orders", 0, 2), "/a".to_owned()),
            (TopicPartitionReplica::new("orders", 1, 2), "/a".to_owned()),
            (TopicPartitionReplica::new("orders", 0, 1), "/b".to_owned()),
        ];
        let grouped = alter_replica_dirs_for_broker(&assignment, 2);
        assert_eq!(grouped.first().map(|dir| dir.path), Some("/a"));
        assert_eq!(grouped.len(), 1);
        let topics = grouped.first().map(|dir| dir.topics.as_slice());
        assert_eq!(
            topics
                .and_then(|topics| topics.first())
                .map(|topic| { (topic.name, topic.partitions.as_slice()) }),
            Some(("orders", &[1, 0][..]))
        );
        assert_eq!(
            topics
                .and_then(|topics| topics.get(1))
                .map(|topic| { (topic.name, topic.partitions.as_slice()) }),
            Some(("payments", &[0][..]))
        );
    }

    #[test]
    fn records_to_delete_before_offset_converts_to_i64() {
        assert_eq!(i64::from(RecordsToDelete::before_offset(42)), 42);
        assert_eq!(RecordsToDelete::before_offset(7).offset(), 7);
        assert_eq!(
            RecordsToDelete::before_offset(42).to_string(),
            "(beforeOffset = 42)"
        );
        assert_eq!(
            RecordsToDelete::before_offset(
                crate::protocol::admin::DeleteRecordsRequest::HIGH_WATERMARK
            )
            .offset(),
            crate::protocol::admin::DeleteRecordsRequest::HIGH_WATERMARK
        );
    }

    #[test]
    fn list_config_resources_response_config_resources_matches_java() {
        // Java 4.1.0 ListConfigResourcesResponse.configResources maps
        // each ConfigResource (Type.forId, resourceName). Unknown ids
        // are UNKNOWN (0). Official Java
        // ListConfigResourcesResponse.configResources (4.1.0; 4.0.0 404
        // as the current name). ListedConfigResource::to_config_resource
        // keeps the wire id. This crate speaks 0-1. This is not error()
        // / errorCounts / getErrorResponse / supportedResourceTypes /
        // Builder.build.
        assert!(ListConfigResourcesResponse::new(0, Vec::new())
            .config_resources()
            .is_empty());
        let full = ListConfigResourcesResponse::new(
            crate::error::INVALID_REQUEST,
            vec![
                ListedConfigResource::new("t", CONFIG_RESOURCE_TOPIC),
                ListedConfigResource::new("1", CONFIG_RESOURCE_BROKER),
                ListedConfigResource::new("r", CONFIG_RESOURCE_CLIENT_METRICS),
                ListedConfigResource::new("g", CONFIG_RESOURCE_GROUP),
                ListedConfigResource::new("x", 99),
            ],
        );
        assert_eq!(
            full.config_resources(),
            vec![
                ConfigResource::topic("t"),
                ConfigResource::broker(1),
                ConfigResource::of(ConfigResourceType::ClientMetrics, "r"),
                ConfigResource::group("g"),
                ConfigResource {
                    resource_type: 0,
                    name: "x".into(),
                    keys: None,
                },
            ]
        );
        assert!(full.config_resources().iter().all(|r| r.keys.is_none()));
        assert_eq!(
            ListedConfigResource::new("x", 99)
                .to_config_resource()
                .resource_type,
            99,
            "to_config_resource keeps the wire id; configResources uses Type.forId"
        );

        let metrics = ListConfigResourcesResponse::new(
            0,
            vec![ListedConfigResource::new(
                "r",
                CONFIG_RESOURCE_CLIENT_METRICS,
            )],
        );
        for version in 0..=1_i16 {
            let mut buf = BytesMut::new();
            encode_list_config_resources_response(&mut buf, version, &metrics).unwrap();
            let mut cur = buf.as_ref();
            let decoded = decode_list_config_resources_response(&mut cur, version).unwrap();
            assert_eq!(
                decoded.config_resources(),
                vec![ConfigResource::of(ConfigResourceType::ClientMetrics, "r")],
                "ListConfigResources v{version} configResources must convert the decoded listing"
            );
            assert!(
                cur.is_empty(),
                "ListConfigResources v{version} configResources leftover-empty; leftover {} bytes",
                cur.len()
            );
        }

        let unknown = ListConfigResourcesResponse::new(0, vec![ListedConfigResource::new("x", 99)]);
        let mut v1 = BytesMut::new();
        encode_list_config_resources_response(&mut v1, 1, &unknown).unwrap();
        let mut cur = v1.as_ref();
        let decoded = decode_list_config_resources_response(&mut cur, 1).unwrap();
        assert_eq!(
            decoded.config_resources.first().map(|r| r.resource_type),
            Some(99)
        );
        assert_eq!(
            decoded.config_resources(),
            vec![ConfigResource {
                resource_type: 0,
                name: "x".into(),
                keys: None,
            }]
        );
        assert!(
            cur.is_empty(),
            "ListConfigResources v1 configResources leftover-empty; leftover {} bytes",
            cur.len()
        );
    }

    #[test]
    fn update_features_client_checks_match_java() {
        let empty = Admin::reject_java_feature_updates(&[])
            .unwrap_err()
            .to_string();
        assert!(
            empty.contains("Feature updates can not be null or empty."),
            "{empty}"
        );
        let blank = Admin::reject_java_feature_updates(&[FeatureUpdate::new("  ", 1)])
            .unwrap_err()
            .to_string();
        assert!(
            blank.contains("Provided feature can not be empty."),
            "{blank}"
        );
        let unnamed = Admin::reject_java_feature_updates(&[FeatureUpdate::new("", 1)])
            .unwrap_err()
            .to_string();
        assert!(
            unnamed.contains("Provided feature can not be empty."),
            "{unnamed}"
        );
        Admin::reject_java_feature_updates(&[FeatureUpdate::new("metadata.version", 17)]).unwrap();
    }

    #[test]
    fn deleted_records_matches_java() {
        assert_eq!(DeletedRecords::INVALID_LOW_WATERMARK, -1);
        let ok = DeletedRecords::new(42);
        assert_eq!(ok.low_watermark(), 42);
        assert_eq!(ok.error_code(), 0);
        let with_err = DeletedRecords::with_error_code(7, 6);
        assert_eq!(with_err.low_watermark(), 7);
        assert_eq!(with_err.error_code(), 6);
        let pair: (i64, i16) = with_err.into();
        assert_eq!(pair, (7, 6));
        assert_eq!(DeletedRecords::from((9, 0)).low_watermark(), 9);
        assert_eq!(
            DeletedRecords::with_error_code(DeletedRecords::INVALID_LOW_WATERMARK, 6)
                .low_watermark(),
            DeletedRecords::INVALID_LOW_WATERMARK
        );
    }

    #[test]
    fn topic_partition_replica_and_log_dir_getters() {
        let replica = TopicPartitionReplica::new("t", 2, 5);
        assert_eq!(replica.topic(), "t");
        assert_eq!(replica.partition(), 2);
        assert_eq!(replica.broker_id(), 5);
        assert_eq!(replica.to_string(), "t-2-5");
        let dirs = ReplicaLogDirInfo::new(Some("/data".into()), 3, Some("/next".into()), 4);
        assert_eq!(dirs.current_log_dir(), Some("/data"));
        assert_eq!(dirs.current_offset_lag(), 3);
        assert_eq!(dirs.future_log_dir(), Some("/next"));
        assert_eq!(dirs.future_offset_lag(), 4);
        assert_eq!(
            dirs.to_string(),
            "(currentReplicaLogDir=/data, futureReplicaLogDir=/next, futureReplicaOffsetLag=4)"
        );
        let unknown = ReplicaLogDirInfo::unknown();
        assert!(unknown.current_log_dir().is_none());
        assert_eq!(unknown.current_offset_lag(), -1);
        assert_eq!(
            unknown.to_string(),
            "ReplicaLogDirInfo(currentReplicaLogDir=null)"
        );
        assert_eq!(
            ReplicaLogDirInfo::new(None, -1, Some("/next".into()), 7).to_string(),
            "(currentReplicaLogDir=null, futureReplicaLogDir=/next, futureReplicaOffsetLag=7)"
        );
        let replica_info = DescribeLogDirsPartition::new(0, 10, 3, false);
        assert_eq!(replica_info.size(), 10);
        assert_eq!(replica_info.offset_lag(), 3);
        assert!(!replica_info.is_future());
        let log_dir = DescribeLogDirsResult::new(
            0,
            "/data",
            vec![DescribeLogDirsTopic::new("t", vec![replica_info])],
            4096,
            1024,
        );
        assert_eq!(log_dir.log_dir(), "/data");
        assert_eq!(log_dir.total_bytes(), Some(4096));
        assert_eq!(log_dir.usable_bytes(), Some(1024));
        assert_eq!(
            DescribeLogDirsResult::new(
                0,
                "/d",
                Vec::new(),
                UNKNOWN_VOLUME_BYTES,
                UNKNOWN_VOLUME_BYTES
            )
            .total_bytes(),
            None
        );
        let assignment = [
            (TopicPartitionReplica::new("t", 0, 2), "/d1".to_owned()),
            (TopicPartitionReplica::new("u", 1, 2), "/d1".to_owned()),
            (TopicPartitionReplica::new("t", 0, 1), "/d2".to_owned()),
        ];
        let grouped = group_alter_replica_log_dirs_sync(&assignment);
        assert_eq!(grouped.len(), 2);
        assert_eq!(grouped[0].0, 2);
        assert_eq!(grouped[0].1[0].path, "/d1");
        assert_eq!(grouped[0].1[0].topics[0].name, "t");
        assert_eq!(grouped[0].1[0].topics[0].partitions, &[0]);
        assert_eq!(grouped[0].1[0].topics[1].name, "u");
        assert_eq!(grouped[1].0, 1);
        assert_eq!(grouped[1].1[0].path, "/d2");
        let dir = AssignReplicasToDirsDirectory::new(
            Uuid::from_bytes([0x11; 16]),
            vec![AssignReplicasToDirsTopic::new(
                Uuid::from_bytes([0x22; 16]),
                vec![AssignReplicasToDirsPartition::new(0)],
            )],
        );
        assert_eq!(dir.id(), Uuid::from_bytes([0x11; 16]));
        assert_eq!(dir.topics()[0].topic_id(), Uuid::from_bytes([0x22; 16]));
        assert_eq!(dir.topics()[0].partitions()[0].partition_index(), 0);
        let assigned = AssignReplicasToDirsResponse::new(
            0,
            vec![AssignReplicasToDirsResponseDirectory::new(
                [0x11; 16],
                vec![AssignReplicasToDirsResponseTopic::new(
                    [0x22; 16],
                    vec![AssignReplicasToDirsResponsePartition::new(0, 0)],
                )],
            )],
        );
        assert_eq!(assigned.error_code(), 0);
        assert_eq!(assigned.throttle_time_ms(), 0);
        assert_eq!(assigned.directories()[0].id(), Uuid::from_bytes([0x11; 16]));
        assert_eq!(
            assigned.directories()[0].topics()[0].topic_id(),
            Uuid::from_bytes([0x22; 16])
        );
        assert_eq!(
            assigned.directories()[0].topics()[0].partitions()[0].error_code(),
            0
        );
        let altered =
            AlterReplicaLogDirsResponse::new(vec![AlterReplicaLogDirsResponseTopic::new(
                "t",
                vec![AlterReplicaLogDirsResponsePartition::new(0, 0)],
            )]);
        assert_eq!(altered.results()[0].topic_name(), "t");
        assert_eq!(altered.throttle_time_ms(), 0);
        assert_eq!(altered.results()[0].partitions()[0].partition_index(), 0);
        assert_eq!(altered.results()[0].partitions()[0].error_code(), 0);
        assert_eq!(alter_replica_partition_error(altered.results(), "t", 0), 0);
        assert_eq!(
            alter_replica_partition_error(altered.results(), "missing", 0),
            0
        );
    }

    #[test]
    fn admin_java_spec_getters_match_fields() {
        let topic = NewTopic::new("orders", 3, 1);
        assert_eq!(topic.name(), "orders");
        assert_eq!(topic.num_partitions(), 3);
        assert_eq!(topic.replication_factor(), 1);
        assert!(topic.replicas_assignments().is_none());
        assert_eq!(
            topic.to_string(),
            "(name=orders, numPartitions=3, replicationFactor=1, replicasAssignments=null, configs=null)"
        );
        assert_eq!(
            NewTopic::broker_defaults("t").to_string(),
            "(name=t, numPartitions=default, replicationFactor=default, replicasAssignments=null, configs=null)"
        );
        let assigned = NewTopic::with_assignments("t", [(0, vec![1, 2])]);
        assert_eq!(
            assigned.num_partitions(),
            CreateTopicsRequest::NO_NUM_PARTITIONS
        );
        assert_eq!(
            assigned.replication_factor(),
            CreateTopicsRequest::NO_REPLICATION_FACTOR
        );
        assert_eq!(
            assigned.replicas_assignments(),
            Some(&[(0, vec![1, 2])][..])
        );
        assert_eq!(
            assigned.to_string(),
            "(name=t, numPartitions=default, replicationFactor=default, replicasAssignments={0=[1, 2]}, configs=null)"
        );
        assert_eq!(
            NewTopic::new("orders", 3, 1)
                .config("cleanup.policy", "compact")
                .to_string(),
            "(name=orders, numPartitions=3, replicationFactor=1, replicasAssignments=null, configs={cleanup.policy=compact})"
        );
        let parts = NewPartitions::increase_to("t", 5);
        assert_eq!(parts.name(), "t");
        assert_eq!(parts.total_count(), 5);
        assert!(parts.assignments().is_none());
        assert_eq!(parts.to_string(), "(totalCount=5, newAssignments=null)");
        let with = parts.with_assignments([vec![1, 2]]);
        assert_eq!(with.assignments().map(<[Vec<i32>]>::len), Some(1));
        assert_eq!(with.to_string(), "(totalCount=5, newAssignments=[[1, 2]])");
        assert_eq!(
            NewPartitions::increase_to("t", 5)
                .with_assignments(Vec::<Vec<i32>>::new())
                .to_string(),
            "(totalCount=5, newAssignments=[])"
        );
        let abort = AbortTransactionSpec::new(("events", 2), 9, 1, 3);
        assert_eq!(
            abort.topic_partition(),
            crate::TopicPartition::new("events", 2)
        );
        assert_eq!(abort.producer_id(), 9);
        assert_eq!(abort.producer_epoch(), 1);
        assert_eq!(abort.coordinator_epoch(), 3);
        assert_eq!(
            abort.to_string(),
            "AbortTransactionSpec(topicPartition=events-2, producerId=9, producerEpoch=1, coordinatorEpoch=3)"
        );
        let member = MemberToRemove::new("i-1");
        assert_eq!(member.group_instance_id(), "i-1");
        let removed = RemovedMember {
            member_id: "m".into(),
            group_instance_id: Some("i-1".into()),
            error_code: 0,
        };
        assert_eq!(removed.member_id(), "m");
        assert_eq!(removed.group_instance_id(), Some("i-1"));
        assert_eq!(removed.error_code(), 0);
        let spec = ListConsumerGroupOffsetsSpec::topic_partitions([("t", 0)]);
        assert_eq!(spec.partitions().map(<[_]>::len), Some(1));
        assert_eq!(
            spec.to_string(),
            "ListConsumerGroupOffsetsSpec(topicPartitions=[t-0])"
        );
        assert_eq!(
            ListConsumerGroupOffsetsSpec::topic_partitions([("t", 0), ("t", 1)]).to_string(),
            "ListConsumerGroupOffsetsSpec(topicPartitions=[t-0, t-1])"
        );
        assert_eq!(
            ListConsumerGroupOffsetsSpec {
                partitions: Some(Vec::new()),
            }
            .to_string(),
            "ListConsumerGroupOffsetsSpec(topicPartitions=[])"
        );
        assert!(ListConsumerGroupOffsetsSpec::all().partitions().is_none());
        assert_eq!(
            ListConsumerGroupOffsetsSpec::all().to_string(),
            "ListConsumerGroupOffsetsSpec(topicPartitions=null)"
        );
        let update = FeatureUpdate::new("metadata.version", 20);
        assert_eq!(update.name(), "metadata.version");
        assert_eq!(update.max_version_level(), 20);
        assert!(!update.is_delete_request());
        assert_eq!(
            update.to_string(),
            "FeatureUpdate{maxVersionLevel:20, upgradeType:UPGRADE}"
        );
        assert_eq!(
            FeatureUpdate::new("metadata.version", 20)
                .upgrade_type(UpgradeType::SafeDowngrade)
                .to_string(),
            "FeatureUpdate{maxVersionLevel:20, upgradeType:SAFE_DOWNGRADE}"
        );
        assert!(!FeatureUpdate::new("metadata.version", 20)
            .upgrade_type(UpgradeType::SafeDowngrade)
            .is_delete_request());
        assert_eq!(
            FeatureUpdate::new("metadata.version", 0)
                .upgrade_type(UpgradeType::UnsafeDowngrade)
                .to_string(),
            "FeatureUpdate{maxVersionLevel:0, upgradeType:UNSAFE_DOWNGRADE}"
        );
        assert!(FeatureUpdate::new("metadata.version", 0)
            .upgrade_type(UpgradeType::UnsafeDowngrade)
            .is_delete_request());
        assert!(FeatureUpdate::new("metadata.version", 0)
            .upgrade_type(UpgradeType::SafeDowngrade)
            .is_delete_request());
        assert!(!FeatureUpdate::new("metadata.version", 0).is_delete_request());
        assert_eq!(UpgradeType::Upgrade.to_string(), "UPGRADE");
        assert_eq!(UpgradeType::SafeDowngrade.to_string(), "SAFE_DOWNGRADE");
        assert_eq!(UpgradeType::UnsafeDowngrade.to_string(), "UNSAFE_DOWNGRADE");
        assert_eq!(UpgradeType::Upgrade.code(), UPGRADE_TYPE_UPGRADE);
        assert_eq!(
            UpgradeType::SafeDowngrade.code(),
            UPGRADE_TYPE_SAFE_DOWNGRADE
        );
        assert_eq!(
            UpgradeType::UnsafeDowngrade.code(),
            UPGRADE_TYPE_UNSAFE_DOWNGRADE
        );
        assert_eq!(UpgradeType::from_code(1), Some(UpgradeType::Upgrade));
        assert_eq!(UpgradeType::from_code(2), Some(UpgradeType::SafeDowngrade));
        assert_eq!(
            UpgradeType::from_code(3),
            Some(UpgradeType::UnsafeDowngrade)
        );
        assert!(UpgradeType::from_code(0).is_none());
        assert!(UpgradeType::from_code(99).is_none());
        assert_eq!(
            FeatureUpdate::new("metadata.version", 1)
                .upgrade_type(0_i8)
                .to_string(),
            "FeatureUpdate{maxVersionLevel:1, upgradeType:UNKNOWN}"
        );
        let range = SupportedVersionRange::new("metadata.version", 1, 20).unwrap();
        assert_eq!(range.min_version(), 1);
        assert_eq!(range.max_version(), 20);
        assert_eq!(
            range.to_string(),
            "SupportedVersionRange[min_version:1, max_version:20]"
        );
        let fin = FinalizedVersionRange::new("metadata.version", 1, 17).unwrap();
        assert_eq!(fin.min_version_level(), 1);
        assert_eq!(fin.max_version_level(), 17);
        assert_eq!(
            fin.to_string(),
            "FinalizedVersionRange[min_version_level:1, max_version_level:17]"
        );
        let kraft = SupportedVersionRange::new("kraft.version", 0, 1).unwrap();
        assert_eq!(
            kraft.to_string(),
            "SupportedVersionRange[min_version:0, max_version:1]"
        );
        let err = SupportedVersionRange::new("f", 0, -1).unwrap_err();
        assert!(
            matches!(err, Error::Protocol(_)),
            "negative maxVersion is Java IllegalArgumentException, got {err}"
        );
        assert!(
            err.to_string().contains(
                "Expected 0 <= minVersion <= maxVersion but received minVersion:0, maxVersion:-1."
            ),
            "got {err}"
        );
        let err = SupportedVersionRange::new("f", 2, 1).unwrap_err();
        assert!(
            err.to_string()
                .contains("but received minVersion:2, maxVersion:1."),
            "got {err}"
        );
        let err = FinalizedVersionRange::new("f", -1, 1).unwrap_err();
        assert!(
            matches!(err, Error::Protocol(_)),
            "negative minVersionLevel is Java IllegalArgumentException, got {err}"
        );
        assert!(
            err.to_string().contains(
                "Expected minVersionLevel >= 0, maxVersionLevel >= 0 and maxVersionLevel >= minVersionLevel, but received minVersionLevel: -1, maxVersionLevel: 1"
            ),
            "got {err}"
        );
        let err = FinalizedVersionRange::new("f", 2, 1).unwrap_err();
        assert!(
            err.to_string()
                .contains("minVersionLevel: 2, maxVersionLevel: 1"),
            "got {err}"
        );
        let zero = FinalizedVersionRange::new("f", 0, 0).unwrap();
        assert_eq!(zero.min_version_level(), 0);
        assert_eq!(zero.max_version_level(), 0);
        let md = FeatureMetadata {
            supported_features: vec![range],
            finalized_features: vec![fin],
            finalized_features_epoch: Some(8),
            zk_migration_ready: true,
        };
        assert_eq!(md.supported_features().len(), 1);
        assert_eq!(md.finalized_features().len(), 1);
        assert_eq!(md.finalized_features_epoch(), Some(8));
        assert!(md.zk_migration_ready());
        assert_eq!(
            md.to_string(),
            "FeatureMetadata{finalizedFeatures:{(metadata.version -> FinalizedVersionRange[min_version_level:1, max_version_level:17])}, finalizedFeaturesEpoch:8, supportedFeatures:{(metadata.version -> SupportedVersionRange[min_version:1, max_version:20])}}"
        );
        let empty_epoch = FeatureMetadata {
            finalized_features_epoch: None,
            supported_features: Vec::new(),
            finalized_features: Vec::new(),
            zk_migration_ready: false,
        };
        assert_eq!(
            empty_epoch.to_string(),
            "FeatureMetadata{finalizedFeatures:{}, finalizedFeaturesEpoch: , supportedFeatures:{}}"
        );
        let cluster = ClusterDescription::new(
            0,
            None,
            Some("mock".into()),
            1,
            1,
            AUTHORIZED_OPERATIONS_OMITTED,
            vec![DescribeClusterBroker::new(
                1,
                "127.0.0.1",
                9092,
                Some("r".into()),
                false,
            )],
        );
        assert_eq!(cluster.error_code(), 0);
        assert_eq!(cluster.cluster_id(), Some("mock"));
        assert_eq!(
            cluster.cluster_resource().to_string(),
            "ClusterResource(clusterId=mock)"
        );
        assert_eq!(cluster.cluster_resource().cluster_id(), Some("mock"));
        assert_eq!(
            ClusterResource::new(None::<String>).to_string(),
            "ClusterResource(clusterId=null)"
        );
        assert_eq!(cluster.controller_id(), 1);
        assert_eq!(cluster.brokers()[0].id(), 1);
        assert_eq!(cluster.brokers()[0].host(), "127.0.0.1");
        assert_eq!(cluster.brokers()[0].port(), 9092);
        assert_eq!(cluster.brokers()[0].rack(), Some("r"));
        assert!(cluster.brokers()[0].has_rack());
        assert!(!cluster.brokers()[0].is_fenced());
        assert_eq!(cluster.brokers()[0].id_string(), "1");
        assert!(!cluster.brokers()[0].is_empty());
        assert!(cluster.error_message().is_none());
        assert_eq!(
            cluster.brokers()[0].to_string(),
            "127.0.0.1:9092 (id: 1 rack: r isFenced: false)"
        );
        let empty = DescribeClusterBroker::no_node();
        assert_eq!(empty.id(), -1);
        assert!(empty.is_empty());
        assert_eq!(empty.id_string(), "-1");
        assert_eq!(empty.to_string(), ":-1 (id: -1 rack: null isFenced: false)");
        let from_broker: Node =
            crate::protocol::api::Broker::new(1, "127.0.0.1", 9092, Some("r".into())).into();
        assert_eq!(from_broker.id(), 1);
        assert_eq!(from_broker.host(), "127.0.0.1");
        assert!(!from_broker.is_fenced());
        let from_endpoint: Node =
            crate::protocol::api::NodeEndpoint::new(2, "h2", 9093, None).into();
        assert_eq!(from_endpoint.id_string(), "2");
        assert!(!from_endpoint.has_rack());
        assert_eq!(
            from_endpoint.to_string(),
            "h2:9093 (id: 2 rack: null isFenced: false)"
        );
    }

    #[test]
    fn config_get_and_replacement_match_java() {
        let entry = ConfigEntry::new("retention.ms", Some("1000".into()));
        let config = Config::new([entry.clone()]);
        assert_eq!(config.entries(), std::slice::from_ref(&entry));
        assert_eq!(config.get("retention.ms"), Some(&entry));
        assert_eq!(config.get("missing"), None);
        let described = DescribeConfigsResult {
            error_code: 0,
            error_message: None,
            resource_type: CONFIG_RESOURCE_TOPIC,
            name: "t".into(),
            entries: vec![entry.clone()],
        };
        assert_eq!(described.config().get("retention.ms"), Some(&entry));
        assert_eq!(described.name(), "t");
        assert_eq!(described.error_code(), 0);
        assert_eq!(described.entries().len(), 1);
        assert_eq!(entry.name(), "retention.ms");
        assert_eq!(entry.value(), Some("1000"));
        let replacement = ConfigReplacement::from_config(ConfigResource::topic("t"), &config);
        assert_eq!(replacement.resource.name, "t");
        assert_eq!(
            replacement.configs,
            vec![("retention.ms".into(), Some("1000".into()))]
        );
        let by_resource = crate::protocol::admin::DescribeConfigsResponse::result_map(
            std::slice::from_ref(&described),
        );
        assert_eq!(
            by_resource.get(&ConfigResource::topic("t")),
            Some(&described)
        );
        let unknown_type = DescribeConfigsResult {
            error_code: 0,
            error_message: None,
            resource_type: 99,
            name: "x".into(),
            entries: Vec::new(),
        };
        let unknown_map = crate::protocol::admin::DescribeConfigsResponse::result_map(
            std::slice::from_ref(&unknown_type),
        );
        assert_eq!(
            unknown_map.get(&ConfigResource {
                resource_type: 0,
                name: "x".into(),
                keys: None,
            }),
            Some(&unknown_type)
        );
    }

    #[test]
    fn alter_configs_errors_match_java() {
        let ok = AlterConfigsResourceResult::error(CONFIG_RESOURCE_TOPIC, "t", 0);
        let bad = AlterConfigsResourceResult::error(
            CONFIG_RESOURCE_BROKER,
            "1",
            crate::error::INVALID_REQUEST,
        );
        let results = [ok, bad];
        let errors = crate::protocol::admin::AlterConfigsResponse::errors(&results);
        assert_eq!(errors.len(), 2);
        assert_eq!(
            errors.get(&ConfigResource::topic("t")),
            Some(&crate::error::ApiError::NONE)
        );
        let broker = errors.get(&ConfigResource::broker(1)).unwrap();
        assert_eq!(broker.error(), crate::error::INVALID_REQUEST);
        assert!(broker.message().is_none());
        assert_eq!(
            crate::protocol::admin::IncrementalAlterConfigsResponse::from_response_data(&results),
            errors
        );
    }

    #[test]
    fn alter_configs_request_configs_match_java() {
        let resources = [
            AlterConfigsResource {
                resource_type: CONFIG_RESOURCE_TOPIC,
                name: "t".into(),
                configs: vec![TopicConfig {
                    name: "retention.ms".into(),
                    value: Some("1000".into()),
                }],
            },
            AlterConfigsResource {
                resource_type: 99,
                name: "x".into(),
                configs: vec![TopicConfig {
                    name: "unset".into(),
                    value: None,
                }],
            },
        ];
        let configs = crate::protocol::admin::AlterConfigsRequest::configs(&resources);
        assert_eq!(configs.len(), 2);
        assert_eq!(
            configs
                .get(&ConfigResource::topic("t"))
                .and_then(|c| c.get("retention.ms"))
                .and_then(ConfigEntry::value),
            Some("1000")
        );
        let unknown_key = ConfigResource {
            resource_type: 0,
            name: "x".into(),
            keys: None,
        };
        assert_eq!(
            configs
                .get(&unknown_key)
                .and_then(|c| c.get("unset"))
                .and_then(ConfigEntry::value),
            None
        );
        assert_eq!(
            configs.get(&unknown_key).map(|c| c.entries().len()),
            Some(1)
        );
    }

    #[test]
    fn user_scram_credential_alteration_user_matches_java() {
        let d = UserScramCredentialDeletion::new("alice", SCRAM_SHA_256);
        assert_eq!(d.user(), "alice");
        assert_eq!(d.mechanism(), ScramMechanism::Sha256);
        assert_eq!(UserScramCredentialAlteration::from(d).user(), "alice");
        let u = UserScramCredentialUpsertion::new(
            "bob",
            SCRAM_SHA_256,
            4096,
            b"s".to_vec(),
            b"p".to_vec(),
        );
        assert_eq!(u.user(), "bob");
        assert_eq!(u.salt(), b"s");
        assert_eq!(u.credential_info().mechanism(), ScramMechanism::Sha256);
        assert_eq!(u.credential_info().iterations(), 4096);
        assert_eq!(UserScramCredentialAlteration::from(u).user(), "bob");
        let result = UserScramCredentialResult {
            user: "alice".into(),
            error_code: 0,
            error_message: None,
        };
        assert_eq!(result.user(), "alice");
        assert_eq!(result.error_code(), 0);
        assert!(result.error_message().is_none());
    }

    #[test]
    fn config_resource_type_matches_protocol_consts() {
        assert_eq!(i8::from(ConfigResourceType::Topic), CONFIG_RESOURCE_TOPIC);
        assert_eq!(i8::from(ConfigResourceType::Broker), CONFIG_RESOURCE_BROKER);
        assert_eq!(
            i8::from(ConfigResourceType::BrokerLogger),
            CONFIG_RESOURCE_BROKER_LOGGER
        );
        assert_eq!(
            i8::from(ConfigResourceType::ClientMetrics),
            CONFIG_RESOURCE_CLIENT_METRICS
        );
        assert_eq!(i8::from(ConfigResourceType::Group), CONFIG_RESOURCE_GROUP);
        assert_eq!(
            ConfigResource::topic("t").resource_type,
            i8::from(ConfigResourceType::Topic)
        );
        assert_eq!(ConfigResource::topic("t").name(), "t");
        assert_eq!(
            ConfigResource::topic("t").resource_type(),
            Some(ConfigResourceType::Topic)
        );
        assert!(!ConfigResource::topic("t").is_default());
        assert_eq!(
            ConfigResource::topic("t").to_string(),
            "ConfigResource(type=TOPIC, name='t')"
        );
        assert!(ConfigResource::of(ConfigResourceType::Broker, "").is_default());
        assert_eq!(
            ConfigResource::of(ConfigResourceType::Broker, "").to_string(),
            "ConfigResource(type=BROKER, name='')"
        );
        assert_eq!(ConfigResourceType::Topic.to_string(), "TOPIC");
        assert_eq!(ConfigResourceType::Topic.id(), CONFIG_RESOURCE_TOPIC);
        assert_eq!(ConfigResourceType::Broker.id(), CONFIG_RESOURCE_BROKER);
        assert_eq!(
            ConfigResourceType::BrokerLogger.id(),
            CONFIG_RESOURCE_BROKER_LOGGER
        );
        assert_eq!(
            ConfigResourceType::ClientMetrics.id(),
            CONFIG_RESOURCE_CLIENT_METRICS
        );
        assert_eq!(ConfigResourceType::Group.id(), CONFIG_RESOURCE_GROUP);
        assert_eq!(
            ConfigResourceType::from_id(CONFIG_RESOURCE_TOPIC),
            Some(ConfigResourceType::Topic)
        );
        assert_eq!(ConfigResourceType::from_id(99), None);
    }

    #[test]
    fn config_type_and_source_match_wire_ids() {
        assert_eq!(i8::from(ConfigType::Unknown), CONFIG_TYPE_UNKNOWN);
        assert_eq!(i8::from(ConfigType::String), CONFIG_TYPE_STRING);
        assert_eq!(i8::from(ConfigType::Password), CONFIG_TYPE_PASSWORD);
        assert_eq!(ConfigType::from_id(CONFIG_TYPE_STRING), ConfigType::String);
        assert_eq!(ConfigType::from_id(99), ConfigType::Unknown);
        assert_eq!(ConfigType::Unknown.to_string(), "UNKNOWN");
        assert_eq!(ConfigType::Int.to_string(), "INT");
        assert_eq!(ConfigSource::Default.to_string(), "DEFAULT_CONFIG");
        assert_eq!(
            ConfigSource::DynamicTopic.to_string(),
            "DYNAMIC_TOPIC_CONFIG"
        );
        assert_eq!(i8::from(ConfigSource::Unknown), CONFIG_SOURCE_UNKNOWN);
        assert_eq!(
            i8::from(ConfigSource::DynamicTopic),
            CONFIG_SOURCE_DYNAMIC_TOPIC
        );
        assert_eq!(i8::from(ConfigSource::Default), CONFIG_SOURCE_DEFAULT);
        assert_eq!(
            i8::from(ConfigSource::DynamicGroup),
            CONFIG_SOURCE_DYNAMIC_GROUP
        );
        assert_eq!(
            ConfigSource::from_id(CONFIG_SOURCE_DEFAULT),
            ConfigSource::Default
        );
        assert_eq!(ConfigSource::from_id(-1), ConfigSource::Unknown);
        assert_eq!(ConfigSource::from_id(99), ConfigSource::Unknown);
        let def = ConfigEntry {
            name: "k".into(),
            value: Some("v".into()),
            read_only: false,
            source: CONFIG_SOURCE_DEFAULT,
            is_sensitive: false,
            synonyms: Vec::new(),
            config_type: CONFIG_TYPE_INT,
            documentation: None,
        };
        assert!(def.is_default());
        assert_eq!(def.source(), ConfigSource::Default);
        assert_eq!(def.config_type(), ConfigType::Int);
        assert_eq!(def.name(), "k");
        assert_eq!(def.value(), Some("v"));
        assert!(!def.is_sensitive());
        assert!(!def.is_read_only());
        assert!(def.synonyms().is_empty());
        assert!(def.documentation().is_none());
        let syn = ConfigSynonym {
            name: "k".into(),
            value: Some("v".into()),
            source: CONFIG_SOURCE_DEFAULT,
        };
        assert_eq!(syn.name(), "k");
        assert_eq!(syn.value(), Some("v"));
        assert_eq!(syn.source(), ConfigSource::Default);
        assert_eq!(
            syn.to_string(),
            "ConfigSynonym(name=k, value=v, source=DEFAULT_CONFIG)"
        );
        assert_eq!(
            def.to_string(),
            "ConfigEntry(name=k, value=v, source=DEFAULT_CONFIG, isSensitive=false, isReadOnly=false, synonyms=[], type=INT, documentation=null)"
        );
        let with_syn = ConfigEntry {
            synonyms: vec![syn.clone()],
            ..def.clone()
        };
        assert_eq!(
            with_syn.to_string(),
            "ConfigEntry(name=k, value=v, source=DEFAULT_CONFIG, isSensitive=false, isReadOnly=false, synonyms=[ConfigSynonym(name=k, value=v, source=DEFAULT_CONFIG)], type=INT, documentation=null)"
        );
    }

    #[test]
    fn alter_config_op_type_matches_java() {
        assert_eq!(i8::from(AlterConfigOpType::Set), ALTER_CONFIG_SET);
        assert_eq!(AlterConfigOpType::Set.id(), ALTER_CONFIG_SET);
        assert_eq!(AlterConfigOpType::Delete.id(), ALTER_CONFIG_DELETE);
        assert_eq!(AlterConfigOpType::Append.id(), ALTER_CONFIG_APPEND);
        assert_eq!(AlterConfigOpType::Subtract.id(), ALTER_CONFIG_SUBTRACT);
        assert_eq!(i8::from(AlterConfigOpType::Delete), ALTER_CONFIG_DELETE);
        assert_eq!(i8::from(AlterConfigOpType::Append), ALTER_CONFIG_APPEND);
        assert_eq!(i8::from(AlterConfigOpType::Subtract), ALTER_CONFIG_SUBTRACT);
        assert_eq!(
            AlterConfigOpType::from_id(ALTER_CONFIG_SET),
            Some(AlterConfigOpType::Set)
        );
        assert_eq!(AlterConfigOpType::from_id(99), None);
        assert_eq!(AlterConfigOpType::Set.to_string(), "SET");
        assert_eq!(AlterConfigOpType::Delete.to_string(), "DELETE");
        assert_eq!(AlterConfigOpType::Append.to_string(), "APPEND");
        assert_eq!(AlterConfigOpType::Subtract.to_string(), "SUBTRACT");
        let entry = ConfigEntry::new("retention.ms", Some("1000".into()));
        let op = AlterConfig::from_entry(&entry, AlterConfigOpType::Set);
        assert_eq!(op.op_type(), Some(AlterConfigOpType::Set));
        assert_eq!(op.config_entry().name, "retention.ms");
        assert_eq!(op.config_entry().value.as_deref(), Some("1000"));
        assert_eq!(
            op.to_string(),
            "AlterConfigOp{opType=SET, configEntry=ConfigEntry(name=retention.ms, value=1000, source=UNKNOWN, isSensitive=false, isReadOnly=false, synonyms=[], type=UNKNOWN, documentation=null)}"
        );
        let unknown = AlterConfig {
            name: "k".into(),
            op: 99,
            value: None,
        };
        assert!(unknown.op_type().is_none());
        assert_eq!(
            unknown.to_string(),
            "AlterConfigOp{opType=null, configEntry=ConfigEntry(name=k, value=null, source=UNKNOWN, isSensitive=false, isReadOnly=false, synonyms=[], type=UNKNOWN, documentation=null)}"
        );
        assert_eq!(AlterConfigOp::set("k", "v").op, ALTER_CONFIG_SET);
    }

    #[test]
    fn group_type_and_state_match_java() {
        assert_eq!(GroupType::Classic.as_str(), "Classic");
        assert_eq!(GroupType::parse("classic"), GroupType::Classic);
        assert_eq!(GroupType::parse("CONSUMER"), GroupType::Consumer);
        assert_eq!(GroupType::parse("Unknown"), GroupType::Unknown);
        assert_eq!(GroupType::parse("Streams"), GroupType::Unknown);
        assert_eq!(GroupType::parse("nope"), GroupType::Unknown);
        assert_eq!(GroupState::Stable.as_str(), "Stable");
        assert_eq!(GroupState::parse("stable"), GroupState::Stable);
        assert_eq!(
            GroupState::parse("PreparingRebalance"),
            GroupState::PreparingRebalance
        );
        // Java keys `toString().toUpperCase()`, not the enum name: underscore
        // form is UNKNOWN, same as `GroupState.parse("PREPARING_REBALANCE")`.
        assert_eq!(
            GroupState::parse("PREPARING_REBALANCE"),
            GroupState::Unknown
        );
        assert_eq!(GroupState::parse("Unknown"), GroupState::Unknown);
        assert_eq!(GroupState::parse("nope"), GroupState::Unknown);
        assert_eq!(
            GroupState::group_states_for_type(GroupType::Share),
            &[GroupState::Stable, GroupState::Dead, GroupState::Empty]
        );
        assert!(GroupState::group_states_for_type(GroupType::Unknown).is_empty());
        let listed = ListedGroup {
            group_id: "g".into(),
            protocol_type: "consumer".into(),
            group_state: "Stable".into(),
            group_type: "classic".into(),
        };
        assert_eq!(listed.group_state(), GroupState::Stable);
        assert_eq!(listed.group_type(), GroupType::Classic);
        assert_eq!(listed.group_id(), "g");
        assert_eq!(listed.protocol(), "consumer");
        assert!(!listed.is_simple_consumer_group());
        assert_eq!(
            listed.to_string(),
            "(groupId='g', type=Classic, protocol='consumer', groupState=Stable)"
        );
        assert_eq!(
            ListedGroup::new("g").to_string(),
            "(groupId='g', type=none, protocol='', groupState=none)"
        );
        let simple = ListedGroup {
            group_id: "s".into(),
            protocol_type: String::new(),
            group_state: "Empty".into(),
            group_type: "classic".into(),
        };
        assert!(simple.is_simple_consumer_group());
        assert_eq!(simple.protocol(), "");
        let consumer = ConsumerGroupDescription::Consumer({
            let mut g = DescribedConsumerGroup::new("g-cons", 0);
            g.group_state = "Stable".into();
            g.group_epoch = 4;
            g.assignment_epoch = 5;
            g.assignor_name = "uniform".into();
            g
        });
        assert_eq!(consumer.group_id(), "g-cons");
        assert_eq!(consumer.group_state(), "Stable");
        assert_eq!(consumer.partition_assignor(), "uniform");
        assert_eq!(consumer.group_type(), GroupType::Consumer);
        assert_eq!(consumer.group_epoch(), Some(4));
        assert_eq!(consumer.target_assignment_epoch(), Some(5));
        assert!(!consumer.is_simple_consumer_group());
        assert!(consumer.is_consumer_protocol());
        let classic = ConsumerGroupDescription::Classic({
            let mut g = DescribedGroup::new("g-classic", 0);
            g.group_state = "Stable".into();
            g.protocol_type = "consumer".into();
            g.protocol_data = "range".into();
            g
        });
        assert_eq!(classic.partition_assignor(), "range");
        assert_eq!(classic.group_type(), GroupType::Classic);
        assert!(classic.group_epoch().is_none());
        assert!(classic.target_assignment_epoch().is_none());
        assert!(!classic.is_simple_consumer_group());
        assert!(!classic.is_consumer_protocol());
        let simple_desc = ConsumerGroupDescription::Classic(DescribedGroup::new("s", 0));
        assert!(simple_desc.is_simple_consumer_group());
        assert_eq!(simple_desc.partition_assignor(), "");
    }

    #[test]
    fn remaining_admin_result_getters_match_java() {
        let pid = ProducerIdBlock {
            producer_id_start: 1000,
            producer_id_len: 1000,
        };
        assert_eq!(pid.producer_id_start(), 1000);
        assert_eq!(pid.producer_id_len(), 1000);
        let fenced = FencedProducer {
            transactional_id: "tid".into(),
            producer_id: 9,
            epoch: 1,
        };
        assert_eq!(fenced.transactional_id(), "tid");
        assert_eq!(fenced.producer_id(), 9);
        assert_eq!(fenced.epoch(), 1);
        let deleted = DeletedAclsFilterResult {
            error_code: 0,
            error_message: None,
            matching: vec![crate::protocol::acl::DeleteAclsResponse::matching_acl(
                &AclBinding::allow_topic("t", "User:alice"),
                &crate::error::ApiError::NONE,
            )],
        };
        assert_eq!(deleted.error_code(), 0);
        assert!(deleted.error_message().is_none());
        assert_eq!(deleted.matching().len(), 1);
        let altered = AlterConfigsResourceResult {
            error_code: 0,
            error_message: None,
            resource_type: CONFIG_RESOURCE_TOPIC,
            name: "t".into(),
        };
        assert_eq!(altered.error_code(), 0);
        assert_eq!(altered.name(), "t");
        assert!(altered.error_message().is_none());
        let created = TopicResult {
            name: "orders".into(),
            error_code: 0,
            error_message: None,
            topic_id: Uuid::ONE.to_bytes(),
            num_partitions: 3,
            replication_factor: 1,
            configs: vec![CreatedTopicConfig {
                name: "cleanup.policy".into(),
                value: Some("compact".into()),
                read_only: false,
                config_source: CONFIG_SOURCE_DYNAMIC_TOPIC,
                is_sensitive: false,
            }],
        };
        assert_eq!(created.name(), "orders");
        assert_eq!(created.error_code(), 0);
        assert!(created.error_message().is_none());
        assert_eq!(created.topic_id(), Uuid::ONE);
        assert_eq!(created.num_partitions(), 3);
        assert_eq!(created.replication_factor(), 1);
        assert_eq!(
            created
                .config()
                .get("cleanup.policy")
                .and_then(ConfigEntry::value),
            Some("compact")
        );
        let listed = ListedConfigResource::new("r", CONFIG_RESOURCE_CLIENT_METRICS);
        assert_eq!(listed.name(), "r");
        assert_eq!(
            listed.resource_type(),
            Some(ConfigResourceType::ClientMetrics)
        );
        assert!(!listed.is_default());
        assert_eq!(
            listed.to_string(),
            "ConfigResource(type=CLIENT_METRICS, name='r')"
        );
        assert!(ListedConfigResource::new("", CONFIG_RESOURCE_BROKER).is_default());
        assert_eq!(
            ListedConfigResource::new("t", CONFIG_RESOURCE_TOPIC).to_string(),
            "ConfigResource(type=TOPIC, name='t')"
        );
        let resource = listed.to_config_resource();
        assert_eq!(resource.name(), "r");
        assert_eq!(
            resource.resource_type(),
            Some(ConfigResourceType::ClientMetrics)
        );
        let owned = ConfigResource::from(listed);
        assert_eq!(owned.name(), "r");
        let deleted = DeletableGroupResult::new("g", 0);
        assert_eq!(deleted.group_id(), "g");
        assert_eq!(deleted.error_code(), 0);
        let telemetry = GetTelemetrySubscriptionsResponse::new(
            0,
            Uuid::from_bytes([0x11; 16]),
            1,
            vec![1],
            1000,
            100,
            true,
            vec!["m".into()],
        );
        assert_eq!(telemetry.error_code(), 0);
        assert_eq!(telemetry.throttle_time_ms(), 0);
        assert_eq!(telemetry.client_instance_id(), Uuid::from_bytes([0x11; 16]));
        assert_eq!(telemetry.subscription_id(), 1);
        assert_eq!(telemetry.accepted_compression_types(), &[1]);
        assert_eq!(telemetry.push_interval_ms(), 1000);
        assert_eq!(telemetry.telemetry_max_bytes(), 100);
        assert!(telemetry.delta_temporality());
        assert_eq!(telemetry.requested_metrics(), &["m".to_string()]);
        assert_eq!(PushTelemetryResponse::new(0).error_code(), 0);
        assert_eq!(PushTelemetryResponse::new(0).throttle_time_ms(), 0);
        let push =
            PushTelemetryRequest::new(Uuid::from_bytes([0x11; 16]), 1, false, 0, b"m".to_vec());
        assert_eq!(push.client_instance_id(), Uuid::from_bytes([0x11; 16]));
        assert_eq!(push.subscription_id(), 1);
        assert!(!push.terminating());
        assert_eq!(push.compression_type(), 0);
        assert_eq!(push.metrics(), b"m");
        let cluster = ClusterDescription::new(
            0,
            None,
            Some("c".into()),
            2,
            1,
            AUTHORIZED_OPERATIONS_OMITTED,
            vec![
                DescribeClusterBroker::new(1, "h1", 9092, None, false),
                DescribeClusterBroker::new(2, "h2", 9092, Some("r".into()), false),
            ],
        );
        assert_eq!(cluster.nodes().len(), 2);
        assert_eq!(cluster.controller().map(DescribeClusterBroker::id), Some(2));
        assert_eq!(
            cluster.authorized_operations(),
            AUTHORIZED_OPERATIONS_OMITTED
        );
        assert!(cluster.error_message().is_none());
        let controller = cluster.controller().unwrap();
        assert_eq!(controller.id_string(), "2");
        assert!(!controller.is_empty());
        assert_eq!(
            controller.to_string(),
            "h2:9092 (id: 2 rack: r isFenced: false)"
        );
        let no_controller = ClusterDescription {
            controller_id: -1,
            ..cluster.clone()
        };
        assert!(no_controller.controller().is_none());
        let unreg = UnregisterBrokerResponse::new(0, None);
        assert_eq!(unreg.error_code(), 0);
        assert!(unreg.error_message().is_none());
    }

    #[test]
    fn delegation_token_getters_match_java() {
        let renewer = CreatableRenewer::new("User", "r");
        assert_eq!(renewer.principal_type(), "User");
        assert_eq!(renewer.principal_name(), "r");
        assert_eq!(renewer.to_string(), "User:r");
        assert_eq!(CreatableRenewer::USER_TYPE, "User");
        assert_eq!(CreatableRenewer::anonymous().to_string(), "User:ANONYMOUS");
        assert_eq!(
            DescribeDelegationTokenOwner::anonymous().principal_name(),
            "ANONYMOUS"
        );
        assert_eq!(
            DescribedDelegationTokenRenewer::anonymous().to_string(),
            "User:ANONYMOUS"
        );
        let req = CreateDelegationTokenRequest::new(
            Some("User".into()),
            Some("alice".into()),
            vec![renewer],
            -1,
        );
        assert_eq!(req.owner_principal_type(), Some("User"));
        assert_eq!(req.owner_principal_name(), Some("alice"));
        assert_eq!(req.renewers().len(), 1);
        assert_eq!(req.max_lifetime_ms(), -1);
        let created = CreateDelegationTokenResponse::new(
            0,
            "User",
            "alice",
            "User",
            "bob",
            1,
            2,
            3,
            "tid",
            vec![0xaa],
        );
        assert_eq!(created.error_code(), 0);
        assert_eq!(created.principal_type(), "User");
        assert_eq!(created.principal_name(), "alice");
        assert_eq!(created.owner_as_string(), "User:alice");
        assert_eq!(created.token_requester_as_string(), "User:bob");
        assert_eq!(created.issue_timestamp(), 1);
        assert_eq!(created.expiry_timestamp(), 2);
        assert_eq!(created.max_timestamp(), 3);
        assert_eq!(created.token_id(), "tid");
        assert_eq!(created.hmac(), &[0xaa]);
        assert_eq!(created.hmac_as_base64_string(), "qg==");
        let created_debug = format!("{created:?}");
        assert!(
            created_debug.contains("[*******]"),
            "Java DelegationToken.toString redacts hmac: {created_debug}"
        );
        assert!(
            !created_debug.contains("aa") && !created_debug.contains("170"),
            "Debug must not leak hmac bytes: {created_debug}"
        );
        let owner = DescribeDelegationTokenOwner::new("User", "alice");
        assert_eq!(owner.to_string(), "User:alice");
        let described_req = DescribeDelegationTokenRequest::new(Some(vec![owner]));
        assert_eq!(
            described_req
                .owners()
                .map(<[DescribeDelegationTokenOwner]>::len),
            Some(1)
        );
        let token = DescribedDelegationToken::new(
            "User",
            "alice",
            "User",
            "bob",
            1,
            2,
            3,
            "tid",
            vec![0xaa],
            vec![DescribedDelegationTokenRenewer::new("User", "r")],
        );
        assert_eq!(token.owner_as_string(), "User:alice");
        assert_eq!(token.hmac_as_base64_string(), "qg==");
        assert_eq!(token.renewers()[0].to_string(), "User:r");
        assert_eq!(token.renewers_as_string(), vec!["User:r".to_string()]);
        assert!(token.owner_or_renewer("User", "alice"));
        assert!(token.owner_or_renewer("User", "bob"));
        assert!(token.owner_or_renewer("User", "r"));
        assert!(!token.owner_or_renewer("User", "other"));
        assert_eq!(
            token.to_string(),
            "DelegationToken{tokenInformation=TokenInformation{owner=User:alice, tokenRequester=User:bob, renewers=[User:r], issueTimestamp=1, maxTimestamp=3, expiryTimestamp=2, tokenId='tid'}, hmac=[*******]}"
        );
        let empty_renewers = DescribedDelegationToken::new(
            "User",
            "alice",
            "User",
            "bob",
            1,
            2,
            3,
            "tid",
            vec![0xaa],
            vec![],
        );
        assert_eq!(
            empty_renewers.to_string(),
            "DelegationToken{tokenInformation=TokenInformation{owner=User:alice, tokenRequester=User:bob, renewers=[], issueTimestamp=1, maxTimestamp=3, expiryTimestamp=2, tokenId='tid'}, hmac=[*******]}"
        );
        let two_renewers = DescribedDelegationToken::new(
            "User",
            "alice",
            "User",
            "bob",
            1,
            2,
            3,
            "tid",
            vec![0xaa],
            vec![
                DescribedDelegationTokenRenewer::new("User", "r"),
                DescribedDelegationTokenRenewer::new("User", "s"),
            ],
        );
        assert_eq!(
            two_renewers.to_string(),
            "DelegationToken{tokenInformation=TokenInformation{owner=User:alice, tokenRequester=User:bob, renewers=[User:r, User:s], issueTimestamp=1, maxTimestamp=3, expiryTimestamp=2, tokenId='tid'}, hmac=[*******]}"
        );
        let token_debug = format!("{token:?}");
        assert!(token_debug.contains("[*******]"));
        assert!(!token_debug.contains("170"));
        let listed = DescribeDelegationTokenResponse::new(0, vec![token]);
        assert_eq!(listed.error_code(), 0);
        assert_eq!(listed.tokens().len(), 1);
        let renewed = RenewDelegationTokenResponse::new(0, 9);
        assert_eq!(renewed.error_code(), 0);
        assert_eq!(renewed.expiry_timestamp(), 9);
        let expired = ExpireDelegationTokenResponse::new(0, 8);
        assert_eq!(expired.error_code(), 0);
        assert_eq!(expired.expiry_timestamp(), 8);
        let renew_req = RenewDelegationTokenRequest::new(vec![0xaa], -1);
        assert_eq!(renew_req.hmac(), &[0xaa]);
        assert_eq!(renew_req.renew_period_ms(), -1);
        let expire_req = ExpireDelegationTokenRequest::new(vec![0xaa], -1);
        assert_eq!(expire_req.hmac(), &[0xaa]);
        assert_eq!(expire_req.expiry_time_period_ms(), -1);
    }

    #[test]
    fn new_partition_reassignment_matches_java() {
        let neu = NewPartitionReassignment::new([2, 1]).unwrap();
        assert_eq!(neu.target_replicas(), &[2, 1]);
        let err = NewPartitionReassignment::new(Vec::<i32>::new()).unwrap_err();
        assert!(
            err.to_string().contains("without any replicas"),
            "Java NewPartitionReassignment rejects an empty replica list: {err}"
        );
        let assigned = PartitionReassignment::from_new(("t", 0), Some(neu));
        assert_eq!(assigned.topic(), "t");
        assert_eq!(assigned.partition(), 0);
        assert_eq!(assigned.replicas(), Some(&[2, 1][..]));
        let cancelled = PartitionReassignment::from_new(("t", 0), None);
        assert!(cancelled.replicas().is_none());
        let ongoing = OngoingReassignment {
            topic: "t".into(),
            partition: 0,
            replicas: vec![2, 1],
            adding_replicas: vec![2],
            removing_replicas: vec![3],
        };
        assert_eq!(ongoing.topic(), "t");
        assert_eq!(ongoing.partition(), 0);
        assert_eq!(ongoing.replicas(), &[2, 1]);
        assert_eq!(ongoing.adding_replicas(), &[2]);
        assert_eq!(ongoing.removing_replicas(), &[3]);
        assert_eq!(
            ongoing.to_string(),
            "PartitionReassignment(replicas=[2, 1], addingReplicas=[2], removingReplicas=[3])"
        );
        let result = ReassignmentResult {
            topic: "t".into(),
            partition: 0,
            error_code: 0,
            error_message: None,
        };
        assert_eq!(result.topic(), "t");
        assert_eq!(result.partition(), 0);
        assert_eq!(result.error_code(), 0);
        assert!(result.error_message().is_none());
    }

    #[test]
    fn uuid_matches_java() {
        assert_eq!(Uuid::ZERO.to_string(), "AAAAAAAAAAAAAAAAAAAAAA");
        assert_eq!(Uuid::ONE.to_string(), "AAAAAAAAAAAAAAAAAAAAAQ");
        assert_eq!(Uuid::ZERO_UUID, Uuid::ZERO);
        assert_eq!(Uuid::ONE_UUID, Uuid::ONE);
        assert_eq!(Uuid::METADATA_TOPIC_ID, Uuid::ONE);
        assert_eq!(Uuid::ZERO.most_significant_bits(), 0);
        assert_eq!(Uuid::ZERO.least_significant_bits(), 0);
        assert_eq!(Uuid::ONE.most_significant_bits(), 0);
        assert_eq!(Uuid::ONE.least_significant_bits(), 1);
        assert_eq!(
            Uuid::from_string("AAAAAAAAAAAAAAAAAAAAAA").unwrap(),
            Uuid::ZERO
        );
        assert_eq!(
            Uuid::from_string("AAAAAAAAAAAAAAAAAAAAAQ").unwrap(),
            Uuid::ONE
        );
        assert_eq!(
            Uuid::from_string("AAAAAAAAAAAAAAAAAAAAAQ==").unwrap(),
            Uuid::ONE,
            "Java fromString accepts URL-safe padding"
        );
        let invalid = Uuid::from_string("!!!!").unwrap_err();
        assert!(
            invalid
                .to_string()
                .contains("Uuid string `!!!!` is not a base64url UUID"),
            "{invalid}"
        );
        let too_long = Uuid::from_string("AAAAAAAAAAAAAAAAAAAAAAAAA").unwrap_err();
        assert!(
            too_long.to_string().contains(
                "Input string with prefix `AAAAAAAAAAAAAAAAAAAAAAAA` is too long to be decoded as a base64 UUID"
            ),
            "{too_long}"
        );
        let wrong_len = Uuid::from_string("AAAA").unwrap_err();
        assert!(
            wrong_len.to_string().contains(
                "Input string `AAAA` decoded as 3 bytes, which is not equal to the expected 16 bytes of a base64-encoded UUID"
            ),
            "{wrong_len}"
        );
        let parsed: Uuid = "AAAAAAAAAAAAAAAAAAAAAA".parse().unwrap();
        assert_eq!(parsed, Uuid::ZERO);
        assert_eq!(<[u8; 16]>::from(Uuid::ONE), Uuid::ONE.to_bytes());
        let neg = Uuid::from_parts(i64::MIN, 0);
        assert!(neg < Uuid::ZERO, "Java compareTo uses signed longs");
        let listing = TopicListing::new("t", Uuid::ONE, false);
        assert_eq!(listing.topic_id(), Uuid::ONE);
        assert_eq!(listing.name(), "t");
        assert!(!listing.is_internal());
        assert_eq!(
            listing.to_string(),
            "(name=t, topicId=AAAAAAAAAAAAAAAAAAAAAQ, internal=false)"
        );
        assert!(Uuid::RESERVED.contains(&Uuid::ZERO));
        assert!(Uuid::RESERVED.contains(&Uuid::ONE));
        assert!(Uuid::RESERVED.contains(&Uuid::METADATA_TOPIC_ID));
        let samples: Vec<Uuid> = (0..32).map(|_| Uuid::random_uuid()).collect();
        for (i, u) in samples.iter().enumerate() {
            assert_ne!(*u, Uuid::ZERO);
            assert_ne!(*u, Uuid::ONE);
            assert!(
                !u.to_string().starts_with('-'),
                "Java randomUuid skips dash-prefixed base64url"
            );
            assert_eq!(
                u.as_bytes().get(6).map(|b| b >> 4),
                Some(4),
                "Java randomUuid is RFC 4122 version 4"
            );
            assert_eq!(
                u.as_bytes().get(8).map(|b| b >> 6),
                Some(2),
                "Java randomUuid is RFC 4122 variant 2"
            );
            for (j, other) in samples.iter().enumerate() {
                if i != j {
                    assert_ne!(*u, *other);
                }
            }
        }
    }

    #[test]
    fn topic_collection_matches_java() {
        let names = TopicCollection::of_topic_names(["orders", "events"]);
        assert_eq!(names.topic_names().map(<[String]>::len), Some(2));
        assert!(names.topic_ids().is_none());
        let ids = TopicCollection::of_topic_ids([Uuid::ONE, Uuid::ZERO]);
        assert_eq!(ids.topic_ids(), Some(&[Uuid::ONE, Uuid::ZERO][..]));
        assert!(ids.topic_names().is_none());
        let from_bytes = TopicCollection::of_topic_ids([[1u8; 16]]);
        assert_eq!(
            from_bytes.topic_ids().and_then(|ids| ids.first().copied()),
            Some(Uuid::from_bytes([1u8; 16]))
        );
        let empty = TopicCollection::of_topic_ids(Vec::<Uuid>::new());
        assert_eq!(empty, TopicCollection::Ids(Vec::new()));
        assert!(empty.topic_ids().unwrap().is_empty());
    }

    #[test]
    fn scram_mechanism_matches_protocol_consts() {
        assert_eq!(i8::from(ScramMechanism::Unknown), SCRAM_UNKNOWN);
        assert_eq!(i8::from(ScramMechanism::Sha256), SCRAM_SHA_256);
        assert_eq!(i8::from(ScramMechanism::Sha512), SCRAM_SHA_512);
        assert_eq!(ScramMechanism::Unknown.id(), SCRAM_UNKNOWN);
        assert_eq!(ScramMechanism::Sha256.id(), SCRAM_SHA_256);
        assert_eq!(ScramMechanism::Sha512.id(), SCRAM_SHA_512);
        assert_eq!(
            ScramMechanism::from_id(SCRAM_SHA_256),
            ScramMechanism::Sha256
        );
        assert_eq!(ScramMechanism::from_id(0), ScramMechanism::Unknown);
        assert_eq!(ScramMechanism::from_id(99), ScramMechanism::Unknown);
        assert_eq!(
            ScramMechanism::from_mechanism_name("SCRAM-SHA-256"),
            ScramMechanism::Sha256
        );
        assert_eq!(
            ScramMechanism::from_mechanism_name("SCRAM_SHA_256"),
            ScramMechanism::Unknown
        );
        assert_eq!(ScramMechanism::Sha256.mechanism_name(), "SCRAM-SHA-256");
        assert_eq!(ScramMechanism::Unknown.to_string(), "UNKNOWN");
        assert_eq!(ScramMechanism::Sha256.to_string(), "SCRAM_SHA_256");
        assert_eq!(ScramMechanism::Sha512.to_string(), "SCRAM_SHA_512");
        let info = ScramCredentialInfo::new(ScramMechanism::Sha512, 8192);
        assert_eq!(info.mechanism(), ScramMechanism::Sha512);
        assert_eq!(info.iterations(), 8192);
        assert_eq!(
            info.to_string(),
            "ScramCredentialInfo{mechanism=SCRAM_SHA_512, iterations=8192}"
        );
        let described = DescribeUserScramCredentialsResult {
            user: "alice".into(),
            error_code: 0,
            error_message: None,
            credential_infos: vec![ScramCredentialInfo::new(ScramMechanism::Sha256, 4096)],
        };
        assert_eq!(
            described.to_string(),
            "UserScramCredentialsDescription{name='alice', credentialInfos=[ScramCredentialInfo{mechanism=SCRAM_SHA_256, iterations=4096}]}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn topic_listings_skip_errors_and_unnamed() {
        use crate::protocol::api::{PartitionMetadata, TopicMetadata};

        let md = MetadataResponse {
            throttle_time_ms: 0,
            brokers: Vec::new(),
            cluster_id: None,
            controller_id: 1,
            topics: vec![
                TopicMetadata {
                    error_code: 0,
                    name: Some("ok".into()),
                    topic_id: [1; 16],
                    is_internal: false,
                    partitions: vec![PartitionMetadata {
                        error_code: 0,
                        partition_index: 0,
                        leader_id: 1,
                        leader_epoch: 3,
                        replica_nodes: vec![1],
                        isr_nodes: vec![1],
                        offline_replicas: Vec::new(),
                    }],
                    topic_authorized_operations: i32::MIN,
                },
                TopicMetadata {
                    error_code: error::UNKNOWN_TOPIC_OR_PARTITION,
                    name: Some("gone".into()),
                    topic_id: [0; 16],
                    is_internal: false,
                    partitions: vec![PartitionMetadata {
                        error_code: error::UNKNOWN_TOPIC_OR_PARTITION,
                        partition_index: 0,
                        leader_id: -1,
                        leader_epoch: -1,
                        replica_nodes: Vec::new(),
                        isr_nodes: Vec::new(),
                        offline_replicas: Vec::new(),
                    }],
                    topic_authorized_operations: i32::MIN,
                },
                TopicMetadata {
                    error_code: 0,
                    name: None,
                    topic_id: [2; 16],
                    is_internal: true,
                    partitions: Vec::new(),
                    topic_authorized_operations: i32::MIN,
                },
                TopicMetadata {
                    error_code: 0,
                    name: Some("__consumer_offsets".into()),
                    topic_id: [3; 16],
                    is_internal: true,
                    partitions: Vec::new(),
                    topic_authorized_operations: i32::MIN,
                },
            ],
            cluster_authorized_operations: MetadataResponse::AUTHORIZED_OPERATIONS_OMITTED,
            error_code: 0,
        };
        let listed = topic_listings_from(&md, true);
        assert_eq!(listed.len(), 2);
        assert_eq!(listed[0].name, "ok");
        assert_eq!(listed[0].name(), "ok");
        assert_eq!(listed[0].topic_id, [1; 16]);
        assert_eq!(listed[0].topic_id(), Uuid::from_bytes([1; 16]));
        assert!(!listed[0].is_internal());
        assert_eq!(listed[1].name, "__consumer_offsets");
        assert!(listed[1].is_internal);
        assert!(listed[1].is_internal());
        let listed = topic_listings_from(&md, false);
        assert_eq!(listed.len(), 1);
        assert_eq!(listed[0].name, "ok");
        let described = topic_descriptions_including_unnamed(&md).await;
        assert_eq!(described.len(), 4);
        assert_eq!(described[0].name, "ok");
        assert_eq!(described[0].partitions.len(), 1);
        assert_eq!(described[0].partitions().len(), 1);
        assert_eq!(described[0].error_code(), 0);
        assert_eq!(
            described[0].authorized_operations(),
            AUTHORIZED_OPERATIONS_OMITTED
        );
        assert_eq!(described[0].partitions[0].leader_epoch, 3);
        assert_eq!(described[1].name, "gone");
        assert_eq!(described[1].error_code, error::UNKNOWN_TOPIC_OR_PARTITION);
        assert_eq!(described[1].error_code(), error::UNKNOWN_TOPIC_OR_PARTITION);
        assert!(described[1].partitions.is_empty());
        assert!(described[1].partitions().is_empty());
        assert!(described[2].name.is_empty());
        assert_eq!(described[2].topic_id, [2; 16]);
        assert_eq!(described[2].topic_id(), Uuid::from_bytes([2; 16]));
        assert_eq!(described[3].name, "__consumer_offsets");
        assert_eq!(described[3].name(), "__consumer_offsets");
        assert!(described[3].is_internal);
        assert!(described[3].is_internal());
        let named = topic_descriptions_for_names(
            &md,
            &["ok".to_string(), "gone".to_string(), "missing".to_string()],
        )
        .await;
        assert_eq!(named.len(), 3);
        assert_eq!(named[0].name, "ok");
        assert_eq!(named[0].error_code, 0);
        assert_eq!(named[1].name, "gone");
        assert_eq!(named[1].error_code, error::UNKNOWN_TOPIC_OR_PARTITION);
        assert_eq!(named[2].name, "missing");
        assert_eq!(named[2].error_code, error::UNKNOWN_TOPIC_OR_PARTITION);
    }

    fn many_replicas(count: i32) -> Vec<TopicPartitionReplica> {
        (0..count)
            .map(|index| TopicPartitionReplica::new("orders", index, 2))
            .collect()
    }

    #[tokio::test(flavor = "current_thread")]
    async fn remembering_many_replica_dirs_does_not_hold_the_caller() {
        // 20_000 replicas: scanning the directory list for each one held the
        // caller 1.39s. A longer indexed walk still has to pause.
        let replicas = many_replicas(500_000);
        let described = DescribeLogDirsResponse::new(
            0,
            vec![DescribeLogDirsResult::new(
                0,
                "/data",
                vec![DescribeLogDirsTopic::new(
                    "orders",
                    (0..500_000)
                        .map(|index| DescribeLogDirsPartition::new(index, 10, 1, false))
                        .collect(),
                )],
                1,
                1,
            )],
        );
        let mut infos = HashMap::new();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = remember_replica_dirs_cooperative(&mut infos, &replicas, 2, &described) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "remembering replica directories held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn recording_many_replica_dir_errors_does_not_hold_the_caller() {
        // 20_000 replicas: scanning the error list for each one held the caller 580ms.
        let replicas = many_replicas(500_000);
        let altered =
            AlterReplicaLogDirsResponse::new(vec![AlterReplicaLogDirsResponseTopic::new(
                "orders",
                (0..500_000)
                    .map(|index| AlterReplicaLogDirsResponsePartition::new(index, 0))
                    .collect(),
            )]);
        let assignment: Vec<(TopicPartitionReplica, String)> = replicas
            .iter()
            .cloned()
            .map(|replica| (replica, "/data".to_owned()))
            .collect();
        let mut errors = HashMap::new();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = record_alter_replica_errors_cooperative(&mut errors, &assignment, 2, &altered) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "recording replica directory errors held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn recording_many_election_topics_does_not_hold_the_caller() {
        // 20_000 distinct topics: scanning the name list held the caller 1.38s.
        // A longer indexed walk still has to pause.
        let partitions: Vec<TopicPartition> = (0..200_000)
            .map(|index| TopicPartition::new(format!("topic-{index}"), 0))
            .collect();
        let mut selection = ElectionSelection::default();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = record_election_partitions(&mut selection, partitions) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "recording election topics held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn grouping_many_describable_replicas_does_not_hold_the_caller() {
        // 20_000 replicas: scanning the growing list held the caller 701ms.
        // A longer walk still has to pause after membership is a set.
        let replicas: Vec<TopicPartitionReplica> = (0..500_000)
            .map(|index| TopicPartitionReplica::new("orders", index, 2))
            .collect();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = describable_topics_for_broker_cooperative(&replicas, 2) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "grouping describable replicas held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn cooperative_describable_topics_match_one_shot() {
        let replicas = [
            TopicPartitionReplica::new("orders", 1, 2),
            TopicPartitionReplica::new("orders", 1, 2),
            TopicPartitionReplica::new("orders", 0, 2),
            TopicPartitionReplica::new("payments", 4, 1),
        ];
        let one = describable_topics_for_broker(&replicas, 2);
        let two = describable_topics_for_broker_cooperative(&replicas, 2).await;
        assert_eq!(one.len(), 1);
        assert_eq!(one[0].0, two[0].0);
        assert_eq!(one[0].1, two[0].1);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn collecting_many_group_ids_does_not_hold_the_caller() {
        // 20_000 group ids: scanning the list held the caller 1.04s.
        let ids: Vec<String> = (0..20_000).map(|id| format!("group-{id}")).collect();
        let pending: Vec<usize> = (0..ids.len()).collect();
        let mut known = HashMap::new();
        let _ = known.insert("group-1".to_owned(), 4);
        let started = std::time::Instant::now();
        tokio::select! {
            () = async {
                let need = first_seen_missing_ids(&ids, &pending, &known);
                assert_eq!(need.len(), 19_999);
                assert_eq!(need.first().copied(), Some("group-0"));
                assert!(!need.contains(&"group-1"));
                assert_eq!(need.last().copied(), Some("group-19999"));
            } => {}
            () = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "collecting group ids held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn collecting_many_replica_brokers_does_not_hold_the_caller() {
        // 20_000 distinct brokers: scanning the list held the caller 705ms.
        let replicas: Vec<_> = (0..20_000)
            .map(|id| TopicPartitionReplica::new("orders", id, id))
            .collect();
        let started = std::time::Instant::now();
        tokio::select! {
            () = async {
                let ids = replica_broker_ids(&replicas).await;
                assert_eq!(ids.len(), 20_000);
                assert_eq!(ids.first().copied(), Some(0));
                assert_eq!(ids.last().copied(), Some(19_999));
            } => {}
            () = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "collecting replica brokers held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn replica_log_dirs_group_and_map_current_future() {
        let replicas = [
            TopicPartitionReplica::new("t", 0, 2),
            TopicPartitionReplica::new("t", 1, 2),
            TopicPartitionReplica::new("u", 0, 1),
            TopicPartitionReplica::new("t", 0, 2),
        ];
        assert_eq!(replica_broker_ids(&replicas).await, vec![2, 1]);
        let on_two = describable_topics_for_broker(&replicas, 2);
        assert_eq!(on_two.len(), 1);
        assert_eq!(on_two[0].0, "t");
        assert_eq!(on_two[0].1, vec![0, 1]);
        let on_one = describable_topics_for_broker(&replicas, 1);
        assert_eq!(on_one.len(), 1);
        assert_eq!(on_one[0].0, "u");
        assert_eq!(on_one[0].1, vec![0]);

        let dirs = vec![
            DescribeLogDirsResult::new(
                0,
                "/current",
                vec![DescribeLogDirsTopic::new(
                    "t",
                    vec![DescribeLogDirsPartition::new(0, 10, 3, false)],
                )],
                -1,
                -1,
            ),
            DescribeLogDirsResult::new(
                0,
                "/future",
                vec![DescribeLogDirsTopic::new(
                    "t",
                    vec![DescribeLogDirsPartition::new(0, 4, 7, true)],
                )],
                -1,
                -1,
            ),
            DescribeLogDirsResult::new(56, "/offline", Vec::new(), -1, -1),
        ];
        let replica = TopicPartitionReplica::new("t", 0, 2);
        let info = replica_log_dir_info_from(&replica, &dirs);
        assert_eq!(info.current_log_dir.as_deref(), Some("/current"));
        assert_eq!(info.current_offset_lag, 3);
        assert_eq!(info.future_log_dir.as_deref(), Some("/future"));
        assert_eq!(info.future_offset_lag, 7);
        let missing = replica_log_dir_info_from(&TopicPartitionReplica::new("t", 9, 2), &dirs);
        assert_eq!(missing, ReplicaLogDirInfo::unknown());
    }

    #[test]
    fn group_reassignments_keeps_duplicate_partitions() {
        let assignments = [
            PartitionReassignment::assign(crate::TopicPartition::new("t", 0), [1, 2]),
            PartitionReassignment::cancel(crate::TopicPartition::new("t", 0)),
            PartitionReassignment::assign(crate::TopicPartition::new("t", 1), [3]),
        ];
        let topics = group_reassignments(&assignments);
        assert_eq!(topics.len(), 1);
        assert_eq!(topics[0].0, "t");
        assert_eq!(topics[0].1.len(), 3);
        assert_eq!(topics[0].1[0].partition_index, 0);
        assert_eq!(topics[0].1[0].replicas, Some(&[1, 2][..]));
        assert_eq!(topics[0].1[1].partition_index, 0);
        assert_eq!(topics[0].1[1].replicas, None);
        assert_eq!(topics[0].1[2].partition_index, 1);
        assert_eq!(topics[0].1[2].replicas, Some(&[3][..]));
    }

    #[tokio::test(flavor = "current_thread")]
    async fn group_list_reassignments_keeps_duplicate_partitions() {
        let partitions = [
            crate::TopicPartition::new("t", 0),
            crate::TopicPartition::new("t", 0),
            crate::TopicPartition::new("t", 1),
        ];
        let topics = group_list_reassignments(&partitions).await;
        assert_eq!(topics.len(), 1);
        assert_eq!(topics[0].0, "t");
        assert_eq!(topics[0].1, vec![0, 0, 1]);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn grouping_many_offset_deletes_does_not_hold_the_caller() {
        // 2_000_000 partitions: grouping them held the caller 332ms.
        let partitions: Vec<(String, i32)> = (0..2_000_000)
            .map(|index| ("orders".to_string(), index))
            .collect();
        let started = std::time::Instant::now();
        tokio::select! {
            topics = offset_delete_named_topics(&partitions) => {
                assert_eq!(topics.first().map(|(_, parts)| parts.len()), Some(2_000_000));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "grouping offset deletes held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn collecting_many_broker_ids_does_not_hold_the_caller() {
        // 2_000_000 broker ids: recording the first copy of each held the caller 299ms.
        let ids: Vec<i32> = (0..2_000_000).map(|index| index % 8).collect();
        let started = std::time::Instant::now();
        tokio::select! {
            unique = first_seen_i32(&ids) => {
                assert_eq!(unique, vec![0, 1, 2, 3, 4, 5, 6, 7]);
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "collecting broker ids held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn flattening_many_list_reassignments_does_not_hold_the_caller() {
        use crate::protocol::admin::{OngoingPartitionReassignment, OngoingTopicReassignment};
        // 2_000_000 partitions: copying each topic name held the caller 231ms.
        let partitions: Vec<OngoingPartitionReassignment> = (0..2_000_000)
            .map(OngoingPartitionReassignment::new)
            .collect();
        let topics = [OngoingTopicReassignment::new("orders", partitions)];
        let started = std::time::Instant::now();
        tokio::select! {
            flat = flatten_list_reassignments(&topics) => {
                assert_eq!(flat.len(), 2_000_000);
                assert_eq!(flat.first().map(|row| row.topic.as_str()), Some("orders"));
                assert_eq!(flat.first().map(|row| row.partition), Some(0));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "flattening list reassignments held the caller for {elapsed:?}"
        );
        let mut repeated = OngoingPartitionReassignment::new(1);
        repeated.replicas = vec![2, 3];
        repeated.adding_replicas = vec![3];
        repeated.removing_replicas = vec![4];
        let small = [
            OngoingTopicReassignment::new(
                "orders",
                vec![OngoingPartitionReassignment::new(0), repeated.clone()],
            ),
            OngoingTopicReassignment::new("payments", vec![OngoingPartitionReassignment::new(7)]),
        ];
        let flat = flatten_list_reassignments(&small).await;
        assert_eq!(flat.len(), 3);
        assert_eq!(flat[0].topic, "orders");
        assert_eq!(flat[0].partition, 0);
        assert!(flat[0].replicas.is_empty());
        assert_eq!(flat[1].topic, "orders");
        assert_eq!(flat[1].replicas, vec![2, 3]);
        assert_eq!(flat[1].adding_replicas, vec![3]);
        assert_eq!(flat[1].removing_replicas, vec![4]);
        assert_eq!(flat[2].topic, "payments");
        assert_eq!(flat[2].partition, 7);
        assert_eq!(small[0].partitions[1].replicas, vec![2, 3]);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn flattening_many_reassignment_results_does_not_hold_the_caller() {
        use crate::protocol::admin::{ReassignmentPartitionResult, ReassignmentTopicResult};
        // 2_000_000 partitions: copying each topic name held the caller 152ms.
        let partitions: Vec<ReassignmentPartitionResult> = (0..2_000_000)
            .map(|index| ReassignmentPartitionResult::error(index, 0))
            .collect();
        let topics = [ReassignmentTopicResult::new("orders", partitions)];
        let started = std::time::Instant::now();
        tokio::select! {
            flat = flatten_reassignment_results(&topics) => {
                assert_eq!(flat.len(), 2_000_000);
                assert_eq!(flat.first().map(|row| row.topic.as_str()), Some("orders"));
                assert_eq!(flat.first().map(|row| row.partition), Some(0));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "flattening reassignment results held the caller for {elapsed:?}"
        );
        let mut noted = ReassignmentPartitionResult::error(1, 3);
        noted.error_message = Some("busy".to_string());
        let small = [
            ReassignmentTopicResult::new(
                "orders",
                vec![ReassignmentPartitionResult::error(0, 0), noted],
            ),
            ReassignmentTopicResult::new(
                "payments",
                vec![ReassignmentPartitionResult::error(7, 0)],
            ),
        ];
        let flat = flatten_reassignment_results(&small).await;
        assert_eq!(flat.len(), 3);
        assert_eq!(flat[0].topic, "orders");
        assert_eq!(flat[0].partition, 0);
        assert_eq!(flat[0].error_code, 0);
        assert_eq!(flat[0].error_message, None);
        assert_eq!(flat[1].topic, "orders");
        assert_eq!(flat[1].error_code, 3);
        assert_eq!(flat[1].error_message.as_deref(), Some("busy"));
        assert_eq!(flat[2].topic, "payments");
        assert_eq!(flat[2].partition, 7);
        assert_eq!(
            small[0].partitions[1].error_message.as_deref(),
            Some("busy")
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn grouping_many_list_reassignments_does_not_hold_the_caller() {
        // 2_000_000 partitions: grouping them held the caller 339ms.
        let topic = crate::TopicPartition::new("orders", 0);
        let partitions: Vec<crate::TopicPartition> = (0..2_000_000)
            .map(|index| crate::TopicPartition::new(topic.topic.as_str(), index))
            .collect();
        let started = std::time::Instant::now();
        tokio::select! {
            topics = group_list_reassignments(&partitions) => {
                assert_eq!(topics.first().map(|(_, parts)| parts.len()), Some(2_000_000));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "grouping list reassignments held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn offset_delete_named_topics_keeps_duplicate_partitions() {
        let partitions = [
            ("orders".to_string(), 0),
            ("orders".to_string(), 0),
            ("orders".to_string(), 1),
        ];
        let topics = offset_delete_named_topics(&partitions).await;
        assert_eq!(topics.len(), 1);
        assert_eq!(topics[0].0, "orders");
        assert_eq!(topics[0].1, vec![0, 0, 1]);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn matching_many_described_producers_does_not_hold_the_caller() {
        // 2_000_000 partitions: taking each producer result held the caller 1.27s.
        let partitions: Vec<DescribeProducersPartition> = (0..2_000_000)
            .map(|index| DescribeProducersPartition::error(index, 0))
            .collect();
        let topics = vec![DescribeProducersTopic::new("orders", partitions)];
        let mut indexed = index_described_producers(topics).await;
        let order: Vec<(usize, &str, i32)> = (0..2_000_000i32)
            .map(|index| (index as usize, "orders", index))
            .collect();
        let started = std::time::Instant::now();
        tokio::select! {
            popped = pop_described_producers(&mut indexed, &order) => {
                assert_eq!(popped.len(), 2_000_000);
                assert_eq!(popped.first().and_then(|part| part.as_ref()).map(|part| part.partition_index), Some(0));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "matching described producers held the caller for {elapsed:?}"
        );
        let repeated = vec![DescribeProducersTopic::new(
            "orders",
            vec![DescribeProducersPartition::error(0, 3)],
        )];
        let mut indexed = index_described_producers(repeated).await;
        let order = [(0usize, "orders", 0), (1, "orders", 0), (2, "missing", 1)];
        let popped = pop_described_producers(&mut indexed, &order).await;
        assert_eq!(popped[0].as_ref().map(|part| part.error_code), Some(3));
        assert!(popped[1].is_none());
        assert!(popped[2].is_none());
    }

    #[tokio::test(flavor = "current_thread")]
    async fn indexing_many_described_producers_does_not_hold_the_caller() {
        // 2_000_000 partitions: recording each producer result held the caller 1.37s.
        let partitions: Vec<DescribeProducersPartition> = (0..2_000_000)
            .map(|index| DescribeProducersPartition::error(index, 0))
            .collect();
        let topics = vec![DescribeProducersTopic::new("orders", partitions)];
        let started = std::time::Instant::now();
        tokio::select! {
            indexed = index_described_producers(topics) => {
                assert_eq!(indexed.get("orders").map(std::collections::HashMap::len), Some(2_000_000));
                assert_eq!(indexed.get("orders").and_then(|parts| parts.get(&0)).map(|part| part.partition_index), Some(0));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "indexing described producers held the caller for {elapsed:?}"
        );
        let repeated = vec![
            DescribeProducersTopic::new(
                "orders",
                vec![
                    DescribeProducersPartition::error(0, 1),
                    DescribeProducersPartition::error(0, 3),
                ],
            ),
            DescribeProducersTopic::new("payments", vec![DescribeProducersPartition::error(4, 0)]),
        ];
        let indexed = index_described_producers(repeated).await;
        assert_eq!(
            indexed
                .get("orders")
                .and_then(|parts| parts.get(&0))
                .map(|part| part.error_code),
            Some(3)
        );
        assert_eq!(
            indexed
                .get("payments")
                .and_then(|parts| parts.get(&4))
                .map(|part| part.partition_index),
            Some(4)
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn grouping_many_describe_producers_does_not_hold_the_caller() {
        // 2_000_000 partitions: grouping them held the caller 354ms.
        let topic = crate::TopicPartition::new("orders", 0);
        let partitions: Vec<crate::TopicPartition> = (0..2_000_000)
            .map(|index| crate::TopicPartition::new(topic.topic.as_str(), index))
            .collect();
        let idxs: Vec<usize> = (0..partitions.len()).collect();
        let started = std::time::Instant::now();
        tokio::select! {
            topics = describe_producers_topics(&partitions, &idxs) => {
                assert_eq!(topics.first().map(|(_, parts)| parts.len()), Some(2_000_000));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "grouping describe producers held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn describe_producers_topics_keeps_duplicate_partitions() {
        let partitions = [
            crate::TopicPartition::new("t", 0),
            crate::TopicPartition::new("t", 0),
            crate::TopicPartition::new("t", 1),
        ];
        let topics = describe_producers_topics(&partitions, &[0, 1, 2]).await;
        assert_eq!(topics.len(), 1);
        assert_eq!(topics[0].0, "t");
        assert_eq!(topics[0].1, vec![0, 0, 1]);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn indexing_many_listed_offsets_does_not_hold_the_caller() {
        // 2_000_000 partitions: recording each offset held the caller 1.70s.
        let partitions: Vec<ListOffsetsResponsePartition> = (0..2_000_000)
            .map(|index| ListOffsetsResponsePartition::error(index, 0))
            .collect();
        let topics = vec![crate::protocol::offsets::ListOffsetsTopicResponse::new(
            "orders", partitions,
        )];
        let started = std::time::Instant::now();
        tokio::select! {
            indexed = index_listed_offsets(topics) => {
                assert_eq!(indexed.get("orders").map(std::collections::HashMap::len), Some(2_000_000));
                assert_eq!(
                    indexed.get("orders").and_then(|parts| parts.get(&0)).and_then(VecDeque::front).map(|part| part.partition_index),
                    Some(0)
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "indexing listed offsets held the caller for {elapsed:?}"
        );
        let repeated = vec![crate::protocol::offsets::ListOffsetsTopicResponse::new(
            "orders",
            vec![
                ListOffsetsResponsePartition {
                    partition_index: 0,
                    error_code: 0,
                    timestamp: 10,
                    offset: 4,
                    leader_epoch: 1,
                },
                ListOffsetsResponsePartition {
                    partition_index: 0,
                    error_code: 3,
                    timestamp: 20,
                    offset: 9,
                    leader_epoch: 2,
                },
            ],
        )];
        let indexed = index_listed_offsets(repeated).await;
        let queued = indexed
            .get("orders")
            .and_then(|parts| parts.get(&0))
            .map(|queue| {
                queue
                    .iter()
                    .map(|part| (part.offset, part.error_code))
                    .collect::<Vec<_>>()
            });
        assert_eq!(queued, Some(vec![(4, 0), (9, 3)]));
    }

    #[tokio::test(flavor = "current_thread")]
    async fn matching_many_listed_offsets_does_not_hold_the_caller() {
        // 2_000_000 partitions: taking each listed offset held the caller 1.09s.
        let partitions: Vec<ListOffsetsResponsePartition> = (0..2_000_000)
            .map(|index| ListOffsetsResponsePartition::error(index, 0))
            .collect();
        let topics = vec![crate::protocol::offsets::ListOffsetsTopicResponse::new(
            "orders", partitions,
        )];
        let mut indexed = index_listed_offsets(topics).await;
        let order: Vec<(usize, &str, i32)> = (0..2_000_000i32)
            .map(|index| (index as usize, "orders", index))
            .collect();
        let started = std::time::Instant::now();
        tokio::select! {
            popped = pop_listed_offsets(&mut indexed, &order) => {
                assert_eq!(popped.len(), 2_000_000);
                assert_eq!(popped.first().and_then(|part| part.as_ref()).map(|part| part.partition_index), Some(0));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "matching listed offsets held the caller for {elapsed:?}"
        );
        let repeated = vec![crate::protocol::offsets::ListOffsetsTopicResponse::new(
            "orders",
            vec![
                ListOffsetsResponsePartition {
                    partition_index: 0,
                    error_code: 0,
                    timestamp: 10,
                    offset: 4,
                    leader_epoch: 1,
                },
                ListOffsetsResponsePartition {
                    partition_index: 0,
                    error_code: 3,
                    timestamp: 20,
                    offset: 9,
                    leader_epoch: 2,
                },
            ],
        )];
        let mut indexed = index_listed_offsets(repeated).await;
        let order = [(0usize, "orders", 0), (1, "orders", 0), (2, "missing", 1)];
        let popped = pop_listed_offsets(&mut indexed, &order).await;
        assert_eq!(popped[0].as_ref().map(|part| part.offset), Some(4));
        assert_eq!(
            popped[1]
                .as_ref()
                .map(|part| (part.offset, part.error_code)),
            Some((9, 3))
        );
        assert!(popped[2].is_none());
    }

    #[tokio::test(flavor = "current_thread")]
    async fn matching_many_deleted_records_does_not_hold_the_caller() {
        // 2_000_000 partitions: taking each deleted-record result held the caller 1.06s.
        let partitions: Vec<crate::protocol::admin::DeletedRecordsPartition> = (0..2_000_000)
            .map(|index| crate::protocol::admin::DeletedRecordsPartition {
                partition: index,
                low_watermark: 1,
                error_code: 0,
            })
            .collect();
        let topics = vec![crate::protocol::admin::DeletedRecordsTopic {
            topic: "orders".to_string(),
            partitions,
        }];
        let mut indexed = index_deleted_records(topics).await;
        let order: Vec<(usize, &str, i32)> = (0..2_000_000i32)
            .map(|index| (index as usize, "orders", index))
            .collect();
        let started = std::time::Instant::now();
        tokio::select! {
            popped = pop_deleted_records(&mut indexed, &order) => {
                assert_eq!(popped.len(), 2_000_000);
                assert_eq!(popped.first().copied().flatten(), Some((1, 0)));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "matching deleted records held the caller for {elapsed:?}"
        );
        let repeated = vec![crate::protocol::admin::DeletedRecordsTopic {
            topic: "orders".to_string(),
            partitions: vec![
                crate::protocol::admin::DeletedRecordsPartition {
                    partition: 0,
                    low_watermark: 10,
                    error_code: 0,
                },
                crate::protocol::admin::DeletedRecordsPartition {
                    partition: 0,
                    low_watermark: 20,
                    error_code: 3,
                },
            ],
        }];
        let mut indexed = index_deleted_records(repeated).await;
        let order = [(0usize, "orders", 0), (1, "orders", 0), (2, "missing", 1)];
        let popped = pop_deleted_records(&mut indexed, &order).await;
        assert_eq!(popped[0], Some((10, 0)));
        assert_eq!(popped[1], Some((20, 3)));
        assert_eq!(popped[2], None);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn indexing_many_deleted_records_does_not_hold_the_caller() {
        // 2_000_000 partitions: recording each low watermark held the caller 1.58s.
        let partitions: Vec<crate::protocol::admin::DeletedRecordsPartition> = (0..2_000_000)
            .map(|index| crate::protocol::admin::DeletedRecordsPartition {
                partition: index,
                low_watermark: 1,
                error_code: 0,
            })
            .collect();
        let topics = vec![crate::protocol::admin::DeletedRecordsTopic {
            topic: "orders".to_string(),
            partitions,
        }];
        let started = std::time::Instant::now();
        tokio::select! {
            indexed = index_deleted_records(topics) => {
                assert_eq!(indexed.get("orders").map(std::collections::HashMap::len), Some(2_000_000));
                assert_eq!(
                    indexed.get("orders").and_then(|parts| parts.get(&0)).and_then(VecDeque::front).copied(),
                    Some((1, 0))
                );
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "indexing deleted records held the caller for {elapsed:?}"
        );
        let repeated = vec![crate::protocol::admin::DeletedRecordsTopic {
            topic: "orders".to_string(),
            partitions: vec![
                crate::protocol::admin::DeletedRecordsPartition {
                    partition: 0,
                    low_watermark: 10,
                    error_code: 0,
                },
                crate::protocol::admin::DeletedRecordsPartition {
                    partition: 0,
                    low_watermark: 20,
                    error_code: 3,
                },
            ],
        }];
        let indexed = index_deleted_records(repeated).await;
        let queued = indexed
            .get("orders")
            .and_then(|parts| parts.get(&0))
            .map(|queue| queue.iter().copied().collect::<Vec<_>>());
        assert_eq!(queued, Some(vec![(10, 0), (20, 3)]));
    }

    #[tokio::test(flavor = "current_thread")]
    async fn grouping_many_delete_records_does_not_hold_the_caller() {
        // 2_000_000 partitions: grouping them held the caller 362ms.
        let topic = crate::TopicPartition::new("orders", 0);
        let records: Vec<(crate::TopicPartition, i64)> = (0..2_000_000)
            .map(|index| (crate::TopicPartition::new(topic.topic.as_str(), index), 1))
            .collect();
        let idxs: Vec<usize> = (0..records.len()).collect();
        let started = std::time::Instant::now();
        tokio::select! {
            topics = delete_records_topics(&records, &idxs) => {
                assert_eq!(topics.first().map(|(_, parts)| parts.len()), Some(2_000_000));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "grouping delete records held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn decoding_many_offset_deletes_does_not_hold_the_caller() {
        use crate::protocol::group::{
            decode_offset_delete_response, decode_offset_delete_response_cooperative,
            encode_offset_delete_response, OffsetDeleteResult,
        };
        use bytes::BufMut;
        // 2_000_000 partitions: copying the topic name for each held the caller 300ms.
        let partitions = 2_000_000i32;
        let mut body = bytes::BytesMut::new();
        body.put_i16(0);
        body.put_i32(0);
        body.put_i32(1);
        body.put_i16(6);
        body.extend_from_slice(b"orders");
        body.put_i32(partitions);
        for index in 0..partitions {
            body.put_i32(index);
            body.put_i16(0);
        }
        let started = std::time::Instant::now();
        tokio::select! {
            decoded = decode_offset_delete_response_cooperative(&mut body) => {
                let (_top, results, _throttle) = decoded.unwrap_or_else(|error| panic!("{error}"));
                assert_eq!(results.len(), partitions as usize);
                assert_eq!(results.first().map(|result| result.topic.as_str()), Some("orders"));
                assert_eq!(results.first().map(|result| result.partition), Some(0));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "decoding offset deletes held the caller for {elapsed:?}"
        );
        let small = [
            OffsetDeleteResult::new("orders", 0, 0),
            OffsetDeleteResult::new("orders", 1, 3),
            OffsetDeleteResult::new("payments", 4, 0),
        ];
        let mut encoded = bytes::BytesMut::new();
        encode_offset_delete_response(&mut encoded, 0, &small)
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = encoded.clone();
        let mut paced = encoded;
        let sync =
            decode_offset_delete_response(&mut once).unwrap_or_else(|error| panic!("{error}"));
        let coop = decode_offset_delete_response_cooperative(&mut paced)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(sync, coop);
        assert_eq!(coop.1[0].topic, "orders");
        assert_eq!(coop.1[1].topic, "orders");
        assert_eq!(coop.1[1].error_code, 3);
        assert_eq!(coop.1[2].topic, "payments");
    }

    #[tokio::test(flavor = "current_thread")]
    async fn encoding_many_delete_records_does_not_hold_the_caller() {
        // 2_000_000 partitions: encoding them in one pass held the caller 275ms.
        use crate::protocol::admin::{
            encode_delete_records_named_topics, encode_delete_records_named_topics_cooperative,
            DeleteRecordsPartition,
        };
        let partitions: Vec<DeleteRecordsPartition> = (0..2_000_000)
            .map(|index| DeleteRecordsPartition {
                partition: index,
                offset: 1,
            })
            .collect();
        let topics = [("orders", partitions)];
        let mut buf = bytes::BytesMut::new();
        let started = std::time::Instant::now();
        tokio::select! {
            result = encode_delete_records_named_topics_cooperative(&mut buf, 2, &topics, 1_000) => {
                result.unwrap_or_else(|error| panic!("{error}"));
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "encoding delete records held the caller for {elapsed:?}"
        );
        let small = [(
            "orders",
            vec![
                DeleteRecordsPartition {
                    partition: 0,
                    offset: 4,
                },
                DeleteRecordsPartition {
                    partition: 1,
                    offset: 9,
                },
            ],
        )];
        let mut paced = bytes::BytesMut::new();
        encode_delete_records_named_topics_cooperative(&mut paced, 2, &small, 1_000)
            .await
            .unwrap_or_else(|error| panic!("{error}"));
        let mut once = bytes::BytesMut::new();
        encode_delete_records_named_topics(&mut once, 2, &small, 1_000)
            .unwrap_or_else(|error| panic!("{error}"));
        assert_eq!(paced, once);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn delete_records_topics_keeps_duplicate_partitions() {
        let records = [
            (crate::TopicPartition::new("t", 0), 10),
            (crate::TopicPartition::new("t", 0), 20),
            (crate::TopicPartition::new("t", 1), 30),
        ];
        let topics = delete_records_topics(&records, &[0, 1, 2]).await;
        assert_eq!(topics.len(), 1);
        assert_eq!(topics[0].0, "t");
        assert_eq!(topics[0].1.len(), 3);
        assert_eq!(topics[0].1[0].offset, 10);
        assert_eq!(topics[0].1[1].offset, 20);
        assert_eq!(topics[0].1[2].partition, 1);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn grouping_many_admin_list_offsets_does_not_hold_the_caller() {
        // 2_000_000 partitions: grouping the request held the caller 378ms.
        let queries: Vec<(crate::TopicPartition, i64)> = (0..2_000_000)
            .map(|index| (crate::TopicPartition::new("orders", index), -1))
            .collect();
        let indexes: Vec<usize> = (0..queries.len()).collect();
        let cluster = Cluster::default();
        let started = std::time::Instant::now();
        tokio::select! {
            _ = list_offset_topic_requests(&queries, &indexes, &cluster) => {}
            _ = tokio::time::sleep(std::time::Duration::from_millis(30)) => {}
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < std::time::Duration::from_millis(80),
            "grouping admin list offsets held the caller for {elapsed:?}"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn list_offset_topic_requests_keeps_duplicate_partitions() {
        let cluster = Cluster::default();
        let queries = [
            (
                crate::TopicPartition::new("t", 0),
                crate::EARLIEST_TIMESTAMP,
            ),
            (crate::TopicPartition::new("t", 0), crate::LATEST_TIMESTAMP),
            (crate::TopicPartition::new("t", 1), crate::LATEST_TIMESTAMP),
        ];
        let topics = list_offset_topic_requests(&queries, &[0, 1, 2], &cluster).await;
        assert_eq!(topics.len(), 1);
        assert_eq!(topics[0].0, "t");
        assert_eq!(topics[0].1.len(), 3);
        assert_eq!(topics[0].1[0].timestamp, crate::EARLIEST_TIMESTAMP);
        assert_eq!(topics[0].1[1].timestamp, crate::LATEST_TIMESTAMP);
        assert_eq!(topics[0].1[2].partition, 1);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn a_finished_leader_rpc_is_kept_when_the_rest_abort() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let hold = tokio::spawn(async move {
            let accepted = listener.accept().await.unwrap();
            std::future::pending::<()>().await;
            drop(accepted);
        });
        let conn = BrokerConn::connect(&addr.to_string(), "admin-reap", Duration::from_secs(1))
            .await
            .unwrap();
        let versions = crate::protocol::api::ApiVersionsResponse {
            api_keys: vec![crate::protocol::api::ApiVersion {
                api_key: crate::protocol::api_keys::LIST_OFFSETS,
                min_version: 0,
                max_version: 10,
            }],
            ..Default::default()
        };
        let opened = AdminOffsetConn::new(conn, &versions);
        let mut rpcing = tokio::task::JoinSet::new();
        let _ = rpcing.spawn(async move { (4, 7i16, opened, Ok(Bytes::from_static(b"ok"))) });
        let _ = rpcing.spawn(async {
            std::future::pending::<(i32, i16, AdminOffsetConn, Result<Bytes>)>().await
        });
        let mut dialing = tokio::task::JoinSet::new();
        let mut held = HashMap::new();
        let mut finished = LeaderExchange::new();
        let mut waiting_rpc = VecDeque::new();
        let mut reconnect_fails = HashMap::new();
        for _ in 0..20 {
            Admin::reap_leader_exchange(
                &mut dialing,
                &mut rpcing,
                &mut held,
                &mut finished,
                &mut waiting_rpc,
                &mut reconnect_fails,
            );
            if finished.contains_key(&4) {
                break;
            }
            tokio::task::yield_now().await;
        }
        rpcing.abort_all();
        hold.abort();
        let kept = finished.get(&4).and_then(|(_, body)| body.as_ref().ok());
        assert_eq!(kept.map(bytes::Bytes::as_ref), Some(&b"ok"[..]));
        assert!(held.contains_key(&4));
        assert!(!finished.contains_key(&9));
    }
}
