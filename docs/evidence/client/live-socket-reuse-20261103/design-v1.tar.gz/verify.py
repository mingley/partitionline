#!/usr/bin/env python3
"""Verify pinned inputs and reproducible projections; no Rust build or tests."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def check_file(path: Path, expected: str) -> None:
    actual = digest(path)
    if actual != expected:
        raise SystemExit(f"SHA-256 mismatch for {path}: {actual} != {expected}")


def between(text: str, start: str, stop: str) -> str:
    a = text.index(start)
    b = text.index(stop, a + len(start))
    return text[a:b]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path,
                        help="reconstructed v16 source root; default uses paths in source-pins.json")
    parser.add_argument("--catalog", type=Path, help="v16 fixed-input catalog override")
    parser.add_argument("--log", type=Path, help="hosted job log override")
    parser.add_argument("--skip-reference-check", action="store_true",
                        help="skip separately scoped v10 and old-draft files if unavailable")
    args = parser.parse_args()
    pins = json.loads((HERE / "source-pins.json").read_text())
    catalog_pin = pins["v16_fixed_input_catalog"]
    catalog_path = args.catalog or Path(catalog_pin["path"])
    check_file(catalog_path, catalog_pin["sha256"])
    catalog = json.loads(catalog_path.read_text())
    paths = {}
    for key, pin in pins["v16_fixed_sources"].items():
        path = args.source_root / key if args.source_root else Path(pin["path"])
        check_file(path, pin["sha256"])
        if catalog.get(key) != pin["sha256"]:
            raise SystemExit(f"catalog mismatch for {key}")
        paths[key] = path
    log_pin = pins["v16_hosted_job_log"]
    log = args.log or Path(log_pin["path"])
    check_file(log, log_pin["sha256"])
    if not args.skip_reference_check:
        for pin in pins["separately_scoped_evidence"].values():
            check_file(Path(pin["path"]), pin["sha256"])

    producer = paths["src/producer.rs"].read_text()
    prepare = paths["src/producer/prepare.rs"].read_text()
    net = paths["src/net.rs"].read_text()
    fire = between(producer, "    async fn fire(&mut self)", "    async fn wait_one(&mut self)")
    assert fire.index("self.preparing.write_started = true;") < fire.index(".write_all_timeout(")
    assert fire.index(".write_all_timeout(") < fire.index("self.in_flight.push_back(InFlight")
    assert "self.conn.next_correlation()" in fire
    assert ".send_deadline(" not in fire
    assert ".is_session_expired(" not in fire and ".needs_reauth(" not in fire
    begin = between(prepare, "    pub(super) fn begin(", "    pub(super) fn records(")
    take = between(prepare, "    pub(super) fn take_groups(", "    #[cfg(test)]")
    assert "self.write_started = false;" in begin and "write_started" not in take
    send = between(net, "    pub async fn send_deadline(", "    pub async fn send(")
    assert "self.is_session_expired()" in send and "self.in_flight += 1;" in send
    assert send.index(".await?;") < send.index("self.in_flight += 1;")
    drop = between(net, "impl Drop for BrokerConn", "impl BrokerConn")
    assert "self.idle_watch.abort();" in drop and ".await" not in drop
    queued = between(net, "    pub(crate) fn has_queued_response(", "    /// Mark this connection")
    assert "self.read_buf" in queued and "self.prefetch" in queued

    with tempfile.TemporaryDirectory(prefix="socket-design-verify-") as temporary:
        out = Path(temporary) / "projection.json"
        subprocess.run([sys.executable, str(HERE / "extract_projection.py"), str(log), str(out)], check=True)
        if out.read_bytes() != (HERE / "v16-mock-projection.json").read_bytes():
            raise SystemExit("visible projection differs from pinned extraction")
        model = subprocess.run([sys.executable, str(HERE / "model.py")], check=True,
                               stdout=subprocess.PIPE, text=True)
        outcome = json.loads(model.stdout)
        assert outcome["cases"]["partial_real_write_model"]["naive_guard"]
        assert outcome["cases"]["full_write_response_outstanding_model"]["naive_guard"]
    print(json.dumps({
        "result": "pass",
        "checks": ["catalog and source digests", "source patterns and order", "v16 visible diagnostic projection", "illustrative counter model"],
        "reference_files": "skipped" if args.skip_reference_check else "digest checked",
        "limitations": "No Rust compile, runtime, production, auth, transport, lifecycle or performance test was run. Source-pattern checks are not proof of behavior."
    }, indent=2))


if __name__ == "__main__":
    main()
