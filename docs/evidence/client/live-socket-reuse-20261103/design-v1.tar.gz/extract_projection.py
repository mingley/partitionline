#!/usr/bin/env python3
"""Project visible mock diagnostics from the hash-pinned v16 hosted job log."""
import gzip
import hashlib
import json
import sys
from pathlib import Path

EXPECTED = "9d1c4c7be7b99a787d5be57df32025efb04136f2452fe0d33c71991ea74acd88"
PROFILES = ("default-mock_produce", "all-features-mock_produce")


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: extract_projection.py <job.log.gz> <output.json>")
    source, output = map(Path, sys.argv[1:])
    if hashlib.sha256(source.read_bytes()).hexdigest() != EXPECTED:
        raise SystemExit("hosted log SHA-256 mismatch")
    if output.exists():
        raise SystemExit("refusing to overwrite output")
    data = {p: {"summary": None, "tests": {}} for p in PROFILES}
    profile = None
    test = None
    with gzip.open(source, "rt", encoding="utf-8") as stream:
        for raw in stream:
            line = raw.rstrip("\n")
            if " {\"name\": " in line:
                try:
                    parsed = json.loads(line.split(" ", 1)[1])
                except (ValueError, IndexError):
                    parsed = {}
                if parsed.get("name") in PROFILES:
                    p = parsed["name"]
                    if data[p]["summary"] is not None:
                        raise SystemExit(f"duplicate summary: {p}")
                    data[p]["summary"] = parsed
            if "candidate-diagnostic | " not in line:
                continue
            payload = line.split("candidate-diagnostic | ", 1)[1]
            if payload.endswith(": failed-test diagnostics"):
                candidate = payload.removesuffix(": failed-test diagnostics")
                profile = candidate if candidate in data else None
                test = None
            elif profile and payload == profile + ": qualification gate failed":
                profile = None
                test = None
            elif profile and payload.startswith("test: "):
                test = payload.removeprefix("test: ")
                if test in data[profile]["tests"]:
                    raise SystemExit(f"duplicate test: {profile}/{test}")
                data[profile]["tests"][test] = []
            elif profile and test:
                data[profile]["tests"][test].append(payload)
    for p in PROFILES:
        summary = data[p]["summary"]
        if not summary or summary.get("projection") != "unverified; full receipt retained":
            raise SystemExit(f"missing or unexpectedly qualified summary: {p}")
        tests = data[p]["tests"]
        if len(tests) != 15 or set(tests) != set(summary["test_failures"]):
            raise SystemExit(f"diagnostic identities mismatch: {p}")
        if not all(any("panicked at " in x for x in rows) for rows in tests.values()):
            raise SystemExit(f"missing diagnostic panic location: {p}")
    if set(data[PROFILES[0]]["tests"]) != set(data[PROFILES[1]]["tests"]):
        raise SystemExit("profile failure identities differ")
    result = {"input_sha256": EXPECTED, "scope": "visible job log projection only; full artifact not independently verified", "profiles": data}
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
