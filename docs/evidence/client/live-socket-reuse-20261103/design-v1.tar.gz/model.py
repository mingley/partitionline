#!/usr/bin/env python3
"""Illustrate two v16 source-derived states, not a running Rust implementation."""
from dataclasses import dataclass, replace
import json


@dataclass(frozen=True)
class State:
    conn_in_flight: int = 0
    worker_in_flight: int = 0
    write_started: bool = False
    queued_response: bool = False
    owner_quiesced: bool = False
    active_response_decode: bool = False
    session_eligible: bool = True


def naive(s: State) -> bool:
    # This deliberately unsound guard is the negative control.
    return s.conn_in_flight == 0 and not s.queued_response


def main() -> None:
    idle = State(owner_quiesced=True)
    partial = replace(idle, owner_quiesced=False, write_started=True)
    full_waiting = replace(partial, worker_in_flight=1)
    decoding = replace(full_waiting, worker_in_flight=0, active_response_decode=True)
    # The exercise assumes a silent peer, so no user-space bytes were buffered.
    # Real Rust state is not instantiated and the peer may behave differently.
    cases = {"idle": idle, "partial_real_write_model": partial,
             "full_write_response_outstanding_model": full_waiting,
             "response_decode_active_model": decoding}
    assert naive(idle)
    for name in ("partial_real_write_model", "full_write_response_outstanding_model",
                 "response_decode_active_model"):
        assert naive(cases[name]), name
    print(json.dumps({
        "scope": "source-derived illustration only; not an implementation test or proof",
        "cases": {name: {"naive_guard": naive(s), "owner_quiesced": s.owner_quiesced}
                  for name, s in cases.items()},
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
