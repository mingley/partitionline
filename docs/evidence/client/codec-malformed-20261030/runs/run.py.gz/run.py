import hashlib
import json
import os
import pathlib
import re
import shutil
import signal
import subprocess
import sys
import time

ROOT = pathlib.Path('/workspace/work/codec-errors-candidate')
OUT = pathlib.Path('/workspace/work/codec-validation-20261030')
FLOOR = 2 * 1024 ** 3
ENV = os.environ.copy()
ENV.update({
    'RUSTUP_HOME': '/workspace/work/rustup',
    'CARGO_HOME': '/workspace/work/cargo',
    'PATH': '/workspace/work/cargo/bin:' + ENV.get('PATH', ''),
    'CARGO_TARGET_DIR': '/workspace/work/qualification-20261027/broker-check-target',
    'CARGO_BUILD_JOBS': '2', 'CARGO_INCREMENTAL': '0',
    'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
})
for name in ('RUST_TEST_THREADS', 'RUST_MIN_STACK', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'):
    ENV.pop(name, None)
ROWS = []

def digest(path):
    with pathlib.Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def manifest():
    r = subprocess.run(['rg', '--files', '--hidden', '-0', '-g', '!/.git', '-g', '!/target/**', '-g', '!/docs/**'], cwd=ROOT, check=True, capture_output=True)
    return {p: digest(ROOT / p) for p in sorted(os.fsdecode(p) for p in r.stdout.split(b'\0') if p)}

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def memory_events():
    path = pathlib.Path('/sys/fs/cgroup/memory.events')
    return path.read_text() if path.exists() else None

def run(name, args, timeout=300, stderr=None):
    if shutil.disk_usage(ROOT).free <= FLOOR:
        raise RuntimeError('disk reserve not available before ' + name)
    row = {'name': name, 'argv': args, 'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'timeout_seconds': timeout, 'disk_stop_bytes': FLOOR, 'memory_events_before': memory_events()}
    started = time.monotonic()
    with (OUT / (name + '.log')).open('wb') as log:
        error = (OUT / stderr).open('wb') if stderr else None
        try:
            proc = subprocess.Popen(args, cwd=ROOT, env=ENV, stdout=log, stderr=error or subprocess.STDOUT, start_new_session=True)
            minimum = shutil.disk_usage(ROOT).free
            samples = []
            reason = None
            while proc.poll() is None:
                free = shutil.disk_usage(ROOT).free
                minimum = min(minimum, free)
                samples.append({'seconds': round(time.monotonic() - started, 3), 'free_bytes': free})
                if free < FLOOR or time.monotonic() - started >= timeout:
                    reason = 'disk_floor' if free < FLOOR else 'timeout'
                    row['processes_before_stop'] = subprocess.run(['ps', '-eo', 'pid,ppid,pgid,stat,args'], capture_output=True, text=True).stdout
                    os.killpg(proc.pid, signal.SIGTERM)
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(proc.pid, signal.SIGKILL)
                        proc.wait()
                    break
                time.sleep(0.25)
            row.update({'exit': proc.wait(), 'stop_reason': reason, 'minimum_disk_free_bytes': minimum, 'disk_samples': samples})
        finally:
            if error:
                error.close()
    row.update({'elapsed_seconds': round(time.monotonic() - started, 3), 'log_sha256': digest(OUT / (name + '.log')), 'memory_events_after': memory_events()})
    save(name + '.json', row)
    ROWS.append(row)
    print(name, 'exit', row['exit'], 'stop', row['stop_reason'], flush=True)
    if row['stop_reason']:
        raise RuntimeError(name + ' incomplete: ' + row['stop_reason'])
    return row

def build(name, all_features=False, library=True):
    for group in ('src', 'tests', 'examples'):
        for path in (ROOT / group).rglob('*.rs'):
            path.touch()
    args = ['cargo', '+stable', 'test', '--locked', '--no-run', '--message-format=json-render-diagnostics']
    if library:
        args += ['--lib']
    for target in ('codec_malformed_java', 'codec_matrix', 'codec_sparse'):
        args += ['--test', target]
    if all_features:
        args += ['--all-features']
    row = run(name, args, stderr=name + '.stderr.log')
    if row['exit']:
        raise RuntimeError('build failed: ' + name)
    artifacts = {}
    for line in (OUT / (name + '.log')).read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get('reason') == 'compiler-artifact' and event.get('executable') and event.get('profile', {}).get('test'):
            target = event.get('target', {}).get('name')
            if target not in ('partitionline', 'codec_malformed_java', 'codec_matrix', 'codec_sparse'):
                continue
            if event.get('fresh'):
                raise RuntimeError('stale build artifact: ' + target)
            source = pathlib.Path(event['executable'])
            retained = OUT / (name + '-' + target + '.elf')
            if shutil.disk_usage(ROOT).free - source.stat().st_size < FLOOR:
                raise RuntimeError('insufficient disk to retain executable: ' + target)
            shutil.copyfile(source, retained)
            retained.chmod(0o700)
            if digest(source) != digest(retained):
                raise RuntimeError('artifact copy changed bytes: ' + target)
            artifacts[target] = {'source': str(source), 'saved': str(retained), 'sha256': digest(retained), 'bytes': retained.stat().st_size, 'fresh': False, 'package_id': event.get('package_id')}
    required = {'codec_malformed_java', 'codec_matrix', 'codec_sparse'} | ({'partitionline'} if library else set())
    if set(artifacts) != required:
        raise RuntimeError('missing executables: ' + str(required - set(artifacts)))
    save(name + '-artifacts.json', artifacts)
    return artifacts

def exact(name, artifact, test):
    row = run(name, [artifact['saved'], '--exact', test, '--test-threads=1'])
    data = (OUT / (name + '.log')).read_text()
    row['exactly_one_selected'] = bool(re.search(r'test result: (?:ok|FAILED)\. \d+ passed; \d+ failed; \d+ ignored; \d+ measured; \d+ filtered out;', data)) and 'running 1 test' in data
    row['expected_test'] = test
    save(name + '.json', row)
    if not row['exactly_one_selected']:
        raise RuntimeError('zero/multiple test selection: ' + name)

try:
    run('format-initial', ['rustfmt', '+stable', '--check', '--edition', '2021', 'src/protocol/records.rs', 'tests/codec_malformed_java.rs'])
    run('format-apply', ['rustfmt', '+stable', '--edition', '2021', 'src/protocol/records.rs', 'tests/codec_malformed_java.rs'])
    run('format-final', ['rustfmt', '+stable', '--check', '--edition', '2021', 'src/protocol/records.rs', 'tests/codec_malformed_java.rs'])
    before = manifest()
    save('inputs-before.json', before)
    run('rustc', ['rustc', '+stable', '-Vv'])
    run('cargo', ['cargo', '+stable', '-V'])
    run('git-head', ['git', 'rev-parse', 'HEAD'])
    run('git-status', ['git', 'status', '--short'])
    run('candidate', ['git', 'diff', 'HEAD', '--binary'])
    default = build('default-build')
    tests = [
        'decode_record_invalid_headers_match_java',
        'decode_record_batch_count_checks_match_java',
        'malformed_first_record_precedes_batch_count_eof',
        'impossible_count_does_not_reserve_for_absent_records',
        'large_valid_record_count_decodes_with_bounded_growth',
        'crc_valid_inflated_counts_obey_the_shared_metadata_budget',
        'tiny_limits_and_reused_capacity_are_accounted_without_losing_valid_records',
        'header_metadata_is_aggregated_across_records_and_batches',
        'excess_allocator_capacity_preserves_vector_and_budget',
        'slot_list_hints_and_growth_obey_the_shared_budget',
        'cooperative_compressed_decode_matches_one_shot',
        'decode_record_batch_from_bytes_shares_value',
    ]
    for i, test in enumerate(tests, 1):
        exact('default-unit-%02d' % i, default['partitionline'], 'protocol::records::tests::' + test)
    for target in ('codec_malformed_java', 'codec_matrix', 'codec_sparse'):
        run('default-' + target, [default[target]['saved'], '--test-threads=1'])
    all_features = build('all-features-build', all_features=True, library=False)
    for target in ('codec_malformed_java', 'codec_matrix', 'codec_sparse'):
        run('all-features-' + target, [all_features[target]['saved'], '--test-threads=1'])
    run('strict-clippy', ['cargo', '+stable', 'clippy', '--locked', '--all-features', '--lib', '--test', 'codec_malformed_java', '--test', 'codec_matrix', '--test', 'codec_sparse', '--', '-D', 'warnings'])
    after = manifest()
    save('inputs-after.json', after)
    save('summary.json', {'source_scope': 'visible rg files excluding .git, docs and target; dependencies/toolchain bytes and ignored files are not pinned', 'inputs_stable': before == after, 'results': ROWS})
    if before != after or any(row['exit'] != 0 for row in ROWS if row['name'] != 'format-initial'):
        sys.exit(1)
except Exception as error:
    save('failure.json', {'error': str(error), 'results': ROWS, 'inputs_after': manifest()})
    print(str(error), flush=True)
    sys.exit(1)
