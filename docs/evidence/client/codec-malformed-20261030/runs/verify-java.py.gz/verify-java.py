import hashlib
import json
import pathlib
import subprocess
import time

ROOT = pathlib.Path('/workspace/work/codec-errors-candidate')
OUT = pathlib.Path('/workspace/work/codec-validation-20261030')
JAR = pathlib.Path('/workspace/work/goal-qualification-20261028/narrow-profile/java/kafka-clients-4.3.1.jar')
SLF4J = JAR.parent / 'slf4j-api-1.7.36.jar'
JAVA = pathlib.Path('/usr/lib/jvm/java-21-openjdk-amd64/bin/java')
MODULES = JAVA.parent.parent / 'lib/modules'
SOURCE = ROOT / 'tests/conformance/java/MalformedRecordOracle.java'

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

files = [JAR, SLF4J, JAVA, MODULES, SOURCE]
before = {str(p): sha(p) for p in files}
if before[str(JAR)] != '52501b7b47510c66f898871adaf6d2968ab7246561d44ced43643a8a587f0b36':
    raise RuntimeError('unexpected Kafka Java jar')
output = OUT / 'java-generated'
argv = [str(JAVA), '--class-path', str(JAR) + ':' + str(SLF4J), str(SOURCE), str(output)]
started = time.monotonic()
with (OUT / 'java-oracle.log').open('wb') as log:
    result = subprocess.run(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=60)
after = {str(p): sha(p) for p in files}
fixtures = json.loads((ROOT / 'tests/fixtures/codec-malformed/manifest.json').read_text())
generated = {name: sha(output / name) for name in fixtures['files']}
original = {name: sha(ROOT / 'tests/fixtures/codec-malformed' / name) for name in fixtures['files']}
receipt = {'argv': argv, 'exit': result.returncode, 'elapsed_seconds': time.monotonic() - started, 'inputs_before': before, 'inputs_after': after, 'inputs_stable': before == after, 'generated': generated, 'checked_in': original, 'match_manifest': generated == original == fixtures['files'], 'log_sha256': sha(OUT / 'java-oracle.log')}
(OUT / 'java-oracle.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ('exit', 'inputs_stable', 'match_manifest')}))
if result.returncode or before != after or not receipt['match_manifest']:
    raise SystemExit(1)
