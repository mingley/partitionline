import hashlib, json, os, pathlib, shutil, signal, subprocess, sys, time
root=pathlib.Path('/workspace/work/client-fixtures-candidate')
out=pathlib.Path('/workspace/work/goal-qualification-20261028/client-fixtures-validation-01')
out.mkdir(mode=0o700, parents=True, exist_ok=False)
env=os.environ.copy()
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUST_TEST_THREADS','RUST_MIN_STACK']:
    env.pop(key,None)
env.update({'RUSTUP_HOME':'/workspace/work/rustup','CARGO_HOME':'/workspace/work/cargo','PATH':'/workspace/work/cargo/bin:'+env.get('PATH',''),'CARGO_TARGET_DIR':'/workspace/work/qualification-20261027/broker-check-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0'})

def command(args, name, timeout=600, stderr=None):
    print('running:', ' '.join(map(str,args)), flush=True)
    started=time.monotonic()
    with (out/name).open('wb') as log:
        err=(out/stderr).open('wb') if stderr else None
        try:
            p=subprocess.Popen(args,cwd=root,env=env,stdout=log,stderr=err or subprocess.STDOUT,start_new_session=True)
            stop=None
            while p.poll() is None:
                if time.monotonic()-started>timeout: stop='timeout'
                elif shutil.disk_usage(root).free<2*1024**3: stop='disk_floor'
                if stop:
                    os.killpg(p.pid,signal.SIGTERM)
                    try: p.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(p.pid,signal.SIGKILL);p.wait()
                    break
                time.sleep(1)
            code=p.returncode
        finally:
            if err: err.close()
    print('exit:',code,'stop:',stop,flush=True)
    return {'argv':args,'exit':code,'stop':stop,'elapsed_seconds':round(time.monotonic()-started,3),'log_sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()}

def manifest(filename):
    cmd="set -o pipefail; rg --files --hidden -0 -g '!/.git' -g '!/target/**' -g '!/docs/**' | sort -z | xargs -0 sha256sum"
    status=command(['bash','-c',cmd],filename)
    if status['exit']!=0: raise RuntimeError('manifest failed')

def memory():
    p=pathlib.Path('/sys/fs/cgroup/memory.events')
    return p.read_text() if p.exists() else None

if shutil.disk_usage(root).free<2.5*1024**3:
    raise RuntimeError('less than 2.5 GiB free before build; 2 GiB reserve required')
manifest('inputs-before.sha256')
for args,name in [(['git','rev-parse','HEAD'],'head.txt'),(['git','status','--short'],'status.txt'),(['git','diff','--binary'],'candidate.diff'),(['rustc','+stable','-Vv'],'rustc.txt'),(['cargo','+stable','-V'],'cargo.txt')]: command(args,name)
# The shared target may contain newer artifacts from another worktree. Touch the
# crate root and test inputs without changing bytes, then require Cargo to report
# a non-fresh test executable. Record its actual source path, hash and copy.
for p in ['src/lib.rs','tests/full_surface.rs','tests/common/mod.rs']: os.utime(root/p,None)
mem_before=memory()
results={}
results['build']=command(['cargo','+stable','test','--locked','--no-run','--test','full_surface','--message-format=json-render-diagnostics'],'build.jsonl',timeout=900,stderr='build.stderr.log')
if results['build']['exit']!=0 or results['build']['stop']:
    manifest('inputs-after.sha256');(out/'summary.json').write_text(json.dumps({'results':results,'memory_before':mem_before,'memory_after':memory()},indent=2)+'\n');sys.exit(1)
artifacts=[]
for line in (out/'build.jsonl').read_text().splitlines():
    try: row=json.loads(line)
    except json.JSONDecodeError: continue
    if row.get('reason')=='compiler-artifact' and row.get('target',{}).get('name')=='full_surface' and row.get('profile',{}).get('test') and row.get('executable'):
        artifacts.append(row)
if len(artifacts)!=1 or artifacts[0].get('fresh'):
    raise RuntimeError('expected one freshly built full_surface executable')
source=pathlib.Path(artifacts[0]['executable']); retained=out/'full_surface-candidate.elf'
shutil.copyfile(source,retained);retained.chmod(0o700)
digest=hashlib.sha256(retained.read_bytes()).hexdigest()
if digest!=hashlib.sha256(source.read_bytes()).hexdigest(): raise RuntimeError('executable hash mismatch')
(out/'executable.json').write_text(json.dumps({'source':str(source),'retained':str(retained),'sha256':digest,'artifact':artifacts[0]},indent=2)+'\n')
results['enumerate']=command([str(retained),'--list'],'test-list.log',timeout=120)
cases=['group_coord_reconnects_when_connection_idle','fetch_offset_out_of_range_jumps_to_log_start','describe_quorum_reconnect_renegotiates_and_deadline_is_total','add_raft_voter_lost_response_retries_without_masking_duplicate_outcome','add_raft_voter_invalid_input_and_unavailable_versions_send_nothing','remove_raft_voter_lost_response_preserves_not_found_as_ambiguous_error','remove_raft_voter_invalid_input_and_unavailable_versions_send_nothing']
listed=(out/'test-list.log').read_text()
results['targeted']=[]
for n,name in enumerate(cases,1):
    if f'{name}: test' not in listed: raise RuntimeError('missing exact test: '+name)
    result=command([str(retained),'--exact',name,'--test-threads=1'],f'test-{n:02}.log',timeout=120)
    result.update({'name':name,'exactly_one_pass':b'test result: ok. 1 passed;' in (out/f'test-{n:02}.log').read_bytes()})
    results['targeted'].append(result)
    if result['stop']: break
if all(not x['stop'] for x in results['targeted']):
    results['full_surface']=command([str(retained)],'full-surface.log',timeout=1200)
if not results.get('full_surface',{}).get('stop'):
    results['clippy']=command(['cargo','+stable','clippy','--locked','--all-features','--test','full_surface','--','-D','warnings'],'clippy.log',timeout=900)
manifest('inputs-after.sha256')
same=(out/'inputs-before.sha256').read_bytes()==(out/'inputs-after.sha256').read_bytes()
summary={'results':results,'same_visible_inputs':same,'memory_before':mem_before,'memory_after':memory(),'free_bytes':shutil.disk_usage(root).free,'scope':'sparse candidate visible inputs excluding docs/.git/target, external dependencies and operating system not exhaustively pinned; full_surface run uses default test threading'}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
if not same or any(not t['exactly_one_pass'] for t in results['targeted']) or len(results['targeted'])!=len(cases) or results.get('full_surface',{}).get('exit')!=0 or results.get('clippy',{}).get('exit')!=0:sys.exit(1)
