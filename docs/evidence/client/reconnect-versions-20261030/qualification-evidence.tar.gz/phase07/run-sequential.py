"""Run source-pinned reconnect checks with one executable retained at a time."""
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

OUT = Path(sys.argv[1]).resolve()
spec = importlib.util.spec_from_file_location('q', OUT / 'run.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
TARGETS = ['lookup_auth_version', 'live_bootstrap_rediscovery', 'heartbeat_load_reuse',
           'wire_trace_fixture', 'bootstrap_handshake', 'legacy_discovery_v0',
           'consumer_fetch_semantics']
OUTCOMES = {}
RETENTION = []

_ORIGINAL_RUN = q.run

def recorded_run(name, command, *args, **kwargs):
    # Only compilation may use the lower disk threshold authorized by the root.
    compile_only = command[:3] == ['cargo', '+stable', 'test'] and '--no-run' in command
    prior_floor = q.FLOOR
    q.FLOOR = 1536 * 1024**2
    actual_floor = q.FLOOR
    receipt_path = OUT/(name+'.json')
    assert not receipt_path.exists(), receipt_path
    try:
        receipt, text = _ORIGINAL_RUN(name, command, *args, **kwargs)
        receipt.update(disk_floor_bytes=actual_floor,
                       case_start_guard_bytes=actual_floor + 8*1024**2,
                       continuous_stop_bytes=actual_floor + 8*1024**2,
                       disk_sample_interval_seconds=0.25,
                       threshold_scope='sequential qualification; 1.5 GiB guard plus 8 MiB log buffer')
        (OUT/(name+'.json')).write_text(json.dumps(receipt, indent=2)+'\n')
        return receipt, text
    except Exception:
        if receipt_path.exists():
            receipt = json.loads(receipt_path.read_text())
            receipt.update(disk_floor_bytes=actual_floor,
                           case_start_guard_bytes=actual_floor + 8*1024**2,
                           continuous_stop_bytes=actual_floor + 8*1024**2,
                           disk_sample_interval_seconds=0.25,
                           threshold_scope='sequential qualification; 1.5 GiB guard plus 8 MiB log buffer')
            receipt_path.write_text(json.dumps(receipt, indent=2)+'\n')
        raise
    finally:
        q.FLOOR = prior_floor

q.run = recorded_run

def save_json(name, value):
    (OUT / (name + '.json')).write_text(json.dumps(value, indent=2) + '\n')

def build(name, lib=False):
    command = ['cargo', '+stable', 'test', '--locked', '--no-run',
               '--message-format=json-render-diagnostics']
    command += ['--lib'] if lib else ['--test', name]
    receipt, text = q.run('build-' + name, command, timeout=900)
    if receipt['exit']:
        raise RuntimeError('compilation failed: ' + name)
    artifacts = []
    for line in text.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if item.get('reason') == 'compiler-artifact' and item.get('executable'):
            if Path(item.get('manifest_path', '')).parent == q.ROOT:
                artifacts.append(item)
    matches = [x for x in artifacts if x['target']['name'] == ('partitionline' if lib else name)]
    if len(matches) != 1 or matches[0]['fresh']:
        raise RuntimeError('fresh candidate target not established: ' + name)
    artifact = matches[0]
    binary = Path(artifact['executable'])
    digest = q.sha(binary)
    save_json(name + '-executable', {'cargo_artifact': artifact, 'sha256': digest,
              'execution_path': str(binary), 'retention': 'gzip stream saved after tests; no second raw copy'})
    _, listing = q.run('list-' + name, [str(binary), '--list'])
    return binary, digest, listing

def retain(name, binary, digest):
    assert q.sha(binary) == digest
    used, inaccessible = [], []
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            if (proc/'exe').resolve() == binary:
                used.append(proc.name)
        except (OSError, PermissionError):
            inaccessible.append(proc.name)
    assert not used, used
    dest = OUT / (name + '.elf.gz')
    size = binary.stat().st_size
    with binary.open('rb') as source, dest.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as zipped:
            shutil.copyfileobj(source, zipped, 1024*1024)
        raw.flush()
        os.fsync(raw.fileno())
    h = hashlib.sha256(); reconstructed_size = 0
    with gzip.open(dest, 'rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk); reconstructed_size += len(chunk)
    assert h.hexdigest() == digest and reconstructed_size == size
    RETENTION.append({'historical_execution_path': str(binary), 'canonical_retained_path': str(dest),
        'uncompressed_sha256': digest, 'uncompressed_size': size,
        'compressed_sha256': q.sha(dest), 'compressed_size': dest.stat().st_size,
        'decompressed_hash_and_size_verified': True, 'accessible_proc_exe_users': used,
        'inaccessible_proc_entries': inaccessible,
        'regenerable_target_copy_removed_after_retention': True})
    save_json('executable-retention', RETENTION)
    assert q.sha(binary) == digest
    binary.unlink()

assert q.inputs() == q.EXPECTED
(OUT/'toolchain.txt').write_text(subprocess.check_output(['rustc', '-Vv'], env=q.ENV, text=True))
# Shared target roots can otherwise reuse a different worktree's newer executable.
for top in ['src', 'tests']:
    for path in (q.ROOT / top).rglob('*.rs'):
        os.utime(path, None)

binary, digest, listing = build('lib', lib=True)
names = [
    'group::offsets::tests::name_based_offsets_follow_both_bounds_of_the_new_socket',
    'group::offsets::tests::offset_downgrade_does_not_drop_identity_or_stability_fields',
    'group::offsets::tests::large_offset_reencode_yields_before_completion',
    'group::offsets::tests::typed_offset_reconnect_reencodes_for_both_new_range_bounds',
    'group::offsets::tests::typed_offset_reconnect_rejects_unrepresentable_fields_before_wire',
    'group::offsets::tests::offset_encoding_deadline_expires_before_any_request_is_sent',
    'net::tests::cancelling_first_poll_of_large_frame_retires_connection',
    'net::tests::expired_preencoded_frame_sends_no_request',
    'group::offsets::reconnect_tests::offset_load_retry_rediscovers_after_second_coordinator_error',
    'group::offsets::reconnect_tests::v10_load_retry_never_downgrades_uuid_requests',
    'group::rediscover_stop_tests::remembered_coordinator_dial_uses_versions_from_new_socket',
    'group::rediscover_stop_tests::moved_coordinator_dial_uses_remaining_lookup_deadline',
    'share::tests::unremembered_share_leader_fallback_uses_one_deadline',
    'share::tests::unremembered_share_leader_stalled_tls_obeys_deadline',
]
for n, name in enumerate(names, 1):
    OUTCOMES[name] = q.exact(binary, digest, listing, name, n)
save_json('focused-summary', {'outcomes': OUTCOMES, 'all_passed': all(OUTCOMES.values())})
retain('lib', binary, digest)

for target in TARGETS:
    binary, digest, listing = build(target)
    command = [str(binary), '--test-threads=1']
    receipt, text = q.run('suite-' + target, command, timeout=240)
    assert q.sha(binary) == digest
    if not receipt['results'] or any('0 passed;' in r and '0 failed;' in r for r in receipt['results']):
        raise RuntimeError('nonempty test execution not established: ' + target)
    OUTCOMES[target] = receipt['exit'] == 0
    retain(target, binary, digest)
    save_json('integration-summary', {'outcomes': OUTCOMES,
        'all_passed': all(OUTCOMES.values()), 'inputs_stable': q.inputs() == q.EXPECTED,
        'scope': 'reconnect candidate only; serial default integration targets on reconnect-only source; assignment ownership repair excluded from source; no production or speed qualification'})

command = ['cargo', '+stable', 'clippy', '--locked', '--all-features', '--lib']
for target in TARGETS:
    command += ['--test', target]
command += ['--', '-D', 'warnings']
receipt, _ = q.run('clippy', command, timeout=900)
OUTCOMES['strict-all-feature-scoped-clippy'] = receipt['exit'] == 0
save_json('integration-summary', {'outcomes': OUTCOMES, 'all_passed': all(OUTCOMES.values()),
    'inputs_stable': q.inputs() == q.EXPECTED,
    'scope': 'isolated reconnect candidate; all-feature scoped lint, default integration tests on reconnect-only source; no full matrix or readiness qualification'})
