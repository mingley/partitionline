import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time

ROOT = Path('/workspace/work/reconnect-typed-split')
OUT = Path(__file__).resolve().parent
FLOOR = 1536 * 1024**2
EXPECTED = json.loads((OUT / 'inputs-before.json').read_text())
ENV = dict(os.environ)
ENV.update(RUSTUP_HOME='/workspace/work/rustup', CARGO_HOME='/workspace/work/cargo',
           PATH='/workspace/work/cargo/bin:' + ENV['PATH'],
           CARGO_TARGET_DIR='/workspace/work/qualification-20261027/broker-check-target',
           CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
for key in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER',
            'RUSTC_WORKSPACE_WRAPPER', 'RUST_TEST_THREADS', 'RUST_MIN_STACK'):
    ENV.pop(key, None)

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def inputs():
    names = subprocess.check_output(
        ['rg', '--files', '--hidden', '-g', '!.git/**', '-g', '!docs/**'],
        cwd=ROOT, text=True).splitlines()
    return {name: sha(ROOT / name) for name in sorted(names)
            if (ROOT / name).is_file()}

def memory():
    return Path('/sys/fs/cgroup/memory.events').read_text()

def run(name, command, timeout=300, exact=False):
    if inputs() != EXPECTED:
        raise RuntimeError('candidate inputs changed before ' + name)
    before = memory()
    if shutil.disk_usage(ROOT).free < FLOOR + 8 * 1024**2:
        raise RuntimeError('insufficient disk before ' + name)
    started = time.monotonic()
    samples, stop = [], None
    log = OUT / (name + '.log')
    with log.open('x') as stream:
        proc = subprocess.Popen(command, cwd=ROOT, env=ENV, stdout=stream,
                                stderr=subprocess.STDOUT, start_new_session=True)
        while proc.poll() is None:
            free = shutil.disk_usage(ROOT).free
            samples.append({'seconds': round(time.monotonic() - started, 3), 'free_bytes': free})
            if free < FLOOR + 8 * 1024**2:
                stop = 'disk-floor'
            elif time.monotonic() - started > timeout:
                stop = 'process-timeout'
            if stop:
                os.killpg(proc.pid, signal.SIGTERM)
                break
            time.sleep(0.25)
        try:
            code = proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            code = proc.wait()
    text = log.read_text()
    stable = inputs() == EXPECTED
    results = re.findall(r'^test result:.*$', text, re.M)
    selected_one = not exact or any('1 passed; 0 failed;' in line for line in results)
    receipt = {'command': command, 'exit': code, 'stop_reason': stop,
               'elapsed_seconds': time.monotonic() - started, 'inputs_stable': stable,
               'results': results, 'failures': re.findall(r'^test (.*?) \.\.\. FAILED$', text, re.M),
               'exactly_one_passed': selected_one, 'log_sha256': sha(log), 'samples': samples,
               'memory_events_before': before, 'memory_events_after': memory()}
    (OUT / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'name': name, **{k: receipt[k] for k in
          ('exit', 'stop_reason', 'inputs_stable', 'results', 'exactly_one_passed')}}), flush=True)
    if stop or not stable:
        raise RuntimeError('incomplete or unstable ' + name)
    return receipt, text

def build(target, lib=False):
    # Cargo can otherwise reuse a newer artifact from a different worktree.
    for p in (ROOT / 'src').rglob('*.rs'):
        os.utime(p, None)
    for p in (ROOT / 'tests').rglob('*.rs'):
        os.utime(p, None)
    command = ['cargo', '+stable', 'test', '--locked', '--no-run',
               '--message-format=json-render-diagnostics']
    command += ['--lib'] if lib else ['--test', target]
    receipt, text = run('build-' + target, command, timeout=900)
    if receipt['exit']:
        raise RuntimeError('compilation failed for ' + target)
    artifacts = []
    for line in text.splitlines():
        if not line.startswith('{'):
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if item.get('reason') == 'compiler-artifact' and item.get('executable'):
            if Path(item.get('manifest_path', '')).parent == ROOT:
                artifacts.append(item)
    chosen = [a for a in artifacts if a['target']['name'] == ('partitionline' if lib else target)]
    if len(chosen) != 1 or chosen[0]['fresh']:
        raise RuntimeError('fresh candidate executable not established for ' + target)
    artifact = chosen[0]
    binary = Path(artifact['executable'])
    digest = sha(binary)
    saved = OUT / (target + '.elf')
    retained = False
    if shutil.disk_usage(ROOT).free > FLOOR + binary.stat().st_size + 64 * 1024**2:
        shutil.copyfile(binary, saved)
        shutil.copymode(binary, saved)
        assert sha(saved) == digest
        binary, retained = saved, True
    (OUT / (target + '-executable.json')).write_text(json.dumps(
        {'cargo_artifact': artifact, 'sha256': digest, 'execution_path': str(binary),
         'retained': retained, 'retention_limit': 'Hash only if immutable copy would cross disk reserve'},
        indent=2) + '\n')
    _, listing = run('list-' + target, [str(binary), '--list'])
    return binary, digest, listing

def exact(binary, digest, listing, name, ordinal):
    if sha(binary) != digest or name + ': test' not in listing:
        raise RuntimeError('test provenance/name mismatch: ' + name)
    receipt, _ = run(f'unit-{ordinal:02d}', [str(binary), name, '--exact', '--test-threads=1'], exact=True)
    if sha(binary) != digest:
        raise RuntimeError('test binary changed during execution')
    return receipt['exit'] == 0 and receipt['exactly_one_passed']

if __name__ == '__main__':
    assert inputs() == EXPECTED
    (OUT / 'toolchain.txt').write_text(subprocess.check_output(['rustc', '-Vv'], env=ENV, text=True))
    unit, digest, listing = build('lib', lib=True)
    names = [
        'group::offsets::tests::name_based_offsets_follow_both_bounds_of_the_new_socket',
        'group::offsets::tests::offset_downgrade_does_not_drop_identity_or_stability_fields',
        'group::offsets::tests::large_offset_reencode_yields_before_completion',
        'group::offsets::tests::typed_offset_reconnect_reencodes_for_both_new_range_bounds',
        'group::offsets::tests::typed_offset_reconnect_rejects_unrepresentable_fields_before_wire',
        'group::offsets::tests::offset_encoding_deadline_expires_before_any_request_is_sent',
        'net::tests::cancelling_preencoded_frame_write_never_sends_a_complete_request',
        'net::tests::expired_preencoded_frame_sends_no_request',
    ]
    outcomes = [exact(unit, digest, listing, name, n) for n, name in enumerate(names, 1)]
    (OUT / 'focused-summary.json').write_text(json.dumps({'all_selected_passed': all(outcomes),
        'tests': names, 'outcomes': outcomes, 'inputs_stable': inputs() == EXPECTED}, indent=2) + '\n')
