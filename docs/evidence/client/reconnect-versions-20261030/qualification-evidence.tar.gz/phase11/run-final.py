"""Run source-pinned reconnect checks with one executable retained at a time."""
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

OUT = Path(sys.argv[1]).resolve()
spec = importlib.util.spec_from_file_location('q', OUT / 'run.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
TARGETS = ['lookup_auth_version', 'live_bootstrap_rediscovery', 'heartbeat_load_reuse',
           'wire_trace_fixture', 'bootstrap_handshake', 'legacy_discovery_v0',
           'consumer_fetch_semantics']
OUTCOMES = {}
RETENTION = []

_ORIGINAL_RUN = q.run

def recorded_run(name, command, *args, **kwargs):
    # These sequential qualification cases use the recorded 1.5 GiB guard.
    compile_only = command[:3] == ['cargo', '+stable', 'test'] and '--no-run' in command
    prior_floor = q.FLOOR
    q.FLOOR = 1536 * 1024**2
    actual_floor = q.FLOOR
    receipt_path = OUT/(name+'.json')
    assert not receipt_path.exists(), receipt_path
    try:
        receipt, text = _ORIGINAL_RUN(name, command, *args, **kwargs)
        receipt.update(disk_floor_bytes=actual_floor,
                       case_start_guard_bytes=actual_floor + 8*1024**2,
                       continuous_stop_bytes=actual_floor + 8*1024**2,
                       disk_sample_interval_seconds=0.25,
                       threshold_scope='sequential qualification; 1.5 GiB guard plus 8 MiB log buffer')
        (OUT/(name+'.json')).write_text(json.dumps(receipt, indent=2)+'\n')
        return receipt, text
    except Exception:
        if receipt_path.exists():
            receipt = json.loads(receipt_path.read_text())
            receipt.update(disk_floor_bytes=actual_floor,
                           case_start_guard_bytes=actual_floor + 8*1024**2,
                           continuous_stop_bytes=actual_floor + 8*1024**2,
                           disk_sample_interval_seconds=0.25,
                           threshold_scope='sequential qualification; 1.5 GiB guard plus 8 MiB log buffer')
            receipt_path.write_text(json.dumps(receipt, indent=2)+'\n')
        raise
    finally:
        q.FLOOR = prior_floor

q.run = recorded_run

def save_json(name, value):
    (OUT / (name + '.json')).write_text(json.dumps(value, indent=2) + '\n')

def build(name, lib=False):
    command = ['cargo', '+stable', 'test', '--locked', '--no-run',
               '--message-format=json-render-diagnostics']
    command += ['--lib'] if lib else ['--test', name]
    receipt, text = q.run('build-' + name, command, timeout=900)
    if receipt['exit']:
        raise RuntimeError('compilation failed: ' + name)
    artifacts = []
    for line in text.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if item.get('reason') == 'compiler-artifact' and item.get('executable'):
            if Path(item.get('manifest_path', '')).parent == q.ROOT:
                artifacts.append(item)
    matches = [x for x in artifacts if x['target']['name'] == ('partitionline' if lib else name)]
    if len(matches) != 1 or matches[0]['fresh']:
        raise RuntimeError('fresh candidate target not established: ' + name)
    artifact = matches[0]
    binary = Path(artifact['executable'])
    digest = q.sha(binary)
    save_json(name + '-executable', {'cargo_artifact': artifact, 'sha256': digest,
              'execution_path': str(binary), 'retention': 'gzip stream saved after tests; no second raw copy'})
    _, listing = q.run('list-' + name, [str(binary), '--list'])
    return binary, digest, listing

def retain(name, binary, digest):
    assert q.sha(binary) == digest
    used, inaccessible = [], []
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            if (proc/'exe').resolve() == binary:
                used.append(proc.name)
        except (OSError, PermissionError):
            inaccessible.append(proc.name)
    assert not used, used
    dest = OUT / (name + '.elf.gz')
    size = binary.stat().st_size
    with binary.open('rb') as source, dest.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as zipped:
            shutil.copyfileobj(source, zipped, 1024*1024)
        raw.flush()
        os.fsync(raw.fileno())
    h = hashlib.sha256(); reconstructed_size = 0
    with gzip.open(dest, 'rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk); reconstructed_size += len(chunk)
    assert h.hexdigest() == digest and reconstructed_size == size
    RETENTION.append({'historical_execution_path': str(binary), 'canonical_retained_path': str(dest),
        'uncompressed_sha256': digest, 'uncompressed_size': size,
        'compressed_sha256': q.sha(dest), 'compressed_size': dest.stat().st_size,
        'decompressed_hash_and_size_verified': True, 'accessible_proc_exe_users': used,
        'inaccessible_proc_entries': inaccessible,
        'regenerable_target_copy_removed_after_retention': True})
    save_json('executable-retention', RETENTION)
    assert q.sha(binary) == digest
    binary.unlink()



_original_guarded_run = q.run

def pressure_run(name, command, *args, **kwargs):
    before_cpu = Path('/sys/fs/cgroup/cpu.stat').read_text()
    before_load = Path('/proc/loadavg').read_text()
    receipt, text = _original_guarded_run(name, command, *args, **kwargs)
    receipt.update(cpu_stat_before=before_cpu, cpu_stat_after=Path('/sys/fs/cgroup/cpu.stat').read_text(),
                   loadavg_before=before_load, loadavg_after=Path('/proc/loadavg').read_text(),
                   minimum_sampled_free_bytes=min((s['free_bytes'] for s in receipt['samples']), default=None))
    save_json(name, receipt)
    return receipt, text

q.run = pressure_run

assert q.inputs()==q.EXPECTED
(OUT/'toolchain.txt').write_text(subprocess.check_output(['rustc','-Vv'],env=q.ENV,text=True))
save_json('scheduler-and-scope',{'jobs':1,'disk_floor_bytes':1536*1024**2,'log_buffer_bytes':8*1024**2,
    'source_scope':'client1809 per case with full7731 before/after',
    'change':'One predicate and comment in one returning-bootstrap test; actual commit lookup selected by known OffsetCommit socket, separate heartbeat lookup permitted',
    'broad_result_not_repeated':'phase10 consumerFetch167pass2fail1ignored retained; phase11 focused predicate correction is not a new broad pass',
    'root_approval':'Focused exact changed test plus strict lint sufficient after fresh consumer build; no additional full matrix cycle',
    'limits':'External installed toolchain/dependency bytes not source-snapshotted; no full production or performance qualification'})
receipt,_=q.run('clippy',['cargo','+stable','clippy','--locked','--all-features','--lib','--test','consumer_fetch_semantics','--','-D','warnings'],timeout=900)
OUTCOMES['strict-all-feature-consumer-clippy']=receipt['exit']==0
receipt,_=q.run('format',['rustfmt','+stable','--check','--edition','2021',*json.loads((OUT/'candidate.json').read_text())['changed_paths']])
OUTCOMES['format']=receipt['exit']==0
save_json('preflight',OUTCOMES)
if not all(OUTCOMES.values()):raise RuntimeError('preflight failed')
binary,digest,listing=build('consumer_fetch_semantics')
name='group_commit_reuses_bootstrap_when_the_coordinator_returns';assert name+': test' in listing
receipt,_=q.run('focused-'+name,[str(binary),'--exact',name,'--test-threads=1','--nocapture'],exact=True)
assert q.sha(binary)==digest
OUTCOMES[name]=receipt['exit']==0 and receipt['exactly_one_passed']
retain('consumer_fetch_semantics',binary,digest)
names=subprocess.check_output(['rg','--files','--hidden','-g','!.git/**','-g','!docs/**'],cwd=q.ROOT,text=True).splitlines()
if (q.ROOT/'docs/latency-baseline.json').is_file():names.append('docs/latency-baseline.json')
full={name:q.sha(q.ROOT/name) for name in sorted(set(names)) if (q.ROOT/name).is_file()}
client=q.inputs();save_json('inputs-full-after',full);save_json('inputs-after',client)
save_json('summary',{'outcomes':OUTCOMES,'client_inputs_stable':client==q.EXPECTED,
    'full_inputs_stable':full==json.loads((OUT/'inputs-full-before.json').read_text()),
    'scope':'Only changed role-specific predicate/comment requalified by fresh focused runtime and strict scoped lint',
    'phase10_broad_consumer_result':'167pass2fail1ignored; not rerun in phase11',
    'qualification':'Full consumerFetch remains unqualified; no release, full production, or global speed claim'})
