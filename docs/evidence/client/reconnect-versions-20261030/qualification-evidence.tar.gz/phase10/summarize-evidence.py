from pathlib import Path
import datetime,gzip,hashlib,json,re,subprocess
BASE=Path('/workspace/work/client-fresh-versions-overlay');OUT=BASE/'typed-refreshed-20261030-10';ROOT=Path('/workspace/work/reconnect-typed-split');MAIN=Path('/workspace/partitionline')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def save(name,value):(OUT/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n')
verification={};index={};nonruntime=[];scoped_runs={}
for phase in ['07','08','09','10']:
 d=BASE/('typed-refreshed-20261030-'+phase);records=[];retentions=[]
 for r in json.loads((d/'executable-retention.json').read_text()):
  p=Path(r['canonical_retained_path']);h=hashlib.sha256();size=0
  with gzip.open(p,'rb') as f:
   for b in iter(lambda:f.read(1048576),b''):h.update(b);size+=len(b)
  assert h.hexdigest()==r['uncompressed_sha256'] and size==r['uncompressed_size']
  assert sha(p)==r['compressed_sha256'] and p.stat().st_size==r['compressed_size']
  retentions.append({'file':str(p),'uncompressed_sha256':h.hexdigest(),'uncompressed_size':size,'compressed_sha256':r['compressed_sha256'],'compressed_size':r['compressed_size']})
 for p in sorted(d.glob('*.json')):
  r=json.loads(p.read_text())
  if not isinstance(r,dict) or 'command' not in r:continue
  log=d/(p.stem+'.log');assert sha(log)==r['log_sha256']
  assert r['inputs_stable'] and r['stop_reason'] is None
  minimum=min((x['free_bytes'] for x in r['samples']),default=None)
  assert r['memory_events_before']==r['memory_events_after']
  if phase in ['09','10']:assert minimum>=r['continuous_stop_bytes']
  records.append({'case':p.stem,'exit':r['exit'],'results':r['results'],'minimum_sampled_free_bytes':minimum,'disk_floor_bytes':r.get('disk_floor_bytes'),'continuous_stop_bytes':r.get('continuous_stop_bytes'),'memory_events_unchanged':True,'log_sha256':r['log_sha256']})
  if p.stem.startswith('suite-'):
   target=p.stem[len('suite-'):];scoped_runs[(phase,target)]={'results':r['results'],'failures':r['failures'],'receipt':str(p)}
  else:target='consumer_fetch_semantics' if ('group_' in p.stem or 'idle_coordinator' in p.stem) else p.stem
  text=log.read_text()
  if r['exit']!=0 and not r['results']:
   nonruntime.append({'phase':phase,'case':p.stem,'exit':r['exit'],'log':str(log)})
  for match in re.finditer(r'^---- (.*?) stdout ----\n(.*?)(?=^---- |^failures:|\Z)',text,re.M|re.S):
   name,block=match.groups();at=block.find('panicked at ')
   excerpt=block[at if at>=0 else 0:]
   excerpt='\n'.join(excerpt.strip().splitlines()[:8])[:1200]
   key=target+'::'+name
   entry=index.setdefault(key,{'target':target,'test':name,'occurrences':[]})
   entry['occurrences'].append({'phase':phase,'case':p.stem,'log':str(log),'failure_excerpt':excerpt})
 for p in d.glob('*-executable.json'):
  r=json.loads(p.read_text());assert r['cargo_artifact']['fresh'] is False
  assert any(x['uncompressed_sha256']==r['sha256'] for x in retentions)
 verification[phase]={'retained_executables':retentions,'fresh_false_artifact_count':len(list(d.glob('*-executable.json'))),'receipts':records}
 if (d/'inputs-after.json').exists():assert json.loads((d/'inputs-before.json').read_text())==json.loads((d/'inputs-after.json').read_text())
 if (d/'inputs-full-after.json').exists():assert json.loads((d/'inputs-full-before.json').read_text())==json.loads((d/'inputs-full-after.json').read_text())
for key,entry in index.items():
 final=scoped_runs.get(('10',entry['target']))
 entry['phase10_full_target_status']='not rerun; phase09 result retained' if final is None else ('FAILED' if entry['test'] in final['failures'] else 'passed in phase10 broad target')
 entry['cause_status']='Unresolved; timing values alone do not prove socket serialization or runtime scheduling cause.'
 if 'recreated_topic_reassignment' in entry['test']:entry['cause_status']='Semantic ownership/recreation assertion remains open; excluded assignment repair not applied.'
 if entry['test']=='group_join_dials_reset_leaders_while_fetching_offsets':entry['cause_status']='True join/Fetch/dial overlap requirement remains open; unrelated repair excluded.'
 if entry['test']=='group_commit_redials_coordinator_while_finding_it':entry['cause_status']='Phase07 interval assertion compared discovery against earlier required negotiation. Phase08+ use overlap of both ApiVersions windows and exact socket reuse, retaining650ms; later wall failures retained.'
 if entry['test']=='idle_coordinator_reuses_the_other_bootstrap_handshake':entry['cause_status']='Phase07 wall bound included200ms periodic wait plus250ms required negotiation. Phase08+ separate scheduling from active reconnect, retaining450ms active bound and socket proof.'
 if entry['test']=='list_offsets_renegotiates_a_remote_leader_after_idle':entry['cause_status']='Phase09 global initial negotiation count assumed the40ms bootstrap idle timer never expired. Phase10 tests actual leader socket ranges/order/once and replacement identity, retaining400ms.'
 if entry['test']=='group_commit_reuses_bootstrap_when_the_coordinator_returns':entry['cause_status']='Phase09 global node1 Accept count does not identify the discovery role. Phase10 asserts FindCoordinator/OffsetCommit use one actual negotiated socket, retains450ms and subsequent same-socket reuse; full initial/commit timeline retained.'
save('failure-index',{'scope':'Every recorded runtime assertion failure across phases07-10; exact final10 status retained. Focused diagnostics never replace broad results.','tests':dict(sorted(index.items())),'nonruntime_failures':nonruntime})
save('independent-verification',verification)
current=json.loads((OUT/'inputs-full-after.json').read_text());assert all(sha(ROOT/name)==value for name,value in current.items())
manifest07=json.loads((BASE/'typed-refreshed-20261030-07'/'inputs-before.json').read_text());assert all(value==manifest07[name] for name,value in current.items() if name.startswith('src/'))
patch=OUT/'current-main-to-candidate.patch';meta=json.loads((OUT/'candidate.json').read_text());assert sha(patch)==meta['patch_sha256']
subprocess.run(['git','apply','--check',str(patch)],cwd=MAIN,check=True)
final={target:record for (phase,target),record in scoped_runs.items() if phase=='10'}
main_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN,text=True).strip()
save('handoff-evidence',{'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'product_base':meta['main_head'],'main_head_at_final_check':main_head,'patch':str(patch),'patch_sha256':sha(patch),'apply_check_current_main':True,'candidate_inputs_currently_match_final_snapshot':True,'product_src_and_unit_fixture_identical_to_phase07':True,'input_manifest_sha256':{name:sha(OUT/(name+'.json')) for name in ['inputs-before','inputs-after','inputs-full-before','inputs-full-after']},'product_module_sha256':{name:{'main_before':sha(MAIN/name),'candidate_current':sha(ROOT/name)} for name in ['src/consumer.rs','src/net.rs','src/group.rs','src/group/offsets.rs','src/producer.rs','src/share.rs']},'unit_controls':json.loads((BASE/'typed-refreshed-20261030-07'/'focused-summary.json').read_text()),'phase10_full_targets':final,'other_target_results_phase09':{target:record for (phase,target),record in scoped_runs.items() if phase=='09' and target not in final},'verification_artifact':str(OUT/'independent-verification.json'),'failure_index':str(OUT/'failure-index.json'),'claims':'Full consumer Fetch suite unqualified. No full production, release, external interoperability, or global speed qualification. No unrelated assignment/ReadCommitted repair applied.'})
print(json.dumps({'patch_sha256':sha(patch),'final10':final,'failure_index_unique_tests':len(index),'current_main_head':main_head},indent=2))
