#!/usr/bin/env python3
"""Verify source pins and test-only patch roundtrip; never run Rust or network."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/partitionline')
SOURCE = Path('/workspace/work/client-v14-deadline-fixture-20261103/after/src/producer.rs')
CLUSTER = Path('/workspace/work/client-v10-wire-v3-thin-20261103/fixed/src/cluster.rs')
NET = Path('/workspace/work/client-v10-wire-v3-thin-20261103/fixed/src/net.rs')
CATALOG = ROOT / 'docs/evidence/client/candidate-20261030/v16/fixed-inputs.json'
API = ROOT / 'src/protocol/api.rs'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def block(text, start, end):
    left = text.index(start)
    return text[left:text.index(end, left + len(start))]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--catalog', type=Path, default=CATALOG)
    parser.add_argument('--producer', type=Path, default=SOURCE)
    parser.add_argument('--cluster', type=Path, default=CLUSTER)
    parser.add_argument('--net', type=Path, default=NET)
    parser.add_argument('--api', type=Path, default=API)
    args = parser.parse_args()
    pin = json.loads((HERE / 'pins.json').read_text())
    catalog = json.loads(args.catalog.read_text())
    assert digest(args.catalog.read_bytes()) == pin['base_v16_fixed_catalog_sha256']
    for name, path in [('src/producer.rs', args.producer), ('src/cluster.rs', args.cluster),
                       ('src/net.rs', args.net), ('src/protocol/api.rs', args.api)]:
        assert digest(path.read_bytes()) == catalog[name], name
    before = args.producer.read_text()
    assert digest(args.producer.read_bytes()) == pin['before_producer_sha256']
    insert = (HERE / 'insert.rs').read_text()
    anchor = '    #[tokio::test(flavor = "current_thread")]\n    async fn retired_fast_route_falls_back_to_the_live_worker() {'
    assert before.count(anchor) == 1
    after = before.replace(anchor, insert + anchor, 1).encode()
    assert digest(after) == pin['after_producer_sha256']
    assert digest((HERE / 'endpoint-stale-dial-tests.patch').read_bytes()) == pin['test_patch_sha256']

    select = block(before, 'fn prepare_slot_dial(', 'fn finish_slot_connect(')
    finish = block(before, 'fn finish_slot_connect(', '/// KL09-25: open one connection')
    reconnect = block(before, '    async fn reconnect_if_idle(', '    async fn fire(')
    metadata = block(before, 'async fn decode_shared_metadata(', '/// Record `topic` once')
    assert 'cluster.lock().brokers.get(&node).cloned()' in select
    assert 'reconnect_busy.lock()' in select
    assert '*s = Some(handle);' in finish and 'cluster.lock()' not in finish
    assert 'self.conn.addr().to_string()' in reconnect and 'open_produce_socket' in reconnect
    assert metadata.index('shared.cluster.lock().clone()') < metadata.index('cluster.apply_image(&image, version).await') < metadata.index('*shared.cluster.lock() = cluster')
    assert 'fn apply_node_endpoints(' in args.cluster.read_text()

    with tempfile.TemporaryDirectory(prefix='endpoint-stale-dial-peer-', dir=HERE) as temp:
        root = Path(temp)
        target = root / 'src/producer.rs'
        target.parent.mkdir()
        target.write_bytes(args.producer.read_bytes())
        patch = HERE / 'endpoint-stale-dial-tests.patch'
        for flags in (['--check'], [], ['--reverse', '--check'], ['--reverse']):
            result = subprocess.run(['git', 'apply', *flags, str(patch)], cwd=root,
                                    capture_output=True, text=True)
            assert result.returncode == 0, result.stderr
            if flags == []:
                assert target.read_bytes() == after
        assert target.read_bytes() == args.producer.read_bytes()

    result = subprocess.run([sys.executable, '-B', str(HERE / 'model.py')],
                            check=True, capture_output=True)
    assert result.stdout == (HERE / 'model.json').read_bytes()
    print(json.dumps({'source_pins': 'pass', 'test_only_patch_roundtrip': 'pass',
                      'source_order_checks': 'pass', 'illustrative_model': 'pass',
                      'limitations': 'No Rust compile, native execution, actual race, fd retirement or performance claim.'}, indent=2))


if __name__ == '__main__':
    main()
