# Endpoint-change regression proposal

This package contains a test-only patch and design notes for the pinned v16 producer. It has not been compiled, run natively or adopted. The current source predicts that the unchanged-endpoint control passes and the A→B and A→B→A rejection controls fail; these are predictions, not observed results.

`endpoint-stale-dial-tests.patch` adds three tests around a real loopback ApiVersions exchange and the existing slot-publication code. `DESIGN.md` defines the proposed local route identity, metadata publication, cancellation and in-flight boundaries. `OBSERVATIONS.md` separates the v16 console projection from the earlier v10 physical-wire trace. `model.py` is a sequential illustration only.

Run `python3 -B verify.py` in the original workspace, or provide `--catalog`, `--producer`, `--cluster`, `--net` and `--api` paths for a reconstructed v16 fixed source. The verifier checks source pins, test-only patch roundtrip, source patterns and model output. It does not compile or execute the Rust tests.

The control observes the slot after publication returns. It does not prove absence of a transient stale publication, actual misrouted Produce, physical fd retirement or safe in-flight retry. A later implementation needs the separate controls described in the design.
