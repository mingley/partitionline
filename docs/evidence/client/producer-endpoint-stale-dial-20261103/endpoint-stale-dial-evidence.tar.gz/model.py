#!/usr/bin/env python3
"""Illustrate source-derived endpoint publication; no Rust code executes."""
import json


def baseline(transitions):
    route = 'A'
    selected = route
    for endpoint in transitions:
        route = endpoint
    # Current finish_slot_connect receives a WorkerHandle but no dial stamp.
    published = selected
    return {'selected': selected, 'current': route, 'published': published}


def conservative(transitions):
    route, revision = 'A', 0
    selected, stamp = route, revision
    for endpoint in transitions:
        if endpoint != route:
            route, revision = endpoint, revision + 1
    return {'selected': selected, 'current': route,
            'published': selected if stamp == revision else None}


cases = {'unchanged': [], 'changed': ['B'], 'aba': ['B', 'A']}
result = {name: {'baseline': baseline(sequence), 'illustration': conservative(sequence)}
          for name, sequence in cases.items()}
assert result['unchanged']['baseline']['published'] == 'A'
assert result['changed']['baseline']['published'] == 'A'
assert result['aba']['baseline']['published'] == 'A'
assert result['unchanged']['illustration']['published'] == 'A'
assert result['changed']['illustration']['published'] is None
assert result['aba']['illustration']['published'] is None
print(json.dumps({'scope': 'sequential illustration, not a Rust/native observation', 'cases': result}, indent=2))
