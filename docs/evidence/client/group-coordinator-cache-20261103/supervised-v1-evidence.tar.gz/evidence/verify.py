#!/usr/bin/env python3
"""Check and round-trip the supervised group draft against reconstructed v14 inputs."""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('v14_fixed_source', type=Path)
parser.add_argument('v14_fixed_catalog', type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parent
receipt = json.loads((root / 'receipt.json').read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
catalog_data = args.v14_fixed_catalog.read_bytes()
assert sha(catalog_data) == receipt['v14_fixed_catalog_sha256']
catalog = json.loads(catalog_data)
compressed = (root / 'supervised-group-v1.patch.gz').read_bytes()
assert sha(compressed) == receipt['patch_gzip_sha256']
patch = gzip.decompress(compressed)
assert sha(patch) == receipt['patch_sha256']
for p, entry in receipt['files'].items():
    expected = entry['v14_sha256']
    if expected is None:
        assert p not in catalog and not (args.v14_fixed_source / p).exists(), p
    else:
        assert catalog[p] == expected and sha((args.v14_fixed_source / p).read_bytes()) == expected, p
with tempfile.TemporaryDirectory(prefix='group-supervisor-roundtrip-') as name:
    stage = Path(name)
    for p, entry in receipt['files'].items():
        if entry['v14_sha256'] is None:
            continue
        dest = stage / p
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes((args.v14_fixed_source / p).read_bytes())
    subprocess.run(['git', 'apply', '--check', '-'], input=patch, cwd=stage, check=True)
    subprocess.run(['git', 'apply', '-'], input=patch, cwd=stage, check=True)
    for p, entry in receipt['files'].items():
        assert sha((stage / p).read_bytes()) == entry['candidate_sha256'], p
    subprocess.run(['git', 'apply', '--reverse', '--check', '-'], input=patch, cwd=stage, check=True)
    subprocess.run(['git', 'apply', '--reverse', '-'], input=patch, cwd=stage, check=True)
    for p, entry in receipt['files'].items():
        if entry['v14_sha256'] is None:
            assert not (stage / p).exists(), p
        else:
            assert sha((stage / p).read_bytes()) == entry['v14_sha256'], p
print('V14 pinned preimages and all candidate bytes verified; patch applies and reverses exactly.')
