#!/usr/bin/env python3
"""Check the frozen preimage and reproduce the tests-only delta without building."""
from pathlib import Path
import hashlib
import re
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
PREIMAGES = {
    'src/producer/group_coordinator_tests.rs': '628505d950c98c7f0a7736c85858bdbc9e1813821b25c02518945cfc74421c51',
    'src/producer/group_runtime_tests.rs': '797d1be3d7b7363b25bd58e1424ac7814761008c0806557868b9d6f946fc0537',
    'tests/mock_produce.rs': 'cf7d40114fcda892f6c1e0736ec364da229afad43a195d7f76e607b4cd1687b7',
}
OUTPUTS = {
    'src/producer/group_coordinator_tests.rs': '6381f0d3d6ad97a18e0a18348b2beb45a5c0a594b587b05a4c34412bbdd14cc0',
    'src/producer/group_runtime_tests.rs': '8186e2656b338dd135f1a1ce675deb00b31422a9dccb2efc87ec4f544d029cd6',
    'tests/mock_produce.rs': 'f73b7546d0765882e4e18187da1f0521d8d1124a77b168b338f0d1a82ee19d85',
}
PATCH = 'f7bc4e313e42716b2536f6707994f06d91c6046282232b98e425fb665de37592'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def section(text, name):
    start = re.search(r'(?m)^#\[tokio::test[^\n]*\]\nasync fn ' + re.escape(name) + r'\([^\n]*\) \{', text)
    if not start:
        raise RuntimeError(f'missing test {name}')
    tail = re.search(r'(?m)^#\[tokio::test', text[start.end():])
    return start.start(), start.end() + tail.start() if tail else len(text)

def require(value, message):
    if not value:
        raise RuntimeError(message)

if len(sys.argv) not in (2, 3):
    raise SystemExit('usage: verify.py <frozen-candidate-directory> [v14-mock-produce-file]')
base = Path(sys.argv[1])
patch = HERE / 'followup.patch'
require(sha(patch) == PATCH, 'follow-up patch hash mismatch')
for file, digest in PREIMAGES.items():
    require(sha(base / file) == digest, f'preimage mismatch: {file}')
with tempfile.TemporaryDirectory(prefix='group-followup-verify-') as tmp:
    dest = Path(tmp)
    for file in PREIMAGES:
        (dest / file).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(base / file, dest / file)
    subprocess.run(['git', 'apply', '--check', str(patch)], cwd=dest, check=True)
    subprocess.run(['git', 'apply', str(patch)], cwd=dest, check=True)
    for file, digest in OUTPUTS.items():
        require(sha(dest / file) == digest, f'output mismatch: {file}')
    group = 'src/producer/group_coordinator_tests.rs'
    require((dest / group).read_bytes().startswith((base / group).read_bytes()), 'group controls changed')
    runtime = 'src/producer/group_runtime_tests.rs'
    text = (dest / runtime).read_text()
    start, end = section(text, 'same_group_waiters_do_not_exhaust_unrelated_physical_lanes')
    require(text[:start] + text[end:] == (base / runtime).read_text(), 'old runtime controls changed')
    mock = 'tests/mock_produce.rs'
    text = (dest / mock).read_text()
    if len(sys.argv) == 3:
        require(text.encode().startswith(Path(sys.argv[2]).read_bytes()), 'v14 mock prefix changed')
    start, end = section(text, 'same_group_public_calls_preserve_order_across_a_retry')
    text = text[:start] + text[end:]
    old = (base / mock).read_text()
    start, end = section(text, 'group_cache_evicts_the_previous_group_and_retires_its_socket')
    old_start, old_end = section(old, 'group_cache_evicts_the_previous_group_and_retires_its_socket')
    require(text[:start] + old[old_start:old_end] + text[end:] == old, 'other old mock content changed')
    subprocess.run(['git', 'apply', '--reverse', '--check', str(patch)], cwd=dest, check=True)
    subprocess.run(['git', 'apply', '--reverse', str(patch)], cwd=dest, check=True)
    for file, digest in PREIMAGES.items():
        require(sha(dest / file) == digest, f'reverse mismatch: {file}')
print('PASS: preimages, output hashes, preserved test text, and exact forward/reverse patch')
if len(sys.argv) == 3:
    print('PASS: exact v14 mock prefix')
print('No Rust compilation, tests, or runtime qualification performed.')
