#!/usr/bin/env python3
"""Check source provenance and sparse diagnostic patches, without native execution."""
from pathlib import Path
import ast
import hashlib
import os
import shutil
import subprocess
import tempfile
import sys

root=Path(__file__).resolve().parent.parent
repo=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('/workspace/partitionline')
commit='2645e96ce693fcdaa9d8c56f6f0c910934fd19a2'
expected={
 'src/group.rs':'ce00d2e7b049298b6c8111b7123f39859c9f2f6f3d89cbc51dc6939962d868ab',
 'tests/broker_compatibility.rs':'5e289d3af378a44c162e3142468cbf58afe03955f6204a67825b0776f424cad0',
 'tests/common/mod.rs':'23188e64380ead0d29b99eecff346c297dcdc43be9acd65987711d5c2962c497',
 'src/consumer.rs':'3dc409b86be0aeafed632d7d3e4a5c02b32aca07171877613f7da096f9858563',
 'src/net.rs':'df239f20fdc4e3240defa78e632faa50c09dc69876478581e061d5c68722bb38',
 'Cargo.toml':'98b437d0dab4d8289a9fd097f9f7a8c4b6e227c505584eb1ea22e0c8bc28f389',
 'Cargo.lock':'bdc37c48feb0d7a17a1b08e70c5301ec30b9a90e64c93adaf28aef6b6f9f46bc',
 'scripts/ci-broker-compatibility.sh':'5802854a8c31993bd69679d0cdd33dc4ef921a60c5a7e7c4be699744d9c2f2ac',
 'scripts/ci-broker-smoke.sh':'344c083e94c7dffc46d48a12e32c729c5685f93af22fd4f1cab6bd2179cd0f76',
}
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env['LC_ALL']='C'
for name,digest in expected.items():
 data=subprocess.run(['git','show',commit+':'+name],cwd=repo,check=True,capture_output=True,timeout=60,env=env).stdout
 assert hashlib.sha256(data).hexdigest()==digest,name
 if name in ('src/group.rs','tests/broker_compatibility.rs'):
  assert (root/'base'/name).read_bytes()==data
patches={
 'future-size-diagnostic.patch':'0157eb425faf4e889cfc77945d44c7044f652948d068ee5fe498739f3733aa7a',
 'caller-box-experiment.patch':'3f2789b159f8927e6d1bd30881bb3f2d94c771483e4f59dcf0e9addbfd0ef2c5',
 'library-box-experiment.patch':'05e3a3da42b1a93d374fdc96b60740a3e48a30942267a2bbbfe99a6abfac0904',
 'phase-trace-diagnostic.patch':'be731d5ae65140e96d25b1419a7903f3320dee173d0a07b53ed352a2b3888223',
 'prior-two-mib-mock-control.patch':'40e71f2acd99baf3c91e384d4ea4b49147d4cd9739942c6b5a94935da2fb624a',
}
for name,digest in patches.items():
 assert hashlib.sha256((root/'evidence'/name).read_bytes()).hexdigest()==digest
decoded_logs={
 'connector-decoded-job-125774457011.log':'ad5e8ddaaa8f37bcc98d01b5cf6c9f8e7d1d6e210db22c43bf6c4e4bfc9568fe',
 'connector-decoded-job-125774457154.log':'6b538cca30d661b7e9c8dcc80a70cc95ca023c150e4e29033e959306ec5eb2d4',
 'connector-decoded-job-125774457229.log':'521f7f6bb9a6280d6fc09c65c6f7c254097d1a24b340e886511693edd43350f9',
}
for name,digest in decoded_logs.items():
 data=(root/'evidence'/name).read_bytes()
 assert hashlib.sha256(data).hexdigest()==digest
 text=data.decode('utf-8')
 assert 'compatibility group phase: classic join' in text
 assert "has overflowed its stack" in text and 'SIGABRT' in text
with tempfile.TemporaryDirectory(prefix='live-stack-patches-',dir='/workspace/work') as temp:
 d=Path(temp);shutil.copytree(root/'base',d/'base');d=d/'base'
 def apply(name,reverse=False):
  for check in (True,False):
   subprocess.run(['git','apply']+(['--reverse'] if reverse else [])+(['--check'] if check else [])+[str(root/'evidence'/name)],cwd=d,check=True,capture_output=True,timeout=60,env=env)
 for patch,variant,path in [('future-size-diagnostic.patch','diagnostic','tests/broker_compatibility.rs'),
  ('caller-box-experiment.patch','caller-box','tests/broker_compatibility.rs'),
  ('library-box-experiment.patch','library-box','src/group.rs'),
  ('phase-trace-diagnostic.patch','trace','src/group.rs')]:
  apply(patch);assert (d/path).read_bytes()==(root/variant/path).read_bytes(),patch
  apply(patch,True);assert (d/path).read_bytes()==(root/'base'/path).read_bytes(),patch
 apply('prior-two-mib-mock-control.patch');assert (d/'tests/group_stack.rs').is_file()
 apply('prior-two-mib-mock-control.patch',True);assert not (d/'tests/group_stack.rs').exists()
 # The two separate experiments and size diagnostic can be composed without
 # modifying each other's files/hunks. This is a source check, not a test.
 apply('caller-box-experiment.patch');apply('library-box-experiment.patch');apply('future-size-diagnostic.patch')
 assert (d/'src/group.rs').read_bytes()==(root/'library-box/src/group.rs').read_bytes()
 assert b'report_compatibility_future_state_sizes' in (d/'tests/broker_compatibility.rs').read_bytes()
base=(root/'base/tests/broker_compatibility.rs').read_bytes()
diag=(root/'diagnostic/tests/broker_compatibility.rs').read_bytes()
assert diag.startswith(base)
assert b'#[ignore = "explicit future-state diagnostic uses an 8 MiB thread"]' in diag[len(base):]
trace=(root/'trace/src/group.rs').read_text().splitlines(keepends=True)
assert ''.join(line for line in trace if 'eprintln!("PL_GROUP_STACK_TRACE ' not in line)==(root/'base/src/group.rs').read_text()
assert (root/'base/src/group.rs').read_text().count('            let revoked = self.rejoin_once(deadline).await?;')==1
source=(root/'base/tests/broker_compatibility.rs').read_text()
assert source.count('        let mut group = join_group(&bootstrap, &id, &input, kind, &mut attempts).await?;')==1
assert 'tokio::time::timeout(Duration::from_secs(150), run())' in source
assert 'tokio::time::timeout(Duration::from_secs(20), async {' in source
assert '.request_timeout(Duration::from_secs(3))' in source
assert (root/'caller-box/tests/broker_compatibility.rs').read_text()==source.replace(
 '        let mut group = join_group(&bootstrap, &id, &input, kind, &mut attempts).await?;',
 '        let mut group = Box::pin(join_group(&bootstrap, &id, &input, kind, &mut attempts)).await?;')
group=(root/'base/src/group.rs').read_text()
assert (root/'library-box/src/group.rs').read_text()==group.replace(
 '            let revoked = self.rejoin_once(deadline).await?;',
 '            let revoked = Box::pin(self.rejoin_once(deadline)).await?;')
probe_source=(root/'evidence/inspect-elf.py').read_text()
ast.parse(probe_source)
namespace={'__name__':'stack_elf_header_control'}
exec(compile(probe_source,'inspect-elf.py','exec'),namespace)
validate=namespace['require_x86_64_elf_header']
h=bytearray(64);h[:4]=b'\x7fELF';h[4]=2;h[5]=1;h[6]=1
h[16:18]=(2).to_bytes(2,'little');h[18:20]=(62).to_bytes(2,'little');validate(h)
for index,value in [(0,0),(4,1),(5,2),(6,0),(16,1),(18,183)]:
 x=bytearray(h);x[index]=value
 try:validate(x)
 except ValueError:pass
 else:raise AssertionError(('incorrect ELF header accepted',index,value))
try:validate(h[:63])
except ValueError:pass
else:raise AssertionError('truncated ELF header accepted')
# Fake hashes and binutils show both source-change checks fail before reporting.
# No native program is invoked by these controls.
with tempfile.TemporaryDirectory(prefix='stack-header-control-',dir='/workspace/work') as temp:
 d=Path(temp);elf=d/'fake.elf';elf.write_bytes(h);old_argv=sys.argv[:]
 try:
  sys.argv=['inspect-elf.py',str(elf),str(d/'header-race')]
  values=iter(['a','b']);namespace['sha']=lambda _:next(values)
  try:namespace['main']()
  except SystemExit as error:assert str(error)=='ELF changed while validating its header'
  else:raise AssertionError('header-window change accepted')
  assert not (d/'header-race').exists()
  sys.argv=['inspect-elf.py',str(elf),str(d/'inspection-race')]
  values=iter(['a','a','b']);namespace['sha']=lambda _:next(values)
  def fake_run(command,timeout=120):
   if '--version' in command:return b'fake-binutils 1\n'
   if command[0]=='nm':return b'0000000000000010 0000000000000020 T broker_compatibility::run\n'
   return b'fake prologue\n'
  namespace['run']=fake_run
  try:namespace['main']()
  except SystemExit as error:assert str(error)=='ELF changed during inspection'
  else:raise AssertionError('inspection-window change accepted')
  assert not (d/'inspection-race/report.json').exists()
 finally:sys.argv=old_argv
fmt='/workspace/work/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt'
for p in (root/'diagnostic/tests/broker_compatibility.rs',root/'caller-box/tests/broker_compatibility.rs'):
 subprocess.run([fmt,'--edition','2021','--check',str(p)],check=True,capture_output=True,timeout=60)
for p in (root/'library-box/src/group.rs',root/'trace/src/group.rs'):
 subprocess.run([fmt,'--edition','2021','--config','skip_children=true','--check',str(p)],check=True,capture_output=True,timeout=60)
print('2645 source pins, patch roundtrips/composition, diagnostic-only edits and rustfmt verified.')
print('No Cargo, compiler, native test, stack measurement, Kafka, or benchmark was run.')
