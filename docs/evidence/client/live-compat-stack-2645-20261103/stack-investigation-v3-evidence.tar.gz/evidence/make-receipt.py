from pathlib import Path
import hashlib,json
here=Path(__file__).resolve().parent
root=here.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(here.iterdir()) if p.is_file() and p.name!='receipt.json'}
record={
 'scope':'Source-only live compatibility stack investigation revision 3 at exact 2645 commit; no qualified fix',
 'prior_v1_archive_sha256':'026dfbc60f86e72eec4bba92fb7101c2f0e4f34de0a0048eaa60cd032947c4c8',
 'prior_v2_archive_sha256':'c398b06339b746acd387862ff883306c39f2e106869ea6cc18d7da0009470955',
 'source_commit':'2645e96ce693fcdaa9d8c56f6f0c910934fd19a2',
 'source_pins':{
  'src/group.rs':'ce00d2e7b049298b6c8111b7123f39859c9f2f6f3d89cbc51dc6939962d868ab',
  'tests/broker_compatibility.rs':'5e289d3af378a44c162e3142468cbf58afe03955f6204a67825b0776f424cad0',
  'tests/common/mod.rs':'23188e64380ead0d29b99eecff346c297dcdc43be9acd65987711d5c2962c497',
  'src/consumer.rs':'3dc409b86be0aeafed632d7d3e4a5c02b32aca07171877613f7da096f9858563',
  'src/net.rs':'df239f20fdc4e3240defa78e632faa50c09dc69876478581e061d5c68722bb38',
  'Cargo.toml':'98b437d0dab4d8289a9fd097f9f7a8c4b6e227c505584eb1ea22e0c8bc28f389',
  'Cargo.lock':'bdc37c48feb0d7a17a1b08e70c5301ec30b9a90e64c93adaf28aef6b6f9f46bc',
  'scripts/ci-broker-compatibility.sh':'5802854a8c31993bd69679d0cdd33dc4ef921a60c5a7e7c4be699744d9c2f2ac',
  'scripts/ci-broker-smoke.sh':'344c083e94c7dffc46d48a12e32c729c5685f93af22fd4f1cab6bd2179cd0f76',
 },
 'observed_jobs':[
  {'job_id':125774457011,'kafka':'4.3.1','decoded_reencoded_log_sha256':'ad5e8ddaaa8f37bcc98d01b5cf6c9f8e7d1d6e210db22c43bf6c4e4bfc9568fe'},
  {'job_id':125774457154,'kafka':'4.2.1','decoded_reencoded_log_sha256':'6b538cca30d661b7e9c8dcc80a70cc95ca023c150e4e29033e959306ec5eb2d4'},
  {'job_id':125774457229,'kafka':'4.1.2','decoded_reencoded_log_sha256':'521f7f6bb9a6280d6fc09c65c6f7c254097d1a24b340e886511693edd43350f9'}],
 'observed':'All three logs print classic join before live_compatibility_required stack overflow and SIGABRT; no stack trace or last RPC is reported.',
 'experiments':{
  'caller_box':'test-only group-loop future box; not a production fix',
  'library_box':'private rejoin_once future box; one added allocation per rejoin attempt; unmeasured',
  'future_sizes':'ignored unpolled future state-size diagnostic in an explicitly 8 MiB diagnostic thread; exact invocation documented',
  'phase_trace':'instrumented library stderr checkpoints; not the original binary',
  'prior_mock':'previous two-MiB mock lifecycle test, which passed on other v16 source, not current live reproduction',
  'elf_probe':'raw selected prologues and symbol evidence only; not run here'},
 'validation':['Commit source pins and connector-decoded log markers verified.',
  'Experiment/diagnostic sparse patches roundtrip and compose in an isolated directory.',
  'Source-only rustfmt checks pass, including skip_children for isolated group.rs.',
  'Pure-Python ELF header controls accept little-endian x86_64 executables and reject invalid, truncated, non-executable and other-architecture headers.',
  'Pure-Python synthetic changed-hash controls reject mutation across header validation and inspection; fake binutils only.',
  'The original 150-second, 20-second and three-second timeout text is unchanged in both experiments.'],
 'limitations':['No Cargo, compiler, native tests, new stack measurements, Kafka runs or benchmarks.',
  'No exact current compiled call frame, live stack allocation size, or proof of which operation overflowed.',
  'All expected experiment results remain unobserved; phase tracing and future-size probes perturb codegen.',
  'The 8 MiB test thread is diagnostic only and is not an accepted replacement for a normal-stack gate.',
  'ELF header and inspections use separate opens; matching hashes cannot exclude replace-and-restore races. Use a private quiescent snapshot.',
  'No production fix, release readiness or fastest-performance qualification is claimed.'],
 'files':files,
 'variant_sources':{
  str(p.relative_to(root)):sha(p) for p in sorted(root.glob('*/**/*.rs'))
 }
}
(here/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
