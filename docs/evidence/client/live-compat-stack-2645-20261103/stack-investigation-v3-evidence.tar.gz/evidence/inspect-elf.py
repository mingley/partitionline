#!/usr/bin/env python3
"""Retain selected x86_64 debug ELF symbols/prologues; no frame-size claim."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import stat
import subprocess


def require_x86_64_elf_header(header):
    """Require an ELF64 little-endian EM_X86_64 header without running the file."""
    if (len(header) < 64 or header[:4] != b'\x7fELF' or header[4] != 2
            or header[5] != 1 or header[6] != 1
            or int.from_bytes(header[16:18], 'little') not in (2, 3)
            or int.from_bytes(header[18:20], 'little') != 62):
        raise ValueError('expected an ELF64 little-endian x86_64 executable or PIE')


def run(cmd, timeout=120):
    return subprocess.run(cmd, check=True, capture_output=True, timeout=timeout).stdout


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('elf', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    elf = args.elf.resolve(strict=True)
    if args.elf.is_symlink() or not stat.S_ISREG(elf.stat().st_mode):
        raise SystemExit('expected a regular non-symlink ELF')
    original_sha = sha(elf)
    with elf.open('rb') as stream:
        require_x86_64_elf_header(stream.read(64))
    if sha(elf) != original_sha:
        raise SystemExit('ELF changed while validating its header')
    if args.output.exists():
        raise SystemExit('output must not already exist')
    args.output.mkdir(parents=True)
    tool_versions = {
        name: run([name, '--version']).decode('utf-8', 'replace').splitlines()[0]
        for name in ('nm', 'objdump')
    }
    symbols = run(['nm', '-S', '-C', '--defined-only', str(elf)])
    if len(symbols) > 64 * 1024 * 1024:
        raise SystemExit('symbol list exceeds diagnostic bound')
    (args.output/'nm.txt').write_bytes(symbols)
    needles = ('broker_compatibility::run', 'broker_compatibility::join_group',
               'ConsumerGroup>::join_with_protocol_list', 'ConsumerGroup>::rejoin_within',
               'ConsumerGroup>::rejoin_once', 'ConsumerGroup>::assign_committed')
    selected = []
    for line in symbols.decode('utf-8', 'replace').splitlines():
        match = re.match(r'^([0-9a-fA-F]+)\s+([0-9a-fA-F]+)\s+\S\s+(.+)$', line)
        if not match:
            continue
        addr, size, name = int(match.group(1), 16), int(match.group(2), 16), match.group(3)
        if size and any(needle in name for needle in needles):
            selected.append({'address':addr, 'symbol_size':size, 'name':name})
    if len(selected) > 256:
        raise SystemExit('too many diagnostic symbols')
    for index, row in enumerate(selected):
        end = row['address'] + min(row['symbol_size'], 192)
        command = ['objdump', '-d', '-C', '--start-address='+hex(row['address']),
                   '--stop-address='+hex(end), str(elf)]
        data = run(command)
        path = args.output/f'prologue-{index:03}.txt'
        path.write_bytes(data)
        row.update(file=path.name, sha256=hashlib.sha256(data).hexdigest())
    final_sha = sha(elf)
    if final_sha != original_sha:
        raise SystemExit('ELF changed during inspection')
    report = {'elf':str(elf), 'elf_bytes':elf.stat().st_size, 'elf_sha256':original_sha,
              'elf_header':'ELF64 little-endian EM_X86_64 executable or PIE', 'tool_versions':tool_versions,
              'nm_sha256':hashlib.sha256(symbols).hexdigest(), 'symbols':selected,
              'missing_needles':[needle for needle in needles if not any(needle in row['name'] for row in selected)],
              'scope':'Raw prologues only. Future state sizes and prologues do not establish maximum stack use or the crashing call chain.'}
    (args.output/'report.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({'selected':len(selected),'missing':report['missing_needles'],'elf_sha256':report['elf_sha256']}))


if __name__ == '__main__':
    main()
