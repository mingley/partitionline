use super::tests::queued;
use super::*;
use std::task::Poll;
use tokio::io::AsyncReadExt;

const PREPARING_COUNT: usize = 8 * 1024 + 1;

enum Topology {
    One,
    TwoPartitions,
    TwoTopics,
    ManyPartitions,
}

#[derive(Debug)]
struct CleanupSnapshot {
    buffered_bytes: u64,
    sticky_records: usize,
    live_workers: usize,
    retries_out: usize,
}
type CleanupSnapshots = Arc<parking_lot::Mutex<Vec<CleanupSnapshot>>>;

struct PreparationFixture {
    worker: Worker,
    handle: WorkerHandle,
    shared: Arc<Shared>,
    outcomes: Vec<oneshot::Receiver<Result<RecordMetadata>>>,
    errors: Arc<AtomicUsize>,
    acks: Arc<AtomicUsize>,
    peer: tokio::net::TcpStream,
    _meta_peer: tokio::net::TcpStream,
    retry_rx: mpsc::Receiver<Pending>,
    cleanup_snapshots: CleanupSnapshots,
}

async fn preparation_fixture(
    topology: Topology,
    sticky: bool,
    transactional: bool,
) -> PreparationFixture {
    preparation_fixture_with_settings(topology, sticky, transactional, PREPARING_COUNT, None).await
}

async fn preparation_fixture_with_settings(
    topology: Topology,
    sticky: bool,
    transactional: bool,
    batch_records: usize,
    linger: Option<Duration>,
) -> PreparationFixture {
    struct ObserveErrors {
        errors: Arc<AtomicUsize>,
        acks: Arc<AtomicUsize>,
        shared: Arc<parking_lot::Mutex<std::sync::Weak<Shared>>>,
        snapshots: CleanupSnapshots,
    }
    impl ObserveErrors {
        fn snapshot(&self) {
            if let Some(shared) = self.shared.lock().upgrade() {
                let records = shared
                    .sticky_records
                    .as_ref()
                    .map_or(0, |records| records.used.load(Ordering::Acquire));
                self.snapshots.lock().push(CleanupSnapshot {
                    buffered_bytes: shared.buffered_bytes.load(Ordering::SeqCst),
                    sticky_records: records,
                    live_workers: shared.live_workers.load(Ordering::SeqCst),
                    retries_out: shared.retries_out.load(Ordering::SeqCst),
                });
            }
        }
    }
    impl crate::interceptor::ProducerInterceptor for ObserveErrors {
        fn on_error(&self, _error: &Error) {
            let _ = self.errors.fetch_add(1, Ordering::SeqCst);
            self.snapshot();
        }
        fn on_ack(&self, _metadata: &RecordMetadata) {
            let _ = self.acks.fetch_add(1, Ordering::SeqCst);
            self.snapshot();
        }
    }
    let errors = Arc::new(AtomicUsize::new(0));
    let acks = Arc::new(AtomicUsize::new(0));
    let observed_shared = Arc::new(parking_lot::Mutex::new(std::sync::Weak::new()));
    let cleanup_snapshots = Arc::new(parking_lot::Mutex::new(Vec::new()));
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap().to_string();
    let meta = BrokerConn::connect(&addr, "prepare-owner-meta", Duration::from_secs(1))
        .await
        .unwrap();
    let (meta_peer, _) = listener.accept().await.unwrap();
    let conn = BrokerConn::connect(&addr, "prepare-owner-worker", Duration::from_secs(1))
        .await
        .unwrap();
    let (peer, _) = listener.accept().await.unwrap();
    let mut cfg = ProducerConfig::default().interceptor(ObserveErrors {
        errors: Arc::clone(&errors),
        acks: Arc::clone(&acks),
        shared: Arc::clone(&observed_shared),
        snapshots: Arc::clone(&cleanup_snapshots),
    });
    cfg.batch_records = batch_records;
    cfg.batch_bytes = 1024 * 1024;
    if let Some(linger) = linger {
        cfg.linger = linger;
    }
    if sticky {
        cfg = cfg.partitioner(crate::partitioner::StickyPartitioner::new());
    }
    if transactional {
        cfg.transactional_id = Some("prepare-owner-transaction".to_owned());
    }
    let mut shared = test_shared(cfg, meta);
    let (retry_tx, retry_rx) = mpsc::channel(PREPARING_COUNT + 1);
    Arc::get_mut(&mut shared).unwrap().retry_tx = retry_tx;
    *observed_shared.lock() = Arc::downgrade(&shared);
    let (data, data_rx) = mpsc::channel(PREPARING_COUNT);
    let (ctrl, ctrl_rx) = mpsc::channel(1);
    let id = Arc::new(());
    let admission = Arc::new(WorkerAdmission::for_producer(Arc::clone(&shared.closed)));
    let mut worker = Worker {
        id: Arc::clone(&id),
        admission: Arc::clone(&admission),
        node_id: 1,
        throttle: shared.broker_throttle(1),
        conn,
        data: data_rx,
        ctrl: ctrl_rx,
        shared: Arc::clone(&shared),
        write_buf: BytesMut::new(),
        pending: Vec::new(),
        spare_batch: Vec::new(),
        preparing: Default::default(),
        completing: Default::default(),
        splitting: Default::default(),
        response_active: false,
        responding: None,
        response_groups: Default::default(),
        response_current: None,
        pending_estimate: 0,
        earliest_deadline: None,
        pending_deadlines_ordered: true,
        pending_stats_valid: true,
        #[cfg(test)]
        pending_work: Arc::new(PendingWork::default()),
        in_flight: VecDeque::new(),
        fail: None,
        compress_scratch: CompressScratch::default(),
        group_scratch: ProduceGroupScratch::default(),
        ack_index: AckIndex::default(),
        ack_slots: Vec::new(),
        spare_acks: Vec::new(),
        ack_requested: HashMap::new(),
        ack_seen: HashMap::new(),
        ack_tracker: None,
        _live: WorkerLease::register(&shared),
    };
    let handle = WorkerHandle::new(
        id,
        admission,
        data,
        ctrl,
        Arc::new(tokio::spawn(std::future::pending::<()>())),
    );
    let names = [Arc::<str>::from("orders"), Arc::<str>::from("payments")];
    let mut outcomes = Vec::with_capacity(PREPARING_COUNT);
    for index in 0..PREPARING_COUNT {
        let partition = match topology {
            Topology::TwoPartitions => i32::try_from(index % 2).unwrap(),
            Topology::ManyPartitions => i32::try_from(index).unwrap(),
            _ => 0,
        };
        let mut pending = queued("orders", Some(partition));
        pending.rec.topic =
            Arc::clone(&names[usize::from(matches!(topology, Topology::TwoTopics)) * (index % 2)]);
        pending.rec.value = Some(Bytes::from_static(b"x"));
        pending.rec.timestamp = Some(i64::try_from(index).unwrap());
        pending.deadline = Instant::now() + Duration::from_secs(30);
        pending.sticky_record = shared
            .sticky_records
            .as_ref()
            .map(|budget| budget.acquire().unwrap());
        let (result, outcome) = oneshot::channel();
        pending.tx = Some(result);
        assert!(handle.try_send(pending).is_ok());
        outcomes.push(outcome);
    }
    shared
        .buffered_bytes
        .store(u64::try_from(PREPARING_COUNT).unwrap(), Ordering::SeqCst);
    worker.pull_ready();
    PreparationFixture {
        worker,
        handle,
        shared,
        outcomes,
        errors,
        acks,
        peer,
        _meta_peer: meta_peer,
        retry_rx,
        cleanup_snapshots,
    }
}

impl PreparationFixture {
    fn begin(&mut self) {
        let batch = self.worker.take_all_pending();
        self.worker.preparing.begin(batch);
    }

    async fn group(&mut self) {
        self.begin();
        prepare::group_pending(&mut self.worker.preparing, &mut self.worker.group_scratch).await;
    }

    async fn finish(self) {
        self.finish_with_timeout(false).await;
    }

    async fn finish_with_timeout(self, timeout: bool) {
        let Self {
            worker,
            handle,
            shared,
            mut outcomes,
            errors,
            acks: _acks,
            mut peer,
            _meta_peer,
            retry_rx: _retry_rx,
            cleanup_snapshots,
        } = self;
        assert_eq!(
            worker.preparing.retained_records(&worker.group_scratch) + worker.pending.len(),
            PREPARING_COUNT
        );
        assert_eq!(
            shared.buffered_bytes.load(Ordering::SeqCst),
            u64::try_from(PREPARING_COUNT).unwrap()
        );
        assert_eq!(errors.load(Ordering::SeqCst), 0);
        assert!(outcomes
            .iter_mut()
            .all(|outcome| matches!(outcome.try_recv(), Err(oneshot::error::TryRecvError::Empty))));
        shared.closed.store(true, Ordering::SeqCst);
        drop(worker);
        for outcome in outcomes {
            let outcome = outcome.await;
            assert!(if timeout {
                matches!(outcome, Ok(Err(Error::Timeout)))
            } else {
                matches!(outcome, Ok(Err(Error::Closed)))
            });
        }
        if timeout {
            let snapshots = cleanup_snapshots.lock();
            assert_eq!(snapshots.len(), PREPARING_COUNT);
            assert!(snapshots.iter().all(|snapshot| snapshot.buffered_bytes == 0
                && snapshot.sticky_records > 0
                && snapshot.live_workers > 0));
            assert_eq!(
                snapshots.first().map(|snapshot| snapshot.sticky_records),
                Some(PREPARING_COUNT)
            );
            assert_eq!(
                snapshots.last().map(|snapshot| snapshot.sticky_records),
                Some(1)
            );
        }
        assert_eq!(shared.buffered_bytes.load(Ordering::SeqCst), 0);
        assert_eq!(
            shared.m_errors.load(Ordering::SeqCst),
            u64::try_from(PREPARING_COUNT).unwrap()
        );
        assert_eq!(errors.load(Ordering::SeqCst), PREPARING_COUNT);
        assert_eq!(shared.live_workers.load(Ordering::SeqCst), 0);
        assert_eq!(shared.retries_out.load(Ordering::SeqCst), 0);
        if let Some(records) = &shared.sticky_records {
            assert_eq!(records.used.load(Ordering::Acquire), 0);
        }
        let mut byte = [0];
        assert_eq!(
            tokio::time::timeout(Duration::from_secs(1), peer.read(&mut byte))
                .await
                .expect("cancelled preparation retained the worker socket")
                .unwrap(),
            0
        );
        drop(handle);
        drop(_meta_peer);
    }
}

async fn poll_preparation<F: Future + ?Sized>(mut future: Pin<&mut F>) -> Poll<F::Output> {
    std::future::poll_fn(|cx| Poll::Ready(future.as_mut().poll(cx))).await
}

struct RunningCleanup {
    handle: WorkerHandle,
    shared: Arc<Shared>,
    outcomes: Vec<oneshot::Receiver<Result<RecordMetadata>>>,
    errors: Arc<AtomicUsize>,
    acks: Arc<AtomicUsize>,
    peer: tokio::net::TcpStream,
}

async fn finish_running_worker<F: Future<Output = ()>>(
    running: Pin<Box<F>>,
    cleanup: RunningCleanup,
    completed_timeout: Option<usize>,
) {
    let RunningCleanup {
        handle,
        shared,
        mut outcomes,
        errors,
        acks,
        mut peer,
    } = cleanup;
    let completed = usize::from(completed_timeout.is_some());
    assert!(completed_timeout.is_none_or(|index| index < outcomes.len()));
    for (index, outcome) in outcomes.iter_mut().enumerate() {
        if completed_timeout != Some(index) {
            assert!(matches!(
                outcome.try_recv(),
                Err(oneshot::error::TryRecvError::Empty)
            ));
        }
    }
    assert_eq!(
        shared.buffered_bytes.load(Ordering::SeqCst),
        u64::try_from(PREPARING_COUNT - completed).unwrap()
    );
    assert_eq!(errors.load(Ordering::SeqCst), completed);
    assert_eq!(acks.load(Ordering::SeqCst), 0);
    shared.closed.store(true, Ordering::SeqCst);
    drop(running);
    for (index, outcome) in outcomes.into_iter().enumerate() {
        if completed_timeout != Some(index) {
            assert!(matches!(outcome.await, Ok(Err(Error::Closed))));
        }
    }
    assert_eq!(shared.buffered_bytes.load(Ordering::SeqCst), 0);
    assert_eq!(
        shared.m_errors.load(Ordering::SeqCst),
        u64::try_from(PREPARING_COUNT).unwrap()
    );
    assert_eq!(errors.load(Ordering::SeqCst), PREPARING_COUNT);
    assert_eq!(acks.load(Ordering::SeqCst), 0);
    assert_eq!(shared.live_workers.load(Ordering::SeqCst), 0);
    assert_eq!(shared.retries_out.load(Ordering::SeqCst), 0);
    if let Some(records) = &shared.sticky_records {
        assert_eq!(records.used.load(Ordering::Acquire), 0);
    }
    let mut byte = [0];
    assert_eq!(
        tokio::time::timeout(Duration::from_secs(1), peer.read(&mut byte))
            .await
            .expect("cancelled run retained the worker socket")
            .unwrap(),
        0
    );
    drop(handle);
}

async fn interrupt_accounting_with_tail_deadline(
    worker: &mut Worker,
    old_deadline: Instant,
    tail_deadline: Instant,
) {
    let mut accepted = worker.take_all_pending();
    assert_eq!(accepted.len(), PREPARING_COUNT);
    let mut first = accepted.remove(0);
    first.deadline = old_deadline;
    for record in &mut accepted {
        record.deadline = old_deadline;
    }
    accepted.last_mut().unwrap().deadline = tail_deadline;
    worker.push_pending(first);
    let from = worker.pending.len();
    worker.pending.extend(accepted);
    let previous_valid = worker.invalidate_pending_stats();
    let mut accounting = Box::pin(worker.account_pending_from(from, previous_valid));
    assert!(poll_preparation(accounting.as_mut()).await.is_pending());
    drop(accounting);
    assert!(!worker.pending_stats_valid);
    assert_eq!(worker.earliest_deadline, Some(old_deadline));
}

#[tokio::test(flavor = "current_thread")]
async fn actual_worker_run_recv_many_cancellation_keeps_all_accepted_records() {
    let fixture = preparation_fixture(Topology::One, false, false).await;
    let PreparationFixture {
        mut worker,
        handle,
        shared,
        outcomes,
        errors,
        acks,
        peer,
        _meta_peer,
        retry_rx: _retry_rx,
        cleanup_snapshots: _cleanup_snapshots,
    } = fixture;
    let accepted = worker.take_all_pending();
    assert_eq!(accepted.len(), PREPARING_COUNT);
    let trace = Arc::clone(&worker.pending_work);
    let mut running = Box::pin(worker.run());

    // Park the real worker in its empty-channel select before enqueuing.
    assert!(poll_preparation(running.as_mut()).await.is_pending());
    assert!(trace.main_wait.lock().is_some());
    for record in accepted {
        assert!(handle.try_send(record).is_ok());
    }
    for _ in 0..8 {
        assert!(poll_preparation(running.as_mut()).await.is_pending());
        if trace.main_account_started.load(Ordering::SeqCst) == PREPARING_COUNT {
            break;
        }
    }
    assert_eq!(
        trace.main_account_started.load(Ordering::SeqCst),
        PREPARING_COUNT
    );
    assert!(trace.main_account_invalid.load(Ordering::SeqCst));
    assert_eq!(trace.main_account_finished.load(Ordering::SeqCst), 0);
    finish_running_worker(
        running,
        RunningCleanup {
            handle,
            shared,
            outcomes,
            errors,
            acks,
            peer,
        },
        None,
    )
    .await;
    drop(_meta_peer);
}

#[tokio::test(flavor = "current_thread")]
async fn worker_run_repairs_invalid_accounting_before_arming_deadline_timer() {
    let fixture = preparation_fixture_with_settings(
        Topology::One,
        false,
        false,
        PREPARING_COUNT + 1,
        Some(Duration::from_secs(120)),
    )
    .await;
    let PreparationFixture {
        mut worker,
        handle,
        shared,
        outcomes,
        errors,
        acks,
        peer,
        _meta_peer,
        retry_rx: _retry_rx,
        cleanup_snapshots: _cleanup_snapshots,
    } = fixture;
    let start = Instant::now();
    let old_deadline = start + Duration::from_secs(180);
    let actual_deadline = start + Duration::from_secs(60);
    interrupt_accounting_with_tail_deadline(&mut worker, old_deadline, actual_deadline).await;
    assert!(worker.pending.iter().map(estimate).sum::<usize>() < shared.cfg.produce_batch_bytes());

    // An interrupted internal accounting future is resumed here only as a test
    // fixture; aborting the real Worker::run drops the Worker.
    let trace = Arc::clone(&worker.pending_work);
    let mut running = Box::pin(worker.run());
    for _ in 0..12 {
        assert!(poll_preparation(running.as_mut()).await.is_pending());
        if trace.main_wait.lock().is_some() {
            break;
        }
    }
    let observation = (*trace.main_wait.lock()).expect("worker never reached its wait");
    assert!(observation.valid);
    assert_eq!(observation.earliest, Some(actual_deadline));
    assert!(observation.observed_at < actual_deadline);
    assert_eq!(
        observation.wake_delay,
        Some(actual_deadline.saturating_duration_since(observation.observed_at))
    );
    assert_eq!(trace.main_invalid_selects.load(Ordering::Relaxed), 0);
    finish_running_worker(
        running,
        RunningCleanup {
            handle,
            shared,
            outcomes,
            errors,
            acks,
            peer,
        },
        None,
    )
    .await;
    drop(_meta_peer);
}

#[tokio::test(flavor = "current_thread")]
async fn worker_run_expires_record_hidden_by_interrupted_accounting() {
    let fixture = preparation_fixture_with_settings(
        Topology::One,
        false,
        false,
        PREPARING_COUNT + 1,
        Some(Duration::from_secs(120)),
    )
    .await;
    let PreparationFixture {
        mut worker,
        handle,
        shared,
        mut outcomes,
        errors,
        acks,
        peer,
        _meta_peer,
        retry_rx: _retry_rx,
        cleanup_snapshots: _cleanup_snapshots,
    } = fixture;
    let now = Instant::now();
    let old_deadline = now + Duration::from_secs(180);
    interrupt_accounting_with_tail_deadline(&mut worker, old_deadline, now).await;
    let trace = Arc::clone(&worker.pending_work);
    let mut running = Box::pin(worker.run());
    let mut result = None;
    for _ in 0..16 {
        assert!(poll_preparation(running.as_mut()).await.is_pending());
        match outcomes.last_mut().unwrap().try_recv() {
            Ok(value) => {
                result = Some(value);
                break;
            }
            Err(oneshot::error::TryRecvError::Empty) => {}
            Err(error) => panic!("expired outcome channel unexpectedly closed: {error}"),
        }
    }
    assert!(matches!(result, Some(Err(Error::Timeout))));
    assert_eq!(trace.main_invalid_selects.load(Ordering::Relaxed), 0);
    finish_running_worker(
        running,
        RunningCleanup {
            handle,
            shared,
            outcomes,
            errors,
            acks,
            peer,
        },
        Some(PREPARING_COUNT - 1),
    )
    .await;
    drop(_meta_peer);
}

#[tokio::test(flavor = "current_thread")]
async fn sticky_wait_repairs_invalid_accounting_before_choosing_timer() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    fixture.tag_sticky(false);
    let tag = fixture.worker.pending.first().unwrap().sticky.unwrap();
    assert_ne!(tag.id, 0);
    assert_eq!(
        fixture.shared.sticky.as_ref().unwrap().lock().members(tag),
        PREPARING_COUNT
    );
    assert!(fixture
        .worker
        .pending
        .iter()
        .all(|record| record.sticky.is_some_and(|member| member.id == tag.id)));

    let start = Instant::now();
    let old_deadline = start + Duration::from_secs(180);
    let actual_deadline = start + Duration::from_secs(60);
    interrupt_accounting_with_tail_deadline(&mut fixture.worker, old_deadline, actual_deadline)
        .await;

    // One cohort member is owned by another worker phase, so the remaining
    // queued cohort cannot be drained and must enter its sticky wait.
    let in_flight_phase = fixture.worker.pending.remove(0);
    fixture.worker.preparing.begin(vec![in_flight_phase]);
    let trace = Arc::clone(&fixture.worker.pending_work);
    let mut taking = Box::pin(fixture.worker.take_sticky_batch());
    for _ in 0..16 {
        assert!(poll_preparation(taking.as_mut()).await.is_pending());
        if trace.sticky_wait.lock().is_some() {
            break;
        }
    }
    let observation = (*trace.sticky_wait.lock()).expect("sticky worker never reached its wait");
    assert!(observation.valid);
    assert_eq!(observation.earliest, Some(actual_deadline));
    assert_eq!(observation.wake_delay, Duration::from_millis(10));
    assert_eq!(trace.sticky_invalid_selects.load(Ordering::Relaxed), 0);
    drop(taking);
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_fire_grouping_retains_actual_accepted_records() {
    // The future deadline fast path skips both expiry scans. Poll the real
    // size scan, drain accounting, and grouping classification yield. No
    // test-only gate replaces admission, grouping or Worker::drop.
    let mut fixture = preparation_fixture(Topology::One, false, false).await;
    let mut fire = Box::pin(fixture.worker.fire());
    for _ in 0..3 {
        assert!(poll_preparation(fire.as_mut()).await.is_pending());
    }
    drop(fire);
    assert!(fixture.worker.pending.is_empty());
    assert_eq!(
        fixture
            .worker
            .preparing
            .retained_records(&fixture.worker.group_scratch),
        PREPARING_COUNT
    );
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn future_deadlines_without_sticky_skip_the_expiry_walk() {
    let mut fixture = preparation_fixture(Topology::One, false, false).await;
    let future = Instant::now() + Duration::from_secs(3600);
    for record in &mut fixture.worker.pending {
        record.deadline = future;
    }
    fixture.worker.recompute_pending_estimate().await;
    assert_eq!(fixture.worker.earliest_deadline, Some(future));
    let now = Instant::now();
    let found = {
        let mut search = Box::pin(fixture.worker.first_expired_pending(now));
        poll_preparation(search.as_mut()).await
    };
    // The previous full scan yielded after 8192 of these 8193 records.
    assert_eq!(found, Poll::Ready(None));
    assert_eq!(
        fixture
            .worker
            .pending_work
            .expiry_record_checks
            .load(Ordering::Relaxed),
        0
    );
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn ordered_deadlines_drain_without_rescanning_the_suffix() {
    let mut fixture = preparation_fixture(Topology::One, false, false).await;
    let start = Instant::now() + Duration::from_secs(3600);
    for (index, record) in fixture.worker.pending.iter_mut().enumerate() {
        // Equal leading deadlines must not be mistaken for disorder.
        record.deadline =
            start + Duration::from_micros(u64::try_from(index.saturating_sub(1)).unwrap());
    }
    fixture.worker.recompute_pending_estimate().await;
    assert!(fixture.worker.pending_deadlines_ordered);
    let expected_next = fixture.worker.pending.get(1).unwrap().deadline;
    let expected_total = fixture.worker.pending_estimate;
    let batch = {
        let mut draining = Box::pin(fixture.worker.drain_pending(1));
        match poll_preparation(draining.as_mut()).await {
            Poll::Ready(batch) => batch,
            Poll::Pending => panic!("ordered one-record drain scanned the suffix"),
        }
    };
    assert_eq!(batch.len(), 1);
    assert_eq!(fixture.worker.earliest_deadline, Some(expected_next));
    assert_eq!(
        fixture.worker.pending_estimate,
        expected_total.saturating_sub(estimate(&batch[0]))
    );
    assert_eq!(fixture.worker.pending.len(), PREPARING_COUNT - 1);
    assert_eq!(
        fixture
            .worker
            .pending_work
            .deadline_rescan_records
            .load(Ordering::Relaxed),
        0
    );
    fixture.worker.preparing.begin(batch);
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn ordered_queue_repeated_drains_do_not_walk_expiry_or_deadline_suffixes() {
    let mut fixture = preparation_fixture(Topology::One, false, false).await;
    let start = Instant::now() + Duration::from_secs(3600);
    for (index, record) in fixture.worker.pending.iter_mut().enumerate() {
        record.deadline = start + Duration::from_micros(u64::try_from(index).unwrap());
    }
    fixture.worker.recompute_pending_estimate().await;
    let now = Instant::now();
    let mut drained = Vec::new();
    for index in 0..64usize {
        assert_eq!(fixture.worker.first_expired_pending(now).await, None);
        let mut batch = fixture.worker.drain_pending(1).await;
        assert_eq!(batch.len(), 1);
        assert_eq!(
            batch.first().unwrap().rec.timestamp,
            Some(i64::try_from(index).unwrap())
        );
        drained.append(&mut batch);
        fixture.worker.park_batch(batch);
    }
    assert_eq!(
        fixture
            .worker
            .pending_work
            .expiry_record_checks
            .load(Ordering::Relaxed),
        0
    );
    assert_eq!(
        fixture
            .worker
            .pending_work
            .deadline_rescan_records
            .load(Ordering::Relaxed),
        0
    );
    assert_eq!(
        fixture.worker.earliest_deadline,
        Some(start + Duration::from_micros(64))
    );
    fixture.worker.preparing.begin(drained);
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn unordered_deadlines_keep_the_cooperative_minimum_scan() {
    let mut fixture = preparation_fixture(Topology::One, false, false).await;
    let start = Instant::now() + Duration::from_secs(3600);
    for record in &mut fixture.worker.pending {
        record.deadline = start + Duration::from_secs(30);
    }
    fixture.worker.pending.first_mut().unwrap().deadline = start;
    fixture.worker.pending.last_mut().unwrap().deadline = start + Duration::from_secs(1);
    fixture.worker.recompute_pending_estimate().await;
    assert!(!fixture.worker.pending_deadlines_ordered);
    let batch = {
        let mut draining = Box::pin(fixture.worker.drain_pending(1));
        assert!(poll_preparation(draining.as_mut()).await.is_pending());
        draining.await
    };
    assert_eq!(batch.len(), 1);
    assert_eq!(
        fixture.worker.earliest_deadline,
        Some(start + Duration::from_secs(1))
    );
    assert_eq!(
        fixture
            .worker
            .pending_work
            .deadline_rescan_records
            .load(Ordering::Relaxed),
        PREPARING_COUNT - 1
    );
    fixture.worker.preparing.begin(batch);
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn appended_older_deadline_disables_ordered_fast_path() {
    let mut fixture = preparation_fixture(Topology::One, false, false).await;
    let mut accepted = fixture.worker.take_all_pending();
    let mut older = accepted.pop().unwrap();
    let deadline = Instant::now();
    older.deadline = deadline;
    for record in accepted {
        fixture.worker.push_pending(record);
    }
    let from = fixture.worker.pending.len();
    // Mirror recv_many: append before the cooperative accounting phase.
    fixture.worker.pending.push(older);
    let previous_valid = fixture.worker.invalidate_pending_stats();
    fixture
        .worker
        .account_pending_from(from, previous_valid)
        .await;
    assert!(!fixture.worker.pending_deadlines_ordered);
    assert_eq!(fixture.worker.earliest_deadline, Some(deadline));
    assert_eq!(
        fixture.worker.first_expired_pending(deadline).await,
        Some(PREPARING_COUNT - 1)
    );
    assert_eq!(
        fixture
            .worker
            .pending_work
            .expiry_record_checks
            .load(Ordering::Relaxed),
        PREPARING_COUNT
    );
    let mut accepted = fixture.worker.take_all_pending();
    let older = accepted.pop().unwrap();
    for record in accepted {
        fixture.worker.push_pending(record);
    }
    fixture.worker.push_pending(older);
    assert!(!fixture.worker.pending_deadlines_ordered);
    assert_eq!(fixture.worker.earliest_deadline, Some(deadline));
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_append_accounting_cannot_hide_an_earlier_deadline() {
    let mut fixture = preparation_fixture(Topology::One, false, false).await;
    let mut accepted = fixture.worker.take_all_pending();
    let mut first = accepted.remove(0);
    first.deadline = Instant::now() + Duration::from_secs(3600);
    fixture.worker.push_pending(first);
    let expired = Instant::now();
    accepted.last_mut().unwrap().deadline = expired;
    let from = fixture.worker.pending.len();
    fixture.worker.pending.extend(accepted);
    let previous_valid = fixture.worker.invalidate_pending_stats();
    let mut accounting = Box::pin(fixture.worker.account_pending_from(from, previous_valid));
    assert!(poll_preparation(accounting.as_mut()).await.is_pending());
    drop(accounting);

    assert!(!fixture.worker.pending_stats_valid);
    assert!(!fixture.worker.queued_batch_ready().await);
    assert!(!fixture.worker.can_fire(None).await);
    assert!(fixture.worker.earliest_pending_deadline().unwrap() <= Instant::now());
    assert_eq!(
        fixture.worker.first_expired_pending(expired).await,
        Some(PREPARING_COUNT - 1)
    );
    assert_eq!(
        fixture
            .worker
            .pending_work
            .expiry_record_checks
            .load(Ordering::Relaxed),
        PREPARING_COUNT
    );
    fixture.worker.recompute_pending_estimate().await;
    assert!(fixture.worker.pending_stats_valid);
    assert_eq!(fixture.worker.earliest_deadline, Some(expired));
    assert!(!fixture.worker.pending_deadlines_ordered);
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_sticky_classification_invalidates_stats_until_cleanup() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    let mut requeue = Box::pin(fixture.worker.requeue_displaced_sticky());
    assert!(poll_preparation(requeue.as_mut()).await.is_pending());
    drop(requeue);
    assert!(!fixture.worker.pending_stats_valid);
    assert_eq!(fixture.worker.pending.len(), PREPARING_COUNT);
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn unchanged_sticky_classification_preserves_valid_stats() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    fixture.worker.requeue_displaced_sticky().await;
    assert!(fixture.worker.pending_stats_valid);
    assert_eq!(fixture.worker.pending.len(), PREPARING_COUNT);
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_sticky_member_is_found_before_its_future_deadline() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    fixture.tag_sticky(false);
    let tag = fixture.worker.pending.first().unwrap().sticky.unwrap();
    assert_ne!(tag.id, 0);
    fixture.shared.sticky.as_ref().unwrap().lock().cancel(tag);
    let now = Instant::now();
    assert!(fixture.worker.earliest_deadline.unwrap() > now);
    assert_eq!(fixture.worker.first_expired_pending(now).await, Some(0));
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_preparation_classification_keeps_payloads_in_worker() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    fixture.begin();
    let mut grouping = Box::pin(prepare::group_pending(
        &mut fixture.worker.preparing,
        &mut fixture.worker.group_scratch,
    ));
    assert!(poll_preparation(grouping.as_mut()).await.is_pending());
    drop(grouping);
    assert_eq!(fixture.worker.preparing.records().len(), PREPARING_COUNT);
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_one_topic_distribution_keeps_group_prefix_and_source_suffix() {
    let mut fixture = preparation_fixture(Topology::TwoPartitions, true, false).await;
    fixture.begin();
    let mut grouping = Box::pin(prepare::group_pending(
        &mut fixture.worker.preparing,
        &mut fixture.worker.group_scratch,
    ));
    for _ in 0..3 {
        assert!(poll_preparation(grouping.as_mut()).await.is_pending());
    }
    drop(grouping);
    assert_eq!(fixture.worker.preparing.records().len(), 1);
    assert_eq!(
        fixture
            .worker
            .preparing
            .groups()
            .iter()
            .map(|(_, _, records)| records.len())
            .sum::<usize>(),
        PREPARING_COUNT - 1
    );
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_mixed_distribution_keeps_bucket_prefix_and_source_suffix() {
    let mut fixture = preparation_fixture(Topology::TwoTopics, true, false).await;
    fixture.begin();
    let mut grouping = Box::pin(prepare::group_pending(
        &mut fixture.worker.preparing,
        &mut fixture.worker.group_scratch,
    ));
    for _ in 0..2 {
        assert!(poll_preparation(grouping.as_mut()).await.is_pending());
    }
    drop(grouping);
    assert_eq!(fixture.worker.preparing.records().len(), 1);
    assert_eq!(
        fixture
            .worker
            .group_scratch
            .buckets
            .values()
            .flat_map(|parts| &parts.order)
            .map(|(_, records)| records.len())
            .sum::<usize>(),
        PREPARING_COUNT - 1
    );
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_mixed_assembly_keeps_the_current_partition_cursor() {
    let mut fixture = preparation_fixture(Topology::ManyPartitions, true, false).await;
    let batch = fixture.worker.take_all_pending();
    let topic = Arc::<str>::from("orders");
    let parts = batch
        .into_iter()
        .map(|record| (record.rec.partition.unwrap(), vec![record]))
        .collect::<Vec<_>>();
    let slots = parts
        .iter()
        .enumerate()
        .map(|(index, (partition, _))| (*partition, index))
        .collect();
    let _ = fixture.worker.group_scratch.buckets.insert(
        Arc::clone(&topic),
        PendingParts {
            order: parts,
            slots,
        },
    );
    let mut assembly = Box::pin(prepare::assemble_mixed_groups(
        &mut fixture.worker.preparing,
        &mut fixture.worker.group_scratch,
        vec![topic],
    ));
    assert!(poll_preparation(assembly.as_mut()).await.is_pending());
    drop(assembly);
    let completed = fixture
        .worker
        .preparing
        .groups()
        .iter()
        .map(|(_, _, records)| records.len())
        .sum::<usize>();
    assert!(completed > 0 && completed < PREPARING_COUNT);
    assert!(fixture.worker.group_scratch.buckets.is_empty());
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_sequence_stamping_keeps_the_partially_stamped_batch() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    fixture.group().await;
    let mut assignment = Box::pin(assign_sequences(
        fixture.worker.preparing.groups_mut(),
        1,
        &fixture.shared.seqs,
        1,
    ));
    for _ in 0..2 {
        assert!(poll_preparation(assignment.as_mut()).await.is_pending());
    }
    drop(assignment);
    assert!(fixture.worker.preparing.groups()[0]
        .2
        .iter()
        .any(|record| record.seq.is_some()));
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_transaction_partition_walk_keeps_accepted_payloads() {
    let mut fixture = preparation_fixture(Topology::ManyPartitions, true, true).await;
    fixture.shared.in_txn.store(true, Ordering::SeqCst);
    fixture.group().await;
    let mut registration = Box::pin(
        fixture
            .worker
            .add_txn_partitions(fixture.worker.preparing.groups()),
    );
    assert!(poll_preparation(registration.as_mut()).await.is_pending());
    drop(registration);
    assert!(!fixture.shared.txn_partitions.lock().is_empty());
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_produce_encoding_keeps_accepted_payloads() {
    let mut fixture = preparation_fixture(Topology::ManyPartitions, true, false).await;
    fixture.group().await;
    let worker = &mut fixture.worker;
    let mut encoding = Box::pin(encode_produce_body_async(
        &mut worker.write_buf,
        8,
        1,
        1000,
        worker.preparing.groups(),
        &[],
        Compression::None,
        now_ms(),
        RecordBatch::NO_PRODUCER_ID,
        RecordBatch::NO_PRODUCER_EPOCH,
        None,
        &mut worker.compress_scratch,
        &mut worker.group_scratch,
    ));
    assert!(poll_preparation(encoding.as_mut()).await.is_pending());
    drop(encoding);
    fixture.finish().await;
}

#[tokio::test(flavor = "current_thread")]
async fn forward_preparation_cursor_preserves_the_reusable_batch_allocation() {
    let topic = Arc::<str>::from("orders");
    let mut batch = Vec::with_capacity(31);
    for (index, partition) in [3, 1, 3].into_iter().enumerate() {
        let mut record = queued("orders", Some(partition));
        record.rec.topic = Arc::clone(&topic);
        record.rec.timestamp = Some(i64::try_from(index).unwrap());
        batch.push(record);
    }
    let pointer = batch.as_ptr();
    let capacity = batch.capacity();
    let mut state = Preparing::default();
    state.begin(batch);
    let mut scratch = ProduceGroupScratch::default();
    prepare::group_pending(&mut state, &mut scratch).await;
    let empty = state.take_batch();
    assert!(empty.is_empty());
    assert_eq!(empty.as_ptr(), pointer);
    assert_eq!(empty.capacity(), capacity);
    assert_eq!(
        state
            .groups()
            .iter()
            .map(|(_, partition, records)| (
                *partition,
                records
                    .iter()
                    .map(|record| record.rec.timestamp)
                    .collect::<Vec<_>>()
            ))
            .collect::<Vec<_>>(),
        vec![(3, vec![Some(0), Some(2)]), (1, vec![Some(1)])]
    );
}

#[tokio::test(flavor = "current_thread")]
async fn open_worker_cleanup_transfers_prepared_prefix_before_its_partition_suffix() {
    let mut fixture = preparation_fixture(Topology::TwoPartitions, true, false).await;
    fixture.begin();
    let mut grouping = Box::pin(prepare::group_pending(
        &mut fixture.worker.preparing,
        &mut fixture.worker.group_scratch,
    ));
    for _ in 0..3 {
        assert!(poll_preparation(grouping.as_mut()).await.is_pending());
    }
    drop(grouping);
    assert_eq!(fixture.worker.preparing.records().len(), 1);
    let PreparationFixture {
        worker,
        handle,
        shared,
        mut outcomes,
        errors,
        acks: _acks,
        mut peer,
        _meta_peer,
        mut retry_rx,
        cleanup_snapshots: _cleanup_snapshots,
    } = fixture;
    drop(worker);
    assert!(!shared.closed.load(Ordering::SeqCst));
    assert_eq!(shared.live_workers.load(Ordering::SeqCst), 0);
    assert_eq!(shared.retries_out.load(Ordering::SeqCst), PREPARING_COUNT);
    assert_eq!(
        shared.buffered_bytes.load(Ordering::SeqCst),
        u64::try_from(PREPARING_COUNT).unwrap()
    );
    assert_eq!(
        shared
            .sticky_records
            .as_ref()
            .unwrap()
            .used
            .load(Ordering::Acquire),
        PREPARING_COUNT
    );
    assert_eq!(errors.load(Ordering::SeqCst), 0);
    assert!(outcomes
        .iter_mut()
        .all(|outcome| matches!(outcome.try_recv(), Err(oneshot::error::TryRecvError::Empty))));

    let mut retained = Vec::with_capacity(PREPARING_COUNT);
    let mut partitions = [Vec::new(), Vec::new()];
    for _ in 0..PREPARING_COUNT {
        let record = retry_rx
            .try_recv()
            .expect("prepared record was not handed to the retry owner");
        let partition = usize::try_from(record.rec.partition.unwrap()).unwrap();
        partitions[partition].push(record.rec.timestamp.unwrap());
        assert_eq!(record.retry, 1);
        retained.push(record);
    }
    assert!(matches!(
        retry_rx.try_recv(),
        Err(mpsc::error::TryRecvError::Empty)
    ));
    for (partition, actual) in partitions.into_iter().enumerate() {
        let expected = (partition..PREPARING_COUNT)
            .step_by(2)
            .map(|index| i64::try_from(index).unwrap())
            .collect::<Vec<_>>();
        assert_eq!(actual, expected);
    }
    // Return the inspected messages unchanged, without adding another retry
    // count. The real RetryReceiver destructor must then finish every callback
    // and release each count ticket, buffer charge and record permit.
    for record in retained {
        assert!(shared.try_retry(record).is_ok());
    }
    shared.closed.store(true, Ordering::SeqCst);
    drop(RetryReceiver {
        weak: Arc::downgrade(&shared),
        rx: retry_rx,
    });
    for outcome in outcomes {
        assert!(matches!(outcome.await, Ok(Err(Error::Timeout))));
    }
    assert_eq!(shared.retries_out.load(Ordering::SeqCst), 0);
    assert_eq!(shared.buffered_bytes.load(Ordering::SeqCst), 0);
    assert_eq!(
        shared
            .sticky_records
            .as_ref()
            .unwrap()
            .used
            .load(Ordering::Acquire),
        0
    );
    assert_eq!(
        shared.m_errors.load(Ordering::SeqCst),
        u64::try_from(PREPARING_COUNT).unwrap()
    );
    assert_eq!(errors.load(Ordering::SeqCst), PREPARING_COUNT);
    let mut byte = [0];
    assert_eq!(
        tokio::time::timeout(Duration::from_secs(1), peer.read(&mut byte))
            .await
            .expect("retired preparation kept the worker socket")
            .unwrap(),
        0
    );
    drop(handle);
    drop(_meta_peer);
}

#[tokio::test(flavor = "current_thread")]
async fn closed_write_phase_cleanup_times_out_each_first_or_retry_record_once() {
    // This control checks the retained write-phase cleanup state. It does not
    // assert that a socket write happened or prove retirement before replay.
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    fixture.group().await;
    for (index, pending) in fixture.worker.preparing.groups_mut()[0]
        .2
        .iter_mut()
        .enumerate()
    {
        pending.retry = u32::try_from(index % 2).unwrap();
    }
    fixture.worker.preparing.write_started = true;
    fixture.finish_with_timeout(true).await;
}

impl PreparationFixture {
    fn retained(&self) -> usize {
        self.worker.pending.len()
            + self
                .worker
                .preparing
                .retained_records(&self.worker.group_scratch)
            + self.worker.completing.retained_records()
            + self.worker.splitting.retained_selected()
            + self.worker.responding.as_ref().map_or(0, |request| {
                request
                    .groups
                    .iter()
                    .map(|(_, _, records)| records.len())
                    .sum()
            })
            + self.worker.response_groups.retained_records()
            + self
                .worker
                .response_current
                .as_ref()
                .map_or(0, |(_, _, records)| records.len())
            + self
                .worker
                .in_flight
                .iter()
                .flat_map(|request| request.groups.iter())
                .map(|(_, _, records)| records.len())
                .sum::<usize>()
    }

    async fn finish_terminal<F>(self, acked: usize, check: F)
    where
        F: Fn(usize, Result<RecordMetadata>),
    {
        assert_eq!(
            self.retained() + self.errors.load(Ordering::SeqCst) + self.acks.load(Ordering::SeqCst),
            PREPARING_COUNT
        );
        let Self {
            worker,
            handle,
            shared,
            outcomes,
            errors,
            acks,
            mut peer,
            _meta_peer,
            mut retry_rx,
            cleanup_snapshots,
        } = self;
        shared.closed.store(true, Ordering::SeqCst);
        drop(worker);
        assert!(
            retry_rx.try_recv().is_err(),
            "terminal work unexpectedly transferred a record"
        );
        for (index, mut outcome) in outcomes.into_iter().enumerate() {
            check(
                index,
                outcome
                    .try_recv()
                    .expect("accepted record lost its terminal result"),
            );
        }
        assert_eq!(acks.load(Ordering::SeqCst), acked);
        assert_eq!(errors.load(Ordering::SeqCst), PREPARING_COUNT - acked);
        assert_eq!(
            shared.m_acked.load(Ordering::SeqCst),
            u64::try_from(acked).unwrap()
        );
        assert_eq!(
            shared.m_errors.load(Ordering::SeqCst),
            u64::try_from(PREPARING_COUNT - acked).unwrap()
        );
        assert_eq!(
            shared.ack_latency.snapshot().count,
            u64::try_from(acked).unwrap()
        );
        assert_eq!(shared.buffered_bytes.load(Ordering::SeqCst), 0);
        assert_eq!(shared.live_workers.load(Ordering::SeqCst), 0);
        assert_eq!(shared.retries_out.load(Ordering::SeqCst), 0);
        assert_eq!(
            shared
                .sticky_records
                .as_ref()
                .unwrap()
                .used
                .load(Ordering::Acquire),
            0
        );
        {
            let snapshots = cleanup_snapshots.lock();
            assert_eq!(snapshots.len(), PREPARING_COUNT);
            assert!(snapshots
                .iter()
                .all(|snapshot| snapshot.sticky_records > 0 && snapshot.live_workers > 0));
        }
        let mut byte = [0];
        assert_eq!(
            tokio::time::timeout(Duration::from_secs(1), peer.read(&mut byte))
                .await
                .expect("terminal cancellation retained the worker socket")
                .unwrap(),
            0
        );
        drop(handle);
        drop(_meta_peer);
    }

    async fn finish_retried(self) {
        assert_eq!(
            self.retained() + self.shared.retries_out.load(Ordering::SeqCst),
            PREPARING_COUNT
        );
        let Self {
            worker,
            handle,
            shared,
            outcomes,
            errors,
            acks,
            mut peer,
            _meta_peer,
            mut retry_rx,
            cleanup_snapshots: _cleanup_snapshots,
        } = self;
        drop(worker);
        assert_eq!(shared.retries_out.load(Ordering::SeqCst), PREPARING_COUNT);
        assert_eq!(
            shared.buffered_bytes.load(Ordering::SeqCst),
            u64::try_from(PREPARING_COUNT).unwrap()
        );
        assert_eq!(
            shared
                .sticky_records
                .as_ref()
                .unwrap()
                .used
                .load(Ordering::Acquire),
            PREPARING_COUNT
        );
        assert_eq!(errors.load(Ordering::SeqCst), 0);
        assert_eq!(acks.load(Ordering::SeqCst), 0);
        let mut retained = Vec::with_capacity(PREPARING_COUNT);
        let mut retry_after = None;
        for index in 0..PREPARING_COUNT {
            let record = retry_rx
                .try_recv()
                .expect("accepted record lost its retry owner");
            assert_eq!(record.rec.timestamp, Some(i64::try_from(index).unwrap()));
            assert_eq!(record.retry, 1);
            assert_eq!(record.skip_meta_refresh, index > 0);
            if let Some(first) = retry_after {
                assert_eq!(record.retry_after, first);
            } else {
                retry_after = Some(record.retry_after);
            }
            retained.push(record);
        }
        assert!(retry_rx.try_recv().is_err());
        for record in retained {
            assert!(shared.try_retry(record).is_ok());
        }
        shared.closed.store(true, Ordering::SeqCst);
        drop(RetryReceiver {
            weak: Arc::downgrade(&shared),
            rx: retry_rx,
        });
        for mut outcome in outcomes {
            assert!(matches!(outcome.try_recv(), Ok(Err(Error::Timeout))));
        }
        assert_eq!(errors.load(Ordering::SeqCst), PREPARING_COUNT);
        assert_eq!(shared.buffered_bytes.load(Ordering::SeqCst), 0);
        assert_eq!(shared.live_workers.load(Ordering::SeqCst), 0);
        assert_eq!(shared.retries_out.load(Ordering::SeqCst), 0);
        assert_eq!(
            shared
                .sticky_records
                .as_ref()
                .unwrap()
                .used
                .load(Ordering::Acquire),
            0
        );
        let mut byte = [0];
        assert_eq!(
            tokio::time::timeout(Duration::from_secs(1), peer.read(&mut byte))
                .await
                .expect("retry cancellation retained the worker socket")
                .unwrap(),
            0
        );
        drop(handle);
        drop(_meta_peer);
    }

    fn install_response(&mut self, correlation: i32, version: i16) {
        self.worker.response_active = true;
        self.worker.responding = Some(InFlight {
            correlation,
            version,
            topic_ids: ProduceTopicIds::Empty,
            groups: self.worker.preparing.take_groups(),
        });
    }

    fn acks(&self, error_code: i16) -> Vec<ProduceAck> {
        self.worker
            .responding
            .as_ref()
            .unwrap()
            .groups
            .iter()
            .map(|(topic, part, _)| ProduceAck {
                topic: Bytes::copy_from_slice(topic.as_bytes()),
                topic_id: [0; 16],
                partition: *part,
                error_code,
                base_offset: 100,
                log_append_time_ms: RecordBatch::NO_TIMESTAMP,
                current_leader_id: MetadataResponse::NO_LEADER_ID,
                current_leader_epoch: RecordBatch::NO_PARTITION_LEADER_EPOCH,
            })
            .collect()
    }

    fn tag_sticky(&mut self, distinct: bool) {
        let mut cluster = self.shared.cluster.lock();
        let _ = cluster.leaders.insert(Arc::from("orders"), vec![1, 1]);
        let mut policy = self.shared.sticky.as_ref().unwrap().lock();
        for (index, record) in self.worker.pending.iter_mut().enumerate() {
            let part = i32::try_from(usize::from(distinct) * (index % 2)).unwrap();
            let plan = policy.plan(&record.rec.topic, part, &self.worker.id, 1, &cluster);
            record.sticky = Some(plan.tag);
            policy.commit(
                &record.rec.topic,
                part,
                &self.worker.id,
                true,
                plan,
                &cluster,
            );
        }
    }
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_failure_size_walk_keeps_accepted_batch() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    let batch = fixture.worker.take_all_pending();
    let mut failing = Box::pin(fixture.worker.fail_kept_batch(batch, Error::QueueFull));
    assert!(poll_preparation(failing.as_mut()).await.is_pending());
    drop(failing);
    assert_eq!(
        fixture.worker.completing.retained_records(),
        PREPARING_COUNT
    );
    assert_eq!(
        fixture.shared.buffered_bytes.load(Ordering::SeqCst),
        u64::try_from(PREPARING_COUNT).unwrap()
    );
    fixture
        .finish_terminal(0, |_, result| {
            assert!(matches!(result, Err(Error::QueueFull)))
        })
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_failure_callback_walk_finishes_retained_suffix_once() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    let batch = fixture.worker.take_all_pending();
    let mut failing = Box::pin(fixture.worker.fail_kept_batch(batch, Error::QueueFull));
    for _ in 0..3 {
        assert!(poll_preparation(failing.as_mut()).await.is_pending());
    }
    drop(failing);
    assert_eq!(fixture.errors.load(Ordering::SeqCst), PREPARING_COUNT - 1);
    assert_eq!(fixture.worker.completing.retained_records(), 1);
    assert_eq!(fixture.shared.buffered_bytes.load(Ordering::SeqCst), 0);
    assert!(fixture
        .cleanup_snapshots
        .lock()
        .iter()
        .all(|snapshot| snapshot.buffered_bytes == 0));
    fixture
        .finish_terminal(0, |_, result| {
            assert!(matches!(result, Err(Error::QueueFull)))
        })
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_failure_group_walk_keeps_remaining_groups() {
    let mut fixture = preparation_fixture(Topology::TwoPartitions, true, false).await;
    fixture.group().await;
    let groups = fixture.worker.preparing.take_groups();
    let mut failing = Box::pin(fixture.worker.fail_kept_groups(groups, Error::QueueFull));
    for _ in 0..2 {
        assert!(poll_preparation(failing.as_mut()).await.is_pending());
    }
    drop(failing);
    assert_eq!(
        fixture.errors.load(Ordering::SeqCst),
        PREPARING_COUNT.div_ceil(2)
    );
    assert_eq!(
        fixture.worker.completing.retained_records(),
        PREPARING_COUNT / 2
    );
    fixture
        .finish_terminal(0, |_, result| {
            assert!(matches!(result, Err(Error::QueueFull)))
        })
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_ack_latency_walk_preserves_metadata_and_byte_charge() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    let batch = fixture.worker.take_all_pending();
    let mut acking = Box::pin(fixture.worker.complete_acked_batch(
        Arc::from("orders"),
        0,
        100,
        RecordBatch::NO_TIMESTAMP,
        batch,
    ));
    for _ in 0..3 {
        assert!(poll_preparation(acking.as_mut()).await.is_pending());
    }
    drop(acking);
    assert_eq!(fixture.acks.load(Ordering::SeqCst), 0);
    assert_eq!(
        fixture.worker.completing.retained_records(),
        PREPARING_COUNT
    );
    assert_eq!(fixture.shared.buffered_bytes.load(Ordering::SeqCst), 0);
    fixture
        .finish_terminal(PREPARING_COUNT, |index, result| {
            let result = result.unwrap();
            assert_eq!(result.offset, 100 + i64::try_from(index).unwrap());
            assert_eq!(result.timestamp, i64::try_from(index).unwrap());
        })
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_ack_callback_walk_finishes_original_offset_suffix() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    let batch = fixture.worker.take_all_pending();
    let mut acking =
        Box::pin(
            fixture
                .worker
                .complete_acked_batch(Arc::from("orders"), 0, 100, 42, batch),
        );
    for _ in 0..4 {
        assert!(poll_preparation(acking.as_mut()).await.is_pending());
    }
    drop(acking);
    assert_eq!(fixture.acks.load(Ordering::SeqCst), PREPARING_COUNT - 1);
    assert_eq!(fixture.worker.completing.retained_records(), 1);
    assert!(fixture
        .cleanup_snapshots
        .lock()
        .iter()
        .all(|snapshot| snapshot.buffered_bytes == 0));
    fixture
        .finish_terminal(PREPARING_COUNT, |index, result| {
            let result = result.unwrap();
            assert_eq!(result.offset, 100 + i64::try_from(index).unwrap());
            assert_eq!(result.timestamp, 42);
        })
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_zero_ack_group_walk_keeps_accepted_records() {
    let mut fixture = preparation_fixture(Topology::TwoPartitions, true, false).await;
    fixture.group().await;
    let groups = fixture.worker.preparing.take_groups();
    let mut acking = Box::pin(fixture.worker.complete_zero_ack_groups(groups));
    for _ in 0..2 {
        assert!(poll_preparation(acking.as_mut()).await.is_pending());
    }
    drop(acking);
    assert_eq!(
        fixture.acks.load(Ordering::SeqCst),
        PREPARING_COUNT.div_ceil(2)
    );
    fixture
        .finish_terminal(PREPARING_COUNT, |index, result| {
            let result = result.unwrap();
            assert_eq!(result.offset, RecordMetadata::INVALID_OFFSET);
            assert_eq!(result.timestamp, i64::try_from(index).unwrap());
        })
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_retry_sticky_sealing_keeps_accepted_batch() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    let batch = fixture.worker.take_all_pending();
    let mut retrying = Box::pin(fixture.worker.requeue_pendings(batch));
    assert!(poll_preparation(retrying.as_mut()).await.is_pending());
    drop(retrying);
    assert_eq!(
        fixture.worker.completing.retained_records(),
        PREPARING_COUNT
    );
    fixture.finish_retried().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_retry_transfer_keeps_original_suffix_and_backoff() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    let batch = fixture.worker.take_all_pending();
    let mut retrying = Box::pin(fixture.worker.requeue_pendings(batch));
    for _ in 0..5 {
        assert!(poll_preparation(retrying.as_mut()).await.is_pending());
    }
    drop(retrying);
    assert_eq!(
        fixture.shared.retries_out.load(Ordering::SeqCst),
        PREPARING_COUNT - 1
    );
    assert_eq!(fixture.worker.completing.retained_records(), 1);
    fixture.finish_retried().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_retry_topic_index_keeps_accepted_batch() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    let batch = fixture.worker.take_all_pending();
    let mut retrying = Box::pin(fixture.worker.requeue_pendings(batch));
    for _ in 0..3 {
        assert!(poll_preparation(retrying.as_mut()).await.is_pending());
    }
    drop(retrying);
    assert_eq!(
        fixture.worker.completing.retained_records(),
        PREPARING_COUNT
    );
    assert_eq!(fixture.shared.retries_out.load(Ordering::SeqCst), 0);
    fixture.finish_retried().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_expiry_classification_keeps_accepted_records() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    let expired = Instant::now();
    for (index, record) in fixture.worker.pending.iter_mut().enumerate() {
        if index % 2 == 0 {
            record.deadline = expired;
        }
    }
    let mut purging = Box::pin(fixture.worker.purge_expired_pending());
    assert!(poll_preparation(purging.as_mut()).await.is_pending());
    drop(purging);
    assert_eq!(fixture.worker.pending.len(), PREPARING_COUNT);
    assert_eq!(fixture.worker.completing.retained_records(), 0);
    fixture
        .finish_terminal(0, |_, result| assert!(matches!(result, Err(Error::Closed))))
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_pending_permutation_restores_original_order_before_retry() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    let mut splitting = Box::pin(fixture.worker.splitting.partition(
        &mut fixture.worker.pending,
        0,
        |record| record.rec.timestamp.is_some_and(|index| index % 2 == 0),
    ));
    for _ in 0..4 {
        assert!(poll_preparation(splitting.as_mut()).await.is_pending());
    }
    drop(splitting);
    assert_eq!(fixture.worker.pending.len(), PREPARING_COUNT);
    assert!(fixture
        .worker
        .pending
        .iter()
        .enumerate()
        .any(|(index, record)| record.rec.timestamp != Some(i64::try_from(index).unwrap())));
    fixture.finish_retried().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_expiry_after_selection_keeps_failure_disposition() {
    // Walk every suspension of the actual expiry path. This includes the
    // selected-record owner while retained-queue accounting is suspended.
    let mut saw_published_failure = false;
    let mut finished = false;
    for polls in 1..=16 {
        let mut fixture = preparation_fixture(Topology::One, true, false).await;
        fixture.worker.pending.first_mut().unwrap().deadline = Instant::now();
        let mut purging = Box::pin(fixture.worker.purge_expired_pending());
        let mut ready = false;
        for _ in 0..polls {
            if poll_preparation(purging.as_mut()).await.is_ready() {
                ready = true;
                break;
            }
        }
        drop(purging);
        let published = fixture.worker.completing.retained_records() > 0
            || fixture.errors.load(Ordering::SeqCst) > 0;
        saw_published_failure |= fixture.worker.completing.retained_records() == 1;
        assert_eq!(
            fixture.retained() + fixture.errors.load(Ordering::SeqCst),
            PREPARING_COUNT
        );
        fixture
            .finish_terminal(0, |index, result| {
                if index == 0 && published {
                    assert!(matches!(result, Err(Error::Timeout)));
                } else {
                    assert!(matches!(result, Err(Error::Closed)));
                }
            })
            .await;
        if ready {
            finished = true;
            break;
        }
    }
    assert!(
        saw_published_failure,
        "expiry never retained its selected terminal batch"
    );
    assert!(
        finished,
        "expiry did not finish within its bounded source walk"
    );
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_sticky_singleton_accounting_keeps_the_drained_record() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    fixture.worker.pending.first_mut().unwrap().sticky = Some(StickyTag {
        id: 0,
        index: 0,
        identity: None,
    });
    let mut taking = Box::pin(fixture.worker.take_sticky_batch());
    for _ in 0..3 {
        assert!(poll_preparation(taking.as_mut()).await.is_pending());
    }
    drop(taking);
    assert_eq!(fixture.worker.splitting.retained_selected(), 1);
    assert_eq!(fixture.worker.pending.len(), PREPARING_COUNT - 1);
    fixture
        .finish_terminal(0, |_, result| assert!(matches!(result, Err(Error::Closed))))
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_sticky_group_partition_keeps_accepted_payloads() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    fixture.tag_sticky(false);
    let mut taking = Box::pin(fixture.worker.take_sticky_batch());
    for _ in 0..4 {
        assert!(poll_preparation(taking.as_mut()).await.is_pending());
    }
    drop(taking);
    assert_eq!(fixture.retained(), PREPARING_COUNT);
    fixture
        .finish_terminal(0, |_, result| assert!(matches!(result, Err(Error::Closed))))
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_sticky_group_accounting_keeps_selected_payloads() {
    let mut saw_selected = false;
    let mut finished = false;
    for polls in 1..=18 {
        let mut fixture = preparation_fixture(Topology::One, true, false).await;
        {
            let mut cluster = fixture.shared.cluster.lock();
            let _ = cluster.leaders.insert(Arc::from("orders"), vec![1]);
            let mut policy = fixture.shared.sticky.as_ref().unwrap().lock();
            let first = fixture.worker.pending.first_mut().unwrap();
            let plan = policy.plan(&first.rec.topic, 0, &fixture.worker.id, 1, &cluster);
            first.sticky = Some(plan.tag);
            policy.commit(
                &first.rec.topic,
                0,
                &fixture.worker.id,
                true,
                plan,
                &cluster,
            );
        }
        let mut taking = Box::pin(fixture.worker.take_sticky_batch());
        let mut returned = None;
        for _ in 0..polls {
            if let Poll::Ready(batch) = poll_preparation(taking.as_mut()).await {
                returned = Some(batch);
                break;
            }
        }
        drop(taking);
        saw_selected |= fixture.worker.splitting.retained_selected() == 1;
        if let Some(batch) = returned {
            assert_eq!(batch.len(), 1);
            fixture.worker.preparing.begin(batch);
            finished = true;
        }
        assert_eq!(fixture.retained(), PREPARING_COUNT);
        fixture
            .finish_terminal(0, |_, result| assert!(matches!(result, Err(Error::Closed))))
            .await;
        if finished {
            break;
        }
    }
    assert!(
        saw_selected,
        "sticky extraction never retained its selected batch during accounting"
    );
    assert!(
        finished,
        "sticky extraction did not finish within its bounded source walk"
    );
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_sticky_displacement_keeps_the_retry_batch() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    fixture.tag_sticky(false);
    {
        let tag = fixture.worker.pending.first().unwrap().sticky.unwrap();
        fixture
            .shared
            .sticky
            .as_ref()
            .unwrap()
            .lock()
            .rebind(tag, &Arc::new(()));
    }
    let mut displacing = Box::pin(fixture.worker.requeue_displaced_sticky());
    for _ in 0..2 {
        assert!(poll_preparation(displacing.as_mut()).await.is_pending());
    }
    drop(displacing);
    assert_eq!(
        fixture.worker.completing.retained_records(),
        PREPARING_COUNT
    );
    fixture.finish_retried().await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_response_endpoint_walk_keeps_decoded_request() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    fixture.group().await;
    fixture.install_response(7, 3);
    let acks = fixture.acks(0);
    let endpoints = (0..PREPARING_COUNT)
        .map(|index| {
            crate::protocol::api::NodeEndpoint::new(
                i32::try_from(index).unwrap(),
                "localhost",
                9092,
                None,
            )
        })
        .collect();
    let mut responding = Box::pin(fixture.worker.finish_response(acks, endpoints, 3));
    assert!(poll_preparation(responding.as_mut()).await.is_pending());
    drop(responding);
    assert!(fixture.worker.responding.is_some());
    assert_eq!(fixture.retained(), PREPARING_COUNT);
    fixture
        .finish_terminal(0, |_, result| {
            assert!(matches!(result, Err(Error::Timeout)))
        })
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_response_index_walk_keeps_decoded_request() {
    let mut fixture = preparation_fixture(Topology::ManyPartitions, true, false).await;
    fixture.group().await;
    fixture.install_response(7, 3);
    let acks = fixture.acks(0);
    let mut responding = Box::pin(fixture.worker.finish_response(acks, Vec::new(), 3));
    assert!(poll_preparation(responding.as_mut()).await.is_pending());
    drop(responding);
    assert!(fixture.worker.responding.is_some());
    assert_eq!(fixture.retained(), PREPARING_COUNT);
    fixture
        .finish_terminal(0, |_, result| {
            assert!(matches!(result, Err(Error::Timeout)))
        })
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_response_identity_renewal_keeps_current_and_later_groups() {
    let mut fixture = preparation_fixture(Topology::TwoPartitions, true, false).await;
    fixture.group().await;
    fixture.install_response(7, 3);
    let acks = fixture.acks(error::UNKNOWN_PRODUCER_ID);
    fixture.shared.producer_id.store(1, Ordering::SeqCst);
    fixture
        .shared
        .producer_epoch
        .store(i16::MAX, Ordering::SeqCst);
    let shared = Arc::clone(&fixture.shared);
    // The actual metadata mutex makes the real identity renewal suspend.
    let metadata = shared.meta.lock().await;
    let mut responding = Box::pin(fixture.worker.finish_response(acks, Vec::new(), 3));
    assert!(poll_preparation(responding.as_mut()).await.is_pending());
    drop(responding);
    drop(metadata);
    assert_eq!(
        fixture.worker.response_current.as_ref().unwrap().2.len(),
        PREPARING_COUNT.div_ceil(2)
    );
    assert_eq!(
        fixture.worker.response_groups.retained_records(),
        PREPARING_COUNT / 2
    );
    assert_eq!(fixture.retained(), PREPARING_COUNT);
    fixture
        .finish_terminal(0, |_, result| {
            assert!(matches!(result, Err(Error::Timeout)))
        })
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_response_ack_completion_preserves_current_disposition() {
    let mut fixture = preparation_fixture(Topology::TwoPartitions, true, false).await;
    fixture.group().await;
    fixture.install_response(7, 3);
    let acks = fixture.acks(0);
    let mut responding = Box::pin(fixture.worker.finish_response(acks, Vec::new(), 3));
    assert!(poll_preparation(responding.as_mut()).await.is_pending());
    drop(responding);
    assert_eq!(
        fixture.worker.completing.retained_records(),
        PREPARING_COUNT.div_ceil(2)
    );
    assert_eq!(
        fixture.worker.response_groups.retained_records(),
        PREPARING_COUNT / 2
    );
    fixture
        .finish_terminal(PREPARING_COUNT.div_ceil(2), |index, result| {
            if index % 2 == 0 {
                let result = result.unwrap();
                assert_eq!(result.offset, 100 + i64::try_from(index / 2).unwrap());
            } else {
                assert!(matches!(result, Err(Error::Timeout)));
            }
        })
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_wait_one_ack_keeps_decoded_accepted_records() {
    use tokio::io::AsyncWriteExt;
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    fixture.group().await;
    fixture.worker.in_flight.push_back(InFlight {
        correlation: 7,
        version: 3,
        topic_ids: ProduceTopicIds::Empty,
        groups: fixture.worker.preparing.take_groups(),
    });
    let mut body = BytesMut::new();
    body.put_i32(1);
    crate::protocol::buf::put_string(&mut body, false, Some("orders")).unwrap();
    body.put_i32(1);
    body.put_i32(0);
    body.put_i16(0);
    body.put_i64(100);
    body.put_i64(RecordBatch::NO_TIMESTAMP);
    body.put_i32(0);
    let mut frame = BytesMut::new();
    frame.put_i32(i32::try_from(body.len() + 4).unwrap());
    frame.put_i32(7);
    frame.extend_from_slice(&body);
    fixture.peer.write_all(&frame).await.unwrap();
    let shared = Arc::clone(&fixture.shared);
    let mut waiting = Box::pin(fixture.worker.wait_one());
    tokio::time::timeout(
        Duration::from_secs(1),
        std::future::poll_fn(|cx| {
            assert!(waiting.as_mut().poll(cx).is_pending());
            if shared.m_acked.load(Ordering::SeqCst) > 0 {
                Poll::Ready(())
            } else {
                Poll::Pending
            }
        }),
    )
    .await
    .expect("real Produce response never reached its acknowledgement fold");
    drop(waiting);
    assert_eq!(
        fixture.worker.completing.retained_records(),
        PREPARING_COUNT
    );
    fixture
        .finish_terminal(PREPARING_COUNT, |index, result| {
            assert_eq!(result.unwrap().offset, 100 + i64::try_from(index).unwrap());
        })
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn completed_ack_cursor_preserves_the_reusable_batch_allocation() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    let batch = fixture.worker.take_all_pending();
    let pointer = batch.as_ptr();
    let capacity = batch.capacity();
    fixture
        .worker
        .complete_acked_batch(
            Arc::from("orders"),
            0,
            100,
            RecordBatch::NO_TIMESTAMP,
            batch,
        )
        .await;
    assert!(fixture.worker.spare_batch.is_empty());
    assert_eq!(fixture.worker.spare_batch.as_ptr(), pointer);
    assert_eq!(fixture.worker.spare_batch.capacity(), capacity);
    fixture
        .finish_terminal(PREPARING_COUNT, |index, result| {
            assert_eq!(result.unwrap().offset, 100 + i64::try_from(index).unwrap());
        })
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn stable_pending_partition_preserves_order_and_the_kept_allocation() {
    let mut pending = Vec::with_capacity(31);
    for index in 0..7 {
        let mut record = queued("orders", Some(0));
        record.rec.timestamp = Some(index);
        pending.push(record);
    }
    let pointer = pending.as_ptr();
    let capacity = pending.capacity();
    let mut split = split::Split::default();
    split
        .partition(&mut pending, 1, |record| {
            record.rec.timestamp.is_some_and(|index| index % 2 == 0)
        })
        .await;
    let selected = split.take_selected();
    assert_eq!(pending.as_ptr(), pointer);
    assert_eq!(pending.capacity(), capacity);
    assert_eq!(
        pending
            .iter()
            .map(|record| record.rec.timestamp)
            .collect::<Vec<_>>(),
        vec![Some(0), Some(1), Some(3), Some(5)]
    );
    assert_eq!(
        selected
            .iter()
            .map(|record| record.rec.timestamp)
            .collect::<Vec<_>>(),
        vec![Some(2), Some(4), Some(6)]
    );
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_retry_full_queue_keeps_callback_count_until_terminal_release() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    let shared = Arc::clone(&fixture.shared);
    // Reserve capacity without inventing extra accepted records or retry tickets.
    let reserved = shared
        .retry_tx
        .try_reserve_many(shared.retry_tx.capacity())
        .unwrap();
    let batch = fixture.worker.take_all_pending();
    let mut retrying = Box::pin(fixture.worker.requeue_pendings(batch));
    for _ in 0..5 {
        assert!(poll_preparation(retrying.as_mut()).await.is_pending());
    }
    drop(retrying);
    assert_eq!(fixture.errors.load(Ordering::SeqCst), PREPARING_COUNT - 1);
    assert_eq!(fixture.worker.completing.retained_records(), 1);
    assert_eq!(shared.retries_out.load(Ordering::SeqCst), 0);
    assert_eq!(shared.buffered_bytes.load(Ordering::SeqCst), 1);
    assert!(fixture
        .cleanup_snapshots
        .lock()
        .iter()
        .all(|snapshot| snapshot.retries_out == 1));
    fixture
        .finish_terminal(0, |index, result| {
            if index + 1 == PREPARING_COUNT {
                // Cancellation closes admission before finishing the retained suffix.
                assert!(matches!(result, Err(Error::Closed)));
            } else {
                assert!(matches!(result, Err(Error::QueueFull)));
            }
        })
        .await;
    drop(reserved);
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_retry_closed_admission_releases_each_count_after_callback() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    fixture.shared.retry_admission.close();
    let batch = fixture.worker.take_all_pending();
    let mut retrying = Box::pin(fixture.worker.requeue_pendings(batch));
    for _ in 0..5 {
        assert!(poll_preparation(retrying.as_mut()).await.is_pending());
    }
    drop(retrying);
    assert_eq!(fixture.errors.load(Ordering::SeqCst), PREPARING_COUNT - 1);
    assert_eq!(fixture.worker.completing.retained_records(), 1);
    assert_eq!(fixture.shared.retries_out.load(Ordering::SeqCst), 0);
    assert!(fixture
        .cleanup_snapshots
        .lock()
        .iter()
        .all(|snapshot| snapshot.retries_out == 1));
    fixture
        .finish_terminal(0, |_, result| assert!(matches!(result, Err(Error::Closed))))
        .await;
}

#[tokio::test(flavor = "current_thread")]
async fn cancelled_retry_expiry_finishes_suffix_without_retry_tickets() {
    let mut fixture = preparation_fixture(Topology::One, true, false).await;
    let expired = Instant::now();
    for record in &mut fixture.worker.pending {
        record.deadline = expired;
    }
    let batch = fixture.worker.take_all_pending();
    let mut retrying = Box::pin(fixture.worker.requeue_pendings(batch));
    for _ in 0..5 {
        assert!(poll_preparation(retrying.as_mut()).await.is_pending());
    }
    drop(retrying);
    assert_eq!(fixture.errors.load(Ordering::SeqCst), PREPARING_COUNT - 1);
    assert_eq!(fixture.worker.completing.retained_records(), 1);
    assert_eq!(fixture.shared.retries_out.load(Ordering::SeqCst), 0);
    assert_eq!(fixture.shared.buffered_bytes.load(Ordering::SeqCst), 1);
    assert!(fixture
        .cleanup_snapshots
        .lock()
        .iter()
        .all(|snapshot| snapshot.retries_out == 0));
    fixture
        .finish_terminal(0, |_, result| {
            assert!(matches!(result, Err(Error::Timeout)))
        })
        .await;
}

// The producer must see a fatal partition even when another partition came
// first. The public first-error decoder remains a separate compatibility API.
#[tokio::test(flavor = "current_thread")]
async fn add_partitions_fatal_precedence_validates_all_spoken_versions() {
    use crate::protocol::txn::{
        decode_add_partitions_to_txn_response, encode_add_partitions_to_txn_topics_response,
        AddPartitionsToTxnPartitionResult, AddPartitionsToTxnTopicResult,
    };
    let cases = [
        (
            [error::COORDINATOR_LOAD_IN_PROGRESS, error::PRODUCER_FENCED],
            true,
            error::PRODUCER_FENCED,
        ),
        (
            [error::PRODUCER_FENCED, error::COORDINATOR_LOAD_IN_PROGRESS],
            true,
            error::PRODUCER_FENCED,
        ),
        (
            [
                error::TOPIC_AUTHORIZATION_FAILED,
                error::INVALID_PRODUCER_EPOCH,
            ],
            true,
            error::INVALID_PRODUCER_EPOCH,
        ),
        (
            [
                error::COORDINATOR_LOAD_IN_PROGRESS,
                error::UNKNOWN_PRODUCER_ID,
            ],
            false,
            error::UNKNOWN_PRODUCER_ID,
        ),
        (
            [
                error::COORDINATOR_LOAD_IN_PROGRESS,
                error::UNKNOWN_PRODUCER_ID,
            ],
            true,
            error::COORDINATOR_LOAD_IN_PROGRESS,
        ),
        (
            [
                error::CONCURRENT_TRANSACTIONS,
                error::OPERATION_NOT_ATTEMPTED,
            ],
            true,
            error::CONCURRENT_TRANSACTIONS,
        ),
        (
            [
                error::OPERATION_NOT_ATTEMPTED,
                error::CONCURRENT_TRANSACTIONS,
            ],
            true,
            error::OPERATION_NOT_ATTEMPTED,
        ),
        (
            [i16::MAX, error::COORDINATOR_LOAD_IN_PROGRESS],
            true,
            i16::MAX,
        ),
        ([0, error::PRODUCER_FENCED], true, error::PRODUCER_FENCED),
        ([0, 0], true, 0),
    ];
    for version in 0..=3 {
        for (codes, can_handle, expected) in cases {
            let topics: Vec<_> = codes
                .iter()
                .enumerate()
                .map(|(index, code)| AddPartitionsToTxnTopicResult {
                    topic: format!("t{index}"),
                    partitions: vec![AddPartitionsToTxnPartitionResult::error(0, *code)],
                })
                .collect();
            let mut encoded = BytesMut::new();
            encode_add_partitions_to_txn_topics_response(&mut encoded, version, &topics).unwrap();
            let public_first =
                decode_add_partitions_to_txn_response(&mut encoded.as_ref(), version).unwrap();
            assert_eq!(
                public_first,
                codes.iter().copied().find(|code| *code != 0).unwrap_or(0)
            );
            let mut input = encoded.as_ref();
            assert_eq!(
                decode_add_partitions_producer_error(&mut input, version, can_handle, |_| {})
                    .await
                    .unwrap(),
                expected
            );
            assert!(input.is_empty());
            let mut truncated = encoded.clone();
            truncated.truncate(truncated.len().saturating_sub(1));
            assert!(decode_add_partitions_producer_error(
                &mut truncated.as_ref(),
                version,
                can_handle,
                |_| {},
            )
            .await
            .is_err());
            let mut extended = encoded.clone();
            extended.extend_from_slice(&[0]);
            assert!(decode_add_partitions_producer_error(
                &mut extended.as_ref(),
                version,
                can_handle,
                |_| {},
            )
            .await
            .is_err());
        }
    }
}

// A real Worker sends AddPartitionsToTxn over a local TCP connection. The peer
// supplies mixed results and verifies that the fencing error reaches state.
#[tokio::test(flavor = "current_thread")]
async fn mixed_coordinator_error_and_fence_fences_worker_without_rediscovery() {
    use crate::protocol::header::decode_request_header;
    use crate::protocol::txn::{
        decode_add_partitions_to_txn_request, encode_add_partitions_to_txn_topics_response,
        AddPartitionsToTxnPartitionResult, AddPartitionsToTxnTopicResult,
    };
    use tokio::io::AsyncWriteExt;

    for (fenced_first, trailing) in [(false, false), (true, false), (false, true)] {
        tokio::time::timeout(Duration::from_secs(8), async {
            let mut f = preparation_fixture_with_settings(
                Topology::TwoPartitions,
                false,
                true,
                PREPARING_COUNT,
                None,
            )
            .await;
            f.shared.in_txn.store(true, Ordering::SeqCst);
            f.shared.producer_id.store(9, Ordering::SeqCst);
            f.shared.producer_epoch.store(2, Ordering::SeqCst);
            f.worker.conn.set_produce_version(3);
            let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
            let addr = listener.local_addr().unwrap().to_string();
            let conn = BrokerConn::connect(&addr, "add-partitions-test", Duration::from_secs(2))
                .await
                .unwrap();
            let (mut peer, _) = tokio::time::timeout(Duration::from_secs(2), listener.accept())
                .await
                .unwrap()
                .unwrap();
            let versions = ApiVersionsResponse {
                api_keys: vec![ApiVersion {
                    api_key: ADD_PARTITIONS_TO_TXN,
                    min_version: 0,
                    max_version: 0,
                }],
                ..Default::default()
            };
            *f.shared.txn.lock().await = Some(coordinator_connection(conn, &versions));
            let groups = vec![
                (Arc::<str>::from("orders"), 0, Vec::new()),
                (Arc::<str>::from("orders"), 1, Vec::new()),
            ];
            let server = async {
                let mut size = [0u8; 4];
                let _size = peer.read_exact(&mut size).await.unwrap();
                let len = usize::try_from(i32::from_be_bytes(size)).unwrap();
                assert!((8..=4096).contains(&len));
                let mut frame = vec![0u8; len];
                let _frame = peer.read_exact(&mut frame).await.unwrap();
                let mut request = frame.as_slice();
                let header = decode_request_header(&mut request).unwrap();
                assert_eq!(header.api_key, ADD_PARTITIONS_TO_TXN);
                assert_eq!(header.api_version, 0);
                let (tid, pid, epoch, topics) =
                    decode_add_partitions_to_txn_request(&mut request, 0).unwrap();
                assert_eq!(tid, "prepare-owner-transaction");
                assert_eq!((pid, epoch), (9, 2));
                assert!(request.is_empty());
                assert_eq!(topics.len(), 1);
                let topic = topics.first().unwrap();
                assert_eq!(topic.topic, "orders");
                assert_eq!(topic.partitions.len(), 2);
                assert!(topic.partitions.contains(&0) && topic.partitions.contains(&1));
                let errors = if fenced_first {
                    [error::PRODUCER_FENCED, error::COORDINATOR_LOAD_IN_PROGRESS]
                } else {
                    [error::COORDINATOR_LOAD_IN_PROGRESS, error::PRODUCER_FENCED]
                };
                let response = [AddPartitionsToTxnTopicResult {
                    topic: "orders".to_owned(),
                    partitions: errors
                        .iter()
                        .enumerate()
                        .map(|(index, code)| {
                            AddPartitionsToTxnPartitionResult::error(
                                i32::try_from(index).unwrap(),
                                *code,
                            )
                        })
                        .collect(),
                }];
                let mut body = BytesMut::new();
                encode_add_partitions_to_txn_topics_response(&mut body, 0, &response).unwrap();
                if trailing {
                    body.extend_from_slice(&[0]);
                }
                let len = i32::try_from(4 + body.len()).unwrap();
                peer.write_all(&len.to_be_bytes()).await.unwrap();
                peer.write_all(&header.correlation_id.to_be_bytes())
                    .await
                    .unwrap();
                peer.write_all(&body).await.unwrap();
            };
            let (result, ()) = tokio::time::timeout(Duration::from_secs(3), async {
                tokio::join!(f.worker.add_txn_partitions(&groups), server)
            })
            .await
            .expect("add-partitions exchange did not complete");
            let returned = result.unwrap_err();
            if trailing {
                assert!(matches!(returned, Error::Protocol(_)));
                assert!(!f.shared.txn_fatal.load(Ordering::SeqCst));
            } else {
                assert_eq!(returned.broker_code(), Some(error::PRODUCER_FENCED));
                assert!(f.shared.txn_fatal.load(Ordering::SeqCst));
                assert_eq!(
                    f.shared.fail_on_txn_fatal().unwrap_err().broker_code(),
                    Some(error::PRODUCER_FENCED)
                );
            }
            assert!(!f.shared.txn_abort_required.load(Ordering::SeqCst));
            assert!(f.shared.txn_added.lock().is_empty());
            f.shared.closed.store(true, Ordering::SeqCst);
            drop(f);
        })
        .await
        .expect("add-partitions fixture did not finish");
    }
}

// Exercise the existing retry loop through a real Worker and peer. The first
// response remains retriable; the second either succeeds or reports fencing.
#[tokio::test(flavor = "current_thread")]
async fn add_partitions_retry_then_fence_or_success_uses_existing_retry_path() {
    use crate::protocol::header::decode_request_header;
    use crate::protocol::txn::{
        decode_add_partitions_to_txn_request, encode_add_partitions_to_txn_topics_response,
        AddPartitionsToTxnPartitionResult, AddPartitionsToTxnTopicResult,
    };
    use tokio::io::AsyncWriteExt;

    async fn respond(peer: &mut tokio::net::TcpStream, errors: [i16; 2]) -> i32 {
        let mut size = [0u8; 4];
        let _size = peer.read_exact(&mut size).await.unwrap();
        let len = usize::try_from(i32::from_be_bytes(size)).unwrap();
        assert!((8..=4096).contains(&len));
        let mut frame = vec![0u8; len];
        let _frame = peer.read_exact(&mut frame).await.unwrap();
        let mut request = frame.as_slice();
        let header = decode_request_header(&mut request).unwrap();
        assert_eq!(
            (header.api_key, header.api_version),
            (ADD_PARTITIONS_TO_TXN, 0)
        );
        let (tid, pid, epoch, topics) =
            decode_add_partitions_to_txn_request(&mut request, 0).unwrap();
        assert_eq!(tid, "prepare-owner-transaction");
        assert_eq!((pid, epoch), (9, 2));
        assert!(request.is_empty());
        assert_eq!(topics.len(), 1);
        let topic = topics.first().unwrap();
        assert_eq!(topic.topic, "orders");
        assert_eq!(topic.partitions.len(), 2);
        assert!(topic.partitions.contains(&0) && topic.partitions.contains(&1));
        let response = [AddPartitionsToTxnTopicResult {
            topic: "orders".to_owned(),
            partitions: errors
                .iter()
                .enumerate()
                .map(|(index, code)| {
                    AddPartitionsToTxnPartitionResult::error(i32::try_from(index).unwrap(), *code)
                })
                .collect(),
        }];
        let mut body = BytesMut::new();
        encode_add_partitions_to_txn_topics_response(&mut body, 0, &response).unwrap();
        let len = i32::try_from(4 + body.len()).unwrap();
        peer.write_all(&len.to_be_bytes()).await.unwrap();
        peer.write_all(&header.correlation_id.to_be_bytes())
            .await
            .unwrap();
        peer.write_all(&body).await.unwrap();
        header.correlation_id
    }

    for fence in [false, true] {
        tokio::time::timeout(Duration::from_secs(8), async {
            let mut f = preparation_fixture_with_settings(
                Topology::TwoPartitions,
                false,
                true,
                PREPARING_COUNT,
                None,
            )
            .await;
            f.shared.in_txn.store(true, Ordering::SeqCst);
            f.shared.producer_id.store(9, Ordering::SeqCst);
            f.shared.producer_epoch.store(2, Ordering::SeqCst);
            f.worker.conn.set_produce_version(3);
            let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
            let addr = listener.local_addr().unwrap().to_string();
            let conn = BrokerConn::connect(&addr, "add-partitions-retry", Duration::from_secs(2))
                .await
                .unwrap();
            let (mut peer, _) = tokio::time::timeout(Duration::from_secs(2), listener.accept())
                .await
                .unwrap()
                .unwrap();
            let versions = ApiVersionsResponse {
                api_keys: vec![ApiVersion {
                    api_key: ADD_PARTITIONS_TO_TXN,
                    min_version: 0,
                    max_version: 0,
                }],
                ..Default::default()
            };
            *f.shared.txn.lock().await = Some(coordinator_connection(conn, &versions));
            let groups = vec![
                (Arc::<str>::from("orders"), 0, Vec::new()),
                (Arc::<str>::from("orders"), 1, Vec::new()),
            ];
            let server = async {
                let first = respond(
                    &mut peer,
                    [
                        error::CONCURRENT_TRANSACTIONS,
                        error::OPERATION_NOT_ATTEMPTED,
                    ],
                )
                .await;
                let errors = if fence {
                    [error::COORDINATOR_LOAD_IN_PROGRESS, error::PRODUCER_FENCED]
                } else {
                    [0, 0]
                };
                let second = respond(&mut peer, errors).await;
                assert_ne!(first, second);
            };
            let (result, ()) = tokio::time::timeout(Duration::from_secs(3), async {
                tokio::join!(f.worker.add_txn_partitions(&groups), server)
            })
            .await
            .expect("add-partitions retry exchange did not complete");
            if fence {
                assert_eq!(
                    result.unwrap_err().broker_code(),
                    Some(error::PRODUCER_FENCED)
                );
                assert!(f.shared.txn_fatal.load(Ordering::SeqCst));
                assert!(f.shared.txn_added.lock().is_empty());
            } else {
                result.unwrap();
                assert!(!f.shared.txn_fatal.load(Ordering::SeqCst));
                let added = f.shared.txn_added.lock();
                let partitions = added.get("orders").unwrap();
                assert_eq!(partitions.len(), 2);
                assert!(partitions.contains(&0) && partitions.contains(&1));
            }
            f.shared.closed.store(true, Ordering::SeqCst);
            drop(f);
        })
        .await
        .expect("add-partitions retry fixture did not finish");
    }
}

// Once structural decoding has finished, cancelling during the reducer's
// cooperative scan must not erase a fatal code that the scan has observed.
#[tokio::test(flavor = "current_thread")]
async fn cancelled_add_partitions_scan_keeps_observed_fence() {
    use crate::protocol::txn::{
        encode_add_partitions_to_txn_topics_response, AddPartitionsToTxnPartitionResult,
        AddPartitionsToTxnTopicResult,
    };
    tokio::time::timeout(Duration::from_secs(8), async {
        let f =
            preparation_fixture_with_settings(Topology::One, false, true, PREPARING_COUNT, None)
                .await;
        f.shared.in_txn.store(true, Ordering::SeqCst);
        let response = [AddPartitionsToTxnTopicResult {
            topic: "orders".to_owned(),
            partitions: (0..PREPARING_COUNT)
                .map(|index| {
                    let code = if index == 0 {
                        error::PRODUCER_FENCED
                    } else {
                        0
                    };
                    AddPartitionsToTxnPartitionResult::error(i32::try_from(index).unwrap(), code)
                })
                .collect(),
        }];
        let mut encoded = BytesMut::new();
        encode_add_partitions_to_txn_topics_response(&mut encoded, 0, &response).unwrap();
        let mut input = encoded.as_ref();
        let mut decode = Box::pin(decode_add_partitions_and_record_fatal(
            &f.shared, &mut input, 0, false,
        ));
        // The parser yields after 8,192 results, before it can validate the
        // full body. The producer cannot yet publish a decoded fatal result.
        assert!(matches!(
            poll_preparation(decode.as_mut()).await,
            Poll::Pending
        ));
        assert!(!f.shared.txn_fatal.load(Ordering::SeqCst));
        // Parsing finishes; the subsequent scan observes the first fence and
        // then yields at 8,192. Drop it at that actual cooperative boundary.
        assert!(matches!(
            poll_preparation(decode.as_mut()).await,
            Poll::Pending
        ));
        assert!(f.shared.txn_fatal.load(Ordering::SeqCst));
        drop(decode);
        assert_eq!(
            f.shared.fail_on_txn_fatal().unwrap_err().broker_code(),
            Some(error::PRODUCER_FENCED)
        );
        f.shared.closed.store(true, Ordering::SeqCst);
        drop(f);
    })
    .await
    .expect("cancelled add-partitions scan fixture did not finish");
}
