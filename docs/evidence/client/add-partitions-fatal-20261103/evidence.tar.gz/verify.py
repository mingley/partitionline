#!/usr/bin/env python3
import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import tempfile

root = pathlib.Path(__file__).resolve().parent
repo = pathlib.Path('/workspace/partitionline')
paths = ['src/producer.rs', 'src/protocol/txn.rs', 'src/producer/prepare_tests.rs']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for version in ('v16', 'v17'):
    catalog = json.loads((repo / 'docs/evidence/client/candidate-20261030' / version / 'fixed-inputs.json').read_text())
    for path in paths:
        assert sha(root / 'before' / path) == catalog[path], (version, path)
    error_pin = '014c33e7716b004aa22ec46b4b7e0e9e67b54d982b69b8f152ee02eb421d45f2'
    assert catalog['src/error.rs'] == error_pin, (version, 'src/error.rs')
    assert sha(repo / 'src/error.rs') == error_pin, 'checkout src/error.rs'
assert (root/'after/src/producer/prepare_tests.rs').read_bytes().startswith((root/'before/src/producer/prepare_tests.rs').read_bytes())
assert sha(root/'before/src/protocol/txn.rs') == sha(repo/'src/protocol/txn.rs')

with tempfile.TemporaryDirectory(prefix='add-partitions-check-', dir='/workspace/work') as temporary:
    temp = pathlib.Path(temporary)
    for path in paths:
        (temp/path).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(root/'before'/path, temp/path)
    patch = str(root/'candidate.patch')
    subprocess.run(['git', 'apply', '--check', patch], cwd=temp, check=True)
    subprocess.run(['git', 'apply', patch], cwd=temp, check=True)
    assert all(sha(temp/path) == sha(root/'after'/path) for path in paths)
    subprocess.run(['git', 'apply', '--reverse', '--check', patch], cwd=temp, check=True)
    subprocess.run(['git', 'apply', '--reverse', patch], cwd=temp, check=True)
    assert all(sha(temp/path) == sha(root/'before'/path) for path in paths)

# Source-derived numerical model checks the refactored predicate's assumption:
# none of its fatal values, including UNKNOWN_PRODUCER_ID, is retryable.
error_source = (repo/'src/error.rs').read_text()
constants = {name:int(value) for name,value in re.findall(r'pub const ([A-Z][A-Z0-9_]*): i16 = (-?\d+);', error_source)}
match = re.search(r'Self::Broker \{ code, \.\. \} => matches!\(\s*\*code,(.*?)\),\s*Self::Io', error_source, re.S)
assert match
retry_names = re.findall(r'\b[A-Z][A-Z0-9_]+\b', match.group(1))
retry = {constants[name] for name in retry_names}
fatal_names = ['INVALID_PRODUCER_EPOCH', 'PRODUCER_FENCED', 'TRANSACTIONAL_ID_AUTHORIZATION_FAILED', 'INVALID_TXN_STATE', 'INVALID_PRODUCER_ID_MAPPING']
fatal = {constants[name] for name in fatal_names}
unknown = constants['UNKNOWN_PRODUCER_ID']
concurrent = constants['CONCURRENT_TRANSACTIONS']
assert fatal.isdisjoint(retry) and unknown not in retry and concurrent not in fatal and concurrent != unknown
for capable in (False, True):
    for code in range(-32768, 32768):
        old = 'retry' if code == concurrent or code in retry else ('fatal' if code in fatal or (code == unknown and not capable) else 'abort')
        new = 'fatal' if code in fatal or (code == unknown and not capable) else ('retry' if code == concurrent or code in retry else 'abort')
        assert old == new, (code, capable)
print('PASS: v16/v17 pins, original test prefix, patch roundtrip and source-derived full-i16 classifier model')
print('This is not Rust compilation, a native test, broker execution, or a full correctness review.')
