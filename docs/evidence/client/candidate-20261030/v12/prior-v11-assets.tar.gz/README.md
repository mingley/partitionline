# Client candidate v11

V11 adds a producer pending-queue source candidate and a separate JoinGroup
wire-order control to the v10 candidate. It keeps all 169 earlier required
identities and adds 13 producer controls and one group control. The original
two-response cancellation test and the original 450 ms end-to-end Produce
test remain unchanged.

The producer candidate can skip expiry and deadline scans in specific
non-sticky, ordered cases. Vec prefix shifts can still be quadratic;
nonmonotonic deadlines and sticky queues retain scan fallbacks. Arbitrary
resumption of an interrupted split is not qualified. No performance change
has been measured.

The original legacy cancellation test has mixed recorded outcomes and is
observed in baseline runs. The new third-request test is a predicted legacy
negative under the current sequential no-fault path. Neither prediction nor
the new producer controls have run. Independent static reviews, Rustfmt and
source reconstruction passed; Cargo, Clippy and runtime qualification of
this combination remain outstanding.

The v10 run passed 2,280 library tests in each profile and strict format and
Clippy, but failed 15 Mock Produce tests and a retained-backing timeout in each
profile. This candidate is not release, live-Kafka or performance qualification.
The complete v10 assets are retained in this directory.
