# Retained producer preparation

This prepared change moves actual `Worker::fire` payload ownership into a
private worker field while grouping, sequence assignment, transaction
registration, encoding and writes suspend. Grouping borrows that field. The
remaining flat records, completed groups, current mixed-topic partition cursor
and unassembled buckets remain reachable by `Worker::drop` after cancellation.
Cleanup handles older in-flight batches first, then prepared records, then newer
queued records. Open cleanup transfers retained records to the existing retry
owner; closed cleanup returns `Closed` for unsent first attempts and `Timeout`
for retries or a possibly-written request.

Forward cursors use `VecDeque::from(Vec)` and recover the allocation with
`Vec::from(VecDeque)`. This avoids an additional record clone, per-record owner
allocation, reversal pass or repeated front drain. The single-partition path
still moves its original vector directly into the inline group. No performance
comparison or allocation count has been measured for this change. Native
pointer/capacity and ordering controls still need to pass.

All three Rust files parse with latest stable rustfmt, and the compressed/raw
patch hashes plus sequential forward/reverse reconstruction are verified.
Eleven normal controls are prepared, including cancellation of the actual fire
path, partial one-topic/mixed distribution and assembly, sequence stamping,
transaction registration, encoding, reusable allocation, open retry transfer and
closed write-phase callback accounting. An independent static review found no
blocking issue in this scope. No Cargo build or native test ran.

The controls-only baseline adds a dormant holder and fixtures while retaining
the legacy fire, grouping, assembly and worker destructor bodies byte for byte.
Only the actual fire regression is a required baseline negative. Additional
direct-owner tests do not establish an old-code causal failure. The baseline
already includes the earlier drain ownership fix, so that defect cannot explain
the new grouping negative. `spec.json` lists exact cases and method hashes.

This is not complete producer ownership or replay qualification. Sticky batch
partitioning, asynchronous failure/requeue routines, acknowledgement handling
and `acks=0` completion still move accepted records through unprotected futures.
Partial sequence assignment, issue ordering, modular wrap, producer identity
transitions and whole-batch replay remain open. `BrokerConn::close` sets a flag;
it is not a physical socket retirement witness before ambiguous replay. The
write-phase control sets the retained state flag and checks cleanup; it does not
prove an actual write or transport cancellation history. Synchronous cleanup
and a nonempty deque-to-vector suffix move have linear cost. Global memory,
variable-width input work and cancellation latency are not bounded here.

Use `controls-only.patch.gz`, then `fix-only.patch.gz` against the combined
client producer hash in `spec.json`. `complete.patch.gz` gives the same final
three files. Original v1 sources and proof files remain unchanged. The exact
temporary v1 reconstruction view was retained and verified before its directory
was reused for v2 reconstruction; `view-retention.json` records that operation.
