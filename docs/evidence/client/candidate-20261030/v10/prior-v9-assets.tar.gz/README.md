# Client candidate v9

V9 rebases the isolated v8 candidate onto reviewed release-tooling changes.
Five existing release-related files have updated source pins, and the new
registry probe test is included in all three source phases. The Rust patches,
167 required test identities, 22 baseline cases, ten full-target selections and
all runtime budgets are byte-for-byte unchanged from v8.

Exact complete source reconstruction and forward/reverse patch checks passed.
Cargo compilation, Clippy and Rust runtime tests have not run for v9. The
known v7 Mock Produce handshake failures and retained-backing timeout remain
unfixed. Live compatibility, producer ordering and replay, release readiness
and performance qualification remain open. V8 assets are preserved.
